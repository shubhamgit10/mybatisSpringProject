package com.scb.selfservice.workflow.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.domains.IngestionWorkflowResponse;
import com.scb.selfservice.domains.WorkflowProcess;
import com.scb.selfservice.domains.WorkflowRequest;
import com.scb.selfservice.domains.WorkflowRequestStepsNames;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.workflow.service.WorkflowProcessService;
import com.scb.selfservice.workflow.service.WorkflowRequestService;

/**
 * Class for initiating Workflow
 */
@RestController
@RequestMapping("/api")
public class WorkflowContoller {
	private static Logger logger = LogManager.getLogger(WorkflowContoller.class);

	@Autowired
	private WorkflowRequestService workflowRequestService; 
	@Autowired
	WorkflowProcessService workflowProcessService;
	
	@Autowired
	IngestionWorkflowResponse ingestionWorkflowResponse;

	@PostMapping(path="/insertProcessInstanceDetails", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> insertWorkFlowRequest(@RequestBody WorkflowRequest workflowRequest) throws Exception {
		logger.info("STARTED - WorkflowRequestContoller::postInitiation()");

		workflowRequestService.insertWorkFlowRequest(workflowRequest, null);

		logger.info("EXITING - WorkflowRequestContoller::postInitiation()");
		return new ResponseEntity<String> ("Success", HttpStatus.OK);
	}

	@GetMapping (path="/getWorkflowRequestSteps/{reqId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<WorkflowRequestStepsNames>> getWorkflowRequestStepsById(@PathVariable("reqId") int reqId) 
			throws Exception {

		logger.info("STARTED WorkflowProcessController::getWorkflowRequestStepsById");

		List<WorkflowRequestStepsNames>  workflowRequestStepsNames = workflowRequestService.getWorkflowRequestStepsById(reqId, null);

		logger.info("EXITING WorkflowProcessController::getWorkflowRequestStepsById");

		return new ResponseEntity<List<WorkflowRequestStepsNames>>(workflowRequestStepsNames, HttpStatus.OK);
	}

	@GetMapping (path="/getProcessDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	//public ResponseEntity<List<WorkflowProcess>> getWorkflowProcesses() {
	public ResponseEntity<Response> getWorkflowProcesses() {

		logger.info("STARTED WorkflowProcessController::getWorkflowProcesses");
		//List<WorkflowProcess>  details = workflowProcessService.getWorkflowProcessDetails();
		Response details = workflowProcessService.getWorkflowProcessDetails();
		logger.info("EXITING WorkflowProcessController::getWorkflowProcesses");

		return new ResponseEntity<Response>(details, HttpStatus.OK);
	}

	@GetMapping (path="/getProcessDetails/{workflowId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<WorkflowProcess> getWorkflowProcessesById(@PathVariable("workflowId") int workflowId) {

		logger.info("STARTED WorkflowProcessController::getWorkflowProcessesById");
		WorkflowProcess  detail = workflowProcessService.getWorkflowProcessDetailById(workflowId);
		logger.info("EXITING WorkflowProcessController::getWorkflowProcessesById");

		return new ResponseEntity<WorkflowProcess>(detail, HttpStatus.OK);
	}
	
	/*
	 * @GetMapping (path="getIngestionWorkflowSteps/{reqId}", produces =
	 * MediaType.APPLICATION_JSON_VALUE) public
	 * ResponseEntity<IngestionWorkflowResponse>
	 * getIngestionWorkflowSteps(@PathVariable("reqId") Integer requestId) {
	 * ingestionWorkflowResponse =
	 * workflowRequestService.getIngestionWorkFlowSteps(requestId); return new
	 * ResponseEntity<IngestionWorkflowResponse>(ingestionWorkflowResponse,
	 * HttpStatus.OK); }
	 */
}
