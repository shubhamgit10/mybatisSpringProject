package com.scb.selfservice.web.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.http.RangerPolicy;
import com.scb.selfservice.model.ServerResponse;
import com.scb.selfservice.model.RangerPolicy.ConsumptionRangerPolicyModel;
import com.scb.selfservice.model.RangerPolicy.PolicyDetailsResp;
import com.scb.selfservice.model.RangerPolicy.PolicyResp;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyModel;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyRequestTypeEnum;
import com.scb.selfservice.service.RangerPolicyService;

/**
 * 
 * @author 1610601
 *
 */

@RestController
@RequestMapping("/rangerPolicy")
public class RangerPolicyController {
	
	@Autowired
	RangerPolicyService rangerPolicyService;
	
	@Autowired
	RangerPolicy rangerPolicy;
	
	private static Logger logger = LogManager.getLogger(RangerPolicyController.class);
	
//	@PostMapping(path="/createPolicy", produces = MediaType.APPLICATION_JSON_VALUE)
//	public @ResponseBody ResponseEntity createRangerPolicy(@RequestParam("requestId") Long requestId) {
//		//to-do : restrict unauthorized access
////		if(SecurityHelper.isAuthenticatedUser()) {
//			if(null != requestId) {
//				RangerPolicyModel rangerPolicyModel = rangerPolicyService.getRangerPolicyByRequestId(requestId);
//				rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.CREATE_POLICY);
//				ServerResponse resp = rangerPolicy.processRequest(rangerPolicyModel);
//				if(null != resp) {
//					return new ResponseEntity<>(resp, HttpStatus.OK);
//				} else {
//					return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
//				}
//			} else {
//				return new ResponseEntity<> (HttpStatus.BAD_REQUEST);
//			}
////		}
////		return new ResponseEntity<>(HttpStatus.FORBIDDEN);
//	}
	
//	@PutMapping(path="/updatePolicy", produces = MediaType.APPLICATION_JSON_VALUE)
//	public @ResponseBody ResponseEntity updateRangerPolicy(@RequestParam("requestId") Long requestId) {
//		//to-do : restrict unauthorized access
////		if(SecurityHelper.isAuthenticatedUser()) {
//			if(null != requestId) {
//				RangerPolicyModel rangerPolicyModel = rangerPolicyService.getRangerPolicyByRequestId(requestId);
//				rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.UPDATE_POLICY);
//				ServerResponse resp = rangerPolicy.processRequest(rangerPolicyModel);
//				if(null != resp) {
//					return new ResponseEntity<>(resp, HttpStatus.OK);
//				} else {
//					return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
//				}
//			} else {
//				return new ResponseEntity<> (HttpStatus.BAD_REQUEST);
//			}
////		}
////		return new ResponseEntity<>(HttpStatus.FORBIDDEN);
//	}
	
	@GetMapping(path="/getPolicies", produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity getRangerPolicies(@RequestParam("type") String type) {
		//to-do : restrict unauthorized access
//		if(SecurityHelper.isAuthenticatedUser()) {
		RangerPolicyModel rangerPolicyModel = new RangerPolicyModel();
		logger.info("In getRangerPolicies type : " +type);
		if(type == null || type.trim().isEmpty() || type.equalsIgnoreCase("ALL")) {
			logger.info("getRangerPolicies for all");
			rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.GET_POLICIES);
		} else {
			rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.GET_POLICIES_BY_TYPE);
			rangerPolicyModel.setRepositoryType(type);
			logger.info("getRangerPolicies for type : " +type);
		}
		
		ServerResponse resp = rangerPolicy.processRequest(rangerPolicyModel);
		if(null != resp) {
			logger.info("Get policies for type : " +type + ", response status code : " 
					+resp.getStatusCode() + ", Status Message : " +resp.getStatusMessage());
			logger.debug("Got Policies : " + ((PolicyDetailsResp) resp.getOutput()).toString());
			return new ResponseEntity<>(resp, HttpStatus.OK);
		} else {
			logger.error("Error while processing get policies for type : " +type);
			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
		}
//		}
//		return new ResponseEntity<>(HttpStatus.FORBIDDEN);
	}
	
	@GetMapping(path="/getPolicy", produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity getRangerPolicy(@RequestParam("policyId") Long policyId) {
		//to-do : restrict unauthorized access
//		if(SecurityHelper.isAuthenticatedUser()) {
		if(policyId != null) {
			RangerPolicyModel rangerPolicyModel = new RangerPolicyModel();
			rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.GET_POLICY_BY_ID);
			rangerPolicyModel.setPolicyId(policyId);
			ServerResponse resp = rangerPolicy.processRequest(rangerPolicyModel);
			if(null != resp) {
				logger.info("Get policy for policy id : " +policyId + ", response status code : " 
						+resp.getStatusCode() + ", Status Message : " +resp.getStatusMessage());
				if(resp.getStatusCode() == 200) {
					logger.debug("Got Policy : " + ((PolicyResp) resp.getOutput()).toString());
				}
				return new ResponseEntity<>(resp, HttpStatus.OK);
			} else {
				logger.error("Error while processing get policy for policy id : " +policyId);
				return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			return new ResponseEntity<> (HttpStatus.BAD_REQUEST);
		}
//		}
//		return new ResponseEntity<>(HttpStatus.FORBIDDEN);
	}
	
	@DeleteMapping(path="/deletePolicy", produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity deletePolicy(@RequestParam("policyId") Long policyId) {
		//to-do : restrict unauthorized access
//		if(SecurityHelper.isAuthenticatedUser()) {
		if(policyId != null) {
			RangerPolicyModel rangerPolicyModel = new RangerPolicyModel();
			rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.DELETE_POLICY);
			rangerPolicyModel.setPolicyId(policyId);
			ServerResponse resp = rangerPolicy.processRequest(rangerPolicyModel);
			if(null != resp) {
				logger.info("Delete policy for policy id : " +policyId + ", response status code : " 
						+resp.getStatusCode() + ", Status Message : " +resp.getStatusMessage());
				return new ResponseEntity<>(resp, HttpStatus.OK);
			} else {
				logger.error("Error while processing delete policy for policy id : " +policyId);
				return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			return new ResponseEntity<> (HttpStatus.BAD_REQUEST);
		}
//		}
//		return new ResponseEntity<>(HttpStatus.FORBIDDEN);
	}
	
	
	@GetMapping(path="/createOrUpdatePolicy", produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity createOrUpdateRangerPolicy(@RequestParam("requestId") Long requestId, 
			@RequestParam("groupName") String groupName/*, @RequestParam("repoType") RepositoryTypeEnum repoType*/) {
		//to-do : restrict unauthorized access
//		if(SecurityHelper.isAuthenticatedUser()) {
//		logger.info(PropertyConfigurer.getProperty("ranger_policy.username"));
		if(null == requestId) {
			logger.error("Request Id is mandatory" + requestId);
			return new ResponseEntity<> ("Request Id is mandatory", HttpStatus.BAD_REQUEST);
		}
		if(null == groupName || groupName.trim().isEmpty()) {
			logger.error("Group Name is mandatory for the request id : " +requestId +", group name : " +groupName);
			return new ResponseEntity<> ("Group Name is mandatory", HttpStatus.BAD_REQUEST);
		}
//		if(null == repoType) {
//			logger.error("Repository Type is mandatory for the request id : " +requestId +", repository type : " +repoType);
//			return new ResponseEntity<> ("Repository Type is mandatory", HttpStatus.BAD_REQUEST);
//		}
		ServerResponse resp = null;
		ConsumptionRangerPolicyModel consumptionRangerPolicyModel = rangerPolicyService.getRangerPoliciesByRequestId(requestId);
		
		if(null == consumptionRangerPolicyModel) {
			logger.error("Either request details are null or empty for the request id : " +requestId);
			return new ResponseEntity("Either request details are null or empty for the request id : " +requestId, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		logger.debug("consumptionRangerPolicyModel : " +consumptionRangerPolicyModel);
		
		return doCreateOrUpdateRangerPolciy(requestId, groupName, consumptionRangerPolicyModel);
		
//		return processCreateOrUpdateRangerPolicy(requestId, "hive" , groupName, consumptionRangerPolicyModel);
				
//		}
//		return new ResponseEntity<>(HttpStatus.FORBIDDEN);
	}
	
	private ResponseEntity doCreateOrUpdateRangerPolciy(Long requestId, String groupName, 
			ConsumptionRangerPolicyModel consumptionRangerPolicyModel) {
		ServerResponse resp = null;
		String repoType = null;
		
		for(String appName : consumptionRangerPolicyModel.getMetadataDetails().keySet()) {
			for(String country : consumptionRangerPolicyModel.getMetadataDetails().get(appName).keySet()) {
				logger.info("Initiated Ranger Policy Creation for reqId : " 
						+requestId + ", groupName : " +groupName + ", appName : " 
						+appName + ", instance : " +country);
				repoType = "hive";
				resp = doProcessCreateOrUpdateRangerPolicy(requestId, repoType, groupName, 
						country, appName, consumptionRangerPolicyModel.getMetadataDetails().get(appName).get(country));
				if(resp.getStatusCode() == 200) {
					logger.info("Ranger Policy Created for reqId : " 
							+requestId + ", groupName : " +groupName + ", appName : " 
							+appName + ", instance : " +country + ", repoType : " +repoType);
					repoType = "hdfs";
					resp = doProcessCreateOrUpdateRangerPolicy(requestId, repoType, groupName, 
							country, appName, consumptionRangerPolicyModel.getMetadataDetails().get(appName).get(country));
					if(resp.getStatusCode() == 200) {
						logger.info("Ranger Policy Created for reqId : " 
								+requestId + ", groupName : " +groupName + ", appName : " 
								+appName + ", instance : " +country + ", repoType : " +repoType);
					}
				}
				if(resp.getStatusCode() != 200) {
					logger.error("Error while creating Ranger Policy for reqId : " 
							+requestId + ", groupName : " +groupName +", appName : " 
							+appName +", instance : " +country + ", repoType : " +repoType);
					return new ResponseEntity (HttpStatus.resolve(resp.getStatusCode()));
				}
			}
		}
		
		return new ResponseEntity(resp, HttpStatus.OK);
	}
	
	private ServerResponse doProcessCreateOrUpdateRangerPolicy(Long requestId, String repoType, 
			String groupName, String country, String appName, 
			Map<String, Map<String, Set<String>>> dbMetadata) {
		ServerResponse resp = null;
		RangerPolicyModel rangerPolicyModel = new RangerPolicyModel();
		rangerPolicyModel.setRequestId(requestId);
		rangerPolicyModel.setRepositoryType(repoType.toString().toLowerCase());
		rangerPolicyModel.setGroups(groupName);
		rangerPolicyModel.setPolicyName(groupName + "_" + appName.toLowerCase().trim() + "_" + country.toLowerCase().trim());
		rangerPolicyModel.setDescription(groupName + "_" + appName + "_" + country);
		rangerPolicyModel.setAppName(appName);
		rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.GET_POLICIES_BY_TYPE_AND_GROUP_AND_POLICYNAME);
		resp = rangerPolicy.processRequest(rangerPolicyModel);
		if(resp != null) {
			if(resp.getStatusCode() == 200) {
//				HivePolicyRequestModel rangerPolicyModel = new HivePolicyRequestModel();
//				rangerPolicyModel = new RangerPolicyModel();
				PolicyDetailsResp policyDetails = (PolicyDetailsResp) resp.getOutput();
//				PolicyDetailsResp policyDetails = new PolicyDetailsResp();
//				policyDetails.setResultSize(0);
				if(null != policyDetails) {
					if(policyDetails.getResultSize() == 0) {
						logger.info("No policies exist for group : "+groupName +", repository type : " 
								+repoType + ", Policy name : " +rangerPolicyModel.getPolicyName());
						return doPopulateRangerPolicyDetails(requestId, null, rangerPolicyModel.getRepositoryType(), 
								false, dbMetadata, rangerPolicyModel);
					} else {
						List<PolicyResp> policies = policyDetails.getvXPolicies();
						//usually there should be only one policy per groupname and appname and country
						PolicyResp policy = policies.get(policies.size() - 1);
						logger.info("Got policies for group : "+groupName +", repository type : " +repoType);
						logger.debug("Using policy to update : " +policy);
						return doPopulateRangerPolicyDetails(requestId, policy, rangerPolicyModel.getRepositoryType(), 
								true, dbMetadata, rangerPolicyModel);
					}
				} else {
					logger.error("Error while reading policies from server.");
//					return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
					return new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Error while reading policies from server");
				}
			} else {
				logger.error("Fetching policies for type : " + 
						repoType + ", groupName : " +groupName + ", policyName : " + 
						rangerPolicyModel.getPolicyName() +", response status code : " 
						+ resp.getStatusCode() + ", Status Message : " +resp.getStatusMessage());
//				return new ResponseEntity<> (HttpStatus.valueOf(resp.getStatusCode()));
				return resp;
			}
		} else {
			logger.error("Error while fetching policies for type : " 
					+ repoType + ", groupName : " +groupName + ", policyName : " 
					+rangerPolicyModel.getPolicyName());
			return new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Error while fetching policies for type : " 
					+ repoType + ", groupName : " +groupName + ", policyName : " +rangerPolicyModel.getPolicyName());
//			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	private ResponseEntity processCreateOrUpdateRangerPolicy(Long requestId, String repoType, 
			String groupName, ConsumptionRangerPolicyModel consumptionRangerPolicyModel) {
		ServerResponse resp = null;
		RangerPolicyModel rangerPolicyModel = new RangerPolicyModel();
		rangerPolicyModel.setRequestId(requestId);
		rangerPolicyModel.setRepositoryType(repoType.toString().toLowerCase());
		rangerPolicyModel.setGroups(groupName);
		rangerPolicyModel.setPolicyName(groupName);
		rangerPolicyModel.setDescription(groupName);
		rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.GET_POLICIES_BY_TYPE_AND_GROUP);
		resp = rangerPolicy.processRequest(rangerPolicyModel);
		if(resp != null) {
			if(resp.getStatusCode() == 200) {
//				HivePolicyRequestModel rangerPolicyModel = new HivePolicyRequestModel();
//				rangerPolicyModel = new RangerPolicyModel();
				PolicyDetailsResp policyDetails = (PolicyDetailsResp) resp.getOutput();
//				PolicyDetailsResp policyDetails = new PolicyDetailsResp();
//				policyDetails.setResultSize(0);
				if(null != policyDetails) {
					if(policyDetails.getResultSize() == 0) {
						logger.info("No policies exist for group : "+groupName +", repository type : " +repoType);
						return populateRangerPolicyDetails(requestId, null, rangerPolicyModel.getRepositoryType(), false, consumptionRangerPolicyModel, rangerPolicyModel);
					} else {
						List<PolicyResp> policies = policyDetails.getvXPolicies();
						//usually there should be only one policy per groupname
						//if there are more than one policy per groupname, 
						//take the last created policy and update it
						PolicyResp policy = policies.get(policies.size() - 1);
						logger.info("Got policies for group : "+groupName +", repository type : " +repoType);
						logger.debug("Using policy to update : " +policy);
						return populateRangerPolicyDetails(requestId, policy, rangerPolicyModel.getRepositoryType(), true, consumptionRangerPolicyModel, rangerPolicyModel);
					}
				} else {
					logger.error("Error while reading policies from server.");
					return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} else {
				logger.error("Fetching policies for type and group : " + " " + ", response status code : " 
						+resp.getStatusCode() + ", Status Message : " +resp.getStatusMessage());
				return new ResponseEntity<> (HttpStatus.valueOf(resp.getStatusCode()));
			}
		} else {
			logger.error("Error while fetching policies for type and group : " + " " );
			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	private ServerResponse doPopulateRangerPolicyDetails(Long reqId, PolicyResp policy, String repoType, 
			boolean isToUpdatePolicy, Map<String, Map<String, Set<String>>> metadata, RangerPolicyModel rangerPolicyModel) {

//		RangerPolicyModel rangerPolicyModel = new RangerPolicyModel();
//		rangerPolicyModel.setAppName(consumptionRangerPolicyModel.getAppName().toLowerCase());
		ServerResponse resp = null;
		if(isToUpdatePolicy && null != policy) {
			rangerPolicyModel.setPolicyId((long) policy.getPolicyId());
			rangerPolicyModel.setPolicyName(policy.getPolicyName());
			rangerPolicyModel.setDescription(policy.getDescription());
			rangerPolicyModel.setPermissionsMap(policy.getPermMapList());
			rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.UPDATE_POLICY);
			switch(repoType.toLowerCase()) {
			case "hive":
				
				Set<String> policyDatabases = new HashSet<String>();
				String[] databases = policy.getDatabases().split(",");
				for(String database : databases) {
					policyDatabases.add(database.trim());
				}
				
				Set<String> policyTables = new HashSet<String>(); 
				String[] tables = policy.getTables().split(",");
				for(String table : tables) {
					policyTables.add(table.trim());
				}
				
				Set<String> policyColumns = new HashSet<String>();
				String[] columns = policy.getColumns().split(",");
				for(String column : columns) {
					policyColumns.add(column.trim());
				}
				
				for(String database : metadata.keySet()) {
					policyDatabases.add(database.trim());
					Map<String, Set<String>> colTableMapping = metadata.get(database);
					for(String column : colTableMapping.keySet()) {
						policyColumns.add("all".equalsIgnoreCase(column.trim()) ? "*" : column.trim());
						policyTables.addAll(colTableMapping.get(column));
					}
				}
				StringBuilder sb = new StringBuilder("");
				for(String database : policyDatabases) {
					if(sb.length() > 0) {
						sb.append(",");
					}
					sb.append(database);
				}
				rangerPolicyModel.setDatabases(sb.toString());
				sb = new StringBuilder("");
				for(String column : policyColumns) {
					if(sb.length() > 0) {
						sb.append(",");
					}
					sb.append(column);
				}
				rangerPolicyModel.setColumns(sb.toString());
				sb = new StringBuilder("");
				for(String table : policyTables) {
					if(sb.length() > 0) {
						sb.append(",");
					}
					sb.append(table);
				}
				rangerPolicyModel.setTables(sb.toString());
//				resp = rangerPolicy.processRequest(rangerPolicyModel);
				break;
			case "hdfs":
				rangerPolicyModel.setResourceName(policy.getResourceName());
				Set<String> resourceNames = new HashSet<String> ();
				for(String database : metadata.keySet()) {
//					databases.add(database);
					Map<String, Set<String>> colTableMapping = metadata.get(database);
					for(String column : colTableMapping.keySet()) {
						for(String table : colTableMapping.get(column)) {
							resourceNames.add(database.toLowerCase().trim() + "/" + table.trim());
						}
					}
				}
				StringBuilder resources = new StringBuilder("");
				for(String resourceName : resourceNames) {
					if(resources.length() != 0) {
						resources.append(",");
					}
					resources.append(resourceName.trim());
				}
				
				rangerPolicyModel.setTables(resources.toString());
				break;
			case "hbase":
				return null;
			}
			
		} else {
			rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.CREATE_POLICY);
			StringBuilder databases = new StringBuilder("");
			switch(repoType.toLowerCase()) {
			case "hive":
				StringBuilder tables = new StringBuilder("");
				StringBuilder columns = new StringBuilder("");
				for(String database : metadata.keySet()) {
					if(databases.length() != 0) {
						databases.append(",");
					}
					databases.append(database.trim());
					Map<String, Set<String>> colTableMapping = metadata.get(database);
					for(String column : colTableMapping.keySet()) {
						if(columns.length() != 0) {
							columns.append(",");
						}
						columns.append("all".equalsIgnoreCase(column.trim()) ? "*" : column.trim());
						for(String table : colTableMapping.get(column)) {
							if(tables.length() != 0) {
								tables.append(",");
							}
							tables.append(table.trim());
						}
						
					}
				}
				rangerPolicyModel.setDatabases(databases.toString());
				rangerPolicyModel.setColumns(columns.toString());
				rangerPolicyModel.setTables(tables.toString());
				break;
			case "hdfs":
				Set<String> resourceNames = new HashSet<String> ();
				for(String database : metadata.keySet()) {
//					if(databases.length() != 0) {
//						databases.append(",");
//					}
//					databases.append(database);
					Map<String, Set<String>> colTableMapping = metadata.get(database);
					for(String column : colTableMapping.keySet()) {
						for(String table : colTableMapping.get(column)) {
							resourceNames.add(database.toLowerCase().trim() + "/" +table.trim());
						}
					}
				}
				StringBuilder resources = new StringBuilder("");
				for(String resourceName : resourceNames) {
					if(resources.length() != 0) {
						resources.append(",");
					}
					resources.append(resourceName.trim());
				}
//				rangerPolicyModel.setResourceName(sb.toString());
				rangerPolicyModel.setTables(resources.toString());
				break;
			case "hbase":
				return null;
			}
		}
		resp = rangerPolicy.processRequest(rangerPolicyModel);
		if(null != resp) {
			logger.info("Create or Update policy for request id : " +reqId + ", response status code : " 
					+resp.getStatusCode() + ", Status Message : " +resp.getStatusMessage());
//			return new ResponseEntity<>(resp, HttpStatus.OK);
			return resp;
		} else {
			logger.error("Error while processing create or update policy for request id : " +reqId);
//			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
			return new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, 
					"Error while processing create or update policy for request id : " +reqId);
		}
	
	}
	
	private ResponseEntity populateRangerPolicyDetails(Long requestId, PolicyResp policy, String repositoryType, 
			boolean isToUpdatePolicy, ConsumptionRangerPolicyModel consumptionRangerPolicyModel, RangerPolicyModel rangerPolicyModel) {
//		RangerPolicyModel rangerPolicyModel = new RangerPolicyModel();
//		rangerPolicyModel.setAppName(consumptionRangerPolicyModel.getAppName().toLowerCase());
		rangerPolicyModel.setAppName("");
		ServerResponse resp = null;
		if(isToUpdatePolicy) {
			rangerPolicyModel.setPolicyId((long) policy.getPolicyId());
			rangerPolicyModel.setPolicyName(policy.getPolicyName());
			rangerPolicyModel.setDescription(policy.getDescription());
			rangerPolicyModel.setPermissionsMap(policy.getPermMapList());
			rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.UPDATE_POLICY);
			switch(repositoryType.toLowerCase()) {
			case "hive":
				
				Set<String> policyDatabases = new HashSet<String>();
				String[] databases = policy.getDatabases().split(",");
				for(String database : databases) {
					policyDatabases.add(database.trim());
				}
				
				Set<String> policyTables = new HashSet<String>(); 
				String[] tables = policy.getTables().split(",");
				for(String table : tables) {
					policyTables.add(table.trim());
				}
				
				Set<String> policyColumns = new HashSet<String>();
				String[] columns = policy.getColumns().split(",");
				for(String column : columns) {
					policyColumns.add(column.trim());
				}
				
				for(String database : consumptionRangerPolicyModel.getMetadataDetails().keySet()) {
					policyDatabases.add(database);
					Map<String, Set<String>> colTableMapping = consumptionRangerPolicyModel.getMetadataDetails().get(database).get("").get("");
					for(String column : colTableMapping.keySet()) {
						policyColumns.add("all".equalsIgnoreCase(column) ? "*" : column);
						policyTables.addAll(colTableMapping.get(column));
					}
				}
				StringBuilder sb = new StringBuilder("");
				for(String database : policyDatabases) {
					if(sb.length() > 0) {
						sb.append(", ");
					}
					sb.append(database);
				}
				rangerPolicyModel.setDatabases(sb.toString());
				sb = new StringBuilder("");
				for(String column : policyColumns) {
					if(sb.length() > 0) {
						sb.append(", ");
					}
					sb.append(column);
				}
				rangerPolicyModel.setColumns(sb.toString());
				sb = new StringBuilder("");
				for(String table : policyTables) {
					if(sb.length() > 0) {
						sb.append(", ");
					}
					sb.append(table);
				}
				rangerPolicyModel.setTables(sb.toString());
//				resp = rangerPolicy.processRequest(rangerPolicyModel);
				break;
			case "hdfs":
				rangerPolicyModel.setResourceName(policy.getResourceName());
				Set<String> resourceNames = new HashSet<String> ();
				for(String database : consumptionRangerPolicyModel.getMetadataDetails().keySet()) {
//					databases.add(database);
					Map<String, Set<String>> colTableMapping = consumptionRangerPolicyModel.getMetadataDetails().get(database).get("").get("");
					for(String column : colTableMapping.keySet()) {
						for(String table : colTableMapping.get(column)) {
							resourceNames.add(database.toLowerCase().trim() + "/" + table.trim());
						}
					}
				}
				StringBuilder resources = new StringBuilder("");
				for(String resourceName : resourceNames) {
					if(resources.length() != 0) {
						resources.append(", ");
					}
					resources.append(resourceName.trim());
				}
				
				rangerPolicyModel.setTables(resources.toString());
				break;
			case "hbase":
				break;
			}
			
		} else {
			rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.CREATE_POLICY);
			StringBuilder databases = new StringBuilder("");
			switch(repositoryType.toLowerCase()) {
			case "hive":
				StringBuilder tables = new StringBuilder("");
				StringBuilder columns = new StringBuilder("");
				for(String database : consumptionRangerPolicyModel.getMetadataDetails().keySet()) {
					if(databases.length() != 0) {
						databases.append(", ");
					}
					databases.append(database);
					Map<String, Set<String>> colTableMapping = consumptionRangerPolicyModel.getMetadataDetails().get(database).get("").get("");
					for(String column : colTableMapping.keySet()) {
						if(columns.length() != 0) {
							columns.append(", ");
						}
						columns.append("all".equalsIgnoreCase(column) ? "*" : column);
						for(String table : colTableMapping.get(column)) {
							if(tables.length() != 0) {
								tables.append(", ");
							}
							tables.append(table);
						}
						
					}
				}
				rangerPolicyModel.setDatabases(databases.toString());
				rangerPolicyModel.setColumns(columns.toString());
				rangerPolicyModel.setTables(tables.toString());
				break;
			case "hdfs":
				Set<String> resourceNames = new HashSet<String> ();
				for(String database : consumptionRangerPolicyModel.getMetadataDetails().keySet()) {
//					if(databases.length() != 0) {
//						databases.append(", ");
//					}
//					databases.append(database);
					Map<String, Set<String>> colTableMapping = consumptionRangerPolicyModel.getMetadataDetails().get(database).get("").get("");
					for(String column : colTableMapping.keySet()) {
						for(String table : colTableMapping.get(column)) {
							resourceNames.add(database.toLowerCase().trim());
						}
					}
				}
				StringBuilder resources = new StringBuilder("");
				for(String resourceName : resourceNames) {
					if(resources.length() != 0) {
						resources.append(", ");
					}
					resources.append(resourceName.trim());
				}
//				rangerPolicyModel.setResourceName(sb.toString());
				rangerPolicyModel.setTables(resources.toString());
				break;
			case "hbase":
				break;
			}
		}
		resp = rangerPolicy.processRequest(rangerPolicyModel);
		if(null != resp) {
			logger.info("Create or Update policy for request id : " +requestId + ", response status code : " 
					+resp.getStatusCode() + ", Status Message : " +resp.getStatusMessage());
			return new ResponseEntity<>(resp, HttpStatus.OK);
		} else {
			logger.error("Error while processing create or update policy for request id : " +requestId);
			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping(path="/serverCookie", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity getServerCookie() {
		ServerResponse resp = rangerPolicy.getCookie();
		return new ResponseEntity<> (resp, HttpStatus.OK);
	}
}
