package com.scb.selfservice.domains;

public class EdmpIngestionUserResp {

	private Integer reqId;
	
	private String stepId;
	
	private String propertyName;
	
	private String propertyType;

	public Integer getReqId() {
		return reqId;
	}

	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public String getPropertyName() {
		return propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	public String getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	@Override
	public String toString() {
		return "EdmpIngestionUserResp [reqId=" + reqId + ", stepId=" + stepId + ", propertyName=" + propertyName
				+ ", propertyType=" + propertyType + "]";
	}
	
	
}
