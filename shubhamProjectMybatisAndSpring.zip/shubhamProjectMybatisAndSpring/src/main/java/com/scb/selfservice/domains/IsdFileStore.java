package com.scb.selfservice.domains;

import java.util.Arrays;

public class IsdFileStore {

	private String reqId;
	private Integer versionNo;
	private String systems;
	private String countries;
	private byte[] files;

	public String getReqId() {
		return reqId;
	}

	public void setReqId(String reqId) {
		this.reqId = reqId;
	}

	public Integer getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(Integer versionNo) {
		this.versionNo = versionNo;
	}

	public String getSystems() {
		return systems;
	}

	public void setSystems(String systems) {
		this.systems = systems;
	}

	public String getCountries() {
		return countries;
	}

	public void setCountries(String countries) {
		this.countries = countries;
	}

	public byte[] getFiles() {
		return files;
	}

	public void setFiles(byte[] files) {
		this.files = files;
	}

	@Override
	public String toString() {
		return "IsdFileStore [reqId=" + reqId + ", versionNo=" + versionNo + ", systems=" + systems + ", countries="
				+ countries + ", files=" + Arrays.toString(files) + "]";
	}

}
