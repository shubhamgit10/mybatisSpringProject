package com.scb.selfservice.model.RangerPolicy;

public enum RepositoryTypeEnum {
	
	HIVE,
	HDFS,
	HBASE

}
