package com.scb.selfservice.model.RangerPolicy;

import java.util.Date;
import java.util.List;

public class PolicyResp {
	
	private int id;
	private String createDate;
	private String updateDate;
	private String owner;
	private String updatedBy;
	private String policyName;
	private String resourceName;
	private String description;
	private String repositoryName;
	private String repositoryType;
	private List<RangerPolicyPermissionsList> permMapList;
	private String tables;
	private String columns;
	private String databases;
	private String tableType;
	private String columnType;
	private boolean isEnabled;
	private boolean isRecursive;
	private boolean isAuditEnabled;
	private String version;
	private boolean replacePerm;
	private String hiveServices;
	private String udfs;
	private String columnFamilies;
	
	/**
	 * 
	 */
	public PolicyResp() {
	}
	/**
	 * @return the policyId
	 */
	public int getPolicyId() {
		return id;
	}
	/**
	 * @param policyId the policyId to set
	 */
	public void setPolicyId(int policyId) {
		this.id = policyId;
	}
	/**
	 * @return the createDate
	 */
	public String getCreateDate() {
		return createDate;
	}
	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	/**
	 * @return the updateDate
	 */
	public String getUpdateDate() {
		return updateDate;
	}
	/**
	 * @param updateDate the updateDate to set
	 */
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	/**
	 * @return the owner
	 */
	public String getOwner() {
		return owner;
	}
	/**
	 * @param owner the owner to set
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}
	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}
	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	/**
	 * @return the policyName
	 */
	public String getPolicyName() {
		return policyName;
	}
	/**
	 * @param policyName the policyName to set
	 */
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
	/**
	 * @return the resourceName
	 */
	public String getResourceName() {
		return resourceName;
	}
	/**
	 * @param resourceName the resourceName to set
	 */
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the repositoryName
	 */
	public String getRepositoryName() {
		return repositoryName;
	}
	/**
	 * @param repositoryName the repositoryName to set
	 */
	public void setRepositoryName(String repositoryName) {
		this.repositoryName = repositoryName;
	}
	/**
	 * @return the repositoryType
	 */
	public String getRepositoryType() {
		return repositoryType;
	}
	/**
	 * @param repositoryType the repositoryType to set
	 */
	public void setRepositoryType(String repositoryType) {
		this.repositoryType = repositoryType;
	}
	/**
	 * @return the permMapList
	 */
	public List<RangerPolicyPermissionsList> getPermMapList() {
		return permMapList;
	}
	/**
	 * @param permMapList the permMapList to set
	 */
	public void setPermMapList(List<RangerPolicyPermissionsList> permMapList) {
		this.permMapList = permMapList;
	}
	/**
	 * @return the tables
	 */
	public String getTables() {
		return tables;
	}
	/**
	 * @param tables the tables to set
	 */
	public void setTables(String tables) {
		this.tables = tables;
	}
	/**
	 * @return the columns
	 */
	public String getColumns() {
		return columns;
	}
	/**
	 * @param columns the columns to set
	 */
	public void setColumns(String columns) {
		this.columns = columns;
	}
	/**
	 * @return the databases
	 */
	public String getDatabases() {
		return databases;
	}
	/**
	 * @param databases the databases to set
	 */
	public void setDatabases(String databases) {
		this.databases = databases;
	}
	/**
	 * @return the tableType
	 */
	public String getTableType() {
		return tableType;
	}
	/**
	 * @param tableType the tableType to set
	 */
	public void setTableType(String tableType) {
		this.tableType = tableType;
	}
	/**
	 * @return the columnType
	 */
	public String getColumnType() {
		return columnType;
	}
	/**
	 * @param columnType the columnType to set
	 */
	public void setColumnType(String columnType) {
		this.columnType = columnType;
	}
	/**
	 * @return the isEnabled
	 */
	public boolean isEnabled() {
		return isEnabled;
	}
	/**
	 * @param isEnabled the isEnabled to set
	 */
	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}
	/**
	 * @return the isRecursive
	 */
	public boolean isRecursive() {
		return isRecursive;
	}
	/**
	 * @param isRecursive the isRecursive to set
	 */
	public void setRecursive(boolean isRecursive) {
		this.isRecursive = isRecursive;
	}
	/**
	 * @return the isAuditEnabled
	 */
	public boolean isAuditEnabled() {
		return isAuditEnabled;
	}
	/**
	 * @param isAuditEnabled the isAuditEnabled to set
	 */
	public void setAuditEnabled(boolean isAuditEnabled) {
		this.isAuditEnabled = isAuditEnabled;
	}
	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}
	/**
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}
	/**
	 * @return the replacePerm
	 */
	public boolean isReplacePerm() {
		return replacePerm;
	}
	/**
	 * @param replacePerm the replacePerm to set
	 */
	public void setReplacePerm(boolean replacePerm) {
		this.replacePerm = replacePerm;
	}
	/**
	 * @return the hiveServices
	 */
	public String getHiveServices() {
		return hiveServices;
	}
	/**
	 * @param hiveServices the hiveServices to set
	 */
	public void setHiveServices(String hiveServices) {
		this.hiveServices = hiveServices;
	}
	/**
	 * @return the udfs
	 */
	public String getUdfs() {
		return udfs;
	}
	/**
	 * @param udfs the udfs to set
	 */
	public void setUdfs(String udfs) {
		this.udfs = udfs;
	}
	/**
	 * @return the columnFamilies
	 */
	public String getColumnFamilies() {
		return columnFamilies;
	}
	/**
	 * @param columnFamilies the columnFamilies to set
	 */
	public void setColumnFamilies(String columnFamilies) {
		this.columnFamilies = columnFamilies;
	}
	@Override
	public String toString() {
		return "PolicyResp [policyId=" + id + ", createDate=" + createDate + ", updateDate=" + updateDate
				+ ", owner=" + owner + ", updatedBy=" + updatedBy + ", policyName=" + policyName + ", resourceName="
				+ resourceName + ", description=" + description + ", repositoryName=" + repositoryName
				+ ", repositoryType=" + repositoryType + ", permMapList=" + permMapList + ", tables=" + tables
				+ ", columns=" + columns + ", databases=" + databases + ", tableType=" + tableType + ", columnType="
				+ columnType + ", isEnabled=" + isEnabled + ", isRecursive=" + isRecursive + ", isAuditEnabled="
				+ isAuditEnabled + ", version=" + version + ", replacePerm=" + replacePerm + ", hiveServices="
				+ hiveServices + ", udfs=" + udfs + ", columnFamilies=" + columnFamilies + "]";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof PolicyResp))
			return false;
		PolicyResp other = (PolicyResp) obj;
		if (id != other.id)
			return false;
		return true;
	}
	
	
}
