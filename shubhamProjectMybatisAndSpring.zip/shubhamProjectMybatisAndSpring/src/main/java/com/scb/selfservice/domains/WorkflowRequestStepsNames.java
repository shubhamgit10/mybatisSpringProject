package com.scb.selfservice.domains;

import java.sql.Timestamp;

/*
 * pojo
 */
public class WorkflowRequestStepsNames {

	private Integer reqId;
	private String  stepId;
	private String  status;
	private String  stepName;
	private Timestamp approvedAt;
	private String approvedBy;
	
	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStepName() {
		return stepName;
	}
	public void setStepName(String stepName) {
		this.stepName = stepName;
	}
	public Timestamp getApprovedAt() {
		return approvedAt;
	}
	public void setApprovedAt(Timestamp approvedAt) {
		this.approvedAt = approvedAt;
	}
	public String getApprovedBy() {
		return approvedBy;
	}
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}
	@Override
	public String toString() {
		return "WorkflowRequestStepsNames [reqId=" + reqId + ", stepId=" + stepId + ", status=" + status + ", stepName="
				+ stepName + ", approvedAt=" + approvedAt + ", approvedBy=" + approvedBy + "]";
	}
}

