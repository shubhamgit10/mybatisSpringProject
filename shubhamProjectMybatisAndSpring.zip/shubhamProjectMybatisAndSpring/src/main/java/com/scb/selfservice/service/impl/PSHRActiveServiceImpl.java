package com.scb.selfservice.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.td.mapper.PSHRActiveMapper;
import com.scb.selfservice.domains.PSHRActive;
import com.scb.selfservice.domains.databaseentity.DBPSHRActive;
import com.scb.selfservice.service.PSHRActiveService;
import com.scb.selfservice.util.Response;

@Service
public class PSHRActiveServiceImpl implements PSHRActiveService {

	private static Logger logger = LogManager.getLogger(PSHRActiveServiceImpl.class);

	@Autowired
	private PSHRActiveMapper psHRActiveMapper; 

	/**
	 * Method to invoked Teradata DB Mapper
	 * 
	 * @return
	 */
	@Override
	@Transactional(value = "transactionManagerTD", propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public Response validate(HashMap<String, List<PSHRActive>> requestBody) {
		// TODO Auto-generated method stub
		Response validateResponse =  new Response();
		if (requestBody.isEmpty()) {
			validateResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			validateResponse.setStatus(HttpStatus.NO_CONTENT.toString());
		} else {
			//For loop getting the Key
			for(Map.Entry<String, List<PSHRActive>> entry : requestBody.entrySet())  {
				// for loop for PSID
				for (PSHRActive pshrActive : entry.getValue()) {
					DBPSHRActive dbpshrActive = psHRActiveMapper.validate(pshrActive.getPSID());
					if (null != dbpshrActive) 
					{
						pshrActive.setStatus(Boolean.TRUE);
						pshrActive.setEmailId(dbpshrActive.getEmailId());
					} else {
						pshrActive.setStatus(Boolean.FALSE);
					}
				}
			}
			validateResponse.setStatusCode(HttpStatus.OK.value());
			validateResponse.setStatus(HttpStatus.OK.toString());
			validateResponse.setResponse(requestBody);
		}
		logger.info("PSID validation Completed");
		return validateResponse;
	}
	
	
	
	/**
	 *Auto Suggestion PSHRACTIVE
	 */
	@Override
	@Transactional(value = "transactionManagerTD", propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public Response validated(String staffName) {
		Response validate = new Response();
		List<DBPSHRActive> dbpshrActive = psHRActiveMapper.validated(staffName);
		if (dbpshrActive.isEmpty()) 
		{
			validate.setStatusCode(HttpStatus.NO_CONTENT.value());
			validate.setStatus(HttpStatus.NO_CONTENT.toString());
		} else {
			validate.setResponse(dbpshrActive);
			validate.setStatusCode(HttpStatus.OK.value());
			validate.setStatus(HttpStatus.OK.toString());			
			
		}
		return validate;
	}


}
