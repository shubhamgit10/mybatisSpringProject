/**
 * 
 */
package com.scb.selfservice.model;

import java.util.HashMap;
import java.util.List;

/**
 * Consumption Request Model
 * 
 * @author Amarnath BB
 *
 */
public class ConsumptionRequestInfo {
	
	public ConsumptionRequestInfo() {
		
	}
	
	private HashMap<String, String> requestDetails;
	private List<HashMap<String, String>> tablesSubscribed;
	
	/**
	 * @return the requestDetails
	 */
	public HashMap<String, String> getRequestDetails() {
		return requestDetails;
	}
	/**
	 * @param requestDetails the requestDetails to set
	 */
	public void setRequestDetails(HashMap<String, String> requestDetails) {
		this.requestDetails = requestDetails;
	}
	/**
	 * @return the tablesSubscribed
	 */
	public List<HashMap<String, String>> getTablesSubscribed() {
		return tablesSubscribed;
	}
	/**
	 * @param tablesSubscribed the tablesSubscribed to set
	 */
	public void setTablesSubscribed(List<HashMap<String, String>> tablesSubscribed) {
		this.tablesSubscribed = tablesSubscribed;
	}

}
