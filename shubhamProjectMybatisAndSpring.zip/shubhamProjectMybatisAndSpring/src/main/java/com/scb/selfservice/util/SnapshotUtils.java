package com.scb.selfservice.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.scb.selfservice.dao.mapper.FileUploadMapper;
import com.scb.selfservice.domains.EDMPSelfServiceReq;
import com.scb.selfservice.domains.FileData;
import com.scb.selfservice.domains.FileUpload;
import com.scb.selfservice.service.FileDownloadService;

@Component
public class SnapshotUtils {

	private static Logger logger = LogManager.getLogger(SnapshotUtils.class);

	@Autowired
	private FileDownloadService fileDownloadService;

	@Autowired
	FileUploadMapper fileUpdateMapper;

	public int getSnapshot(EDMPSelfServiceReq edmpSelfServiceReq) throws IOException {
		logger.info("SnapshotUtils - getSnapshot - starting");
		//Time to create the snapshot of the current data - 0209
		List<FileData> fileData = fileDownloadService.pullData(edmpSelfServiceReq.getReqId());
		
		ByteArrayInputStream in = CommonUtils.prepareXlsx(fileData);
		logger.info("SnapshotUtils - getSnapshot - done with prepareing xls data and uploading");
		
		FileUpload fileupload = getFileuploadObj (edmpSelfServiceReq, in);
		int uploadId = fileUpdateMapper.insertFile(fileupload);	
		
		logger.info("SnapshotUtils - getSnapshot - exiting with uploadId: " + fileupload.getUploadId());

		return fileupload.getUploadId();
	}

	private FileUpload getFileuploadObj(EDMPSelfServiceReq edmpSelfServiceReq, ByteArrayInputStream in) {
		FileUpload fileUpload = new FileUpload();
		fileUpload.setContent(in.readAllBytes());
		fileUpload.setFileName(CommonUtils.fileName(edmpSelfServiceReq.getReqId()));
		fileUpload.setFileType("xlsx");
		fileUpload.setUserId(edmpSelfServiceReq.getRequestCreatedBy());
		
		return fileUpload;
	}
	
}
