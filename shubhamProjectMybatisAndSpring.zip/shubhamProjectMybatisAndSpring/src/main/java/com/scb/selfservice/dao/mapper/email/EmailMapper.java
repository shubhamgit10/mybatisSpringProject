package com.scb.selfservice.dao.mapper.email;

import com.scb.selfservice.model.AdminData;
import com.scb.selfservice.model.AuditEmailSLA;
import com.scb.selfservice.model.ConsumptionPending;
import com.scb.selfservice.model.EmailAddressDetails;
import com.scb.selfservice.model.EmailContent;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface EmailMapper {

    public EmailAddressDetails getApproveMailToList(@Param("reqId") int reqId, @Param("stepId") String stepId);
    public EmailAddressDetails getApproveMailCcList(@Param("reqId") int reqId, @Param("stepId") String stepId);
    public EmailAddressDetails getRejectMailToList(@Param("reqId") int reqId, @Param("stepId") String stepId);
    public EmailAddressDetails getRejectMailCcList(@Param("reqId") int reqId, @Param("stepId") String stepId);
    public EmailContent getApproveMailContent(@Param("reqId") int reqId, @Param("stepId") String stepId);
    public EmailContent getRejectMailContent(@Param("reqId") int reqId, @Param("stepId") String stepId);
    public EmailAddressDetails getCostEstimationMailToList(@Param("userId") Integer userId);

    //mapper for pulling all pending requests
    public List<ConsumptionPending> getConsumptionPendingReqs(@Param("workflowId") int workflowId);

    //mapper for inserting into audit_email_sla
    public int insertAuditEmailSla(@Param("audit") AuditEmailSLA audit);

    //mapper for updating workflow_request_steps with attempt for the given reqId + stepId
	public int updateWorkflowRequestSteps(@Param("reqId") Integer reqId, @Param("stepId") String stepId, 
			@Param("attempt") Integer attempt);

	//mapper for pulling admin (roleName) emailAddress
	public List<AdminData> getAdminMailCcList();

}
