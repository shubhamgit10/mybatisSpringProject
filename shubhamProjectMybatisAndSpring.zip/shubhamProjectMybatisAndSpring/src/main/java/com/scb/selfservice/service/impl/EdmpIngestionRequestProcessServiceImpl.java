package com.scb.selfservice.service.impl;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.EdmpIngDmApprovalMapper;
import com.scb.selfservice.dao.mapper.EdmpIngRequestorRespMapper;
import com.scb.selfservice.dao.mapper.EdmpIngSolArchReqMapper;
import com.scb.selfservice.dao.mapper.EdmpIngestionRequestMapper;
import com.scb.selfservice.dao.mapper.WorkflowMapper;
import com.scb.selfservice.domains.BizAnylstResponse;
import com.scb.selfservice.domains.IngestionDmApproval;
import com.scb.selfservice.domains.IngestionRequest;
import com.scb.selfservice.domains.IngestionRequestorResp;
import com.scb.selfservice.domains.IngestionSolArchApproval;
import com.scb.selfservice.domains.Upject;
import com.scb.selfservice.domains.WorkflowIdType;
import com.scb.selfservice.domains.WorkflowProcessSteps;
import com.scb.selfservice.domains.WorkflowRespTableMapping;
import com.scb.selfservice.model.CostEstimationRequest;
import com.scb.selfservice.model.CostEstimationSummary;
import com.scb.selfservice.service.CostEstimationSummaryService;
import com.scb.selfservice.service.EdmpIngestionRequestProcessService;
import com.scb.selfservice.service.EdmpIngestionRequestService;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.workflow.service.WorkflowRequestService;
import com.scb.selfservice.workflow.service.impl.WorkflowRequestServiceImpl;

/**
 * @author cpedada
 *
 */
@Service
public class EdmpIngestionRequestProcessServiceImpl implements EdmpIngestionRequestProcessService {

	private static Logger logger = LogManager.getLogger(EdmpIngestionRequestProcessServiceImpl.class);

	@Autowired
	private EdmpIngSolArchReqMapper edmpIrpMapper;

	@Autowired
	EdmpIngRequestorRespMapper edmpirrMapper;

	@Autowired
	EdmpIngDmApprovalMapper edmpDmMapper;

	@Autowired
	WorkflowMapper workflowMapper;

	@Autowired
	WorkflowRequestService workflowRequestService;

	@Autowired
	WorkflowRequestServiceImpl wfrsi;

	@Autowired
	MyRequestServiceImpl mrServiceImpl;

	@Autowired
	ApplicationContext applicationContext;

	@Autowired
	CostEstimationSummaryService cesService;

	@Autowired
	EdmpIngestionRequestService eiReqService;

	@Autowired
	EdmpIngestionRequestMapper eirMapper;

	/**
	 *
	 */
	@Override
	@Transactional
	public Response saveSolutionArchResp(IngestionSolArchApproval ingestionSolArchApproval, Integer userId)
			throws Exception {
		// TODO Auto-generated method stub
		logger.info("START EdmpIngestionRequestProcessServiceImpl::saveSolutionArchResp");
		Response isaResponse = new Response();
		Integer reqId = 0;
		String userAction = ingestionSolArchApproval.getUserAction();

		IngestionSolArchApproval crObj = edmpIrpMapper.findByRequestId(ingestionSolArchApproval.getReqId());

		WorkflowIdType workflowIdType = workflowMapper.getWorkflowId(ingestionSolArchApproval.getWorkflowType());
		WorkflowProcessSteps workflowProcessStep = workflowMapper
				.getWorkflowProcessStepByStepId(ingestionSolArchApproval.getStepId(), workflowIdType.getWorkflowId());
		ingestionSolArchApproval.setStepName(workflowProcessStep.getStepName());
		ingestionSolArchApproval.setRequestCreatedBy(userId);

		int estimationId = ingestionSolArchApproval.getEstimationId();

		if ("APPROVED".equalsIgnoreCase(userAction)) {

			if (estimationId != 0) {
				CostEstimationRequest ceRequest = new CostEstimationRequest();

				ceRequest.setEstimationId(ingestionSolArchApproval.getEstimationId());
				ceRequest.setSourceName("");
				ceRequest.setSourceType(ingestionSolArchApproval.getSourceType());

				ceRequest.setSourcingType(ingestionSolArchApproval.getProposedSolution());
				ceRequest.setInstances("");
				ceRequest.setNumberOfInstances(null);
				ceRequest.setNumberOfTables(0);
				ceRequest.setSourceDataSystem(ingestionSolArchApproval.getSrcDataSys());
				ceRequest.setWorkflowType(ingestionSolArchApproval.getWorkflowType());
				ceRequest.setStepId(ingestionSolArchApproval.getStepId());

				ceRequest.setNumberOfColumnsAccrossTable(0);
				ceRequest.setFileFormat("");
				ceRequest.setDownstreamOlaRequired("");

				ceRequest.setNewTransformationRulesRequired("");

				ceRequest.setSourceSystemCommunication(ingestionSolArchApproval.getSrcSysCommunications());

				ceRequest.setPlannedGoLiveMonth("");
				ceRequest.setHistoryData(0);
				ceRequest.setHistoryStorageType("");
				ceRequest.setIncrementalData(0);
				ceRequest.setIncrementalStorageType("");

				Response estimation = cesService.getEstimatedCost(ceRequest, userId);

				CostEstimationSummary Cost = (CostEstimationSummary) estimation.getResponse();

				logger.info("Printing the Proposed Cost::::: " + Cost.getEstimatedCost());

				String newcost = Cost.getEstimatedCost();

				Double proposedCost = Double.parseDouble(newcost);

				Response crObjNew = eiReqService.findByReqId(ingestionSolArchApproval.getReqId());

				if (null != crObjNew) {

					eiReqService.updateProposedCost(ingestionSolArchApproval.getReqId(), userId, proposedCost);// update

				}
			}
		}

		if (crObj == null) {
			logger.info("START it is a new entry for new request..." + ingestionSolArchApproval.getReqId());

			int saveStatus = edmpIrpMapper.saveSolutionArchRequest(ingestionSolArchApproval); // insert

			isaResponse = getActionStatus("save", saveStatus, ingestionSolArchApproval.getReqId());

			logger.info("EXIT save request");

		} else {
			logger.info("START it an existing request..." + ingestionSolArchApproval.getReqId());

			int updateStatus = edmpIrpMapper.updateSolArchRequest(ingestionSolArchApproval); // update

			isaResponse = getActionStatus("update", updateStatus, ingestionSolArchApproval.getReqId());

			logger.info("EXIT update request");
		}

		// int reqCreatedBy = ingestionSolArchApproval.getRequestCreatedBy();

		reqId = ingestionSolArchApproval.getReqId();

		String stepId = ingestionSolArchApproval.getStepId();
		Integer workflowId = workflowRequestService.getWorkflowId(ingestionSolArchApproval.getWorkflowType());
		Upject upject = new Upject();

		upject.setReqId(reqId);
		upject.setStepId(stepId);
		upject.setWorkflowId(workflowId);
		upject.setStatus(userAction);
		upject.setRemarks(ingestionSolArchApproval.getSolutionComments());
		upject.setUserId(userId);

		if ("APPROVED".equalsIgnoreCase(userAction)) {

			try {
				wfrsi.workflowApprove(upject, null);
				logger.info("in Workflow Approve");

			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.info("Exception in workflowApprove" + e);
			}

		} else if ("REJECTED".equalsIgnoreCase(userAction)) {

			try {
				wfrsi.workflowReject(upject, null);

				logger.info("in Workflow Reject");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.info("Exception in workflowReject" + e);
			}

		}

		logger.info("EXIT EdmpIngestionRequestProcessServiceImpl::saveSolutionArchRequest");
		return isaResponse;

	}

	/**
	 *
	 */
	@Override
	@Transactional
	public Response saveIngestionRequestorResp(IngestionRequestorResp ingestionRequestorResp, Integer userId)
			throws Exception {
		// TODO Auto-generated method stub
		logger.info("START EdmpIngestionRequestProcessServiceImpl::saveIngestionRequestorResp");
		Response isaResponse = new Response();
		Integer reqId = 0;
		String userAction = ingestionRequestorResp.getUserAction();

		IngestionRequestorResp crObj = edmpirrMapper.findByRequestId(ingestionRequestorResp.getReqId());

		WorkflowIdType workflowIdType = workflowMapper.getWorkflowId(ingestionRequestorResp.getWorkflowType());
		WorkflowProcessSteps workflowProcessStep = workflowMapper
				.getWorkflowProcessStepByStepId(ingestionRequestorResp.getStepId(), workflowIdType.getWorkflowId());
		ingestionRequestorResp.setStepName(workflowProcessStep.getStepName());

		ingestionRequestorResp.setRequestCreatedBy(userId);
		if (crObj == null) {
			logger.info("START it is a new entry for new request..." + ingestionRequestorResp.getReqId());

			int saveStatus = edmpirrMapper.saveIngestionRequestorResp(ingestionRequestorResp); // insert

			isaResponse = getActionStatus("save", saveStatus, ingestionRequestorResp.getReqId());

			logger.info("EXIT save request");
		} else {
			logger.info("START it an existing request..." + ingestionRequestorResp.getReqId());

			int updateStatus = edmpirrMapper.updateIngestionRequestorResp(ingestionRequestorResp); // update

			isaResponse = getActionStatus("update", updateStatus, ingestionRequestorResp.getReqId());

			logger.info("EXIT update request");
		}

		// int reqCreatedBy = ingestionRequestorResp.getRequestCreatedBy();

		reqId = ingestionRequestorResp.getReqId();

		String stepId = ingestionRequestorResp.getStepId();

		Integer workflowId = workflowRequestService.getWorkflowId(ingestionRequestorResp.getWorkflowType());

		Upject upject = new Upject();

		upject.setReqId(reqId);
		upject.setStepId(stepId);
		upject.setWorkflowId(workflowId);
		upject.setStatus(userAction);
		upject.setRemarks(ingestionRequestorResp.getAdditionalComments());
		upject.setUserId(userId);

		if ("APPROVED".equalsIgnoreCase(userAction)) {

			try {
				wfrsi.workflowApprove(upject, null);
				logger.info("in Workflow Approve");

			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.info("Exception in workflowApprove" + e);
			}

		} else if ("REJECTED".equalsIgnoreCase(userAction)) {

			try {
				wfrsi.workflowReject(upject, null);

				logger.info("in Workflow Rejected");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.info("Exception in workflowReject" + e);
			}

		} else if ("CANCEL".equalsIgnoreCase(userAction)) {

			try {

				HashMap<String, String> cancelMap = new HashMap<String, String>();

				cancelMap.put("reqId", String.valueOf(upject.getReqId()));
				cancelMap.put("stepId", upject.getStepId());
				cancelMap.put("status", upject.getStatus());
				cancelMap.put("remarks", upject.getRemarks());
				cancelMap.put("userId", String.valueOf(upject.getUserId()));
				cancelMap.put("workflowType", ingestionRequestorResp.getWorkflowType());

				System.out.println("cancelMap:::" + cancelMap);

				mrServiceImpl.cancelRequest(cancelMap);

				logger.info("in Workflow Cancel");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.info("Exception in workflow Cancelled" + e.getMessage());

				e.printStackTrace();
			}

		}

		logger.info("EXIT EdmpIngestionRequestProcessServiceImpl::saveIngestionRequestorResp");
		return isaResponse;

	}

	/**
	 *
	 */
	@Override
	@Transactional
	public Response saveDmApprovalResp(IngestionDmApproval ingestionDmApproval, Integer userId) throws Exception {
		// TODO Auto-generated method stub
		logger.info("START EdmpIngestionRequestProcessServiceImpl::saveDmApprovalResp");
		Response isaResponse = new Response();
		Integer reqId = 0;
		String userAction = ingestionDmApproval.getUserAction();
		int rejectedFlag = 1;

		IngestionDmApproval crObj = edmpDmMapper.findByRequestId(ingestionDmApproval.getReqId());
		WorkflowIdType workflowIdType = workflowMapper.getWorkflowId(ingestionDmApproval.getWorkflowType());
		WorkflowProcessSteps workflowProcessStep = workflowMapper
				.getWorkflowProcessStepByStepId(ingestionDmApproval.getStepId(), workflowIdType.getWorkflowId());
		ingestionDmApproval.setStepName(workflowProcessStep.getStepName());

		ingestionDmApproval.setRequestCreatedBy(userId);

		if (crObj == null) {
			logger.info("START it is a new entry for new request..." + ingestionDmApproval.getReqId());

			int saveStatus = edmpDmMapper.saveDmApprovalRequest(ingestionDmApproval); // insert

			isaResponse = getActionStatus("save", saveStatus, ingestionDmApproval.getReqId());

			logger.info("EXIT save request");
		} else {
			logger.info("START it an existing request..." + ingestionDmApproval.getReqId());

			int updateStatus = edmpDmMapper.updateDmApprovalRequest(ingestionDmApproval); // update

			isaResponse = getActionStatus("update", updateStatus, ingestionDmApproval.getReqId());

			logger.info("EXIT update request");
		}

		// DM Rejected Flag functionality::::
		rejectedFlag = 0;

		int status = eirMapper.updateIngestionflag(ingestionDmApproval.getReqId(), rejectedFlag);

		reqId = ingestionDmApproval.getReqId();

		String stepId = ingestionDmApproval.getStepId();

		Integer workflowId = workflowRequestService.getWorkflowId(ingestionDmApproval.getWorkflowType());

		Upject upject = new Upject();

		upject.setReqId(reqId);
		upject.setStepId(stepId);
		upject.setWorkflowId(workflowId);
		upject.setStatus(userAction);
		upject.setRemarks(ingestionDmApproval.getDmComments());
		upject.setUserId(userId);

		if ("APPROVED".equalsIgnoreCase(userAction)) {

			try {
				wfrsi.workflowApprove(upject, null);
				logger.info("in Workflow Approve");

			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.info("Exception in workflowApprove" + e);
			}

		} else if ("REJECTED".equalsIgnoreCase(userAction)) {

			try {
				wfrsi.workflowReject(upject, null);

				logger.info("in Workflow Reject");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.info("Exception in workflowReject" + e);
			}

		} else if ("CANCEL".equalsIgnoreCase(userAction)) {

			try {

				HashMap<String, String> cancelMap = new HashMap<String, String>();

				cancelMap.put("reqId", String.valueOf(upject.getReqId()));
				cancelMap.put("stepId", upject.getStepId());
				cancelMap.put("status", upject.getStatus());
				cancelMap.put("remarks", upject.getRemarks());
				cancelMap.put("userId", String.valueOf(upject.getUserId()));
				cancelMap.put("workflowType", ingestionDmApproval.getWorkflowType());

				mrServiceImpl.cancelRequest(cancelMap);

			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.info("Exception in workflow Cancelled" + e.getMessage());
			}

		}

		logger.info("EXIT EdmpIngestionRequestProcessServiceImpl::saveDmApprovalRequest");
		return isaResponse;

	}

	/**
	 * @param type
	 * @param saveStatus
	 * @param reqId
	 * @return
	 */
	private Response getActionStatus(String type, int saveStatus, int reqId) {
		Response response = new Response();
		if (saveStatus == 1) {
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus(HttpStatus.OK.toString());
			response.setResponse(reqId + "Request id " + (type.equals("save") ? "INSERTED" : "UPDATED"));
		} else {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
			response.setResponse("!!!Action not taken!!!");
		}
		return response;
	}

	@Override
	public Response saveIngestionResponses(Object obj, String stepId, Integer workflowId) {

		logger.info("inside saveIngestionResponses");
		// TODO Auto-generated method stub

		if (workflowId == 102) {
			WorkflowRespTableMapping wfrtm = new WorkflowRespTableMapping();

			wfrtm.setStepId(stepId);
			wfrtm.setWorkflowId(workflowId);
			wfrtm.setTableName("");

		} else {

		}

		return null;
	}

	/**
	 *
	 */
	@Override
	public Response savebizAnalystResp(BizAnylstResponse bizAnResponse, Integer userId) throws Exception {
		// TODO Auto-generated method stub
		logger.info("START EdmpIngestionRequestProcessServiceImpl::savebizAnalystResp");
		Response isaResponse = new Response();
		Integer reqId = 0;
		String userAction = bizAnResponse.getUserAction();

		int reqCreatedBy = bizAnResponse.getRequestCreatedBy();

		reqId = bizAnResponse.getReqId();

		String stepId = bizAnResponse.getStepId();

		Integer workflowId = workflowRequestService.getWorkflowId(bizAnResponse.getWorkflowType());

		Upject upject = new Upject();

		upject.setReqId(reqId);
		upject.setStepId(stepId);
		upject.setWorkflowId(workflowId);
		upject.setStatus(userAction);
		upject.setRemarks("");
		upject.setUserId(userId);

		if ("APPROVED".equalsIgnoreCase(userAction)) {

			try {

				wfrsi.workflowApprove(upject, null);
				logger.info("in Workflow Approve");

			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.info("Exception in workflowApprove" + e);
			}

		} else if ("REJECTED".equalsIgnoreCase(userAction)) {

			try {
				wfrsi.workflowReject(upject, null);

				logger.info("in Workflow Reject");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.info("Exception in workflowReject" + e);
			}

		}

		isaResponse.setStatusCode(HttpStatus.OK.value());
		isaResponse.setStatus("Success");
		isaResponse.setResponse("Workflow UPDATE/APPROVE is SUCCESS");
		logger.info("EXIT EdmpIngestionRequestProcessServiceImpl::bizAnResponse");
		return isaResponse;

	}

	@Override
	@Transactional
	public Response getIngestionRequestorResp(Integer reqId) throws Exception {
		// TODO Auto-generated method stub

		logger.info("START EdmpIngestionRequestProcessServiceImpl::getIngestionRequestorResp");
		Response getRequestorResp = new Response();

		IngestionRequestorResp irObj = edmpirrMapper.findByRequestId(reqId);

		if (null == irObj) {
			// get from Injestion_Request_Table
			IngestionRequest iReq = eirMapper.findByRequestId(reqId);

			if (null == iReq) {

				getRequestorResp.setStatusCode(HttpStatus.NO_CONTENT.value());
				getRequestorResp.setStatus(HttpStatus.NO_CONTENT.toString());

			} else {
				// get from Requester Response table
				IngestionRequestorResp irObjNew = edmpirrMapper.findIngReqById(reqId);
				getRequestorResp.setResponse(irObjNew);
				getRequestorResp.setStatusCode(HttpStatus.OK.value());
				getRequestorResp.setStatus(HttpStatus.OK.toString());
			}
		} else {

			getRequestorResp.setResponse(irObj);
			getRequestorResp.setStatusCode(HttpStatus.OK.value());
			getRequestorResp.setStatus(HttpStatus.OK.toString());
		}

		return getRequestorResp;
	}
}