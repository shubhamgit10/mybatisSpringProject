package com.scb.selfservice.model;

import java.sql.Timestamp;
/*
 * 
 */
public class AuditEmailSLA {

	private Integer emailSlaId;
	private Integer reqId;
	private Integer workflowId;
	private String  stepId;
	private String  emailStatus;
	private Timestamp emailDate;
	private Integer attempt;

	public Integer getEmailSlaId() {
		return emailSlaId;
	}
	public void setEmailSlaId(Integer emailSlaId) {
		this.emailSlaId = emailSlaId;
	}
	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	public Integer getWorkflowId() {
		return workflowId;
	}
	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getEmailStatus() {
		return emailStatus;
	}
	public void setEmailStatus(String emailStatus) {
		this.emailStatus = emailStatus;
	}
	public Timestamp getEmailDate() {
		return emailDate;
	}
	public void setEmailDate(Timestamp emailDate) {
		this.emailDate = emailDate;
	}
	public Integer getAttempt() {
		return attempt;
	}
	public void setAttempt(Integer attempt) {
		this.attempt = attempt;
	}
	@Override
	public String toString() {
		return "EmailSLA [emailSlaId=" + emailSlaId + ", reqId=" + reqId + ", workflowId=" + workflowId + ", stepId="
				+ stepId + ", emailStatus=" + emailStatus + ", emailDate=" + emailDate + ", attempt=" + attempt + "]";
	}
}
