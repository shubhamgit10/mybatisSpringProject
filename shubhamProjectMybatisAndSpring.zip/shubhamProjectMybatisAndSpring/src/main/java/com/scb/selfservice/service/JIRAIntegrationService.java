/**
 * 
 */
package com.scb.selfservice.service;

/**
 * 
 * Service for JIRA Integration
 * 
 * @author Amarnath BB
 *
 */
public interface JIRAIntegrationService {
	
	/**
	 * Method to create a new Consumption JIRA
	 * @param reqDetails
	 * @return
	 */
	public String createOrUpdateJiraDetails(String reqId, String stepId, String userId);
	

}
