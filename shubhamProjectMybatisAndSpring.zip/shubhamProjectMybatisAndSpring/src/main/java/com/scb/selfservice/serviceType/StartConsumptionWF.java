package com.scb.selfservice.serviceType;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class StartConsumptionWF implements ServiceCall {
	
	private static Logger logger = LogManager.getLogger(StartConsumptionWF.class);
	@Override
	public String execute(Map<String, String> params) {
		logger.info("Returning from StartConsumptionWF...");
		return "SUCCESS";
	}

}
