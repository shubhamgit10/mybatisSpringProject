package com.scb.selfservice.service;

import org.springframework.stereotype.Service;

import com.scb.selfservice.util.Response;

/**
 * 
 * @author shubhasi Service class for SDM tech
 */
@Service
public interface SDMTechService {

	public Response getSDMTableName(Integer reqId);

	// method to pull existing ViewPipelineController
	public Response findByReqGlobalParam();

}
