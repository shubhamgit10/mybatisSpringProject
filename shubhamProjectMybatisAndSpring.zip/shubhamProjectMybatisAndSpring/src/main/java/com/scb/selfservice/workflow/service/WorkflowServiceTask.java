/**
 * 
 */
package com.scb.selfservice.workflow.service;

import com.scb.selfservice.util.Response;

/**
 * Workflow Service Task to implement any Service specific steps
 * 
 * @author Amarnath BB
 *
 */
public interface WorkflowServiceTask {
	
	/**
	 * Execute method to contain the logic of Service Task
	 * @param context
	 * @return
	 */
	public String execute(ExecutionContext context);
	

}
