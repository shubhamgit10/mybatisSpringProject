package com.scb.selfservice.elk.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.core.MainResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MultiMatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.QueryStringQueryBuilder;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.scb.selfservice.elk.domains.DynamicFilters;
import com.scb.selfservice.elk.domains.ElkData;
import com.scb.selfservice.elk.domains.GridData;
/*
 * Utility for ELK
 * 	Query, where clause and filters
 *  TypeAhead
 */
public class ELKUtil {
	private static Logger logger = LogManager.getLogger(ELKUtil.class);
	public static Set<String> typeAhead (String typeAhead) {
		try (RestHighLevelClient client = new RestHighLevelClient(
				RestClient.builder(HttpHost.create("http://10.100.252.130:9200")))) {
			MainResponse info = client.info(RequestOptions.DEFAULT);
			String version = info.getVersion().getNumber();
			logger.debug("version = " + version);
			BoolQueryBuilder  booleanquery = QueryBuilders.boolQuery();
			String[] includeFields = new String[]{ "APP_NAME",  "TABLE_NAME_T", "COLUMN_NAME"};

			String[] excludeFields = new String[]{};

			MultiMatchQueryBuilder matchedQuery = QueryBuilders.multiMatchQuery(typeAhead, "APP_NAME", "TABLE_NAME_T", "COLUMN_NAME");
			booleanquery.must(matchedQuery);

			SearchResponse valuesResponse = client.search(new SearchRequest("edmp_model").source(
					new SearchSourceBuilder().query(booleanquery).size(5).fetchSource(includeFields, excludeFields)),RequestOptions.DEFAULT);

			//JsonElement jsonResponse = new JsonParser().parse(valuesResponse.toString());
			//logger.info(jsonResponse.toString());
			//JsonObject  jobject = jsonResponse.getAsJsonObject();
			//logger.info(valuesResponse.toString());
			//logger.info("response.getHits().totalHits = " + valuesResponse.getHits().getTotalHits().value);
			logger.info("response =" + valuesResponse.toString());

			SearchHits docHits = valuesResponse.getHits();
			//SearchHit[] docSearchHits = docHits.getHits();
			Set<String> hits = new HashSet<>();
			Arrays.stream(docHits.getHits()).forEach(hit -> {hit.getSourceAsMap().forEach((k, v) ->{
				String str = (String)v;
				if (str.contains(typeAhead) || str.contains(typeAhead.toUpperCase()))
					hits.add((String)v);
			});
			});
			logger.info(hits.toString());
			//List<Object> uniqValues = new ArrayList<>();
			
//			for (SearchHit hit : docSearchHits) {
//				Map<String, Object> sourceAsMap = hit.getSourceAsMap();
//				logger.debug(sourceAsMap);
//			}
			return hits;
		}catch (Exception e) {
			e.printStackTrace(System.err);
			return null;
		}
	}
	public static ElkData gridData(HashMap<String, String> requestMap) {
		try (RestHighLevelClient client = new RestHighLevelClient(
				RestClient.builder(HttpHost.create("http://10.100.252.130:9200")))) {
			MainResponse info = client.info(RequestOptions.DEFAULT);
			String version = info.getVersion().getNumber();
			logger.debug("version = " + version);
			String query = requestMap.get("searchItem") + "*";

			BoolQueryBuilder boolQuery = QueryBuilders.boolQuery();

			QueryStringQueryBuilder searchQuery = QueryBuilders.queryStringQuery(query)
					.field("APP_NAME",(float)10.5)
					.field("APP_DESCRIPTION",(float)10.5)
					.field("TABLE_NAME_T",(float)7.5)
					.field("TABLE_DESCRIPTION",(float)7.5)
					.field("COLUMN_NAME",(float)5.5)
					.field("COLUMN_DESCRIPTION",(float)5.5)
					.field("BUSINESS_DESCRIPTION",(float)3.5)
					.field("BUSINESS_TERM",(float)3.5);
			//is dynamic filter
			int dynaFilter = isDynamicFilter(requestMap);

			boolQuery.must(searchQuery)
					.should(QueryBuilders.termsQuery("COUNTRY.keyword", requestMap.get("country").split(",")))
					.should(QueryBuilders.termsQuery("BUSINESS_SEGMENT.keyword", requestMap.get("segment").split(",")))
					.should(QueryBuilders.termsQuery("CDE.keyword", requestMap.get("cde").split(",")))
					.should(QueryBuilders.termsQuery("CERTIFIED.keyword", requestMap.get("certified").split(",")))
					.should(QueryBuilders.termsQuery("APP_NAME.keyword", requestMap.get("appName").split(",")))
					.should(QueryBuilders.termsQuery("PII.keyword", requestMap.get("pii").split(",")))
					.should(QueryBuilders.termsQuery("TABLE_NAME_T.keyword", requestMap.get("datasetName").split(",")))
					.minimumShouldMatch(dynaFilter);

			TermsAggregationBuilder gridAgg = AggregationBuilders.terms("TABLE_NAME_T_dedup").field("TABLE_NAME_T.keyword").size(10)
					.subAggregation(AggregationBuilders.terms("COUNTRY_dedup").field("COUNTRY.keyword"))
					.subAggregation(AggregationBuilders.terms("COLUMNS_dedup").field("COLUMN_NAME.keyword").size(500))
					.subAggregation(AggregationBuilders.terms("APP_NAME_dedup").field("APP_NAME.keyword"))
					.subAggregation(AggregationBuilders.terms("APP_DESCRIPTION").field("APP_DESCRIPTION.keyword"))
					.subAggregation(AggregationBuilders.terms("ITAM_ID").field("ITAM_ID"))
					.subAggregation(AggregationBuilders.terms("TABLE_DESCRIPTION").field("TABLE_DESCRIPTION.keyword"))
					.subAggregation(AggregationBuilders.terms("BUSINESS_SEGMENT_dedup").field("BUSINESS_SEGMENT.keyword"))
					.subAggregation(AggregationBuilders.terms("PII_dedup").field("PII.keyword"))
					.subAggregation(AggregationBuilders.terms("CERTIFIED_dedup").field("CERTIFIED.keyword"))
					.subAggregation(AggregationBuilders.terms("CDE_dedup").field("CDE.keyword"));
			
			////
			TermsAggregationBuilder dynamicDatasetlst = AggregationBuilders.terms("Dynamic_Dataset").field("TABLE_NAME_T.keyword");
            TermsAggregationBuilder dynamicDatasourceLst = AggregationBuilders.terms("Dynamic_Datasource").field("APP_NAME.keyword");
            TermsAggregationBuilder dynamicCountryLst = AggregationBuilders.terms("Dynamic_Country").field("COUNTRY.keyword");
            SearchResponse aggResponse = client.search(new SearchRequest("edmp_model").source(
                    new SearchSourceBuilder().query(boolQuery).aggregation(dynamicDatasetlst)
                    .aggregation(dynamicDatasourceLst)
                    .aggregation(dynamicCountryLst)
                    .aggregation(gridAgg)), RequestOptions.DEFAULT);
            //////

			JsonElement jelement = new JsonParser().parse(aggResponse.toString());
			//logger.info(jelement.toString());

			JsonObject  jobject = jelement.getAsJsonObject();
			//logger.info("---------------------------------------------");
			//logger.info(jobject.getAsJsonObject("aggregations"));
			//logger.info("---------------------------------------------");
			//logger.info(jobject.getAsJsonObject("aggregations").getAsJsonObject("sterms#TABLE_NAME_T_dedup").get("sum_other_doc_count").getAsInt());
			//logger.info("---------------------------------------------");
			ElkData elkData = new ElkData();
            //logger.info(jobject.getAsJsonObject("aggregations").getAsJsonObject("sterms#TABLE_NAME_T_dedup").get("sum_other_doc_count"));
            elkData.setSearchCnt(jobject.getAsJsonObject("aggregations").getAsJsonObject("sterms#TABLE_NAME_T_dedup").get("sum_other_doc_count").getAsInt());
            DynamicFilters df = new DynamicFilters();
            df.setDynamicDataset(bucketToList(jobject.getAsJsonObject("aggregations").getAsJsonObject("sterms#Dynamic_Dataset").getAsJsonArray("buckets")));
            df.setDynamicDatasource(bucketToList(jobject.getAsJsonObject("aggregations").getAsJsonObject("sterms#Dynamic_Datasource").getAsJsonArray("buckets")));
            df.setDynamicCountry(bucketToList(jobject.getAsJsonObject("aggregations").getAsJsonObject("sterms#Dynamic_Country").getAsJsonArray("buckets")));
            
            //filter addition
            elkData.setDynamicFilters(df);
 
            //grid data
            JsonArray ja = jobject.getAsJsonObject("aggregations").getAsJsonObject("sterms#TABLE_NAME_T_dedup").getAsJsonArray("buckets");
            
            List<GridData> pojos = new ArrayList<>();
            ja.forEach(bucket -> {
            	GridData pojo = new GridData();
            	//logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            	pojo.setDataSetName(bucket.getAsJsonObject().get("key").getAsString());
            	
            	pojo.setCde(StringUtils.join(bucketToList(bucket.getAsJsonObject().getAsJsonObject("sterms#CDE_dedup").getAsJsonArray("buckets")), ","));
            	String segment = bucket.getAsJsonObject().getAsJsonObject("sterms#BUSINESS_SEGMENT_dedup")
            			.getAsJsonArray("buckets").getAsJsonArray().get(0).getAsJsonObject().get("key").getAsString();
            	//logger.info("-=-=-=-=-=" + segment);
            	pojo.setSegment(Arrays.asList(segment.split(",")).stream().distinct().collect(Collectors.toList()));
            	pojo.setAppName(StringUtils.join(bucketToList(bucket.getAsJsonObject().getAsJsonObject("sterms#APP_NAME_dedup").getAsJsonArray("buckets").getAsJsonArray()), ","));
            	pojo.setAppDesc(StringUtils.join(bucketToList(bucket.getAsJsonObject().getAsJsonObject("sterms#APP_DESCRIPTION").getAsJsonArray("buckets").getAsJsonArray()), ","));
            	pojo.setItamId(StringUtils.join(bucketToList(bucket.getAsJsonObject().getAsJsonObject("lterms#ITAM_ID").getAsJsonArray("buckets").getAsJsonArray()), ","));
            	pojo.setDataSetDesc(StringUtils.join(bucketToList(bucket.getAsJsonObject().getAsJsonObject("sterms#TABLE_DESCRIPTION").getAsJsonArray("buckets").getAsJsonArray()), ","));
            	pojo.setPii(StringUtils.join(bucketToList(bucket.getAsJsonObject().getAsJsonObject("sterms#PII_dedup").getAsJsonArray("buckets").getAsJsonArray()), ","));
            	pojo.setColnames(bucketToList(bucket.getAsJsonObject().getAsJsonObject("sterms#COLUMNS_dedup").getAsJsonArray("buckets").getAsJsonArray()));
            	pojo.setMatchAttribCnt(bucket.getAsJsonObject().getAsJsonObject("sterms#COLUMNS_dedup").getAsJsonArray("buckets").size()); //matched count
            	pojo.setCertified(StringUtils.join(bucketToList(bucket.getAsJsonObject().getAsJsonObject("sterms#CERTIFIED_dedup").getAsJsonArray("buckets").getAsJsonArray()), ","));
            	pojo.setCountry(bucketToList(bucket.getAsJsonObject().getAsJsonObject("sterms#COUNTRY_dedup").getAsJsonArray("buckets").getAsJsonArray()));
            	pojos.add(pojo);
            }
            );
            pojos.forEach(item->logger.info("----->" + item.toString()));

            elkData.setGridData(pojos);
            
            Aggregations termsAggregations = aggResponse.getAggregations();
            Map<String, Aggregation> termsAggregationMap = termsAggregations.getAsMap();

            Terms tableAggregation = (Terms) termsAggregationMap.get("TABLE_NAME_T_dedup" );
            
           logger.debug(tableAggregation.getBuckets().size());
           return elkData;

		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
		return null;
	}

	private static int isDynamicFilter(HashMap<String, String> requestMap) {
		int cnt = 0;
		if (StringUtils.isNotBlank(requestMap.get("country")))
			cnt++;
		if(StringUtils.isNotBlank(requestMap.get("segment")))
			cnt++;
		if(StringUtils.isNotBlank(requestMap.get("cde")))
			cnt++;
		if(StringUtils.isNotBlank(requestMap.get("certified")))
			cnt++;
		if(StringUtils.isNotBlank(requestMap.get("appName")))
			cnt++;
		if(StringUtils.isNotBlank(requestMap.get("pii")))
			cnt++;
		if(StringUtils.isNotBlank(requestMap.get("datasetName")))
			cnt++;
		return cnt;
	}

	private static List<String> bucketToList(JsonArray array) {
		List<String> lst = new ArrayList<>(); //"a", ""
		if (null != array)
			array.forEach(item -> lst.add(item.getAsJsonObject().get("key").getAsString()));

		return lst;
	}
	public static void main(String[] args) {
		HashMap<String, String> requestMap = new HashMap<>();
		requestMap.put("searchItem", "cbs");
		requestMap.put("country", "");
		requestMap.put("segment", "");
		requestMap.put("cde", "");
		requestMap.put("certified", "");
		requestMap.put("appName", "");
		requestMap.put("pii", "");
		requestMap.put("datasetName", "");//CREDITACN
		ELKUtil.typeAhead("cbs");
		//ELKUtil.gridData(requestMap);
		System.exit(0);
		try (RestHighLevelClient client = new RestHighLevelClient(
				RestClient.builder(HttpHost.create("http://10.100.252.130:9200")))) {
			MainResponse info = client.info(RequestOptions.DEFAULT);
			String version = info.getVersion().getNumber();
			logger.debug("version = " + version);
			logger.debug("**********************************");		
			
            logger.debug("SEARCH REQUEST>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
			
			logger.debug("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<grid  query");
		       String query = "*ACC*";

	            BoolQueryBuilder boolQuery = QueryBuilders.boolQuery();

	            QueryStringQueryBuilder searchQuery = QueryBuilders.queryStringQuery(query)
	            		.field("TABLE_NAME_T",(float)3.75)
	                    .field("COLUMN_NAME",(float)5.6)
	                    .field("APP_NAME",3)
	                    .field("APP_DESCRIPTION",(float)2.8)
	                    .field("BUSINESS_DESCRIPTION",(float)2.8);
	            boolQuery.must(searchQuery).should(QueryBuilders.boolQuery()
	                    .should(QueryBuilders.termsQuery("COUNTRY.keyword",""))
	                    .should(QueryBuilders.termsQuery("BUSINESS_SEGMENT.keyword",""))
	                    .should(QueryBuilders.termsQuery("CDE.keyword"," "))
	                    .should(QueryBuilders.termsQuery("CERTIFIED.keyword"," "))
	                    .should(QueryBuilders.termsQuery("APP_NAME.keyword",""))
	                    .should(QueryBuilders.termsQuery("TABLE_NAME_T.keyword",""))).minimumShouldMatch(0);


	            TermsAggregationBuilder gridAgg = AggregationBuilders.terms("TABLE_NAME_T_dedup").field("TABLE_NAME_T.keyword")
	                    .subAggregation(AggregationBuilders.terms("COUNTRY_dedup").field("COUNTRY.keyword"))
	                    .subAggregation(AggregationBuilders.terms("COLUMNS_dedup").field("COLUMN_NAME.keyword"))
	                    .subAggregation(AggregationBuilders.terms("APP_NAME_dedup").field("APP_NAME.keyword"))
	                    .subAggregation(AggregationBuilders.terms( "BUSINESS_SEGMENT_dedup").field("BUSINESS_SEGMENT.keyword"))
	                    .subAggregation(AggregationBuilders.terms("PII_dedup").field("PII.keyword"))
	                    .subAggregation(AggregationBuilders.terms( "CERTIFIED_dedup").field("CERTIFIED.keyword"))
	                    .subAggregation(AggregationBuilders.terms("CDE_dedup").field("CDE.keyword"));

	            TermsAggregationBuilder dynamicDatasetlst = AggregationBuilders.terms("Dynamic_Dataset").field("TABLE_NAME_T.keyword");
	            TermsAggregationBuilder dynamicDatasourceLst = AggregationBuilders.terms("Dynamic_Datasource").field("APP_NAME.keyword");
	            TermsAggregationBuilder dynamicCountryLst = AggregationBuilders.terms("Dynamic_Country").field("COUNTRY.keyword");
	            SearchResponse aggResponse = client.search(new SearchRequest("edmp_model").source(
	                    new SearchSourceBuilder().query(boolQuery).aggregation(dynamicDatasetlst)
	                    .aggregation(dynamicDatasourceLst)
	                    .aggregation(dynamicCountryLst)
	                    .aggregation(gridAgg)), RequestOptions.DEFAULT);
	            
//	            JSONObject SRJSON = new JSONObject(SR.toString());
	            
	            JsonElement jelement = new JsonParser().parse(aggResponse.toString());
	            logger.info(jelement.toString());
	            
	            JsonObject  jobject = jelement.getAsJsonObject();
	            
	            //logger.info(jobject.getAsJsonObject("aggregations"));
	            
	            //logger.info(jobject.getAsJsonObject("aggregations").getAsJsonObject("sterms#TABLE_NAME_T_dedup").get("sum_other_doc_count").getAsInt());
	            
	            //logger.info(jobject.getAsJsonObject("aggregations").getAsJsonObject("sterms#TABLE_NAME_T_dedup").getAsJsonArray("buckets"));
	            
	            Aggregations termsAggregations = aggResponse.getAggregations();
	            Map<String, Aggregation> termsAggregationMap = termsAggregations.getAsMap();

	            Terms tableAggregation = (Terms) termsAggregationMap.get("TABLE_NAME_T_dedup" );
	            
	           logger.debug(tableAggregation.getBuckets().size());

	            List<HashMap<String, List<Object>>> arrayList =new ArrayList<>();

			/*
			 * for (Terms.Bucket bucket1 : tableAggregation.getBuckets()) { List<Object>
			 * tableBucket = new ArrayList<>(); List<Object> countryBucket = new
			 * ArrayList<>(); List<Object> appNameBucket = new ArrayList<>(); List<Object>
			 * segBucket = new ArrayList<>(); List<Object> piiBucket = new ArrayList<>();
			 * List<Object> certifiedBucket = new ArrayList<>(); List<Object> cdeBucket =
			 * new ArrayList<>(); List<Object> matchedColsCount = new ArrayList<>();
			 * List<Object> columnsBucket = new ArrayList<>(); HashMap<String,List<Object>>
			 * hashMap = new HashMap<>(); String key1 = bucket1.getKeyAsString();
			 * tableBucket.add(key1); logger.debug( bucket1.getDocCount()); Aggregations
			 * countryAggregations = bucket1.getAggregations(); Map<String, Aggregation>
			 * countryAggregationMap = countryAggregations.getAsMap(); Terms
			 * countryAggregation = (Terms) countryAggregationMap.get("COUNTRY_dedup" );
			 * logger.debug( countryAggregation.getBuckets().size()); for (Terms.Bucket
			 * bucket2 : countryAggregation.getBuckets()){ String key2 =
			 * bucket2.getKeyAsString(); long colsCount = bucket2.getDocCount();
			 * logger.debug( colsCount); countryBucket.add(key2);
			 * matchedColsCount.add(colsCount); Aggregations columnsMatchedAggregations =
			 * bucket1.getAggregations(); Map<String, Aggregation>
			 * columnsMatchedAggregationMap = columnsMatchedAggregations.getAsMap(); Terms
			 * columnsMatchedAggregation = (Terms)
			 * columnsMatchedAggregationMap.get("COLUMNS_dedup" );
			 * logger.debug(columnsMatchedAggregation.getBuckets().size()); for
			 * (Terms.Bucket bucket8 : columnsMatchedAggregation.getBuckets()) { String key8
			 * = bucket8.getKeyAsString(); columnsBucket.add(key8); Aggregations
			 * appNameAggregations = bucket1.getAggregations(); Map<String, Aggregation>
			 * appNameAggregationMap = appNameAggregations.getAsMap(); Terms
			 * appNameAggregation = (Terms) appNameAggregationMap.get("APP_NAME_dedup");
			 * logger.debug(appNameAggregation.getBuckets().size()); for (Terms.Bucket
			 * bucket3 : appNameAggregation.getBuckets()) { String key3 =
			 * bucket3.getKeyAsString(); appNameBucket.add(key3); Aggregations
			 * businessSegAggregations = bucket1.getAggregations(); Map<String, Aggregation>
			 * businessSegAggregationMap = businessSegAggregations.getAsMap(); Terms
			 * businessSegAggregation = (Terms)
			 * businessSegAggregationMap.get("BUSINESS_SEGMENT_dedup");
			 * logger.debug(businessSegAggregation.getBuckets().size()); for (Terms.Bucket
			 * bucket4 : businessSegAggregation.getBuckets()) { String key4 =
			 * bucket4.getKeyAsString(); segBucket.add(key4); Aggregations PIIAggregations =
			 * bucket1.getAggregations(); Map<String, Aggregation> PIIAggregationMap =
			 * PIIAggregations.getAsMap(); Terms PIIAggregation = (Terms)
			 * PIIAggregationMap.get("PII_dedup");
			 * logger.debug(PIIAggregation.getBuckets().size()); for (Terms.Bucket bucket5 :
			 * PIIAggregation.getBuckets()) { String key5 = bucket5.getKeyAsString();
			 * piiBucket.add(key5); Aggregations certifiedAggregations =
			 * bucket1.getAggregations(); Map<String, Aggregation> certifiedAggregationMap =
			 * certifiedAggregations.getAsMap(); Terms certifiedAggregation = (Terms)
			 * certifiedAggregationMap.get("CERTIFIED_dedup");
			 * logger.debug(certifiedAggregation.getBuckets().size()); for (Terms.Bucket
			 * bucket6 : certifiedAggregation.getBuckets()) { String key6 =
			 * bucket6.getKeyAsString(); certifiedBucket.add(key6); Aggregations
			 * cdeAggregations = bucket1.getAggregations(); Map<String, Aggregation>
			 * cdeAggregationMap = cdeAggregations.getAsMap(); Terms cdeAggregation =
			 * (Terms) cdeAggregationMap.get("CDE_dedup");
			 * logger.debug(cdeAggregation.getBuckets().size()); if
			 * (cdeAggregation.getBuckets().size() > 0) { for (Terms.Bucket bucket7 :
			 * cdeAggregation.getBuckets()) { String key7 = bucket7.getKeyAsString();
			 * cdeBucket.add(key7);
			 * 
			 * } hashMap.put("CDE",
			 * cdeBucket.stream().distinct().collect(Collectors.toList())); } else {
			 * cdeBucket.add("N"); hashMap.put("CDE",
			 * cdeBucket.stream().distinct().collect(Collectors.toList())); }
			 * 
			 * hashMap.put("Certified",
			 * certifiedBucket.stream().distinct().collect(Collectors.toList())); }
			 * hashMap.put("PII",
			 * piiBucket.stream().distinct().collect(Collectors.toList())); }
			 * hashMap.put("Segment",
			 * segBucket.stream().distinct().collect(Collectors.toList())); }
			 * hashMap.put("Data Sources",
			 * appNameBucket.stream().distinct().collect(Collectors.toList())); }
			 * hashMap.put("Attributes",
			 * columnsBucket.stream().distinct().collect(Collectors.toList())); }
			 * hashMap.put("Country/Instance",countryBucket);
			 * hashMap.put("Matched Attributes",matchedColsCount.stream().distinct().collect
			 * (Collectors.toList())); }
			 * 
			 * hashMap.put("Dataset Name",tableBucket); arrayList.add(hashMap); }
			 */
			/*
			 * arrayList.forEach((list) -> { list.forEach((k, v) -> System.out.println(k +
			 * "->" + v)); });
			 */
	            
	            logger.debug(arrayList.size());
			
			logger.debug("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<dynamic selection  filter  query based on attribute");

			 TermsAggregationBuilder aggTableName_T = AggregationBuilders.terms("TABLE_NAME_T_dedup")
                    .field("TABLE_NAME_T.keyword").size(16567);

			//TermQueryBuilder termQuery =  QueryBuilders.termQuery("COUNTRY.keyword","*");
			SearchResponse termResponse = client.search(new SearchRequest("edmp_model").source(
					new SearchSourceBuilder().aggregation(aggTableName_T)), RequestOptions.DEFAULT);
			JsonElement je = new JsonParser().parse(termResponse.toString());
			logger.info("===========" + je.toString());
			Aggregations tableName_T_Aggregations = termResponse.getAggregations();
            Map<String, org.elasticsearch.search.aggregations.Aggregation> tableName_T_AggregationMap = tableName_T_Aggregations.getAsMap();
            Terms tableName_T_Aggregation = (Terms) tableName_T_AggregationMap.get("TABLE_NAME_T_dedup");
            logger.debug(tableName_T_Aggregation.getBuckets().size());
            
            List<String> tableName_T_List = new ArrayList<>();
            for (Terms.Bucket bucket : tableName_T_Aggregation.getBuckets()) {

                String key = bucket.getKeyAsString();
                tableName_T_List.add(key);

            }
            logger.debug(tableName_T_List);
			
        } catch (Exception e) {
			e.printStackTrace(System.err);
		}


		}

}
