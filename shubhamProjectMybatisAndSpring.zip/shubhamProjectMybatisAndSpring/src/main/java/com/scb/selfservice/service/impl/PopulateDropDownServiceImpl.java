package com.scb.selfservice.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.PopulateDropDownMapper;
import com.scb.selfservice.dao.td.mapper.ConsumptionMasterMapper;
import com.scb.selfservice.domains.AdRoleGroup;
import com.scb.selfservice.domains.EDMPLookupTable;
import com.scb.selfservice.domains.databaseentity.DBAdRoleGroup;
import com.scb.selfservice.service.PopulateDropDownService;
import com.scb.selfservice.util.Response;

@Service
public class PopulateDropDownServiceImpl implements PopulateDropDownService{

	@Autowired
	private PopulateDropDownMapper populateDropDownMapper; 
	
	@Autowired
	private ConsumptionMasterMapper consumptionMasterMapper;
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public Response getDropDownValues() {
		// TODO Auto-generated method stub
		List<EDMPLookupTable> lookupTables = populateDropDownMapper.getDropDownValues();
		Response lookupTableresponse =new Response();
		if (lookupTables.isEmpty()) {
			lookupTableresponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			lookupTableresponse.setStatus(HttpStatus.NO_CONTENT.toString());
		} else {
			lookupTableresponse.setStatusCode(HttpStatus.OK.value());
			lookupTableresponse.setStatus(HttpStatus.OK.toString());
			lookupTableresponse.setResponse(lookupTables);
		}
		
		return lookupTableresponse;
	}

	/**
	 * Method to get the Consumer AD Role from the TD Existing Consumption Master table
	 */
	@Override
	@Transactional(value = "transactionManagerTD", propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public Response getConsumerAdRole() {
		//List<DBAdRoleGroup> dbAdRoleGroupList = consumptionMasterMapper.getConsumptionMasterADRole();
		List<DBAdRoleGroup> dbAdRoleGroupList = populateDropDownMapper.getConsumerAdRole();
		Response adRoleresponse = new Response();
		if (dbAdRoleGroupList.isEmpty()) {
			adRoleresponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			adRoleresponse.setStatus(HttpStatus.NO_CONTENT.toString());
		} else {
			List<AdRoleGroup> adRoleGroupList = new ArrayList<AdRoleGroup>();
			for (DBAdRoleGroup dbAdRoleGroup : dbAdRoleGroupList) {
				
				List<String> adGroupNameList = Arrays.asList(dbAdRoleGroup.getAdGroupName().split("\\s*,\\s*")).stream().sorted().collect(Collectors.toList());
				AdRoleGroup adRoleGroup = new AdRoleGroup();
				adRoleGroup.setBizFunctId(dbAdRoleGroup.getBizFunctId());
				adRoleGroup.setBizFuncName(dbAdRoleGroup.getBizFuncName());
				adRoleGroup.setAdGroupName(adGroupNameList);
				adRoleGroupList.add(adRoleGroup);
			}
			adRoleresponse.setStatusCode(HttpStatus.OK.value());
			adRoleresponse.setStatus(HttpStatus.OK.toString());
			adRoleresponse.setResponse(adRoleGroupList);
		}
		
		return adRoleresponse;
	}

}
