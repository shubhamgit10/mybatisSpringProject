/**
 * 
 */
package com.scb.selfservice.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

/**
 * HttpUtils class for retrieving data using HTTP Connection
 * 
 * @author Amarnath BB
 *
 */
public class HttpUtils {

	/**
	 * Method to retrieve Bridge Profile data
	 * 
	 * @param userId
	 * @return
	 */
	public static String retrieveBridgeProfileId(String userId) {
		try {
			URL url = new URL("https://thebridge.zone1.scb.net/people/" + userId);
			HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
			BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String input;
			while ((input = br.readLine()) != null) {
				System.out.println(input);
			}
			br.close();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public static void main(String[] args) {
		HttpUtils.retrieveBridgeProfileId("1565003");
	}

}
