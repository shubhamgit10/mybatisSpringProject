/**
 * 
 */
package com.scb.selfservice.workflow.service;

/**
 * @author 1565003
 *
 */
public class ExecutionContext {
	
	/**
	 * Empty Constructor
	 */
	public ExecutionContext() {
		
	}	
	
	private String reqId;
	private String stepId;
	
	/**
	 * Indicate whether the action was Approve or Reject
	 */
	private String action;
	
	/**
	 * User actioned
	 */
	private String actionedBy;
	/**
	 * @return the reqId
	 */
	public String getReqId() {
		return reqId;
	}
	/**
	 * @param reqId the reqId to set
	 */
	public void setReqId(String reqId) {
		this.reqId = reqId;
	}
	/**
	 * @return the stepId
	 */
	public String getStepId() {
		return stepId;
	}
	/**
	 * @param stepId the stepId to set
	 */
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	/**
	 * @return the actionedBy
	 */
	public String getActionedBy() {
		return actionedBy;
	}
	/**
	 * @param actionedBy the actionedBy to set
	 */
	public void setActionedBy(String actionedBy) {
		this.actionedBy = actionedBy;
	}
	
	

}
