package com.scb.selfservice.isd.entity;

public class ISDSummary {

	private int reqId;
	private String instanceName;
	private String existingDatasets;
	private String newDatasets;
	private String existingAttributes;
	private String newAttributes;
	public int getReqId() {
		return reqId;
	}
	public String getInstanceName() {
		return instanceName;
	}
	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}
	public String getExistingDatasets() {
		return existingDatasets;
	}
	public void setExistingDatasets(String existingDatasets) {
		this.existingDatasets = existingDatasets;
	}
	public String getNewDatasets() {
		return newDatasets;
	}
	public void setNewDatasets(String newDatasets) {
		this.newDatasets = newDatasets;
	}
	public String getExistingAttributes() {
		return existingAttributes;
	}
	public void setExistingAttributes(String existingAttributes) {
		this.existingAttributes = existingAttributes;
	}
	public String getNewAttributes() {
		return newAttributes;
	}
	public void setNewAttributes(String newAttributes) {
		this.newAttributes = newAttributes;
	}
	public void setReqId(int reqId) {
		this.reqId = reqId;
	}
	@Override
	public String toString() {
		return "ISDSummary [reqId=" + reqId + ", instanceName=" + instanceName + ", existingDatasets="
				+ existingDatasets + ", newDatasets=" + newDatasets + ", existingAttributes=" + existingAttributes
				+ ", newAttributes=" + newAttributes + "]";
	}
	
	
	
	
}
