package com.scb.selfservice.model.RangerPolicy;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author 1610601
 *
 */
public class RangerPolicyResourceSupportingModel {
	
	private List<String> values;
	private boolean isExcludes;
	private boolean isRecursive;
	
	/**
	 * 
	 */
	public RangerPolicyResourceSupportingModel() {
		super();
		this.values = new ArrayList<String> ();
		this.isExcludes = false;
		this.isRecursive = false;
	}

	/**
	 * @param values
	 * @param isExcludes
	 * @param isRecursive
	 */
	public RangerPolicyResourceSupportingModel(List<String> values, boolean isExcludes, boolean isRecursive) {
		super();
		this.values = values;
		this.isExcludes = isExcludes;
		this.isRecursive = isRecursive;
	}

	/**
	 * @return the values
	 */
	public List<String> getValues() {
		return values;
	}

	/**
	 * @param values the values to set
	 */
	public void setValues(List<String> values) {
		this.values = values;
	}

	/**
	 * @return the isExcludes
	 */
	public boolean isExcludes() {
		return isExcludes;
	}

	/**
	 * @param isExcludes the isExcludes to set
	 */
	public void setExcludes(boolean isExcludes) {
		this.isExcludes = isExcludes;
	}

	/**
	 * @return the isRecursive
	 */
	public boolean isRecursive() {
		return isRecursive;
	}

	/**
	 * @param isRecursive the isRecursive to set
	 */
	public void setRecursive(boolean isRecursive) {
		this.isRecursive = isRecursive;
	}

	@Override
	public String toString() {
		return "RangerPolicyResourceSupportingModel [values=" + values + ", isExcludes=" + isExcludes + ", isRecursive="
				+ isRecursive + "]";
	}
	
}
