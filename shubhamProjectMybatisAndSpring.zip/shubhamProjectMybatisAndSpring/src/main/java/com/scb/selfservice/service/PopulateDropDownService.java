package com.scb.selfservice.service;

import com.scb.selfservice.util.Response;

public interface PopulateDropDownService {

	public Response getDropDownValues();
	
	public Response getConsumerAdRole();
	
}
