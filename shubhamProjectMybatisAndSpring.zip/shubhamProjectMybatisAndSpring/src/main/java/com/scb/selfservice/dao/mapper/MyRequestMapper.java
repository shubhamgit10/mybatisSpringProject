package com.scb.selfservice.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.EDMPConsumReqUserResp;
import com.scb.selfservice.domains.MyrequestData;
import com.scb.selfservice.domains.WorkflowReqStepsAt;

public interface MyRequestMapper {
	
	public List<MyrequestData> getMyRequest(@Param("userId") Integer userId,
				@Param("workflowId") Integer workflowId, 
				@Param("workflowType") String workflowType);
	
	public List<EDMPConsumReqUserResp> getApprovalResponse(@Param("requestId") Integer requestId, @Param("workflowId") Integer workflowId);
	
	public List<EDMPConsumReqUserResp> getApprovalResponseFileID(@Param("requestId") Integer requestId, @Param("workflowId") Integer workflowId);

	//mapper to cancel requestor's workflow_request
	public int cancelRequestWorkflowRequest(@Param("audit") WorkflowReqStepsAt audit);

	//mapper to cancel requestor's workflow_request_steps
	public int cancelRequestWorkflowRequestSteps(@Param("audit") WorkflowReqStepsAt audit);

	//mapper to mark cancel in edmp_serlfservice_req
	public int CancelRequestEdmpSelfServiceReq(@Param("audit") WorkflowReqStepsAt audit);
	
	//My Ingestion Request list
	public List<MyrequestData> getMyIngestionRequest(@Param("userId") Integer userId, 
			@Param("workflowId") Integer workflowId,
			@Param("workflowType") String workflowType);
}
