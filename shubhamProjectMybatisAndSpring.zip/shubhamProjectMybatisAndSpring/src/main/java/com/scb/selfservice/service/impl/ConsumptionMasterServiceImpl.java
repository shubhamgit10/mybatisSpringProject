/**
 * 
 */
package com.scb.selfservice.service.impl;

import java.sql.Timestamp;
import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.RequestDetailsMapper;
import com.scb.selfservice.dao.td.mapper.ConsumptionMasterMapper;
import com.scb.selfservice.domains.WorkflowReqStepsAt;
import com.scb.selfservice.domains.WorkflowRequestStep;
import com.scb.selfservice.http.RangerPolicyV2Util;
import com.scb.selfservice.model.ConsumptionRequestInfo;
import com.scb.selfservice.service.ConsumptionMasterService;
import com.scb.selfservice.service.RangerPolicyService;
import com.scb.selfservice.workflow.service.WorkflowRequestService;

/**
 * Consumption Master Service for managing Consumer Master data
 * 
 * @author Amarnath BB
 *
 */
@Service
public class ConsumptionMasterServiceImpl implements ConsumptionMasterService {

	@Autowired
	private ConsumptionMasterMapper consumptionMasterMapper;

	@Autowired
	private RequestDetailsMapper requestDetailsMapper;

	@Autowired
	WorkflowRequestService workflowRequestService;
	
	@Autowired
	RangerPolicyService rangerPolicyService;
	
	protected static Logger logger = LogManager.getLogger(ConsumptionMasterServiceImpl.class);

	/**
	 * Method to retrieve the request details for creating Consumption Master
	 * 
	 * @param reqId
	 * @return
	 */
	@Override
	@Transactional(value = "transactionManager", propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public ConsumptionRequestInfo retrieveRequestDetails(String reqId) {
		ConsumptionRequestInfo result = new ConsumptionRequestInfo();
		result.setRequestDetails(requestDetailsMapper.getRequestDetails(reqId));
		result.setTablesSubscribed(requestDetailsMapper.getDatasetSubscribed(reqId));
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.scb.selfservice.service.ConsumptionMasterService#
	 * createNewConsumerMaster()
	 */
	@Override
	@Transactional(value = "transactionManagerTD", propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public String createOrUpdateConsumerMaster(String reqId, ConsumptionRequestInfo data) {
		String message = null;
		HashMap<String, String> requestData = data.getRequestDetails();
		requestData.put("REQ_ID", reqId);
		String consumerId;
		if ("1".equalsIgnoreCase(requestData.get("IS_RELATED_EXIST_REQ"))) {
			consumerId = requestData.get("EXISTING_REQ");
			requestData.put("CONSUMER_ID", consumerId);
			consumptionMasterMapper.updateConsumptionMaster(requestData);
		}
		else {
			consumerId = StringUtils.substring(requestData.get("CONSUMER_APP_NAME"), 0, 12) + "-" + reqId;
			requestData.put("CONSUMER_ID", consumerId);
			String existingConsumer = consumptionMasterMapper.getSLAMetaByConsumerId(consumerId);
			if (existingConsumer == null)
				consumptionMasterMapper.createNewConsumptionRequest(requestData);
		}
		
		consumptionMasterMapper.insertTabDetails(consumerId, data.getTablesSubscribed());	
		consumptionMasterMapper.insertSLAMetaDetails(requestData);
		consumptionMasterMapper.insertADGroupDetails(requestData);
		int recordsProcessed = consumptionMasterMapper.getProcessedCountRecords(consumerId);
		if (recordsProcessed != data.getTablesSubscribed().size()) {
			message = "Mismatch in the numnber of records created in T_OPS_FILE_METADATA for Consumer Id - " 
					+ consumerId + ". This could indicate data not found in T_OPS_FILE_METADATA Table for some of the table";
		}
		consumptionMasterMapper.deleteTabDetails(consumerId);
		return message;
	}

	/**
	 * Method to create Audit Trail of consumption Master creation
	 * 
	 * @param reqId
	 * @param stepId
	 * @param userId
	 */
	@Override
	@Transactional(value = "transactionManager", propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public void createAuditTrailsData(Integer reqId, String stepId, String userId, String status, String remarks) {			
		try {
			if(!"success".equalsIgnoreCase(status)) {
				logger.info("Pushing back the request to INITIATE FULLFILMENT Step for the ReqId : " + reqId);
				String parentStepId = rangerPolicyService.getParentStepId(reqId.longValue(), String.valueOf(stepId));
				WorkflowRequestStep workflowRequestStep = new WorkflowRequestStep(reqId.intValue(), 
						parentStepId, "PENDING", "", new Timestamp(System.currentTimeMillis()), 
						null, "FULLFILMENT", null, Integer.valueOf(userId), "");
				logger.info("With WorkflowRequestStep details : " +workflowRequestStep);
				workflowRequestService.updateWorkflowReqSteps(workflowRequestStep);
			}
			
			WorkflowReqStepsAt workflowReqStepsAt = new WorkflowReqStepsAt();
			workflowReqStepsAt.setReqId(reqId.intValue());
			
			workflowReqStepsAt.setStepActionedBy(Integer.valueOf(userId));
			workflowReqStepsAt.setWorkflowId(workflowRequestService.getWorkflowRequestWorkflowId(reqId.intValue()));
			workflowReqStepsAt.setStepId(requestDetailsMapper.getStepId(""+workflowReqStepsAt.getWorkflowId(), "CONSUMPTION_MASTER_STEPUP"));
			workflowReqStepsAt.setStartTime(new Timestamp(System.currentTimeMillis()));
			workflowReqStepsAt.setStepPendingGrp(null);
			workflowReqStepsAt.setStatus("SUCCESS".equalsIgnoreCase(status) ? "COMPLETED" : status);
			workflowReqStepsAt.setRemarks(remarks);
			workflowRequestService.insertIntoWorkflowReqStepsAt(workflowReqStepsAt);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
