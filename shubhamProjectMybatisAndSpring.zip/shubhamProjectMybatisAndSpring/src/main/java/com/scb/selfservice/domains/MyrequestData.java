package com.scb.selfservice.domains;

import java.sql.Timestamp;

public class MyrequestData {
	
	private Integer requestID;
	private String requestSummary;	
	private String requestCreatedBy;
	private Timestamp requestCreatedAt;
	private String status;
	private String statusPendingBy;
	private String statusApprovedBy;
	private String interimStatus;
	private String stepId;
	private String sourceSystem;
	private String requestSubmissionDate;
	private String requestType;
	private String requestModifiedBy;
	private String requestModifiedAt;
	
	public Integer getRequestID() {
		return requestID;
	}

	public void setRequestID(Integer requestID) {
		this.requestID = requestID;
	}

	public String getRequestSummary() {
		return requestSummary;
	}

	public void setRequestSummary(String requestSummary) {
		this.requestSummary = requestSummary;
	}

	public String getRequestCreatedBy() {
		return requestCreatedBy;
	}

	public void setRequestCreatedBy(String requestCreatedBy) {
		this.requestCreatedBy = requestCreatedBy;
	}

	public Timestamp getRequestCreatedAt() {
		return requestCreatedAt;
	}

	public void setRequestCreatedAt(Timestamp requestCreatedAt) {
		this.requestCreatedAt = requestCreatedAt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusPendingBy() {
		return statusPendingBy;
	}

	public void setStatusPendingBy(String statusPendingBy) {
		this.statusPendingBy = statusPendingBy;
	}

	public String getStatusApprovedBy() {
		return statusApprovedBy;
	}

	public void setStatusApprovedBy(String statusApprovedBy) {
		this.statusApprovedBy = statusApprovedBy;
	}

	public String getInterimStatus() {
		return interimStatus;
	}

	public void setInterimStatus(String interimStatus) {
		this.interimStatus = interimStatus;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}


	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getRequestSubmissionDate() {
		return requestSubmissionDate;
	}

	public void setRequestSubmissionDate(String requestSubmissionDate) {
		this.requestSubmissionDate = requestSubmissionDate;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getRequestModifiedBy() {
		return requestModifiedBy;
	}

	public void setRequestModifiedBy(String requestModifiedBy) {
		this.requestModifiedBy = requestModifiedBy;
	}

	public String getRequestModifiedAt() {
		return requestModifiedAt;
	}

	public void setRequestModifiedAt(String requestModifiedAt) {
		this.requestModifiedAt = requestModifiedAt;
	}

	@Override
	public String toString() {
		return "MyrequestData [requestID=" + requestID + ", requestSummary=" + requestSummary + ", requestCreatedBy="
				+ requestCreatedBy + ", requestCreatedAt=" + requestCreatedAt + ", status=" + status
				+ ", statusPendingBy=" + statusPendingBy + ", statusApprovedBy=" + statusApprovedBy + ", interimStatus="
				+ interimStatus + ", stepId=" + stepId + ", sourceSystem=" + sourceSystem + ", requestSubmissionDate="
				+ requestSubmissionDate + ", requestType=" + requestType + ", requestModifiedBy=" + requestModifiedBy
				+ ", requestModifiedAt=" + requestModifiedAt + "]";
	}

	
}
