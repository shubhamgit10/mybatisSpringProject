/**
 * 
 */
package com.scb.selfservice.util;

import java.io.File;
import java.nio.charset.Charset;

import org.apache.commons.io.FileUtils;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

/**
 * App Encryption to encrypt and decrypt the password
 * 
 * @author Amarnath BB
 *
 */
public class AppEncryption {
	
	private static String SECRET_TEXT = "St@nd@rd!23";
	
	/**
	 * Method to encrypt the text
	 * 
	 * @param password
	 * @return
	 */
	public static String encrypt(String password) {
		StandardPBEStringEncryptor textEncryptor = new StandardPBEStringEncryptor();
		textEncryptor.setPassword(SECRET_TEXT);
		return textEncryptor.encrypt(password);
	}
	
	/**
	 * Method to decrypt the password
	 * 
	 * @param password
	 * @return
	 */
	public static String decrypt(String encryTxt) {
		StandardPBEStringEncryptor textEncryptor = new StandardPBEStringEncryptor();
		textEncryptor.setPassword(SECRET_TEXT);
		return textEncryptor.decrypt(encryTxt);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		if (args.length <= 2) {
			System.out.println("Insufficient Params. Usage ./encryptTool.sh KEY OUTPUT_PATH");
			System.exit(-1);
		}
		try {
			String key = args[0];
			String password = args[1];
			String rootPath = args[2];
            String fileName = "encrypt-config.dat";
            File f = new File(rootPath, fileName); 
            StringBuilder sb = new StringBuilder();
            sb.append(key);
            sb.append("=");
            sb.append(AppEncryption.encrypt(password));
            sb.append("\n");
            if (!f.exists()) 
            	FileUtils.write(f, sb.toString(), Charset.forName("UTF-8"), false);
            else
            	FileUtils.write(f, sb.toString(), Charset.forName("UTF-8"), true);  
            System.out.println("Password encrypted and store securely in the file");            
        }
		catch (Exception ex) {
			ex.printStackTrace();
	}
	}


}
