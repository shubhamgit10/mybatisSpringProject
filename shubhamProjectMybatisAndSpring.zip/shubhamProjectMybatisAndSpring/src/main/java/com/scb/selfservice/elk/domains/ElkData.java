package com.scb.selfservice.elk.domains;

import java.util.List;

/*
 * pojo to hold elk global search related data
 */
public class ElkData {

	private Integer searchCnt;
	private List<GridData> gridData;
	private DynamicFilters dynamicFilters;

	public Integer getSearchCnt() {
		return searchCnt;
	}
	public void setSearchCnt(Integer searchCnt) {
		this.searchCnt = searchCnt;
	}
	public List<GridData> getGridData() {
		return gridData;
	}
	public void setGridData(List<GridData> gridData) {
		this.gridData = gridData;
	}
	public DynamicFilters getDynamicFilters() {
		return dynamicFilters;
	}
	public void setDynamicFilters(DynamicFilters dynamicFilters) {
		this.dynamicFilters = dynamicFilters;
	}
	
}
