package com.scb.selfservice.model;

import java.io.BufferedReader;

import org.springframework.http.HttpStatus;

public class ServerResponse {
	
	private int statusCode;
	private String statusMessage;
	private BufferedReader dataReader;
	private Object output;
	
	/**
	 * @param statusCode
	 * @param statusMessage
	 */
	public ServerResponse(int statusCode, String statusMessage) {
		super();
		this.statusCode = statusCode;
		this.statusMessage = statusMessage;
	}
	
	/**
	 * @param statusCode
	 * @param statusMessage
	 */
	public ServerResponse(HttpStatus statusCode, String statusMessage) {
		super();
		this.statusCode = statusCode.value();
		this.statusMessage = statusMessage;
	}
	
	public ServerResponse() {
	}

	/**
	 * @return the statusCode
	 */
	public int getStatusCode() {
		return statusCode;
	}
	
	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	
	/**
	 * @return the statusMessage
	 */
	public String getStatusMessage() {
		return statusMessage;
	}
	
	/**
	 * @param statusMessage the statusMessage to set
	 */
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	
	/**
	 * @return the data
	 */
	public BufferedReader getDataReader() {
		return dataReader;
	}
	
	/**
	 * @param data the data to set
	 */
	public void setDataReader(BufferedReader dataReader) {
		this.dataReader = dataReader;
	}

	/**
	 * @return the output
	 */
	public Object getOutput() {
		return output;
	}

	/**
	 * @param output the output to set
	 */
	public void setOutput(Object output) {
		this.output = output;
	}

	@Override
	public String toString() {
		return "ServerResponse [statusCode=" + statusCode + ", statusMessage=" + statusMessage + ", output=" + output + "]";
	}
	
}
