/**
 * 
 */
package com.scb.selfservice.web.authentication;

import org.springframework.security.core.GrantedAuthority;

/**
 * @author Amarnath BB
 *
 */
public class UserGroup implements GrantedAuthority {

	String authority;

	public UserGroup(String a) {
		this.authority = a;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.security.core.GrantedAuthority#getAuthority()
	 */
	@Override
	public String getAuthority() {
		return authority;
	}

	/**
	 * toString method
	 */
	public String toString() {
		return authority;
	}

}
