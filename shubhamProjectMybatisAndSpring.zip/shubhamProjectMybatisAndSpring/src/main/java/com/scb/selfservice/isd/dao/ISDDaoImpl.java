package com.scb.selfservice.isd.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.scb.selfservice.dao.mapper.EdmpIngestionRequestMapper;
import com.scb.selfservice.dao.mapper.isd.IsdServiceMapper;
import com.scb.selfservice.isd.entity.ExceptionCategory;
import com.scb.selfservice.isd.entity.ExceptionCategoryProtocol;
import com.scb.selfservice.isd.entity.ISDConfiguration;
import com.scb.selfservice.isd.entity.ISDRequestDetails;
import com.scb.selfservice.isd.entity.ISDTemplateInfo;
import com.scb.selfservice.isd.entity.ISDVerificationStatus;
import com.scb.selfservice.isd.entity.ViewExceptions;
import com.scb.selfservice.isd.exception.InvalidFileException;

/**
 * @author akuma400
 *
 */
@Repository
public class ISDDaoImpl {
	// @Autowired
	// JdbcTemplate template;

	/*
	 * @Autowired
	 * 
	 * @Qualifier(value="transactionManager") private DataSourceTransactionManager
	 * basicDataSource;
	 */

	private static Logger log = LogManager.getLogger(ISDDaoImpl.class);

	@Autowired
	private IsdServiceMapper isdServiceMapper;
	
	@Autowired
	private EdmpIngestionRequestMapper ingestionReqMapper;

	private JdbcTemplate template;

	public ISDDaoImpl(@Qualifier("transactionManager") DataSourceTransactionManager basicDataSource) {
		template = new JdbcTemplate();
		template.setDataSource(basicDataSource.getDataSource());
	}

	public void saveISDRecord(int reqId, List<Map<String, String>> listOfRecords, ISDTemplateInfo isdTemplateInfo,
			String sheetDBTableName) {
		log.info("saveISDRecord:Start");
		isdServiceMapper.deleteLastISDTemplate(reqId, sheetDBTableName.strip());
		saveISDTemplateRecord(reqId, listOfRecords, isdTemplateInfo, sheetDBTableName);
		log.info("saveISDRecord:end");

	}

	private void saveISDTemplateRecord(int reqId, List<Map<String, String>> listOfRecords,
			ISDTemplateInfo isdTemplateInfo, String sheetDBTableName) {
		log.info("saveISDTemplateRecord:start");
		SimpleJdbcInsert insertActor = new SimpleJdbcInsert(template.getDataSource());
		log.info("saveISDTemplateRecord:listOfRecords.size():"+listOfRecords.size());
		Map<String, Object>[] batch = new Map[listOfRecords.size()];
		for (int i = 0; i < batch.length; i++) {

			insertActor.withTableName(sheetDBTableName);
			Map<String, Object> params = new HashMap<>();
			params.put("req_Id", reqId);
			listOfRecords.get(i).forEach((k, v) -> {
				int index = isdTemplateInfo.getCellColumnNumber().indexOf((k.split("(?<=\\D)(?=\\d)"))[0]);
				String dbColumnName = isdTemplateInfo.getDbColumnName().get(index);
				params.put(dbColumnName, v);
			});
			batch[i] = params;
		}
		try {
		insertActor.executeBatch(batch);
		}catch (Exception e) {
			log.error("saveISDTemplateRecord:No contents added to the sheet: " +sheetDBTableName);
			e.printStackTrace();
		throw new InvalidFileException("No contents added to the sheet: " +sheetDBTableName);
		}
		
		log.info("saveISDTemplateRecord:end");
	}

	public ISDTemplateInfo findAll(String sheetName) {
		log.info("findAll:start");

		String sql = "SELECT * FROM ISD_Template_Info where SHEET_NAME=?";

		ISDTemplateInfo isdInfo = new ISDTemplateInfo();
		List<String> cellColumnNumber = new ArrayList<>();
		List<String> sequenceNumber = new ArrayList<>();
		List<String> columnName = new ArrayList<>();
		List<String> dbColumnName = new ArrayList<>();
		List<Boolean> nullable = new ArrayList<>();
		isdInfo.setSheetName(sheetName);
		isdInfo.setIsdId("1");
		SqlRowSet rowSet = template.queryForRowSet(sql, new Object[] { sheetName });
		while (rowSet.next()) {
			cellColumnNumber.add(rowSet.getString("CELL_COLUMN_NUMBER"));
			sequenceNumber.add(rowSet.getString("SEQUENCE_NUMBER"));
			columnName.add(rowSet.getString("COLUMN_NAME"));
			dbColumnName.add(rowSet.getString("DB_COLUMN_NAME"));
			nullable.add((rowSet.getString("VALIDATE_NULL").equals("Y")) ? true : false);
		}
		isdInfo.setCellColumnNumber(cellColumnNumber);
		isdInfo.setSequenceNumber(sequenceNumber);
		isdInfo.setColumnName(columnName);
		isdInfo.setDbColumnName(dbColumnName);
		isdInfo.setNullable(nullable);
		log.info("findAll:end");
		return isdInfo;

	}

	public Map<String, String> getAllSheets() {
		log.info("getAllSheets:start");
		String sql = "select distinct SHEET_NAME,  SHEET_TABLE_NAME from ISD_Template_Info";
		Map<String, String> sheetNameAndsheetDBTableName = new HashMap<>();
		SqlRowSet rowSet = template.queryForRowSet(sql);
		while (rowSet.next()) {
			sheetNameAndsheetDBTableName.put(rowSet.getString("SHEET_NAME"), rowSet.getString("SHEET_TABLE_NAME"));
		}
		log.info("getAllSheets:end");
		return sheetNameAndsheetDBTableName;
	}

	public List<ExceptionCategory> mapExceptions(int reqId,
			Map<String, Map<String, List<String>>> validationPerSheet, Integer latestVersion,
			Map<String, Map<String, String>> refValueOfNullCheckPerSheet) {
		log.info("mapExceptions:start");
		ExceptionCategoryProtocol exceptionCategory = getSampleExceptionCategoryProtocol();
		Map<String, List<String>> errorCountPerCategory = new HashMap<String, List<String>>();
		Map<String, List<String>> errorCellIdPerCategory = new HashMap<String, List<String>>();
		Map<String, Integer> otherExceptions = new HashMap<>();
		validationPerSheet.forEach((k, v) -> {
			if (k.equals("Source_Field_Layout_Target Map") && v.containsKey("invalidTableName")) {
				errorCountPerCategory.put("invalidTableName", v.get("invalidTableName"));
			}

			if (k.equals("Source_Field_Layout_Target Map") && v.containsKey("invalidTargetTableName")) {
				errorCountPerCategory.put("invalidTargetTableName", v.get("invalidTargetTableName"));
			}

			if (k.equals("Source_Table layout") && v.containsKey("invalidDateFormatInFileName")) {
				errorCountPerCategory.put("invalidDateFormatInFileName", v.get("invalidDateFormatInFileName"));
			}

			if (k.equals("Source_Table layout") && v.containsKey("invalidDateFormatInData")) {
				errorCountPerCategory.put("invalidDateFormatInData", v.get("invalidDateFormatInData"));
			}

			if (v.containsKey("nullException")) {
				List<String> list = new ArrayList<>();
				List<String> listRowId = new ArrayList<>();
				list.addAll(v.get("nullException").stream().map(y -> y.split("(?<=\\D)(?=\\d)")[0])
						.collect(Collectors.toList()));
				errorCountPerCategory.put(k, list);

				listRowId.addAll(v.get("nullException"));
				errorCellIdPerCategory.put(k, listRowId);
			}

			if (v.containsKey("filesCountError")) {
				otherExceptions.put("filesCountError", Integer.parseInt(v.get("filesCountError").get(0).toString()));
			}

			if (v.containsKey("attributesCountError")) {
				otherExceptions.put("attributesCountError",
						Integer.parseInt(v.get("attributesCountError").get(0).toString()));
			}

			if (v.containsKey("requestedCountyException")) {
				otherExceptions.put("requestedCountyException",
						Integer.parseInt(v.get("requestedCountyException").get(0).toString()));
			}
		});

		log.info("mapExceptions:end");
		return saveExceptionCounts(reqId, exceptionCategory, errorCountPerCategory, errorCellIdPerCategory,
				latestVersion, otherExceptions, refValueOfNullCheckPerSheet);
	}

	private List<ExceptionCategory> saveExceptionCounts(int reqId,
			ExceptionCategoryProtocol exceptionCategoryProtocol, Map<String, List<String>> errorCountPerCategory,
			Map<String, List<String>> errorCellIdPerCategory, Integer latestVersion,
			Map<String, Integer> otherExceptions, Map<String, Map<String, String>> refValueOfNullCheckPerSheet) {
		log.info("saveExceptionCounts:start");

		List<ExceptionCategory> listOfExceptions = new ArrayList<ExceptionCategory>();

		for (int i = 0; i < exceptionCategoryProtocol.getIssueCategory().size(); i++) {
			ExceptionCategory exceptionCategory = new ExceptionCategory();
			if (exceptionCategoryProtocol.getDescription().get(i).equalsIgnoreCase("NullCount")) {
				int total = Collections.frequency(
						errorCountPerCategory.get(exceptionCategoryProtocol.getSheetName().get(i)),
						exceptionCategoryProtocol.getColumnId().get(i));
				if (total > 0) {
					if (!exceptionCategoryProtocol.getColumnsImpacted().get(i).equals("NA")) {
						exceptionCategory.setColumnsImpacted(String.valueOf(total));
						exceptionCategory.setTablesImpacted("NA");
						exceptionCategory.setDescription(getDetailedInfo(
								errorCellIdPerCategory.get(exceptionCategoryProtocol.getSheetName().get(i)),
								exceptionCategoryProtocol.getColumnId().get(i),
								exceptionCategoryProtocol.getColumnId().get(i),
								exceptionCategoryProtocol.getSheetName().get(i), refValueOfNullCheckPerSheet));
					}
					if (!exceptionCategoryProtocol.getTablesImpacted().get(i).equals("NA")
							&& exceptionCategoryProtocol.getDescription().get(i).equalsIgnoreCase("NullCount")) {
						exceptionCategory.setTablesImpacted(String.valueOf(total));
						exceptionCategory.setColumnsImpacted("NA");
						exceptionCategory.setDescription(getDetailedInfo(
								errorCellIdPerCategory.get(exceptionCategoryProtocol.getSheetName().get(i)),
								exceptionCategoryProtocol.getColumnId().get(i),
								exceptionCategoryProtocol.getColumnId().get(i),
								exceptionCategoryProtocol.getSheetName().get(i), refValueOfNullCheckPerSheet));
					}

					exceptionCategory.setIssueCategory(exceptionCategoryProtocol.getIssueCategory().get(i));
					listOfExceptions.add(exceptionCategory);
				}
			}
			if (!exceptionCategoryProtocol.getTablesImpacted().get(i).equals("NA")
					&& exceptionCategoryProtocol.getDescription().get(i).equalsIgnoreCase("filesCount")) {
				if (null != otherExceptions.get("filesCountError") && otherExceptions.get("filesCountError") != 0) {
					exceptionCategory
							.setTablesImpacted(String.valueOf(Math.abs(otherExceptions.get("filesCountError"))));
					exceptionCategory.setColumnsImpacted("NA");
					exceptionCategory.setIssueCategory(exceptionCategoryProtocol.getIssueCategory().get(i));
					exceptionCategory.setDescription(String.valueOf(Math.abs(otherExceptions.get("filesCountError"))));
					listOfExceptions.add(exceptionCategory);
				}
			}

			if (!exceptionCategoryProtocol.getColumnsImpacted().get(i).equals("NA")
					&& exceptionCategoryProtocol.getDescription().get(i).equalsIgnoreCase("attributesCount")) {
				if (null != otherExceptions.get("attributesCountError")
						&& otherExceptions.get("attributesCountError") != 0) {
					exceptionCategory.setTablesImpacted("NA");
					exceptionCategory
							.setColumnsImpacted(String.valueOf(Math.abs(otherExceptions.get("attributesCountError"))));
					exceptionCategory.setIssueCategory(exceptionCategoryProtocol.getIssueCategory().get(i));
					exceptionCategory
							.setDescription(String.valueOf(Math.abs(otherExceptions.get("attributesCountError"))));
					listOfExceptions.add(exceptionCategory);
				}
			}

			if (!exceptionCategoryProtocol.getTablesImpacted().get(i).equals("NA")
					&& exceptionCategoryProtocol.getDescription().get(i).equalsIgnoreCase("countryCount")) {
				if (null != otherExceptions.get("requestedCountyException")
						&& otherExceptions.get("requestedCountyException") != 0) {
					exceptionCategory.setTablesImpacted(
							String.valueOf(Math.abs(otherExceptions.get("requestedCountyException"))));
					exceptionCategory.setColumnsImpacted("NA");
					exceptionCategory.setIssueCategory(exceptionCategoryProtocol.getIssueCategory().get(i));
					exceptionCategory
							.setDescription(String.valueOf(Math.abs(otherExceptions.get("requestedCountyException"))));
					listOfExceptions.add(exceptionCategory);
				}
			}

			if (!exceptionCategoryProtocol.getColumnsImpacted().get(i).equals("NA")
					&& exceptionCategoryProtocol.getDescription().get(i).equalsIgnoreCase("invalidTableName")) {
				if (null != errorCountPerCategory.get("invalidTableName")
						&& errorCountPerCategory.get("invalidTableName").size() > 0) {
					exceptionCategory.setTablesImpacted("NA");
					exceptionCategory
							.setColumnsImpacted(String.valueOf(errorCountPerCategory.get("invalidTableName").size()));
					exceptionCategory.setIssueCategory(exceptionCategoryProtocol.getIssueCategory().get(i));
					exceptionCategory.setDescription(String.join(", ", errorCountPerCategory.get("invalidTableName")));
					listOfExceptions.add(exceptionCategory);
				}
			}

			if (!exceptionCategoryProtocol.getColumnsImpacted().get(i).equals("NA")
					&& exceptionCategoryProtocol.getDescription().get(i).equalsIgnoreCase("invalidTargetTableName")) {
				if (null != errorCountPerCategory.get("invalidTargetTableName")
						&& errorCountPerCategory.get("invalidTargetTableName").size() > 0) {
					exceptionCategory.setTablesImpacted("NA");
					exceptionCategory.setColumnsImpacted(
							String.valueOf(errorCountPerCategory.get("invalidTargetTableName").size()));
					exceptionCategory.setIssueCategory(exceptionCategoryProtocol.getIssueCategory().get(i));
					exceptionCategory
							.setDescription(String.join(", ", errorCountPerCategory.get("invalidTargetTableName")));
					listOfExceptions.add(exceptionCategory);
				}
			}

			if (!exceptionCategoryProtocol.getTablesImpacted().get(i).equals("NA") && exceptionCategoryProtocol
					.getDescription().get(i).equalsIgnoreCase("invalidDateFormatInFileName")) {
				if (null != errorCountPerCategory.get("invalidDateFormatInFileName")
						&& errorCountPerCategory.get("invalidDateFormatInFileName").size() > 0) {
					exceptionCategory.setTablesImpacted("NA");
					exceptionCategory.setColumnsImpacted(
							String.valueOf(errorCountPerCategory.get("invalidDateFormatInFileName").size()));
					exceptionCategory.setIssueCategory(exceptionCategoryProtocol.getIssueCategory().get(i));
					exceptionCategory.setDescription(
							String.join(", ", errorCountPerCategory.get("invalidDateFormatInFileName")));
					listOfExceptions.add(exceptionCategory);
				}
			}

			if (!exceptionCategoryProtocol.getTablesImpacted().get(i).equals("NA")
					&& exceptionCategoryProtocol.getDescription().get(i).equalsIgnoreCase("invalidDateFormatInData")) {
				if (null != errorCountPerCategory.get("invalidDateFormatInData")
						&& errorCountPerCategory.get("invalidDateFormatInData").size() > 0) {
					exceptionCategory.setTablesImpacted("NA");
					exceptionCategory.setColumnsImpacted(
							String.valueOf(errorCountPerCategory.get("invalidDateFormatInData").size()));
					exceptionCategory.setIssueCategory(exceptionCategoryProtocol.getIssueCategory().get(i));
					exceptionCategory
							.setDescription(String.join(", ", errorCountPerCategory.get("invalidDateFormatInData")));
					listOfExceptions.add(exceptionCategory);
				}
			}

		}
		bachInsert(listOfExceptions, reqId, latestVersion);
		log.info("saveExceptionCounts:end");
		return listOfExceptions;

	}

	private String getDetailedInfo(List<String> list, String columnId, String headerColumnName, String sheetName,
			Map<String, Map<String, String>> refValueOfNullCheckPerSheet) {
		log.info("getDetailedInfo:start");
		Map<String, String> refData = refValueOfNullCheckPerSheet.get(sheetName);
		List<String> data = list.stream()
				.filter(x -> x.split("(?<=\\D)(?=\\d)")[0].equalsIgnoreCase(headerColumnName) && refData.containsKey(x))
				.map(x -> refData.get(x)).collect(Collectors.toList());
		log.debug("getDetailedInfo:data" + data);
		log.info("getDetailedInfo:end");
		return String.join(", ", data);
	}

	private void bachInsert(List<ExceptionCategory> listOfExceptions, int reqId, Integer latestVersion) {
		log.info("bachInsert:start");
		String sql = "insert into ISD_Exceptions values(?,?,?,?,?,?)";
		PreparedStatement ps;
		try {
			ps = template.getDataSource().getConnection().prepareStatement(sql);
			final int batchSize = 1000;
			int count = 0;
			for (ExceptionCategory exceptions : listOfExceptions) {
				ps.setInt(1, reqId);
				ps.setString(2, exceptions.getIssueCategory());
				ps.setString(3, exceptions.getTablesImpacted());
				ps.setString(4, exceptions.getColumnsImpacted());
				ps.setInt(5, latestVersion);
				ps.setString(6, exceptions.getDescription());
				ps.addBatch();
				if (++count % batchSize == 0) {
					ps.executeBatch();
				}
			}
			ps.executeBatch(); // insert remaining records
			ps.close();
			log.info("bachInsert:end");
		} catch (SQLException e) {
			log.error("bachInsert:error in batch insert:" + e.getStackTrace());
		}

	}

	private ExceptionCategoryProtocol getSampleExceptionCategoryProtocol() {
		log.info("getSampleExceptionCategoryProtocol:start");
		String sql = "select * from ISDExceptionPrototype";
		ExceptionCategoryProtocol category = new ExceptionCategoryProtocol();
		List<String> issueCategory = new ArrayList<>();
		List<String> columnId = new ArrayList<>();
		List<String> sheetName = new ArrayList<>();
		List<String> columnsImpacted = new ArrayList<>();
		List<String> tablesImpacted = new ArrayList<>();
		List<String> description = new ArrayList<>();

		SqlRowSet rs = template.queryForRowSet(sql);
		while (rs.next()) {
			issueCategory.add(rs.getString("ISSUE_CATEGORY"));
			columnId.add(rs.getString("CELL_COLUMN_NUMBER"));
			sheetName.add(rs.getString("DB_COLUMN_NAME"));
			columnsImpacted.add(rs.getString("COLUMNS_IMPACTED"));
			tablesImpacted.add(rs.getString("TABLES_IMPACTED"));
			description.add(rs.getString("DESCRIPTION"));
		}

		category.setIssueCategory(issueCategory);
		category.setColumnId(columnId);
		category.setSheetName(sheetName);
		category.setColumnsImpacted(columnsImpacted);
		category.setTablesImpacted(tablesImpacted);
		category.setDescription(description);
		log.info("getSampleExceptionCategoryProtocol:end");
		return category;
	}

	public void saveVarificationStatus(boolean exceptionStatus, int reqId, ISDVerificationStatus varificationStatus,
			Integer latestVersion) {
		log.info("saveVarificationStatus:start");
		String sql = "insert into ISD_Varification_Status values(?,?,?,?,?,?,?,?)";
		log.info("saveVarificationStatus:varificationStatus:" + varificationStatus);

		template.update(sql, reqId, varificationStatus.getUpdatedDate(), varificationStatus.getSystem(),
				varificationStatus.getCountries(), varificationStatus.getIsdUploadStatus(),
				varificationStatus.getIsdVarificationstatus(), String.valueOf(exceptionStatus), latestVersion);
		log.info("saveVarificationStatus:end");
	}

	public void saveExcel(byte[] bytes, ISDRequestDetails isdInputs, String fileName) {
		log.info("Start:saveExcel");
		int recordInserted = isdServiceMapper.saveISDSheet(isdInputs, bytes);
		log.info("saveExcel:Records inserted:" + recordInserted);
		//String tableNameForBA = "EDMP_ING_BA";
		//String tableNameForRequester = "EDMP_ING_Requestor_Resp";
		String tableName = isdServiceMapper.getTabeNameForStepId(isdInputs.getStepId());
		if(isdInputs.getStepId().equals("S8")) {
		int result = isdServiceMapper.updateFileName(isdInputs.getReqId(), fileName, tableName);
		if(result<=0) {
			isdServiceMapper.insertFileName(isdInputs.getReqId(), fileName, tableName, isdInputs.getStepId());
		}
		} else {
			isdServiceMapper.updateFileName(isdInputs.getReqId(), fileName, tableName);
		}
			
		log.info("END:saveExcel");
	}

	public List<ISDVerificationStatus> getVerificationStatus(ISDRequestDetails isdInputs) {
		log.info("getVarificationStatus:start");
		String sql = "select updatedDate, systems, countries, isdUploadStatus, isdVarificationStatus, exception,version_no from ISD_Varification_Status where req_Id=? order by version_no";
		List<ISDVerificationStatus> listVerificationStatus = new ArrayList<>();
		SqlRowSet rowSet = template.queryForRowSet(sql, new Object[] { isdInputs.getReqId() });
		while (null != rowSet && rowSet.next()) {
			ISDVerificationStatus isdVerificationStatus = new ISDVerificationStatus.Builder()
					.updatedDate(rowSet.getString("updatedDate")).systemName(rowSet.getString("systems"))
					.countries(rowSet.getString("countries")).isdUploadStatus(rowSet.getString("isdUploadStatus"))
					.isdVarificationstatus(rowSet.getString("isdVarificationStatus"))
					.exceptionDetails(Boolean.getBoolean(rowSet.getString("exception")))
					.versionNo(rowSet.getInt("version_no")).Build();
			listVerificationStatus.add(isdVerificationStatus);
		}
		log.debug("getVarificationStatus:listVarificationStatus" + listVerificationStatus);
		log.info("getVarificationStatus:end");
		return listVerificationStatus;

	}

	public List<ViewExceptions> getAllException(int reqId, Integer versionNo) {
		log.info("getAllException:start:reqId" + reqId + ":versionNo:" + versionNo);
		return isdServiceMapper.fetchIsdExceptions(reqId, versionNo);

	}

	public Integer getISDVersion(int reqId) {
		log.info("getISDVersion:start:reqId" + reqId);
		return isdServiceMapper.fetchIsdLatestVersion(reqId);

	}

	public List<ExceptionCategory> getExceptionDetails(int reqId, Integer versionNo) {
		log.info("getExceptionDetails:start:reqId" + reqId + ":versionNo:" + versionNo);
		return isdServiceMapper.fetchdetailedException(reqId, versionNo);

	}

	public List<ISDConfiguration> getIsdCongiguration() {
		log.info("getIsdCongiguration:start");
		return isdServiceMapper.getIsdConfigDetails();
	}

	public void updateFlag(int reqId) {
		ingestionReqMapper.updateIngestionflag(reqId, 1);
		
	}

}
