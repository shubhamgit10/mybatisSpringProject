package com.scb.selfservice.domains;

import java.sql.Date;

/*
 * pojo for
 * EDMP_CONSUMPTION_REQUEST
 */
public class ConsumptionRequest {
	private Integer reqId;
	private String  adRoleName;
	private Integer appMcrFileId;
	private String  appMonitoredCntrlRoom;
	private String  bsPii;
	private Integer bsPiiFileId; //5
	private String businessFunction;
	private String consumerAppName;
	private String consumerBusinessOwner;
	private String consumerItam;
	private String dataUsedReportTool;
	private String deliveryManagerPsid;
	private String downOlaDelay;
	private String existingReq;
	private String extractDelivMech; //15
	private String frequency;
	private String historyInfoReq;
	private String impactedAssessment;
	private String isCrossborderReq;
	private String isRelatedExistReq;  //20
	private String opReconExep;
	private String otherConsumPurposeRemarks;
	private String purposeOfConsumption;
	private Integer requestorId;
	private Integer requestCreatedBy; //25
	private String reqIncludesPiiData;
	private String reqSummary;
	private String resTimeReportTool;
	private Date targetDate;
	private String technologyContact;
	private String toolsEnabled;
	private Integer toolsEnabledFileId;
	private Integer upRqmntDocFileId; //35
	private String userTypeCode;
	private String userTypeValue; //37
	private String employeeId;
	private Integer isCrossborderReqFileId;
	private String description;
	private String bsPiiOthRemarks;
	
	public String getAdRoleName() {
		return adRoleName;
	}
	public void setAdRoleName(String adRoleName) {
		this.adRoleName = adRoleName;
	}
	public Integer getAppMcrFileId() {
		return appMcrFileId;
	}
	public void setAppMcrFileId(Integer appMcrFileId) {
		this.appMcrFileId = appMcrFileId;
	}
	public String getAppMonitoredCntrlRoom() {
		return appMonitoredCntrlRoom;
	}
	public void setAppMonitoredCntrlRoom(String appMonitoredCntrlRoom) {
		this.appMonitoredCntrlRoom = appMonitoredCntrlRoom;
	}
	public String getBsPii() {
		return bsPii;
	}
	public void setBsPii(String bsPii) {
		this.bsPii = bsPii;
	}
	public Integer getBsPiiFileId() {
		return bsPiiFileId;
	}
	public void setBsPiiFileId(Integer bsPiiFileId) {
		this.bsPiiFileId = bsPiiFileId;
	}
	public String getBusinessFunction() {
		return businessFunction;
	}
	public void setBusinessFunction(String businessFunction) {
		this.businessFunction = businessFunction;
	}
	public String getConsumerAppName() {
		return consumerAppName;
	}
	public void setConsumerAppName(String consumerAppName) {
		this.consumerAppName = consumerAppName;
	}
	public String getConsumerBusinessOwner() {
		return consumerBusinessOwner;
	}
	public void setConsumerBusinessOwner(String consumerBusinessOwner) {
		this.consumerBusinessOwner = consumerBusinessOwner;
	}
	public String getConsumerItam() {
		return consumerItam;
	}
	public void setConsumerItam(String consumerItam) {
		this.consumerItam = consumerItam;
	}
	public String getDataUsedReportTool() {
		return dataUsedReportTool;
	}
	public void setDataUsedReportTool(String dataUsedReportTool) {
		this.dataUsedReportTool = dataUsedReportTool;
	}
	public String getDeliveryManagerPsid() {
		return deliveryManagerPsid;
	}
	public void setDeliveryManagerPsid(String deliveryManagerPsid) {
		this.deliveryManagerPsid = deliveryManagerPsid;
	}
	public String getDownOlaDelay() {
		return downOlaDelay;
	}
	public void setDownOlaDelay(String downOlaDelay) {
		this.downOlaDelay = downOlaDelay;
	}
	public String getExistingReq() {
		return existingReq;
	}
	public void setExistingReq(String existingReq) {
		this.existingReq = existingReq;
	}
	public String getExtractDelivMech() {
		return extractDelivMech;
	}
	public void setExtractDelivMech(String extractDelivMech) {
		this.extractDelivMech = extractDelivMech;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public String getHistoryInfoReq() {
		return historyInfoReq;
	}
	public void setHistoryInfoReq(String historyInfoReq) {
		this.historyInfoReq = historyInfoReq;
	}
	public String getImpactedAssessment() {
		return impactedAssessment;
	}
	public void setImpactedAssessment(String impactedAssessment) {
		this.impactedAssessment = impactedAssessment;
	}
	public String getIsCrossborderReq() {
		return isCrossborderReq;
	}
	public void setIsCrossborderReq(String isCrossborderReq) {
		this.isCrossborderReq = isCrossborderReq;
	}
	public String getIsRelatedExistReq() {
		return isRelatedExistReq;
	}
	public void setIsRelatedExistReq(String isRelatedExistReq) {
		this.isRelatedExistReq = isRelatedExistReq;
	}
	public String getOpReconExep() {
		return opReconExep;
	}
	public void setOpReconExep(String opReconExep) {
		this.opReconExep = opReconExep;
	}
	public String getOtherConsumPurposeRemarks() {
		return otherConsumPurposeRemarks;
	}
	public void setOtherConsumPurposeRemarks(String otherConsumPurposeRemarks) {
		this.otherConsumPurposeRemarks = otherConsumPurposeRemarks;
	}
	public String getPurposeOfConsumption() {
		return purposeOfConsumption;
	}
	public void setPurposeOfConsumption(String purposeOfConsumption) {
		this.purposeOfConsumption = purposeOfConsumption;
	}
	public Integer getRequestorId() {
		return requestorId;
	}
	public void setRequestorId(Integer requestorId) {
		this.requestorId = requestorId;
	}
	public Integer getRequestCreatedBy() {
		return requestCreatedBy;
	}
	public void setRequestCreatedBy(Integer requestCreatedBy) {
		this.requestCreatedBy = requestCreatedBy;
	}
	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	public String getReqIncludesPiiData() {
		return reqIncludesPiiData;
	}
	public void setReqIncludesPiiData(String reqIncludesPiiData) {
		this.reqIncludesPiiData = reqIncludesPiiData;
	}
	public String getReqSummary() {
		return reqSummary;
	}
	public void setReqSummary(String reqSummary) {
		this.reqSummary = reqSummary;
	}
	public String getResTimeReportTool() {
		return resTimeReportTool;
	}
	public void setResTimeReportTool(String resTimeReportTool) {
		this.resTimeReportTool = resTimeReportTool;
	}
	public Date getTargetDate() {
		return targetDate;
	}
	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}
	public String getTechnologyContact() {
		return technologyContact;
	}
	public void setTechnologyContact(String technologyContact) {
		this.technologyContact = technologyContact;
	}
	public String getToolsEnabled() {
		return toolsEnabled;
	}
	public void setToolsEnabled(String toolsEnabled) {
		this.toolsEnabled = toolsEnabled;
	}
	public Integer getToolsEnabledFileId() {
		return toolsEnabledFileId;
	}
	public void setToolsEnabledFileId(Integer toolsEnabledFileId) {
		this.toolsEnabledFileId = toolsEnabledFileId;
	}
	public Integer getUpRqmntDocFileId() {
		return upRqmntDocFileId;
	}
	public void setUpRqmntDocFileId(Integer upRqmntDocFileId) {
		this.upRqmntDocFileId = upRqmntDocFileId;
	}
	public String getUserTypeCode() {
		return userTypeCode;
	}
	public void setUserTypeCode(String userTypeCode) {
		this.userTypeCode = userTypeCode;
	}
	public String getUserTypeValue() {
		return userTypeValue;
	}
	public void setUserTypeValue(String userTypeValue) {
		this.userTypeValue = userTypeValue;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public Integer getIsCrossborderReqFileId() {
		return isCrossborderReqFileId;
	}
	public void setIsCrossborderReqFileId(Integer isCrossborderReqFileId) {
		this.isCrossborderReqFileId = isCrossborderReqFileId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getBsPiiOthRemarks() {
		return bsPiiOthRemarks;
	}
	public void setBsPiiOthRemarks(String bsPiiOthRemarks) {
		this.bsPiiOthRemarks = bsPiiOthRemarks;
	}
	@Override
	public String toString() {
		return "ConsumptionRequest [reqId=" + reqId + ", adRoleName=" + adRoleName + ", appMcrFileId=" + appMcrFileId
				+ ", appMonitoredCntrlRoom=" + appMonitoredCntrlRoom + ", bsPii=" + bsPii + ", bsPiiFileId="
				+ bsPiiFileId + ", businessFunction=" + businessFunction + ", consumerAppName=" + consumerAppName
				+ ", consumerBusinessOwner=" + consumerBusinessOwner + ", consumerItam=" + consumerItam
				+ ", dataUsedReportTool=" + dataUsedReportTool + ", deliveryManagerPsid=" + deliveryManagerPsid
				+ ", downOlaDelay=" + downOlaDelay + ", existingReq=" + existingReq + ", extractDelivMech="
				+ extractDelivMech + ", frequency=" + frequency + ", historyInfoReq=" + historyInfoReq
				+ ", impactedAssessment=" + impactedAssessment + ", isCrossborderReq=" + isCrossborderReq
				+ ", isRelatedExistReq=" + isRelatedExistReq + ", opReconExep=" + opReconExep
				+ ", otherConsumPurposeRemarks=" + otherConsumPurposeRemarks + ", purposeOfConsumption="
				+ purposeOfConsumption + ", requestorId=" + requestorId + ", requestCreatedBy=" + requestCreatedBy
				+ ", reqIncludesPiiData=" + reqIncludesPiiData + ", reqSummary=" + reqSummary + ", resTimeReportTool="
				+ resTimeReportTool + ", targetDate=" + targetDate + ", technologyContact=" + technologyContact
				+ ", toolsEnabled=" + toolsEnabled + ", toolsEnabledFileId=" + toolsEnabledFileId
				+ ", upRqmntDocFileId=" + upRqmntDocFileId + ", userTypeCode=" + userTypeCode + ", userTypeValue="
				+ userTypeValue + ", employeeId=" + employeeId + ", isCrossborderReqFileId=" + isCrossborderReqFileId
				+ ", description=" + description + ", bsPiiOthRemarks=" + bsPiiOthRemarks + "]";
	}

}
