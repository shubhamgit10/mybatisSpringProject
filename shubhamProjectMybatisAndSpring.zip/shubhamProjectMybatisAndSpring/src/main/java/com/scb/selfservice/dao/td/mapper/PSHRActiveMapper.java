package com.scb.selfservice.dao.td.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.databaseentity.DBPSHRActive;

public interface PSHRActiveMapper {

	public DBPSHRActive validate(@Param("staffID") Integer staffID);
	public List<DBPSHRActive> validated(@Param("staffName") String staffName);
	
}
