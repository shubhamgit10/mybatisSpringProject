package com.scb.selfservice.model.RangerPolicy;

import java.util.List;

/**
 * 
 * @author Chenna
 *
 */
public class HivePolicyRequestModel {
	
	private String repositoryName;
	private  String repositoryType = "hive";
	private String policyName;
	private String description;
	private List<RangerPolicyPermissionsList> permMapList;
	private boolean isAuditEnabled = true;
	private boolean isEnabled = true;
	private String columnType = "Inclusion";
	private String tableType = "Inclusion";
	private String databases;
	private String tables;
	private String columns;
	
	/**
	 * 
	 */
	public HivePolicyRequestModel() {
		this.repositoryType = "hive";
		this.isEnabled = true;
		this.isAuditEnabled = true;
		this.columnType = "Inclusion";
		this.tableType = "Inclusion";
		
	}

	/**
	 * @param repositoryName
	 * @param policyName
	 * @param description
	 * @param permMapList
	 * @param databases
	 * @param tables
	 * @param columns
	 */
	public HivePolicyRequestModel(String repositoryName, String policyName, String description, 
			List<RangerPolicyPermissionsList> permMapList, String databases, String tables, String columns) {
		super();
		this.repositoryName = repositoryName;
		this.policyName = policyName;
		this.description = description;
		this.permMapList = permMapList;
		this.databases = databases;
		this.tables = tables;
		this.columns = columns;
	}

	/**
	 * @return the repositoryName
	 */
	public String getRepositoryName() {
		return repositoryName;
	}

	/**
	 * @param repositoryName the repositoryName to set
	 */
	public void setRepositoryName(String repositoryName) {
		this.repositoryName = repositoryName;
	}

	/**
	 * @return the policyName
	 */
	public String getPolicyName() {
		return policyName;
	}

	/**
	 * @param policyName the policyName to set
	 */
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the permMapList
	 */
	public List<RangerPolicyPermissionsList> getPermMapList() {
		return permMapList;
	}

	/**
	 * @param permMapList the permMapList to set
	 */
	public void setPermMapList(List<RangerPolicyPermissionsList> permMapList) {
		this.permMapList = permMapList;
	}

	/**
	 * @return the databases
	 */
	public String getDatabases() {
		return databases;
	}

	/**
	 * @param databases the databases to set
	 */
	public void setDatabases(String databases) {
		this.databases = databases;
	}

	/**
	 * @return the tables
	 */
	public String getTables() {
		return tables;
	}

	/**
	 * @param tables the tables to set
	 */
	public void setTables(String tables) {
		this.tables = tables;
	}

	/**
	 * @return the columns
	 */
	public String getColumns() {
		return columns;
	}

	/**
	 * @param columns the columns to set
	 */
	public void setColumns(String columns) {
		this.columns = columns;
	}

	/**
	 * @return the repositorytype
	 */
	public String getRepositoryType() {
		return repositoryType;
	}

	/**
	 * @return the isAuditEnabled
	 */
	public boolean isIsAuditEnabled() {
		return isAuditEnabled;
	}

	/**
	 * @return the isEnabled
	 */
	public boolean isIsEnabled() {
		return isEnabled;
	}

	/**
	 * @return the columntype
	 */
	public String getColumnType() {
		return columnType;
	}

	/**
	 * @return the tabletype
	 */
	public String getTableType() {
		return tableType;
	}
	
	

	/**
	 * @return the isAuditEnabled
	 */
	public boolean isAuditEnabled() {
		return isAuditEnabled;
	}

	/**
	 * @param isAuditEnabled the isAuditEnabled to set
	 */
	public void setAuditEnabled(boolean isAuditEnabled) {
		this.isAuditEnabled = isAuditEnabled;
	}

	/**
	 * @return the isEnabled
	 */
	public boolean isEnabled() {
		return isEnabled;
	}

	/**
	 * @param isEnabled the isEnabled to set
	 */
	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}

	/**
	 * @return the repositorytype
	 */
	public String getRepositorytype() {
		return repositoryType;
	}

	/**
	 * @param columnType the columnType to set
	 */
	public void setColumnType(String columnType) {
		this.columnType = columnType;
	}

	/**
	 * @param tableType the tableType to set
	 */
	public void setTableType(String tableType) {
		this.tableType = tableType;
	}

	@Override
	public String toString() {
		return "HivePolicyRequestModel [repositoryName=" + repositoryName + ", repositoryType=" + repositoryType
				+ ", policyName=" + policyName + ", description=" + description + ", permMapList=" + permMapList
				+ ", isAuditEnabled=" + isAuditEnabled + ", isEnabled=" + isEnabled + ", columnType=" + columnType
				+ ", tableType=" + tableType + ", databases=" + databases + ", tables=" + tables + ", columns="
				+ columns + "]";
	}

}
