package com.scb.selfservice.model.RangerPolicy;

import java.util.ArrayList;
import java.util.List;


/**
 * 
 * @author 1610601
 *
 */
public class RangerPolicyV2RespModel {
	
	private Long id;
	private boolean isEnabled;
	private String service;
	private String serviceType;
	private String name;
	private int policyType;
	private String description;
	private boolean isAuditEnabled;
	private RangerPolicyResourcesRespModel resources;
	private List<RangerPolicyPolicyItems> policyItems;
	private List<RangerPolicyPolicyItems> denyPolicyItems;
	private List<RangerPolicyPolicyItems> allowExceptions;
	private List<RangerPolicyPolicyItems> denyExceptions;
	private List<RangerPolicyPolicyItems> dataMaskPolicyItems;
	private List<String> rowFilterPolicyItems;

	public RangerPolicyV2RespModel() {
		this.id = -1L;
		this.isEnabled = true;
		this.isAuditEnabled = true;
		this.rowFilterPolicyItems = new ArrayList<String>();
		this.denyPolicyItems = new ArrayList<RangerPolicyPolicyItems>();
		this.allowExceptions = new ArrayList<RangerPolicyPolicyItems>();
		this.denyExceptions = new ArrayList<RangerPolicyPolicyItems>();
	}

	public RangerPolicyV2RespModel(boolean isEnabled, String service,
									String serviceType, String name,
									int policyType, String description,
									boolean isAuditEnabled, RangerPolicyResourcesRespModel resources,
									List<RangerPolicyPolicyItems> policyItems,
									List<RangerPolicyPolicyItems> dataMaskPolicyItems) {
		this.isEnabled = isEnabled;
		this.service = service;
		this.serviceType = serviceType;
		this.name = name;
		this.policyType = policyType;
		this.description = description;
		this.isAuditEnabled = isAuditEnabled;
		this.resources = resources;
		this.policyItems = policyItems;
		this.dataMaskPolicyItems = dataMaskPolicyItems;
	}

	public boolean isEnabled() {
		return isEnabled;
	}

	public void setEnabled(boolean enabled) {
		isEnabled = enabled;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPolicyType() {
		return policyType;
	}

	public void setPolicyType(int policyType) {
		this.policyType = policyType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isAuditEnabled() {
		return isAuditEnabled;
	}

	public void setAuditEnabled(boolean auditEnabled) {
		isAuditEnabled = auditEnabled;
	}

	public RangerPolicyResourcesRespModel getResources() {
		return resources;
	}

	public void setResources(RangerPolicyResourcesRespModel resources) {
		this.resources = resources;
	}

	public List<RangerPolicyPolicyItems> getPolicyItems() {
		return policyItems;
	}

	public void setPolicyItems(List<RangerPolicyPolicyItems> policyItems) {
		this.policyItems = policyItems;
	}

	public List<RangerPolicyPolicyItems> getDenyPolicyItems() {
		return denyPolicyItems;
	}

	public void setDenyPolicyItems(List<RangerPolicyPolicyItems> denyPolicyItems) {
		this.denyPolicyItems = denyPolicyItems;
	}

	public List<RangerPolicyPolicyItems> getAllowExceptions() {
		return allowExceptions;
	}

	public void setAllowExceptions(List<RangerPolicyPolicyItems> allowExceptions) {
		this.allowExceptions = allowExceptions;
	}

	public List<RangerPolicyPolicyItems> getDenyExceptions() {
		return denyExceptions;
	}

	public void setDenyExceptions(List<RangerPolicyPolicyItems> denyExceptions) {
		this.denyExceptions = denyExceptions;
	}

	public List<RangerPolicyPolicyItems> getDataMaskPolicyItems() {
		return dataMaskPolicyItems;
	}

	public void setDataMaskPolicyItems(List<RangerPolicyPolicyItems> dataMaskPolicyItems) {
		this.dataMaskPolicyItems = dataMaskPolicyItems;
	}

	public List<String> getRowFilterPolicyItems() {
		return rowFilterPolicyItems;
	}

	public void setRowFilterPolicyItems(List<String> rowFilterPolicyItems) {
		this.rowFilterPolicyItems = rowFilterPolicyItems;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "RangerPolicyRequestModel [id=" + id + ", isEnabled=" + isEnabled + ", service=" + service
				+ ", serviceType=" + serviceType + ", name=" + name + ", policyType=" + policyType + ", description="
				+ description + ", isAuditEnabled=" + isAuditEnabled + ", resources=" + resources + ", policyItems="
				+ policyItems + ", denyPolicyItems=" + denyPolicyItems + ", allowExceptions=" + allowExceptions
				+ ", denyExceptions=" + denyExceptions + ", dataMaskPolicyItems=" + dataMaskPolicyItems
				+ ", rowFilterPolicyItems=" + rowFilterPolicyItems + "]";
	}


}
