package com.scb.selfservice.domains;

import java.sql.Timestamp;

/*
 * pojo to for Workflow_req_steps_at
 */
public class AuditWorkflowRequestSteps {
	private Integer reqId;
	private String stepName;
	private String status;
	private String remarks;
	private Timestamp startTime;
	private Timestamp completedTime;
	private String stepActionedBy;
	private Integer snapshotId;

	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	public String getStepName() {
		return stepName;
	}
	public void setStepName(String stepName) {
		this.stepName = stepName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Timestamp getStartTime() {
		return startTime;
	}
	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}
	public Timestamp getCompletedTime() {
		return completedTime;
	}
	public void setCompletedTime(Timestamp completedTime) {
		this.completedTime = completedTime;
	}
	public String getStepActionedBy() {
		return stepActionedBy;
	}
	public void setStepActionedBy(String stepActionedBy) {
		this.stepActionedBy = stepActionedBy;
	}
	public Integer getSnapshotId() {
		return snapshotId;
	}
	public void setSnapshotId(Integer snapshotId) {
		this.snapshotId = snapshotId;
	}
	@Override
	public String toString() {
		return "AuditWorkflowRequestSteps [reqId=" + reqId + ", stepName=" + stepName + ", status=" + status
				+ ", remarks=" + remarks + ", startTime=" + startTime + ", completedTime=" + completedTime
				+ ", stepActionedBy=" + stepActionedBy + ", snapshotId=" + snapshotId + "]";
	}

}
