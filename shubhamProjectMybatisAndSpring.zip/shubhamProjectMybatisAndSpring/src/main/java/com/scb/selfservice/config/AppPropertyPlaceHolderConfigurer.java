package com.scb.selfservice.config;

import java.io.IOException;
import java.util.Properties;

import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

/**
 * 
 * Property PlaceHolder Configurer to load the files externally
 * 
 * @author Amarnath
 *
 */

public class AppPropertyPlaceHolderConfigurer extends PropertySourcesPlaceholderConfigurer {
	
	/**
	 * Method to merge the properties loaded externally
	 */
	@Override
	protected Properties mergeProperties() throws IOException {
		Properties mProp = super.mergeProperties();
		mProp.putAll(PropertyConfigurer.getAllOverrideProperties());
		return mProp;
	}

}
