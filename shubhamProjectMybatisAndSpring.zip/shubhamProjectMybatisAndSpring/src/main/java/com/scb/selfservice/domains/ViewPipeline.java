package com.scb.selfservice.domains;

public class ViewPipeline {

	private Integer slNo;

	private String property;

	private String value;

	public Integer getSlNo() {
		return slNo;
	}

	public void setSlNo(Integer slNo) {
		this.slNo = slNo;
	}

	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "ViewPipeline [slNo=" + slNo + ", property=" + property + ", value=" + value + "]";
	}

}
