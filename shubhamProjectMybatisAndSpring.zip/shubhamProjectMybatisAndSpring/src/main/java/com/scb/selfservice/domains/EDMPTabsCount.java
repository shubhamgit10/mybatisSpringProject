package com.scb.selfservice.domains;

import java.util.List;

public class EDMPTabsCount {

	private String itamId;
	private List<String> countries;
	private Integer tableCount;
	
	public String getItamId() {
		return itamId;
	}
	public void setItamId(String itamId) {
		this.itamId = itamId;
	}
	public List<String> getCountries() {
		return countries;
	}
	public void setCountries(List<String> countries) {
		this.countries = countries;
	}
	public Integer getTableCount() {
		return tableCount;
	}
	public void setTableCount(Integer tableCount) {
		this.tableCount = tableCount;
	}
}
