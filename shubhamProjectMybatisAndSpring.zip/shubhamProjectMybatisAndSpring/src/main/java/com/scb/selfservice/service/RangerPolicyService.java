package com.scb.selfservice.service;

import com.scb.selfservice.model.RangerPolicy.ConsumptionRangerPolicyModel;


/**
 * 
 * @author Chenna
 *
 */
public interface RangerPolicyService {
	
	public ConsumptionRangerPolicyModel getRangerPoliciesByRequestId(Long requestId);
	
	public void addRangerPolicyDetails(Long requestId, String appName, String country, 
			String groupName, String policyName, Long policyId, String policyCreateType, 
			String policyType, String status, String errorMsg, String repoType, 
			String createTime, String updateTime);
	
	public String getParentStepId(Long requestId, String stepId);

}
