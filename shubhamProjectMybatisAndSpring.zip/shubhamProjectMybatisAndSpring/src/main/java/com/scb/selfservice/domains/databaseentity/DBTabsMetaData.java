package com.scb.selfservice.domains.databaseentity;

public class DBTabsMetaData {
	
	private String itamId;
	private String country;
	private String tableName;
	private String tableDescription;
	private String hasPiiCols;
	private Integer noOfCols;
	
	public String getItamId() {
		return itamId;
	}
	public void setItamId(String itamId) {
		this.itamId = itamId;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getTableDescription() {
		return tableDescription;
	}
	public void setTableDescription(String tableDescription) {
		this.tableDescription = tableDescription;
	}
	public String getHasPiiCols() {
		return hasPiiCols;
	}
	public void setHasPiiCols(String hasPiiCols) {
		this.hasPiiCols = hasPiiCols;
	}
	public Integer getNoOfCols() {
		return noOfCols;
	}
	public void setNoOfCols(Integer noOfCols) {
		this.noOfCols = noOfCols;
	}


}
