
package com.scb.selfservice.workflow.service;

public interface SlaEmailSerivice {

	String sendSlaEmail(String workflowType) throws Exception;

}