package com.scb.selfservice.web.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.http.RangerPolicyV2;
import com.scb.selfservice.model.ServerResponse;
import com.scb.selfservice.model.RangerPolicy.ConsumptionRangerPolicyModel;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyAccesses;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyHdfsResourcesModel;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyHiveResourcesModel;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyModel;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyPolicyItems;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyV2ReqModel;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyV2RespModel;
import com.scb.selfservice.model.RangerPolicy.RepositoryTypeEnum;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyRequestTypeEnum;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyResourcesModel;
import com.scb.selfservice.service.RangerPolicyService;

/**
 * 
 * @author 1610601
 *
 */

@RestController
@RequestMapping("/rangerPolicy/v2")
public class RangerPolicyV2Controller {
	
	@Autowired
	RangerPolicyService rangerPolicyService;
	
	@Autowired
	RangerPolicyV2 rangerPolicy;
	
	private static Logger logger = LogManager.getLogger(RangerPolicyV2Controller.class);
	
	private static RepositoryTypeEnum[] repoTypesAllowed = {RepositoryTypeEnum.HIVE, RepositoryTypeEnum.HDFS};
	
	@GetMapping(path="/getPoliciesByType", produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity getRangerPolicies(@RequestParam("type") String type) {
		//to-do : restrict unauthorized access
//		if(SecurityHelper.isAuthenticatedUser()) {
		RangerPolicyModel rangerPolicyModel = new RangerPolicyModel();
		logger.info("In getRangerPolicies type : " +type);
		if(type == null || type.trim().isEmpty() || type.equalsIgnoreCase("ALL")) {
			logger.info("getRangerPolicies for all");
			rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.GET_POLICIES);
		} else {
			rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.GET_POLICIES_BY_TYPE);
			rangerPolicyModel.setRepositoryType(type);
			logger.info("getRangerPolicies for type : " +type);
		}
		
		ServerResponse resp = rangerPolicy.processRequest(rangerPolicyModel);
		if(null != resp) {
			logger.info("Get policies for type : " +type + ", response status code : " 
					+resp.getStatusCode() + ", Status Message : " +resp.getStatusMessage());
			logger.debug("Got Policies : " + ((List<RangerPolicyV2RespModel>) resp.getOutput()).toString());
			return new ResponseEntity<>(resp, HttpStatus.OK);
		} else {
			logger.error("Error while processing get policies for type : " +type);
			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
		}
//		}
//		return new ResponseEntity<>(HttpStatus.FORBIDDEN);
	}
	
	@GetMapping(path="/getPolicy", produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity getRangerPolicy(@RequestParam("policyId") Long policyId) {
		//to-do : restrict unauthorized access
//		if(SecurityHelper.isAuthenticatedUser()) {
		if(policyId != null) {
			RangerPolicyModel rangerPolicyModel = new RangerPolicyModel();
			rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.GET_POLICY_BY_ID);
			rangerPolicyModel.setPolicyId(policyId);
			ServerResponse resp = rangerPolicy.processRequest(rangerPolicyModel);
			if(null != resp) {
				logger.info("Get policy for policy id : " +policyId + ", response status code : " 
						+resp.getStatusCode() + ", Status Message : " +resp.getStatusMessage());
				if(resp.getStatusCode() == 200) {
					logger.debug("Got Policy : " + ((RangerPolicyV2RespModel) resp.getOutput()).toString());
				}
				return new ResponseEntity<>(resp, HttpStatus.OK);
			} else {
				logger.error("Error while processing get policy for policy id : " +policyId);
				return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			return new ResponseEntity<> (HttpStatus.BAD_REQUEST);
		}
//		}
//		return new ResponseEntity<>(HttpStatus.FORBIDDEN);
	}
	
	@GetMapping(path="/getPoliciesByTypeAndGroup", produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity getRangerPoliciesByTypeAndGroup(@RequestParam("type") String type, 
			@RequestParam("group") String group) {
		//to-do : restrict unauthorized access
//		if(SecurityHelper.isAuthenticatedUser()) {
		RangerPolicyModel rangerPolicyModel = new RangerPolicyModel();
		logger.info("In getRangerPolicies type : " +type +", group : " +group);
		if(type == null || type.trim().isEmpty() || type.equalsIgnoreCase("ALL")) {
			logger.info("getRangerPolicies for all");
			rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.GET_POLICIES_BY_GROUP);
		} else {
			rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.GET_POLICIES_BY_TYPE_AND_GROUP);
			rangerPolicyModel.setRepositoryType(type);
			rangerPolicyModel.setGroups(group);
			logger.info("getRangerPolicies for type : " +type);
		}
		
		ServerResponse resp = rangerPolicy.processRequest(rangerPolicyModel);
		if(null != resp) {
			logger.info("Get policies for type : " +type + ", response status code : " 
					+resp.getStatusCode() + ", Status Message : " +resp.getStatusMessage());
			logger.debug("Got Policies : " + ((List<RangerPolicyV2RespModel>) resp.getOutput()).toString());
			return new ResponseEntity<>(resp, HttpStatus.OK);
		} else {
			logger.error("Error while processing get policies for type : " +type);
			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
		}
//		}
//		return new ResponseEntity<>(HttpStatus.FORBIDDEN);
	}
	
	@GetMapping(path="/getPoliciesByTypeAndGroupAndPolicy", produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity getRangerPoliciesByTypeAndGroupAndPolicyName(@RequestParam("type") String type, 
			@RequestParam("groupName") String group, @RequestParam("policyName") String policyName) {
		//to-do : restrict unauthorized access
//		if(SecurityHelper.isAuthenticatedUser()) {
		RangerPolicyModel rangerPolicyModel = new RangerPolicyModel();
		logger.info("In getRangerPolicies type : " +type +", group : " +group + ", Policy name : " +policyName);
		rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.GET_POLICIES_BY_TYPE_AND_GROUP_AND_POLICYNAME);
		rangerPolicyModel.setRepositoryType(type);
		rangerPolicyModel.setGroups(group);
		rangerPolicyModel.setPolicyName(policyName);
		logger.info("getRangerPolicies for type : " +type);
		
		ServerResponse resp = rangerPolicy.processRequest(rangerPolicyModel);
		if(null != resp) {
			logger.info("Get policies for type : " +type + ", response status code : " 
					+resp.getStatusCode() + ", Status Message : " +resp.getStatusMessage());
			logger.debug("Got Policies : " + ((List<RangerPolicyV2RespModel>) resp.getOutput()).toString());
			return new ResponseEntity<>(resp, HttpStatus.OK);
		} else {
			logger.error("Error while processing get policies for type : " +type);
			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
		}
//		}
//		return new ResponseEntity<>(HttpStatus.FORBIDDEN);
	}
	
	
	@GetMapping(path = "/createOrUpdatePolicy", produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity createOrUpdateRangerPolicy(@RequestParam("requestId") Long requestId, 
			@RequestParam("groupName") String groupName) {
		
		if(null == requestId) {
			logger.error("Request Id is mandatory" + requestId);
			return new ResponseEntity<> ("Request Id is mandatory", HttpStatus.BAD_REQUEST);
		}
		if(null == groupName || groupName.trim().isEmpty()) {
			logger.error("Group Name is mandatory for the request id : " +requestId +", group name : " +groupName);
			return new ResponseEntity<> ("Group Name is mandatory", HttpStatus.BAD_REQUEST);
		}
		
		ServerResponse resp = null;
		ConsumptionRangerPolicyModel consumptionRangerPolicyModel = rangerPolicyService.getRangerPoliciesByRequestId(requestId);
		
		if(null == consumptionRangerPolicyModel) {
			logger.error("Either request details are null or empty for the request id : " +requestId);
			return new ResponseEntity("Either request details are null or empty for the request id : " +requestId, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		logger.debug("consumptionRangerPolicyModel : " +consumptionRangerPolicyModel);
		
		return doCreateOrUpdateRangerPolciy(requestId, groupName, consumptionRangerPolicyModel);
	}
	
	private ResponseEntity doCreateOrUpdateRangerPolciy(Long requestId, String groupName, 
			ConsumptionRangerPolicyModel consumptionRangerPolicyModel) {
//		String appName = consumptionRangerPolicyModel.getAppName();
		ServerResponse resp = null;
		for(String appName : consumptionRangerPolicyModel.getMetadataDetails().keySet()) {
			for(String country : consumptionRangerPolicyModel.getMetadataDetails().get(appName).keySet()) {
				logger.info("Initiated Ranger Policy Creation for reqId : " 
						+requestId + ", groupName : " +groupName + ", appName : " 
						+appName + ", instance : " +country);
				for(RepositoryTypeEnum repoType : repoTypesAllowed) {
					resp = doProcessCreateOrUpdateRangerPolicy(requestId, repoType, groupName, 
							country, appName, consumptionRangerPolicyModel.getMetadataDetails().get(appName).get(country));
					if(resp.getStatusCode() == 200) {
						logger.info("Ranger Policy Created for reqId : " 
								+requestId + ", groupName : " +groupName + ", appName : " 
								+appName + ", instance : " +country + ", repoType : " +repoType);
					} else {
						logger.error("Error while creating Ranger Policy for reqId : " 
								+requestId + ", groupName : " +groupName +", appName : " 
								+appName +", instance : " +country + ", repoType : " +repoType);
						return new ResponseEntity (HttpStatus.resolve(resp.getStatusCode()));
					}
				}
			}
		}
		return new ResponseEntity(resp, HttpStatus.OK);
	}
	
	private ServerResponse doProcessCreateOrUpdateRangerPolicy(Long requestId, RepositoryTypeEnum repoType, 
			String groupName, String country, String appName, 
			Map<String, Map<String, Set<String>>> dbMetadata) {
		ServerResponse resp = null;
		RangerPolicyModel rangerPolicyModel = new RangerPolicyModel();
		rangerPolicyModel.setRequestId(requestId);
		rangerPolicyModel.setRepositoryType(repoType.toString().toLowerCase());
		rangerPolicyModel.setGroups(groupName);
		rangerPolicyModel.setPolicyName(groupName + "_" + appName.toLowerCase().trim() + "_" + country.toLowerCase().trim());
		rangerPolicyModel.setDescription(groupName + "_" + appName + "_" + country);
		rangerPolicyModel.setAppName(appName);
		rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.GET_POLICIES_BY_TYPE_AND_GROUP_AND_POLICYNAME);
		resp = rangerPolicy.processRequest(rangerPolicyModel);
		RangerPolicyV2ReqModel policy = null;
		if(resp != null) {
			if(resp.getStatusCode() == 200) {
				List<RangerPolicyV2RespModel> policies = (List<RangerPolicyV2RespModel>) resp.getOutput();
				if(null != policies) {
					policy = new RangerPolicyV2ReqModel();
					if(policies.isEmpty()) {
						logger.info("No policies exist for group : "+groupName +", repository type : " 
								+repoType + ", Policy name : " +rangerPolicyModel.getPolicyName());
						return doPopulateRangerPolicyDetails(requestId, null, repoType, false, dbMetadata, 
								policy, rangerPolicyModel.getPolicyName(), groupName, appName, requestId);
					} else {
						if(policies.size() == 1) {
							return doPopulateRangerPolicyDetails(requestId, policies.get(0), repoType, true, dbMetadata, 
									policy, rangerPolicyModel.getPolicyName(), groupName, appName, requestId);
						} else {
							//to-do: log an error or take last updated one
							logger.error("Fetching policies for type : " + 
									repoType + ", groupName : " +groupName + ", policyName : " + 
									rangerPolicyModel.getPolicyName() +", got more than one policy, policies count : " + policies.size());
							return new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, 
									"Fetching policies for type : " + 
									repoType + ", groupName : " +groupName + ", policyName : " + 
									rangerPolicyModel.getPolicyName() +", got more than one policy, policies count : " + policies.size());
						}
					}
				}
			} else {
				logger.error("Fetching policies for type : " + 
						repoType + ", groupName : " +groupName + ", policyName : " + 
						rangerPolicyModel.getPolicyName() +", response status code : " 
						+ resp.getStatusCode() + ", Status Message : " +resp.getStatusMessage());
//				return new ResponseEntity<> (HttpStatus.valueOf(resp.getStatusCode()));
				return resp;
			}
		} else {
			logger.error("Error while fetching policies for type : " 
					+ repoType + ", groupName : " +groupName + ", policyName : " 
					+rangerPolicyModel.getPolicyName());
			return new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Error while fetching policies for type : " 
					+ repoType + ", groupName : " +groupName + ", policyName : " +rangerPolicyModel.getPolicyName());
//			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return resp;
	}
	
	private ServerResponse doPopulateRangerPolicyDetails(Long reqId, RangerPolicyV2RespModel respPolicy, RepositoryTypeEnum repoType, 
			boolean isToUpdatePolicy, Map<String, Map<String, Set<String>>> metadata, RangerPolicyV2ReqModel policy, 
			String policyName, String groupName, String appName, Long requestId) {
		
		RangerPolicyResourcesModel resources = null;
		if(RepositoryTypeEnum.HIVE == repoType) {
			resources = new RangerPolicyHiveResourcesModel();
		} else if(RepositoryTypeEnum.HDFS == repoType) {
			resources = new RangerPolicyHdfsResourcesModel();
		}
		if(isToUpdatePolicy) {
			policy.setId(respPolicy.getId());
			policy.setPolicyType(respPolicy.getPolicyType());
			policy.setName(respPolicy.getName());
			policy.setDescription(respPolicy.getDescription());
			if(resources instanceof RangerPolicyHiveResourcesModel) {
				((RangerPolicyHiveResourcesModel) resources).setDatabase(respPolicy.getResources().getDatabase());
				((RangerPolicyHiveResourcesModel) resources).setColumn(respPolicy.getResources().getColumn());
				((RangerPolicyHiveResourcesModel) resources).setTable(respPolicy.getResources().getTable());
			} else if (resources instanceof RangerPolicyHdfsResourcesModel) {
				((RangerPolicyHdfsResourcesModel) resources).setPath(respPolicy.getResources().getPath());
			}
		} else {
			policy.setServiceType(repoType.toString().toLowerCase());
			policy.setPolicyType(0);
			policy.setName(policyName);
			policy.setDescription(policyName);
			
//			policy.setResources(resources);
		}
		
		Set<String> pathValues = null;
		
		switch(repoType) {
		case HIVE:
			Set<String> databaseValues = new HashSet<String>(((RangerPolicyHiveResourcesModel) resources).getDatabase().getValues());
			Set<String> columnValues = new HashSet<String>(((RangerPolicyHiveResourcesModel) resources).getColumn().getValues());
			Set<String> tableValues = new HashSet<String>(((RangerPolicyHiveResourcesModel) resources).getTable().getValues());
			
			for(String database : metadata.keySet()) {
				databaseValues.add(database.trim());
				for(String column : metadata.get(database).keySet()) {
					columnValues.add((column.trim().equalsIgnoreCase("all")) ? "*" : column.trim());
					for(String table : metadata.get(database).get(column)) {
						tableValues.add(table.trim());
					}
				}
			}
			List<String> databases = new ArrayList<String> ();
			databases.addAll(databaseValues);
			((RangerPolicyHiveResourcesModel) resources).getDatabase().setValues(databases);
			
			List<String> tables = new ArrayList<String>();
			tables.addAll(tableValues);
			((RangerPolicyHiveResourcesModel) resources).getTable().setValues(tables);
			
			List<String> columns = new ArrayList<String>();
			columns.addAll(columnValues);
			((RangerPolicyHiveResourcesModel) resources).getColumn().setValues(columns);
			break;
		case HDFS:
//			Set<String> pathValues = new HashSet<String>(((RangerPolicyHdfsResourcesModel) resources).getPath().getValues());
			pathValues = new HashSet<String> ();
			for(String database : metadata.keySet()) {
				for(String column : metadata.get(database).keySet()) {
					for(String table : metadata.get(database).get(column)) {
						pathValues.add(database.toLowerCase().trim() + "/" + table.trim());
					}
				}
			}
		}
		
		policy.setResources(resources);
		
		List<RangerPolicyPolicyItems> policyItems = policy.getPolicyItems();
		RangerPolicyPolicyItems policyItem = null;
		if(policyItems != null && policyItems.isEmpty()) {
			policyItem = new RangerPolicyPolicyItems();
//			RangerPolicyAccesses access = new RangerPolicyAccesses();
//			policyItem.getAccesses().add(access);
			policyItems.add(policyItem);
		}
		if(policyItems != null && policyItems.size() == 1) {
			policyItem = policyItems.get(0);
			List<String> groups = policyItem.getGroups();
			if(!groups.contains(groupName)) {
				groups.add(groupName);
			}
		}
		
		return rangerPolicy.processRequest(policy, pathValues, repoType, 
				isToUpdatePolicy ? RangerPolicyRequestTypeEnum.UPDATE_POLICY : RangerPolicyRequestTypeEnum.CREATE_POLICY, 
						appName, requestId);
		
	}

}
