/**
 * 
 */
package com.scb.selfservice.dao.td.mapper;

import java.sql.Timestamp;

/**
 * @author Amarnath
 *
 */
public interface DemoTDMapper {
	
	public Timestamp getCurrentTime();

}
