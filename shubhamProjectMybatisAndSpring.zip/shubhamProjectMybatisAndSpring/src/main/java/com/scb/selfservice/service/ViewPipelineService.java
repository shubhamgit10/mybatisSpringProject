package com.scb.selfservice.service;

import java.util.List;

import com.scb.selfservice.domains.IngestionRequest;
import com.scb.selfservice.domains.Pipelineview;
import com.scb.selfservice.util.Response;

public interface ViewPipelineService {

	// is to pull data for the xls preparation
	public List<Pipelineview> pullData();

}
