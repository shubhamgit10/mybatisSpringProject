package com.scb.selfservice.service.impl;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.scb.selfservice.dao.mapper.IngestionDynamicMapper;
import com.scb.selfservice.dao.mapper.WorkflowMapper;
import com.scb.selfservice.domains.IngestionInput;
import com.scb.selfservice.domains.IngestionSolArchApproval;
import com.scb.selfservice.model.CostEstimationRequest;
import com.scb.selfservice.model.CostEstimationSummary;
import com.scb.selfservice.service.CostEstimationSummaryService;
import com.scb.selfservice.service.EdmpIngestionRequestService;
import com.scb.selfservice.service.UserResponseService;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.workflow.service.WorkflowRequestService;
import com.scb.selfservice.workflow.service.impl.WorkflowRequestServiceImpl;

/**
 * @author cpedada
 *
 */
@Service(value = "SolArchResp")
public class SolArchRespImpl implements UserResponseService {

	private static Logger logger = LogManager.getLogger(SolArchRespImpl.class);

	@Autowired
	IngestionDynamicMapper idynMapper;

	@Autowired
	WorkflowMapper workflowMapper;

	@Autowired
	WorkflowRequestService workflowRequestService;

	@Autowired
	WorkflowRequestServiceImpl wfrsi;

	@Autowired
	EdmpIngestionRequestService eiReqService;

	@Autowired
	CostEstimationSummaryService cesService;

	IngestionSolArchApproval ingestionSolArchApproval;

	Integer userId = 0;

	/**
	 *
	 */
	@Override
	public Response executeSave(IngestionInput ingestionInput) {
		// TODO Auto-generated method stub
		
		logger.info("inside SolArchRespImpl :: executeSave method");

		Response isaResponse = new Response();

		try {
			isaResponse = saveSolutionArchResp(ingestionInput);

		} catch (Exception e) {
			
			logger.info("Exception::" +e);
		}

		return isaResponse;
	}

	/**
	 * @param ingestionInput
	 * @return
	 * @throws Exception
	 */
	public Response saveSolutionArchResp(IngestionInput ingestionInput) throws Exception {
		
		logger.info("START SolArchRespImpl::saveSolutionArchResp");
		Response isaResponse = new Response();
		
		int userId = ingestionInput.getUserId();

		HashMap<String, Object> hm = (HashMap<String, Object>) ingestionInput.getParams();

		hm.put("reqId", ingestionInput.getReqId());

		hm.put("stepId", ingestionInput.getStepId());

		hm.put("workflowType", ingestionInput.getWorkflowType());

		hm.put("userAction", ingestionInput.getUserAction());

		hm.put("requestCreatedBy", ingestionInput.getUserId());

		IngestionSolArchApproval crObj = idynMapper.findByRequestId(ingestionInput.getReqId());
		
		int estimationId = (int) hm.get("estimationId");
		
		if ("APPROVED".equalsIgnoreCase(ingestionInput.getUserAction())) {

		if (estimationId!=0) {

			CostEstimationRequest ceRequest = new CostEstimationRequest();

			ceRequest.setEstimationId((int) hm.get("estimationId"));

			ceRequest.setSourceType((String) hm.get("sourceType"));

			ceRequest.setSourcingType((String)hm.get("proposedSolution"));
			ceRequest.setSourceName("");
			ceRequest.setInstances("");
			ceRequest.setNumberOfInstances(null);
			ceRequest.setNumberOfTables(0);
			ceRequest.setSourceDataSystem((String) hm.get("srcDataSys"));
			ceRequest.setWorkflowType((String) hm.get("workflowType"));
			ceRequest.setStepId((String) hm.get("stepId"));

			ceRequest.setNumberOfColumnsAccrossTable(0);
			ceRequest.setFileFormat("");
			ceRequest.setDownstreamOlaRequired("");

			ceRequest.setNewTransformationRulesRequired("");

			ceRequest.setSourceSystemCommunication((String) hm.get("srcSysCommunications"));

			ceRequest.setPlannedGoLiveMonth("");
			ceRequest.setHistoryData(0);
			ceRequest.setHistoryStorageType("");
			ceRequest.setIncrementalData(0);
			ceRequest.setIncrementalStorageType("");

			Response estimation = cesService.getEstimatedCost(ceRequest, userId);

			CostEstimationSummary Cost = (CostEstimationSummary) estimation.getResponse();

			logger.info("Printing the Proposed Cost::::: " + Cost.getEstimatedCost());

			String newcost = Cost.getEstimatedCost();

			Double proposedCost = Double.parseDouble(newcost);

			Response crObjNew = eiReqService.findByReqId(ingestionInput.getReqId());

			if (null != crObjNew) {

				eiReqService.updateProposedCost(ingestionInput.getReqId(), userId, proposedCost);// update

			}

		}
		
	}

		if (crObj == null) {
			logger.info("START it is a new entry for new request..." + ingestionInput.getReqId());

			int saveStatus = idynMapper.saveSolutionArchRequest(hm); // insert

			isaResponse = getActionStatus("save", saveStatus, ingestionInput.getReqId());

			logger.info("EXIT save request");

		} else {
			logger.info("START it an existing request..." + ingestionInput.getReqId());

			int updateStatus = idynMapper.updateSolArchRequest(hm); // update

			isaResponse = getActionStatus("update", updateStatus, ingestionInput.getReqId());

			logger.info("EXIT update request");
		}

		logger.info("EXIT SolArchRespImpl::saveSolutionArchResp");

		return isaResponse;

	}

	/**
	 * @param type
	 * @param saveStatus
	 * @param reqId
	 * @return
	 */
	private Response getActionStatus(String type, int saveStatus, int reqId) {
		Response response = new Response();
		if (saveStatus == 1) {
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus(HttpStatus.OK.toString());
			response.setResponse(reqId + "Request id " + (type.equals("save") ? "INSERTED" : "UPDATED"));
		} else {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
			response.setResponse("!!!Action not taken!!!");
		}
		return response;
	}
	
	/**
	 *
	 */
	@Override
	public Response fetchApprovalResponse(IngestionInput ingestionInput) {
		IngestionSolArchApproval solnArchResponse = idynMapper.findByRequestId(ingestionInput.getReqId());
		//Response solnArchResponse = eiReqService.findByReqId(requestId);
		Response response = new Response();
		response.setResponse(solnArchResponse);
		return response;
	}
	

}
