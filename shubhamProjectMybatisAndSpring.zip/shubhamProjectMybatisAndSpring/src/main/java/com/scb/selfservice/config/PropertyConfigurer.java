/**
 * 
 */
package com.scb.selfservice.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import com.scb.selfservice.util.AppEncryption;

/**
 * PropertyConfigurer Utility to load all the configuration properties external to the application which are ENV Specific
 * and can be overridden.
 * 
 * @author Amarnath BB
 *
 */
public class PropertyConfigurer {

	private static Properties _prop = new Properties();
	private static Properties _beanOverrideProp = new Properties();
	private static String[] classpathFiles = {"/buildVersion.properties"};

	static {
		// load all the external property files.
		_prop.clear();
		_loadExternalConfigFile();		
		_loadClasspathConfigFiles();
		_loadBeanOverrideFiles();
	}
	
	/**
	 * Method to Seggragate the bean override related property name
	 * 
	 * Propertyname should start with $
	 */
	@SuppressWarnings("rawtypes")
	private static void _loadBeanOverrideFiles() {
		Iterator iter = _prop.keySet().iterator();	
		while (iter.hasNext()) {
			String propName = (String) iter.next();
			if (propName.startsWith("$")) {
				_beanOverrideProp.setProperty(propName.replaceAll("\\$", ""), _prop.getProperty(propName));
				iter.remove();
			}
		}
		iter = _beanOverrideProp.keySet().iterator();
		while (iter.hasNext()) {
			String propName = (String) iter.next();
			String propValue = _beanOverrideProp.getProperty(propName);
			if (propValue.contains("ENC{")) {				
				String encProp = propValue.substring(4,propValue.length()-1);
				_beanOverrideProp.setProperty(propName, decrypt(encProp));
			}
		}		
	}

	/**
	 * Method to load the Property Files from the External Config Folder
	 */
	private static void _loadExternalConfigFile() {
		try {
			String configLoc = System.getProperty("app.configdir", "/configDir");
			File configDir = null;
			if (configLoc != null) {
				configDir = new File(configLoc);
				if (configDir.exists()) {
					// load the properties files recursively from the folder if it
					// is a
					Iterator<?> iter = FileUtils.iterateFiles(configDir, new String[] { "prop" , "properties", "config"}, true);
					while (iter.hasNext()) {
						File nextFile = (File) iter.next();
						FileInputStream fis = new FileInputStream(nextFile);
						_prop.load(fis);
						fis.close();
					}
			
				}
			}
		}
		catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("Exception in Reading Configuration Properties " + ex.getMessage());
		}		
	}
	
	
	/**
	 * Method to load the configFiles from the classpath location
	 */
	private static void _loadClasspathConfigFiles () {
		for (int i=0; i < classpathFiles.length; i++) {
			try {
				InputStream is = PropertyConfigurer.class.getResourceAsStream(classpathFiles[i]);
				if (is != null) {
					_prop.load(is);
					is.close();
				}
			}
			catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	/**
	 * Method to retrieve the property by Given Name
	 * 
	 * @param propName
	 * @param defaultVal
	 * @return
	 */
	public static String getProperty(String propName, String defaultVal) {
		String val = _prop.getProperty(propName, defaultVal);
		if (val.contains("ENC{")) {				
			String encProp = val.substring(4,val.length()-1);
			return decrypt(encProp);
		}
		return val;
	}

	/**
	 * Method to retrieve the property by Given Name
	 * 
	 * @param propName
	 * @param defaultVal
	 * @return
	 */
	public static String getProperty(String propName) {
		return getProperty(propName, null);
	}
	
	/**
	 * Method to return all the properties loaded
	 * @param propsMap 
	 * @return
	 */
	protected static Properties getOverrideProperties() {
		return _beanOverrideProp;
	}
	
	/**
	 * To return all override Properties
	 * @return
	 */
	protected static Properties getAllOverrideProperties() {
		return _prop;
	}
	
	/**
	 * Method to decrypt the encrypted text
	 * @param encryptedStr
	 * @return
	 */
	public static String decrypt (String encryptedStr) {
		return AppEncryption.decrypt(encryptedStr);
	}
	
	/**
	 * Method to override the values of Properties files to values from DB
	 * 
	 * @param props
	 */
	public static void overridePropertiesFromDB(Map<Object,Object> props) {
		if(StringUtils.startsWith(props.get("PROPNAME").toString(), "$")) {
			_beanOverrideProp.setProperty(props.get("PROPNAME").toString().replaceAll("\\$", ""),props.get("PROPVALUE").toString());
		} else {
			_prop.setProperty(props.get("PROPNAME").toString(), props.get("PROPVALUE").toString());
		}
	}
	
}
