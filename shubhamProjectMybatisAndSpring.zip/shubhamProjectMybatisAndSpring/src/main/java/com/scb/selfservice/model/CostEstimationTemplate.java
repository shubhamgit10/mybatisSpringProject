package com.scb.selfservice.model;

import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
/**
 * @author shubhasi
 * 
 *         Modal class to read the template from db
 */
public class CostEstimationTemplate {

	private Integer estimationId;
	private Integer sourceId;
	private String sourceType;
	private byte[] effortSheet;

	public Integer getEstimationId() {
		return estimationId;
	}

	public void setEstimationId(Integer estimationId) {
		this.estimationId = estimationId;
	}

	public Integer getSourceId() {
		return sourceId;
	}

	public void setSourceId(Integer sourceId) {
		this.sourceId = sourceId;
	}

	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public byte[] getEffortSheet() {
		return effortSheet;
	}

	public void setEffortSheet(byte[] effortSheet) {
		this.effortSheet = effortSheet;
	}

	@Override
	public String toString() {
		return "CostEstimationTemplate [estimationId=" + estimationId + ", sourceId=" + sourceId + ", sourceType="
				+ sourceType + ", effortSheet=" + Arrays.toString(effortSheet) + "]";
	}
}