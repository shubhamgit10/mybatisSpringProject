package com.scb.selfservice.domains;

public class EDMPSelfServiceReq {

	private Integer reqId;
	private String status;
	private Integer requestCreatedBy;
	private String workflowType;
	
	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getRequestCreatedBy() {
		return requestCreatedBy;
	}
	public void setRequestCreatedBy(Integer requestCreatedBy) {
		this.requestCreatedBy = requestCreatedBy;
	}
	public String getWorkflowType() {
		return workflowType;
	}
	public void setWorkflowType(String workflowType) {
		this.workflowType = workflowType;
	}
	
}
