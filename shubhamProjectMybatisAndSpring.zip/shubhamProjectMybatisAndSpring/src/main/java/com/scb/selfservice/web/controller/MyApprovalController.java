package com.scb.selfservice.web.controller;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.util.Response;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;
import com.scb.selfservice.web.authentication.UserPrincipal;
import com.scb.selfservice.workflow.service.WorkflowRequestService;

@RestController
@RequestMapping("/api/myApproval")
public class MyApprovalController {
	private static Logger logger = LogManager.getLogger(MyApprovalController.class);

	@Autowired
	WorkflowRequestService workflowRequestService;

	@PostMapping (path="/workflowAction",produces=MediaType.APPLICATION_JSON_VALUE)
	public  ResponseEntity<Response> workflowUpdate(@RequestBody HashMap<String, String> requestMap) {
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response workflowActionresponse =  new Response();
		if (loggedInUser != null) {
			logger.info("STARTED UpdateOrReject with " + requestMap.get("action"));
			requestMap.put("userId", loggedInUser.getUserId());
			try {
				workflowActionresponse = workflowRequestService.initiateUpdateOrReject(requestMap);
			} catch (Exception ex) {
				workflowActionresponse.setStatusCode(HttpStatus.NO_CONTENT.value());
				workflowActionresponse.setStatus(HttpStatus.NO_CONTENT.toString());
				workflowActionresponse.setResponse("Failed to update the status");
				logger.info("EXCEPTION MyApprovalController>workflowUpdate: " + ex.getMessage());
			}
			logger.info("EXITING UpdateOrReject");	
		} else {
			workflowActionresponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			workflowActionresponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
		
		return new ResponseEntity<Response> (workflowActionresponse, HttpStatus.OK);
	}


	@GetMapping (path="/lists", produces=MediaType.APPLICATION_JSON_VALUE)
	public  ResponseEntity<Response> getMyApprovalLists(@RequestParam("workflowType") String workflowType) {
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response myApprovalList =  new Response();
		if (loggedInUser != null) {
			logger.info("STARTED getMyApprovalLists");
			myApprovalList = workflowRequestService.getMyApprovalList(Integer.parseInt(loggedInUser.getUserId()), workflowType);
			logger.info("EXITING getMyApprovalLists");	
		} else {
			myApprovalList.setStatus(HttpStatus.UNAUTHORIZED.toString());
			myApprovalList.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
		
		return new ResponseEntity<Response> (myApprovalList, HttpStatus.OK);
	}

	@PostMapping (path="/auditWorkflowRequestSteps", produces=MediaType.APPLICATION_JSON_VALUE)
	public  ResponseEntity<Response> getAuditWorkflowRequestSteps(@RequestBody HashMap<String, String> requestMap) {
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response getAuditWorkflowRequestSteps =  new Response();
		if (loggedInUser != null) {
			logger.info("STARTED getAuditWorkflowRequestSteps");
			try {
				getAuditWorkflowRequestSteps = workflowRequestService.getAuditWorkflowRequestSteps(requestMap);
			} catch (Exception ex) {
				getAuditWorkflowRequestSteps.setStatusCode(HttpStatus.NO_CONTENT.value());
				getAuditWorkflowRequestSteps.setStatus(HttpStatus.NO_CONTENT.toString());
				logger.info("EXCEPTION MyApprovalController>getAuditWorkflowRequestSteps: " + ex.getMessage());
			}
			logger.info("EXITING getAuditWorkflowRequestSteps");	
		} else {
			getAuditWorkflowRequestSteps.setStatus(HttpStatus.UNAUTHORIZED.toString());
			getAuditWorkflowRequestSteps.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
		
		return new ResponseEntity<Response> (getAuditWorkflowRequestSteps, HttpStatus.OK);
	}
	
	/**
	 * Ingestion - My Approval/ Action list
	 * 
	 * @return
	 */
	@GetMapping (path="/getIngestionApproval", produces=MediaType.APPLICATION_JSON_VALUE)
	public  ResponseEntity<Response> getMyIngestionApproval(@RequestParam("workflowType") String workflowType) {
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response myApprovalList =  new Response();
		if (loggedInUser != null) {
			logger.info("STARTED getMyIngestionApproval");
			try {
			myApprovalList = workflowRequestService.getMyIngestionApproval(Integer.parseInt(loggedInUser.getUserId()), workflowType);
			} catch (Exception ex) {
				myApprovalList.setStatusCode(HttpStatus.NO_CONTENT.value());
				myApprovalList.setStatus(HttpStatus.NO_CONTENT.toString());
				myApprovalList.setResponse("Failed to update the status");
				logger.info("EXCEPTION MyApprovalController>workflowUpdate: " + ex.getMessage());
			}
			//myApprovalList = workflowRequestService.getMyIngestionApproval(userId);
			logger.info("EXITING getMyIngestionApproval");	
		} else {
			myApprovalList.setStatus(HttpStatus.UNAUTHORIZED.toString());
			myApprovalList.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
		
		return new ResponseEntity<Response> (myApprovalList, HttpStatus.OK);
	}
	
	
	

}
