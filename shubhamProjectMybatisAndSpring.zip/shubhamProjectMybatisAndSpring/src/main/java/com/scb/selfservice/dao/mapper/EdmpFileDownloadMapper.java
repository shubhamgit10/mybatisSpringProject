package com.scb.selfservice.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.DownloadFile;
import com.scb.selfservice.domains.EDMPEstimationMetaData;
import com.scb.selfservice.domains.IsdFileStore;

public interface EdmpFileDownloadMapper {

	// method to pull existing EdmpIngestionRequest based on reqId
	public List<DownloadFile> findByRequestId(@Param("reqId") Integer reqId);

	// method to pull existing EdmpIngestionRequest based on reqId
	public EDMPEstimationMetaData findBySourceType(@Param("sourceType") String sourceType);

	// method to pull existing EdmpIngestionRequest based on reqId
	public List<IsdFileStore> findIsdByReqId(@Param("reqId") String reqId);

}
