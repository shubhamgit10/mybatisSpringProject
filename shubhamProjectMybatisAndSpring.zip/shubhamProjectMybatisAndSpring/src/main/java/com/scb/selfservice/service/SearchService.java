package com.scb.selfservice.service;

import com.scb.selfservice.domains.FilterRequest;
import com.scb.selfservice.domains.SearchRequest;
import com.scb.selfservice.util.Response;

public interface SearchService {

	//Search based on DataSource
	public Response searchDataSource(SearchRequest searchRequest);

	//Search based on DataSet
	public Response searchDataSet(SearchRequest searchRequest);

	//Search based on Attributes
	public Response searchAttribute(SearchRequest searchRequest);

	//ApplyFilter based on requestBody
	public Response searchApplyFilter(FilterRequest filterRequest);

}
