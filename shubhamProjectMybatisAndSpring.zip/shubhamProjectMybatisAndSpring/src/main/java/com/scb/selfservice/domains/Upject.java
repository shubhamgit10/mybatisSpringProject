package com.scb.selfservice.domains;

/*
 * pojo for
 * Update/Reject
 */
public class Upject {

	private Integer reqId;
	private String  stepId;
	private Integer userId;
	private String  status;
	private String  remarks;
	private Integer workflowId;

	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Integer getWorkflowId() {
		return workflowId;
	}
	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}
	@Override
	public String toString() {
		return "Upject [reqId=" + reqId + ", stepId=" + stepId + ", userId=" + userId + ", status=" + status
				+ ", remarks=" + remarks + ", workflowId=" + workflowId + "]";
	}
}
