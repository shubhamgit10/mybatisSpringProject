package com.scb.selfservice.domains;

public class FilterRequest {
	private String dataSource;
	private String countries;
	private String segments;
	private String certified;
	private String datasets;
	private int startNum;
	private int endNum;
	
	public String getDataSource() {
		return dataSource;
	}
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
	public String getCountries() {
		return countries;
	}
	public void setCountries(String countries) {
		this.countries = countries;
	}
	public String getSegments() {
		return segments;
	}
	public void setSegments(String segments) {
		this.segments = segments;
	}
	public String getCertified() {
		return certified;
	}
	public void setCertified(String certified) {
		this.certified = certified;
	}
	public String getDatasets() {
		return datasets;
	}
	public void setDatasets(String datasets) {
		this.datasets = datasets;
	}
	public int getStartNum() {
		return startNum;
	}
	public void setStartNum(int startNum) {
		this.startNum = startNum;
	}
	public int getEndNum() {
		return endNum;
	}
	public void setEndNum(int endNum) {
		this.endNum = endNum;
	}
	@Override
	public String toString() {
		return "FilterRequest [dataSource=" + dataSource + ", countries=" + countries + ", segments=" + segments
				+ ", certified=" + certified + ", datasets=" + datasets + ", startNum=" + startNum + ", endNum="
				+ endNum + "]";
	}
		
}