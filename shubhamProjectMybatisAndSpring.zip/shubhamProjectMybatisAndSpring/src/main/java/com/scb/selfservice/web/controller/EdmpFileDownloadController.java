package com.scb.selfservice.web.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.domains.DownloadFile;
import com.scb.selfservice.domains.EDMPEstimationMetaData;
import com.scb.selfservice.domains.IsdFileStore;
import com.scb.selfservice.service.EdmpFileDownloadService;
import com.scb.selfservice.util.CommonUtils;
import com.scb.selfservice.util.EDMpUtil;

@RestController
@RequestMapping("/api/file")
public class EdmpFileDownloadController {

	private static Logger logger = LogManager.getLogger(EdmpFileDownloadController.class);

	@Autowired
	EdmpFileDownloadService edmpFileDownloadService;

	@GetMapping(path = "/download", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<InputStreamResource> getFile(@RequestParam Integer reqId) throws IOException {
		logger.info("STARTING EdmpFileDownloadController::getFile");
		List<DownloadFile> fileData = new ArrayList<DownloadFile>();

		fileData.addAll(edmpFileDownloadService.pullData(reqId));

		ByteArrayInputStream in = EDMpUtil.prepareXlsx(fileData);
		if (null == in) {
			return ResponseEntity.noContent().build();
		}

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=" + CommonUtils.fileName(reqId));
		logger.info("EXISTING EdmpFileDownloadController::getFile");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	@GetMapping(path = "/isddownload", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<InputStreamResource> getIsdFileTemplate(@RequestParam String sourceType) throws IOException {

		logger.info("STARTING EdmpFileDownloadController::getIsdFile");
		EDMPEstimationMetaData fileData = new EDMPEstimationMetaData();

		fileData = edmpFileDownloadService.pullIsdData(sourceType);

		ByteArrayInputStream in = EDMpUtil.prepareIsdXlsx(fileData);
		if (null == in) {
			return ResponseEntity.noContent().build();
		}

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=" + EDMpUtil.fileNameForIsd(sourceType));
		logger.info("EXISTING EdmpFileDownloadController::getIsdFile");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	@GetMapping(path = "/isdfilestoredownload", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<InputStreamResource> getIsdFileStoreTemplate(@RequestParam String reqId) throws IOException {

		logger.info("STARTING EdmpFileDownloadController::getIsdFileStoreTemplate");
		// IsdFileStore fileData = new IsdFileStore();

		// fileData = edmpFileDownloadService.pullIsdFileStoreData(reqId);

		List<IsdFileStore> fileData = edmpFileDownloadService.pullIsdFileStoreData(reqId);
		// fileData.addAll(edmpFileDownloadService.pullIsdFileStoreData(reqId));

		ByteArrayInputStream in = EDMpUtil.prepareIsdFileStoreXlsx(fileData);
		if (null == in) {
			return ResponseEntity.noContent().build();
		}

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=" + EDMpUtil.fileNameIsdFilestore(reqId));
		logger.info("EXISTING EdmpFileDownloadController::getIsdFileStoreTemplate");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

}
