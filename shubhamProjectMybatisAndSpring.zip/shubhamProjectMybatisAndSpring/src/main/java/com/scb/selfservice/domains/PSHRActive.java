package com.scb.selfservice.domains;

public class PSHRActive {
	
	private Integer PSID;
	private Boolean status;
	private String emailId;
	
	public Integer getPSID() {
		return PSID;
	}
	public void setPSID(Integer pSID) {
		PSID = pSID;
	}
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
}
