package com.scb.selfservice.elk.domains;

import java.util.List;

public class DynamicFilters {
	
	private List<String> dynamicDataset;
	private List<String> dynamicDatasource;
	private List<String> dynamicCountry;
	
	public List<String> getDynamicDataset() {
		return dynamicDataset;
	}
	public void setDynamicDataset(List<String> dynamicDataset) {
		this.dynamicDataset = dynamicDataset;
	}
	public List<String> getDynamicDatasource() {
		return dynamicDatasource;
	}
	public void setDynamicDatasource(List<String> dynamicDatasource) {
		this.dynamicDatasource = dynamicDatasource;
	}
	public List<String> getDynamicCountry() {
		return dynamicCountry;
	}
	public void setDynamicCountry(List<String> dynamicCountry) {
		this.dynamicCountry = dynamicCountry;
	}
	@Override
	public String toString() {
		return "DynamicFilters [dynamicDataset=" + dynamicDataset + ", dynamicDatasource=" + dynamicDatasource
				+ ", dynamicCountry=" + dynamicCountry + "]";
	}

}
