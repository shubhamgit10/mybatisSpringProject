package com.scb.selfservice.web.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.service.DemoService;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;

@RestController
@RequestMapping("/api/demo")
public class DemoController {

	@Autowired
	DemoService service;


	@RequestMapping(path = "/getCurrentTime", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public HashMap<String, Object> getCurrentTime() {
		HashMap<String, Object> res = new HashMap<String, Object>();
		res.put("TimeStamp-Oracle", service.getCurrentTime().toString());
		res.put("TimeStamp-Teradata", service.getCurrentTimeTeradata().toString());
		res.put("LoggedInUser", AppSecurityContextHolder.getLoggedInUser());
		return res;
	}	

}
