package com.scb.selfservice.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author shubhasi
 * 
 *         Request body model class
 */
public class CostEstimationRequest {

	private int estimationId;
	private int reqId;
	private String stepId;
	private String workflowType;
	private String sourceName;
	private String instances;
	private String sourcingType;
	private List<String> numberOfInstances;
	private int numberOfTables;
	private int numberOfColumnsAccrossTable;
	private String sourceDataSystem;
	private String fileFormat;
	private String downstreamOlaRequired;
	private String newTransformationRulesRequired;
	private String levelOfFrameworkCustomizationRequired;
	private String sourceSystemCommunication;
	private String plannedGoLiveMonth;
	private int historyData;
	private int incrementalData;
	private String sourceType;
	private String historyStorageType;
	private String incrementalStorageType;

	public int getEstimationId() {
		return estimationId;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public String getWorkflowType() {
		return workflowType;
	}

	public void setWorkflowType(String workflowType) {
		this.workflowType = workflowType;
	}

	public void setEstimationId(int estimationId) {
		this.estimationId = estimationId;
	}

	public String getHistoryStorageType() {
		return historyStorageType;
	}

	public void setHistoryStorageType(String historyStorageType) {
		this.historyStorageType = historyStorageType;
	}

	public String getIncrementalStorageType() {
		return incrementalStorageType;
	}

	public void setIncrementalStorageType(String incrementalStorageType) {
		this.incrementalStorageType = incrementalStorageType;
	}

	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public int getReqId() {
		return reqId;
	}

	public void setReqId(int reqId) {
		this.reqId = reqId;
	}

	public String getSourceName() {
		return sourceName;
	}

	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}

	public String getInstances() {
		return instances;
	}

	public void setInstances(String instances) {
		this.instances = instances;
	}

	public String getSourcingType() {
		return sourcingType;
	}

	public void setSourcingType(String sourcingType) {
		this.sourcingType = sourcingType;
	}

	public List<String> getNumberOfInstances() {
		return numberOfInstances;
	}

	public void setNumberOfInstances(List<String> numberOfInstances) {
		this.numberOfInstances = numberOfInstances;
	}

	public int getNumberOfTables() {
		return numberOfTables;
	}

	public void setNumberOfTables(int numberOfTables) {
		this.numberOfTables = numberOfTables;
	}

	public int getNumberOfColumnsAccrossTable() {
		return numberOfColumnsAccrossTable;
	}

	public void setNumberOfColumnsAccrossTable(int numberOfColumnsAccrossTable) {
		this.numberOfColumnsAccrossTable = numberOfColumnsAccrossTable;
	}

	public String getSourceDataSystem() {
		return sourceDataSystem;
	}

	public void setSourceDataSystem(String sourceDataSystem) {
		this.sourceDataSystem = sourceDataSystem;
	}

	public String getFileFormat() {
		return fileFormat;
	}

	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}

	public String getDownstreamOlaRequired() {
		return downstreamOlaRequired;
	}

	public void setDownstreamOlaRequired(String downstreamOlaRequired) {
		this.downstreamOlaRequired = downstreamOlaRequired;
	}

	public String getNewTransformationRulesRequired() {
		return newTransformationRulesRequired;
	}

	public void setNewTransformationRulesRequired(String newTransformationRulesRequired) {
		this.newTransformationRulesRequired = newTransformationRulesRequired;
	}

	public String getLevelOfFrameworkCustomizationRequired() {
		return levelOfFrameworkCustomizationRequired;
	}

	public void setLevelOfFrameworkCustomizationRequired(String levelOfFrameworkCustomizationRequired) {
		this.levelOfFrameworkCustomizationRequired = levelOfFrameworkCustomizationRequired;
	}

	public String getSourceSystemCommunication() {
		return sourceSystemCommunication;
	}

	public void setSourceSystemCommunication(String sourceSystemCommunication) {
		this.sourceSystemCommunication = sourceSystemCommunication;
	}

	public String getPlannedGoLiveMonth() {
		return plannedGoLiveMonth;
	}

	public void setPlannedGoLiveMonth(String plannedGoLiveMonth) {
		this.plannedGoLiveMonth = plannedGoLiveMonth;
	}

	public int getHistoryData() {
		return historyData;
	}

	public void setHistoryData(int historyData) {
		this.historyData = historyData;
	}

	public int getIncrementalData() {
		return incrementalData;
	}

	public void setIncrementalData(int incrementalData) {
		this.incrementalData = incrementalData;
	}

	@Override
	public String toString() {
		return "CostEstimationRequest [reqId=" + reqId + ", sourceName=" + sourceName + ", instances=" + instances
				+ ", sourcingType=" + sourcingType + ", numberOfInstances=" + numberOfInstances + ", numberOfTables="
				+ numberOfTables + ", numberOfColumnsAccrossTable=" + numberOfColumnsAccrossTable
				+ ", sourceDataSystem=" + sourceDataSystem + ", fileFormat=" + fileFormat + ", downstreamOlaRequired="
				+ downstreamOlaRequired + ", newTransformationRulesRequired=" + newTransformationRulesRequired
				+ ", levelOfFrameworkCustomizationRequired=" + levelOfFrameworkCustomizationRequired
				+ ", sourceSystemCommunication=" + sourceSystemCommunication + ", plannedGoLiveMonth="
				+ plannedGoLiveMonth + ", historyData=" + historyData + ", incrementalData=" + incrementalData + "]";
	}

}