package com.scb.selfservice.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.DeleteCart;
import com.scb.selfservice.domains.EDMPCartConsumptionRequest;
import com.scb.selfservice.domains.EDMPConsumpReqDetails;
import com.scb.selfservice.domains.EDMPSelfServiceReq;

public interface CartDataMapper {
	
	public int insertEDMPSelfService(@Param("insertEDMPSelfService")EDMPSelfServiceReq edmpSelfServiceReq);
	
	public int insertCartData(@Param("eDMPCartConsumptionRequest") List<EDMPCartConsumptionRequest> eDMPCartConsumptionRequest);
	
	public List<EDMPConsumpReqDetails> getCartData(@Param("requestId") Integer requestId);
	
	public Integer getDraftRequest(@Param("userId") Integer userId);

	//mapper for deleteCart
	public int deleteCart(@Param("deleteCart") DeleteCart deleteCart,@Param("instance") List<String> instance,@Param("segment") List<String> segment);
}
