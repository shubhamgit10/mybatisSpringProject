package com.scb.selfservice.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.EDMPColsMetaData;
import com.scb.selfservice.domains.EDMPTabsCount;
import com.scb.selfservice.domains.InstanceCountryMapping;
import com.scb.selfservice.domains.databaseentity.DBAppMetaData;
import com.scb.selfservice.domains.databaseentity.DBTabsMetaData;

public interface CatalogueDataLoadMapper {

	public List<DBAppMetaData> getDataSources();
	
	// Below method is in Ingestion
	public List<DBAppMetaData> getIngestionDataSources();
	
	public List<DBAppMetaData> getIngestionDS();
	
	public List<DBTabsMetaData> getDataSetName(@Param("itamId")String itamId, @Param("country")List<String> country);
	  
	public List<EDMPColsMetaData> getAttributeName(@Param("itamId")String itamId,@Param("tableName")String tableName);

	public List<EDMPTabsCount> getDataSetCount(@Param("tabsList") List<EDMPTabsCount> tabsList);
	
	public List<InstanceCountryMapping> getInstanceCountryMap();
	
}
