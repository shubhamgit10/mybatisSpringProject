package com.scb.selfservice.domains;

import java.util.List;

/*
 * pojo for
 * DeleteCart > EDMP_CONSUMP_REQ_DETAILS
 */
public class DeleteCart {
	private Integer reqId;
	private String  appName;
	private List<String>  instance;
	private List<String>  segment;
	private String  tableName;

	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public List<String> getInstance() {
		return instance;
	}
	public void setInstance(List<String> instance) {
		this.instance = instance;
	}
	public List<String> getSegment() {
		return segment;
	}
	public void setSegment(List<String> segment) {
		this.segment = segment;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	@Override
	public String toString() {
		return "DeleteCart [reqId=" + reqId + ", appName=" + appName + ", instance=" + instance + ", segment=" + segment
				+ ", tableName=" + tableName + "]";
	}
}
