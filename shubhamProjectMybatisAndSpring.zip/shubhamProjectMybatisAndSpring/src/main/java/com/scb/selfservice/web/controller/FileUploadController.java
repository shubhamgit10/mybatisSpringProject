package com.scb.selfservice.web.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import com.scb.selfservice.domains.FileUpload;
import com.scb.selfservice.service.FileUploadService;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;
import com.scb.selfservice.web.authentication.UserPrincipal;

@RestController
@RequestMapping("/api/upload")
public class FileUploadController {

	Logger logger = LogManager.getLogger(FileUploadController.class);

	@Autowired
	FileUploadService fileUploadService;

	@RequestMapping(path = "/fileUpload", method = RequestMethod.POST,consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> saveUploadedFileInDatabase(HttpServletRequest request,@RequestParam CommonsMultipartFile uploadFileObj,
			@RequestParam Integer uploadId) throws IllegalStateException, IOException {
		Response response = new Response();
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		if (loggedInUser == null) {
			response.setStatus(HttpStatus.UNAUTHORIZED.toString());
			response.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		} else {
			if (uploadFileObj.isEmpty()) {
				logger.info("Received files is empty");
				response.setStatusCode(HttpStatus.NO_CONTENT.value());
				response.setStatus("No Content");
				response.setResponse("");
			} else {
				logger.info("Inside processing received files...");
				if (!uploadFileObj.getOriginalFilename().trim().equals("")) {
					FileUpload fileUploadObj = new FileUpload();
					fileUploadObj.setUploadId(uploadId);
					fileUploadObj.setFileName(uploadFileObj.getOriginalFilename().trim());
					fileUploadObj.setContent(uploadFileObj.getBytes());
					fileUploadObj.setFileType(uploadFileObj.getContentType());
					fileUploadObj.setUserId(Integer.valueOf(loggedInUser.getUserId()));
					response= fileUploadService.uploadFile(fileUploadObj);
				}
			}
		}
		return  new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(path = "/fileDelete", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> deleteUploadedFile(@RequestParam("uploadId") Integer uploadId) {
		Response response = new Response();
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		logger.info("Inside processing delete file...");
		if (loggedInUser == null) {
			response.setStatus(HttpStatus.UNAUTHORIZED.toString());
			response.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		} else {
			try {
				response= fileUploadService.deleteFile(uploadId);
			} catch (Exception ex) {
				logger.info("EXCEPTION - fileDelete" + ex.getMessage());
				response.setStatus(HttpStatus.NO_CONTENT.toString());
				response.setStatusCode(HttpStatus.NO_CONTENT.value());
				response.setResponse("DeleteFile failed for " + uploadId);
			}
		}
		return  new ResponseEntity<Response>(response, HttpStatus.OK);
	}
}

