package com.scb.selfservice.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.selfservice.dao.mapper.EdmpFileDownloadMapper;
import com.scb.selfservice.domains.DownloadFile;
import com.scb.selfservice.domains.EDMPEstimationMetaData;
import com.scb.selfservice.domains.EDMPLookupTable;
import com.scb.selfservice.domains.IngestionRequest;
import com.scb.selfservice.domains.IsdFileStore;
import com.scb.selfservice.service.EdmpFileDownloadService;
import com.scb.selfservice.service.PopulateDropDownService;
import com.scb.selfservice.util.Response;

@Service
public class EdmpFileDownloadServiceImpl implements EdmpFileDownloadService {

	private static Logger logger = LogManager.getLogger(FileDownloadServiceImpl.class);

	@Autowired
	EdmpFileDownloadMapper edmpFileDownloadMapper;

	@Autowired
	PopulateDropDownService populateDropDownService;

	private HashMap<String, String> getLookupData() {
		logger.info("STARTED EdmpFileDownloadServiceImpl::getLookupData");
		HashMap<String, String> dropDownData = new HashMap<>();
		Response response = populateDropDownService.getDropDownValues();
		List<EDMPLookupTable> lookupTables = (List<EDMPLookupTable>) response.getResponse();
		String key = null;
		String value = null;
		for (EDMPLookupTable edmpLookupTable : lookupTables) {
			key = edmpLookupTable.getTableName() + edmpLookupTable.getCode();
			value = edmpLookupTable.getDescription();
			dropDownData.put(key, value);
		}
		return dropDownData;
	}

	@Override
	public List<DownloadFile> pullData(Integer reqId) {
		logger.info("STARTED EdmpFileDownloadServiceImpl::pullData");
		HashMap<String, String> dropDownData = getLookupData();
		List<DownloadFile> fileData = edmpFileDownloadMapper.findByRequestId(reqId);
		List<DownloadFile> fileData1 = new ArrayList<>();
		String key = StringUtils.EMPTY;
		String value = StringUtils.EMPTY;

		for (DownloadFile downloadFile : fileData) {

			key = downloadFile.getYearsOfHistoryIsReq();
			value = dropDownData.get("INGESTION History-Duration" + key);
			downloadFile.setYearsOfHistoryIsReq(value);

			/*
			 * key = ingestionRequest.getHistoryStorageType(); value =
			 * dropDownData.get("HISTORY-DATA-STORAGE-TYPE" + key);
			 * ingestionRequest.setHistoryStorageType(value);
			 */

			key = downloadFile.getFrequency();
			value = dropDownData.get("INGESTION FREQUENCY" + key);
			downloadFile.setFrequency(value);

			/*
			 * key = ingestionRequest.getIncrementalStorageType(); value =
			 * dropDownData.get("INCREMENTAL-DATA-STORAGE-TYPE" + key);
			 * ingestionRequest.setIncrementalStorageType(value);
			 */

			key = downloadFile.getPriority();
			value = dropDownData.get("Priority" + key);
			downloadFile.setPriority(value);

			key = downloadFile.getBusinessStream();
			value = dropDownData.get("Business Stream" + key);
			downloadFile.setBusinessStream(value);

			key = downloadFile.getFundingAvenue();
			value = dropDownData.get("Funding Avenue" + key);
			downloadFile.setFundingAvenue(value);

			key = downloadFile.getBenefitCatagory();
			value = dropDownData.get("Benefit Category" + key);
			downloadFile.setBenefitCatagory(value);

			fileData1.add(downloadFile);
		}
		logger.info("EXITING EdmpFileDownloadServiceImpl::pullData");
		return fileData1;

	}

	@Override
	public EDMPEstimationMetaData pullIsdData(String sourceType) {
		logger.info("STARTED EdmpFileDownloadServiceImpl::pullIsdData");
		EDMPEstimationMetaData fileData = edmpFileDownloadMapper.findBySourceType(sourceType);
		logger.info("EXITING EdmpFileDownloadServiceImpl::pullIsdData");
		return fileData;
	}

	@Override
	public List<IsdFileStore> pullIsdFileStoreData(String reqId) {
		logger.info("STARTED EdmpFileDownloadServiceImpl::pullIsdFileStoreData");
		List<IsdFileStore> fileData = edmpFileDownloadMapper.findIsdByReqId(reqId);
		logger.info("EXITING EdmpFileDownloadServiceImpl::pullIsdFileStoreData");
		return fileData;
	}

}
