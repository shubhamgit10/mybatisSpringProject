package com.scb.selfservice.model.RangerPolicy;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;

/**
 * Created by 1610601 on 7/30/2020.
 */

@JsonAutoDetect(fieldVisibility = Visibility.ANY)
public class RangerPolicyHiveResourcesModel extends RangerPolicyResourcesModel  implements Serializable {

    private RangerPolicyResourceSupportingModel database;
    private RangerPolicyResourceSupportingModel column;
    private RangerPolicyResourceSupportingModel table;

    /**
     *
     */
    public RangerPolicyHiveResourcesModel() {
        super();
        this.database = new RangerPolicyResourceSupportingModel();
        this.column = new RangerPolicyResourceSupportingModel();
        this.table = new RangerPolicyResourceSupportingModel();
    }

    /**
     * @param database
     * @param column
     * @param table
     */
    public RangerPolicyHiveResourcesModel(RangerPolicyResourceSupportingModel database,
                                      RangerPolicyResourceSupportingModel column, RangerPolicyResourceSupportingModel table) {
        super();
        this.database = database;
        this.column = column;
        this.table = table;
    }

    public RangerPolicyResourceSupportingModel getDatabase() {
        return database;
    }

    public void setDatabase(RangerPolicyResourceSupportingModel database) {
        this.database = database;
    }

    public RangerPolicyResourceSupportingModel getColumn() {
        return column;
    }

    public void setColumn(RangerPolicyResourceSupportingModel column) {
        this.column = column;
    }

    public RangerPolicyResourceSupportingModel getTable() {
        return table;
    }

    public void setTable(RangerPolicyResourceSupportingModel table) {
        this.table = table;
    }

    @Override
    public String toString() {
        return "RangerPolicyHiveResourcesModel [database=" + database + ", column=" + column + ", table=" + table + "]";
    }

}
