package com.scb.selfservice.dao.ps;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ExportBlobFromDb {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
	    Class.forName("oracle.jdbc.driver.OracleDriver");
	    Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@10.100.252.150:1521:orcl","edmp_api","edmp_api");
	    String sql = "Select cost_estimation_sheet from edmp_estimation_req where estimation_id='625'";
	    PreparedStatement stmt = conn.prepareStatement(sql);
	    ResultSet rs = stmt.executeQuery();
	    byte[] docBlob = null;
//	    String filename = null;
	    FileOutputStream fos = new FileOutputStream("C://Users/shubhasi/test.xlsx");
//	    ZipOutputStream zos = new ZipOutputStream(fos);
	    while (rs.next()) {
	        docBlob = rs.getBytes("cost_estimation_sheet");
//	        filename = rs.getString("ORIG_NM");
	        try {
//	            zos.putNextEntry(new ZipEntry(filename));
	            fos.write(docBlob, 0, docBlob.length);
	        } catch (FileNotFoundException ex) {
	            System.err.println("A file does not exist: " + ex);
	        } catch (IOException ex) {
	            System.err.println("I/O error: " + ex);
	        }
	        fos.close();
	    }
	    System.out.println("downloaded");

	}
}
