package com.scb.selfservice.service;

import com.scb.selfservice.domains.BizAnylstResponse;
import com.scb.selfservice.domains.IngestionDmApproval;
import com.scb.selfservice.domains.IngestionRequestorResp;
import com.scb.selfservice.domains.IngestionSolArchApproval;
import com.scb.selfservice.util.Response;

public interface EdmpIngestionRequestProcessService {
	
	
	Response saveSolutionArchResp(IngestionSolArchApproval ingestionSolArchApproval, Integer userId) throws Exception;
	
	Response saveDmApprovalResp(IngestionDmApproval ingestionDmApproval, Integer userId) throws Exception;
		
	Response saveIngestionRequestorResp(IngestionRequestorResp ingestionRequestorResp, Integer userId) throws Exception;

	Response saveIngestionResponses(Object obj, String stepId, Integer workflowId);

	Response savebizAnalystResp(BizAnylstResponse bizAnResponse, Integer userId) throws Exception;

	//Get API :: getCostApproval
	Response getIngestionRequestorResp(Integer reqId) throws Exception;
}
