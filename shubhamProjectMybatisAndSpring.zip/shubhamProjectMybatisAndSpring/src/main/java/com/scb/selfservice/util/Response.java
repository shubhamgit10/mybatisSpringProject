/**
 * 
 */
package com.scb.selfservice.util;

public class Response {

	public String status;
	
	public Integer statusCode;
	
	public Object response ;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	public Object getResponse() {
		return response;
	}

	public void setResponse(Object response) {
		this.response = response;
	}

	/*
	 * public List<Object> getResponse() { return response; }
	 * 
	 * public void setResponse(List<Object> response) { this.response = response; }
	 */

	
	
	/*
	 * public List<EDMPAppMetaData> getResponse() { return response; }
	 * 
	 * public void setResponse(List<EDMPAppMetaData> response) { this.response =
	 * response; }
	 */
	
	
}
