package com.scb.selfservice.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.EdmpIngDmApprovalMapper;
import com.scb.selfservice.dao.mapper.EdmpIngRequestorRespMapper;
import com.scb.selfservice.dao.mapper.EdmpIngSolArchReqMapper;
import com.scb.selfservice.dao.mapper.EdmpIngestionRequestMapper;
import com.scb.selfservice.dao.mapper.MyRequestMapper;
import com.scb.selfservice.dao.mapper.WorkflowMapper;
import com.scb.selfservice.dao.mapper.WorkflowRespTableMapper;
import com.scb.selfservice.domains.EDMPConsumReqUserResp;
import com.scb.selfservice.domains.IngestionInput;
import com.scb.selfservice.domains.IngestionWorkflowResponse;
import com.scb.selfservice.domains.MyrequestData;
import com.scb.selfservice.domains.WorkflowReqStepsAt;
import com.scb.selfservice.domains.WorkflowRequestStepsNames;
import com.scb.selfservice.domains.WorkflowRespTableMapping;
import com.scb.selfservice.service.MyRequestService;
import com.scb.selfservice.service.UserResponseService;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.workflow.service.WorkflowRequestService;


@Service
public class MyRequestServiceImpl implements MyRequestService {

	private static Logger logger = LogManager.getLogger(MyRequestServiceImpl.class);

	@Autowired
	private MyRequestMapper requestMapper;
	@Autowired
	private WorkflowMapper workflowMapper;
	@Autowired
	private EdmpIngSolArchReqMapper edmpIrpMapper;

	@Autowired
	EdmpIngRequestorRespMapper edmpirrMapper;

	@Autowired
	EdmpIngDmApprovalMapper edmpDmMapper;

	@Autowired
	private WorkflowRequestService workflowRequestService; 
	
	@Autowired
	IngestionWorkflowResponse ingestionWorkflowResponse;
	
	@Autowired
	EdmpIngestionRequestMapper edmpIngestionRequestMapper;

	@Autowired
	ConsumerRequestEmailServiceImpl cancelEmail;
	
	@Autowired
	ApplicationContext applicationContext;

	@Autowired
	WorkflowRespTableMapper wfrTableMapper;

	/*
	 * @Autowired IngestionInput ingestioninput;
	 */

	@Override
	@Transactional
	public Response getMyRequest(Integer userId, String workflowType) {
		Response requestListResponse = new Response();
		try {
			
			Integer workflowId = workflowRequestService.getWorkflowId(workflowType);
			List<MyrequestData>requestList = requestMapper.getMyRequest(userId, workflowId, workflowType);
			if (requestList.isEmpty()) {
				requestListResponse.setStatus(HttpStatus.NO_CONTENT.toString());
				requestListResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			} else {
				requestListResponse.setResponse(requestList);
				requestListResponse.setStatusCode(HttpStatus.OK.value());
				requestListResponse.setStatus(HttpStatus.OK.toString());
			}
		} catch (Exception ex) {
			logger.info("MyRequestServiceImpl->getMyRequest failed for: " + workflowType + " with "+ ex.getMessage());
			requestListResponse.setStatus(HttpStatus.NO_CONTENT.toString());
			requestListResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
		}
		return requestListResponse;
	}

	@Override
	@Transactional
	public Response getApprovalWorkflow(Integer requestId, String workflowType) throws Exception {
		
		List<WorkflowRequestStepsNames> approvalWorkflowList = 
				workflowRequestService.getWorkflowRequestStepsById(requestId, workflowType);
		Response response = new Response();
		if (approvalWorkflowList.isEmpty()) {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
		} else {
			Integer workflowId = workflowRequestService.getWorkflowId(workflowType);
			HashMap<String, Object> myRequestworkflow = new HashMap<>();
			List<EDMPConsumReqUserResp> approvalResponseList = requestMapper.getApprovalResponse(requestId, workflowId);
			List<EDMPConsumReqUserResp> approvalfileIdList = requestMapper.getApprovalResponseFileID(requestId, workflowId);

			List<EDMPConsumReqUserResp> aprrovalResponseTab = new ArrayList<>();
			aprrovalResponseTab.addAll(approvalfileIdList);
			aprrovalResponseTab.addAll(approvalResponseList);

			myRequestworkflow.put("approvalWorkflow", approvalWorkflowList);
			myRequestworkflow.put("approvalResponseList", aprrovalResponseTab);

			response.setResponse(myRequestworkflow);
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus(HttpStatus.OK.toString());
		}
		return response;
	}

	//method for canceling requestor's submitted workflow_request
	@Override
	@Transactional(rollbackFor = Exception.class)
	public Response cancelRequest(HashMap<String, String> cancelMap) throws Exception {
		logger.info("STARTED MyRequestServiceImpl::cancelWorkflow");
		Response cancelResponse = new Response();
		try {
			WorkflowReqStepsAt audit = getAudit(cancelMap);
			
			int cancelValue = requestMapper.cancelRequestWorkflowRequestSteps(audit);
			if (cancelValue == 0)
				throw new Exception ("EXCEPTION - CANCEL - Workflow_Request_steps");
			
			cancelValue = requestMapper.cancelRequestWorkflowRequest(audit);
			if (cancelValue == 0)
				throw new Exception ("EXCEPTION - CANCEL - Workflow_Request");
		
			cancelValue = requestMapper.CancelRequestEdmpSelfServiceReq(audit);
			if (cancelValue == 0)
				throw new Exception ("EXCEPTION - CANCEL - edmp_selfservice_req");
		
			//Now time for audit
			cancelValue = workflowMapper.insertIntoWorkflowReqStepsAt(getAudit(cancelMap));
			if (cancelValue == 0)
				throw new Exception ("EXCEPTION - CANCEL - workflow_req_steps_at");

			//Now it is time for sending an email//
			cancelEmail.sendStatusMail(audit.getReqId(), audit.getStepId(), "CANCELLED");

			cancelResponse.setStatusCode(HttpStatus.OK.value());
			cancelResponse.setStatus(HttpStatus.OK.toString());
			cancelResponse.setResponse("Request " + cancelMap.get("reqId") + " is cancelled.");
		} catch(Exception ex) {
			throw new Exception (ex.getMessage());
		}
		logger.info("EXITING MyRequestServiceImpl::cancelWorkflow");
		return cancelResponse;
	}

	//method to populate the audit pojo
	private WorkflowReqStepsAt getAudit(HashMap<String, String> cancelMap) throws Exception {
		WorkflowReqStepsAt audit = new WorkflowReqStepsAt();
		audit.setReqId(Integer.parseInt(cancelMap.get("reqId")));
		audit.setStepId(cancelMap.get("stepId"));
		audit.setWorkflowId(workflowRequestService.getWorkflowId(cancelMap.get("workflowType")));
		audit.setStatus(cancelMap.get("status"));
		audit.setRemarks(cancelMap.get("remarks"));
		audit.setStepActionedBy(Integer.parseInt(cancelMap.get("userId")));
		audit.setStepAction(cancelMap.get("status"));
		audit.setStartTime(new Timestamp(System.currentTimeMillis()));
		return audit;
	}
	
	/**
	 * Ingestion - 
	 */
	@Transactional
	@Override
	public Response getMyIngestionRequest(Integer userId, String workflowType) {
		Response requestListResponse = new Response();
		try {
		// TODO Auto-generated method stub
		Integer workflowId = workflowRequestService.getWorkflowId(workflowType);
		List<MyrequestData>requestList = requestMapper.getMyIngestionRequest(userId, workflowId, workflowType);
		if (requestList.isEmpty()) {
			requestListResponse.setStatus(HttpStatus.NO_CONTENT.toString());
			requestListResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
		} else {
			requestListResponse.setResponse(requestList);
			requestListResponse.setStatusCode(HttpStatus.OK.value());
			requestListResponse.setStatus(HttpStatus.OK.toString());
		}
		} catch (Exception ex) {
			logger.info("MyRequestServiceImpl->getMyRequest failed for: " + workflowType + " with "+ ex.getMessage());
			requestListResponse.setStatus(HttpStatus.NO_CONTENT.toString());
			requestListResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
		}
		return requestListResponse;
	}
	@Transactional
	@Override
	public Response getIngestionApprovalWorkflow(Integer requestId, String workflowType) throws Exception {
		List<WorkflowRequestStepsNames> approvalWorkflowList = 
				workflowRequestService.getWorkflowRequestStepsById(requestId, workflowType);
		List<IngestionWorkflowResponse> ingestionWorkflowResponses = null;
		//String stepClassName = null;
		//WorkflowRespTableMapping workflowRespTableMap = null;
		//AutowireCapableBeanFactory factory = null;
		//UserResponseService userResponseService = null;
		Response response = new Response();
		IngestionInput ingestioninput = new IngestionInput();
		//Response approvalResponse = null;
		if (approvalWorkflowList.isEmpty()) {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
		} else {
			Integer workflowId = workflowRequestService.getWorkflowId(workflowType);
			HashMap<String, Object> myRequestworkflow = new HashMap<>();
			/*
			 * List<EDMPConsumReqUserResp> approvalResponseList =
			 * requestMapper.getApprovalResponse(requestId, workflowId);
			 * List<EDMPConsumReqUserResp> approvalfileIdList =
			 * requestMapper.getApprovalResponseFil eID(requestId, workflowId);
			 * 
			 * List<EDMPConsumReqUserResp> aprrovalResponseTab = new ArrayList<>();
			 * aprrovalResponseTab.addAll(approvalfileIdList);
			 * aprrovalResponseTab.addAll(approvalResponseList);
			 */
			//ingestionWorkflowResponse.setS0(edmpIngestionRequestMapper.findByRequestId(requestId));
			/*
			 * ingestionWorkflowResponse.setS2(edmpIrpMapper.findByRequestId(requestId));
			 * ingestionWorkflowResponse.setS4(edmpirrMapper.findByRequestId(requestId));
			 * ingestionWorkflowResponse.setS6(edmpDmMapper.findByRequestId(requestId));
			 */
			Map<String, Object> workflowReponse = new HashMap<>();
			//ingestionWorkflowResponses = 
			Map<String, Object> workflowReponses = new HashMap<>();
			workflowReponses = 
			approvalWorkflowList
			.stream()
			.map((WorkflowRequestStepsNames workflowRequest)-> {
				WorkflowRespTableMapping workflowRespTableMap = wfrTableMapper.findByStepId(workflowId, workflowRequest.getStepId());
				Response approvalResponse = null;
				if(workflowRespTableMap!=null) {
				if((!"S0".equals(workflowRequest.getStepId())) && 
						("COMPLETED".equals(workflowRequest.getStatus()) ||
								"PENDING".equals(workflowRequest.getStatus()))) {
					logger.info(workflowRespTableMap.getStepClassName());
					String stepClassName = workflowRespTableMap.getStepClassName();
					if(stepClassName!=null && !"".equals(stepClassName)) {
						UserResponseService userResponseService = (UserResponseService) applicationContext.getBean(stepClassName);
						AutowireCapableBeanFactory factory = applicationContext.getAutowireCapableBeanFactory();
						factory.autowireBean(userResponseService);
						factory.initializeBean(userResponseService, stepClassName);
						//System.out.println("Before workflow response");
						ingestioninput.setReqId(requestId);
						ingestioninput.setStepId(workflowRequest.getStepId());
						ingestioninput.setRemarks(workflowRequest.getStepName());
						approvalResponse = userResponseService.fetchApprovalResponse(ingestioninput);
						//System.out.println("After workflow response");
						//return approvalResponse;		
						//ingestionWorkflowResponse = new IngestionWorkflowResponse();
						workflowReponse.put(workflowRequest.getStepId(),approvalResponse.getResponse() );
						//ingestionWorkflowResponse.setStepName(workflowRequest.getStepName());
						//ingestionWorkflowResponse.setWorkflowApprovalResponse(approvalResponse);
						
					//}
					} else {
						workflowReponse.put(workflowRequest.getStepId(),new Response());
					}
				}
				} else {
					workflowReponse.put(workflowRequest.getStepId(),null);
				}
				return workflowReponse;
				//return approvalResponse;
			})
			
			 .collect(HashMap::new, HashMap::putAll, HashMap::putAll)
			;
			
			workflowReponses.values().removeIf(Objects::isNull);
			//.forEach(step->ingestionWorkflowResponseList.setStepName(step.getStepName()));
			
			myRequestworkflow.put("approvalWorkflow", approvalWorkflowList);
			myRequestworkflow.put("approvalResponse", workflowReponses);

			response.setResponse(myRequestworkflow);
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus(HttpStatus.OK.toString());
		}
		return response;
	}


}
