/**
 * 
 */
package com.scb.selfservice.model;

/**
 * @author 1565003
 *
 */
public class Roles {
	
	protected String roleName;

	/**
	 * @return the roleName
	 */
	public String getRoleName() {
		return roleName;
	}

	/**
	 * @param roleName the roleName to set
	 */
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return roleName;
	}
	
	

}
