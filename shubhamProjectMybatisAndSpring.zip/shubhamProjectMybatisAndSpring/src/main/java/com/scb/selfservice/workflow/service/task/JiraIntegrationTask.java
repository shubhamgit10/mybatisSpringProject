/**
 * 
 */
package com.scb.selfservice.workflow.service.task;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.selfservice.service.JIRAIntegrationService;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;
import com.scb.selfservice.web.authentication.UserPrincipal;
import com.scb.selfservice.workflow.service.ExecutionContext;
import com.scb.selfservice.workflow.service.WorkflowServiceTask;

/**
 * Job to integrate JIRA Creation
 * 
 * @author Amarnath BB
 *
 */
@Service(value = "jiraIntegrationTask")
public class JiraIntegrationTask implements WorkflowServiceTask {

	@Autowired
	private JIRAIntegrationService jiraIntegrationService;

	@Override
	public String execute(ExecutionContext ctx) {
		if (ctx != null && "APPROVE".equalsIgnoreCase(ctx.getAction())) {
			UserPrincipal luser = AppSecurityContextHolder.getLoggedInUser();
			try {
				jiraIntegrationService.createOrUpdateJiraDetails(ctx.getReqId(), ctx.getStepId(), luser.getUserId());
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return "SUCCESS";
	}

}
