package com.scb.selfservice.service.impl;

import com.scb.selfservice.config.PropertyConfigurer;
import com.scb.selfservice.dao.mapper.ingestion.SourceMapper;
import com.scb.selfservice.model.SourceDetails;
import com.scb.selfservice.service.FileService;
import com.scb.selfservice.service.IngestionConfigFileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

public class IngestionConfigFileServiceImpl implements IngestionConfigFileService {

    @Autowired
    private SourceMapper sourceMapper;

    @Autowired
    private FileService fileService;

    String configFileBasePath = PropertyConfigurer.getProperty("ingestion.config.basepath");
    String hdfsBasePath = PropertyConfigurer.getProperty("ingestion.hdfs.basepath");

    String hiveURL = PropertyConfigurer.getProperty("ingestion.hive.url");
    String hiveDRURL = PropertyConfigurer.getProperty("ingestion.hive.dr.url");


    public boolean createDRPartitionFile(int sourceId){
        Map<String,Object> drPartitionParam = new HashMap<String,Object> ();
        SourceDetails sourceDetails = sourceMapper.getSourceDetails(sourceId);

        String sourceSystem = sourceDetails.getSourceSystem().toLowerCase();
        String countryCode = sourceDetails.getCountryCode().toLowerCase();

        drPartitionParam.put("sourceSystem",sourceSystem);
        drPartitionParam.put("countryCode",countryCode);

        drPartitionParam.put("hiveUser", sourceDetails.getAppUserId());
        drPartitionParam.put("hiveUri", hiveURL);

        drPartitionParam.put("hiveDRUser", sourceDetails.getAppDRUserId());
        drPartitionParam.put("hiveDRUri", hiveDRURL);

        drPartitionParam.put("hdfsBasePath", hdfsBasePath);
        drPartitionParam.put("currentDayQuery", "");
        drPartitionParam.put("listPartitionsQuery", "");
        drPartitionParam.put("monthEndQuery", "");

        if (configFileBasePath.substring(configFileBasePath.length() - 1) != "/"){
            configFileBasePath += "/";
        }

        String filePath = configFileBasePath + "configs";
        String fileName= "prd" + "_" + sourceSystem + "_" + countryCode + "_dr_partitions.conf";
        fileService.saveTemplateAsFile(filePath,fileName,"dr-partition.ftl", drPartitionParam,true);

        // Change hive user and url is getting change for DR file

        drPartitionParam.replace("hiveUser", sourceDetails.getAppDRUserId());
        drPartitionParam.replace("hiveUri", hiveDRURL);

        drPartitionParam.replace("hiveDRUser", sourceDetails.getAppUserId());
        drPartitionParam.replace("hiveDRUri", hiveURL);

        fileName= "dr" + "_" + sourceSystem + "_" +  countryCode+ "_dr_partitions.conf";
        fileService.saveTemplateAsFile(filePath,fileName,"dr-partition.ftl", drPartitionParam,true);

        return true;
    }


    public boolean createRetentionFile(int sourceId){
        Map<String,Object> drPartitionParam = new HashMap<String,Object> ();
        SourceDetails sourceDetails = sourceMapper.getSourceDetails(sourceId);

        String sourceSystem = sourceDetails.getSourceSystem().toLowerCase();
        String countryCode = sourceDetails.getCountryCode().toLowerCase();

        drPartitionParam.put("sourceSystem",sourceSystem);
        drPartitionParam.put("countryCode",countryCode);

        drPartitionParam.put("hiveUser", sourceDetails.getAppUserId());
        drPartitionParam.put("hiveUri", hiveURL);

        drPartitionParam.put("hiveDRUser", sourceDetails.getAppDRUserId());
        drPartitionParam.put("hiveDRUri", hiveDRURL);

        drPartitionParam.put("hdfsBasePath", hdfsBasePath);
        drPartitionParam.put("nasBasePath", "");
        drPartitionParam.put("currentDayQuery", "");
        drPartitionParam.put("listPartitionsQuery", "");
        drPartitionParam.put("monthEndQuery", "");

        if (configFileBasePath.substring(configFileBasePath.length() - 1) != "/"){
            configFileBasePath += "/";
        }

        String filePath = configFileBasePath + "configs";
        String fileName= "prd" + "_" + sourceSystem + "_" + countryCode + "_retention.conf";
        fileService.saveTemplateAsFile(filePath,fileName,"retention.ftl", drPartitionParam,true);

        // Change hive user and url is getting change for DR file

        drPartitionParam.replace("hiveUser", sourceDetails.getAppDRUserId());
        drPartitionParam.replace("hiveUri", hiveDRURL);

        drPartitionParam.replace("hiveDRUser", sourceDetails.getAppUserId());
        drPartitionParam.replace("hiveDRUri", hiveURL);

        fileName= "dr" + "_" + sourceSystem + "_" +  countryCode+ "_retention.conf";
        fileService.saveTemplateAsFile(filePath,fileName,"retention.ftl", drPartitionParam,true);

        return true;
    }

}
