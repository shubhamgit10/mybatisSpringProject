package com.scb.selfservice.service.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.scb.selfservice.dao.mapper.FileUploadMapper;
import com.scb.selfservice.domains.FileUpload;
import com.scb.selfservice.service.FileUploadService;
import com.scb.selfservice.util.Response;

@Service
public class FileUploadServiceImpl implements FileUploadService {

	private static Logger logger = LogManager.getLogger(FileUploadServiceImpl.class);
	
	@Autowired
	FileUploadMapper fileUpdateMapper;

	@Override
	@Transactional(rollbackFor = Exception.class)
	public Response uploadFile(FileUpload fileupload) {
		Response uploadResponse = new Response();
		logger.info("STARTED FileUploadServiceImpl::insertFile");
		int uploadId = 0;
		if (StringUtils.isEmpty(fileupload.getUploadId())) {
			uploadId = fileUpdateMapper.insertFile(fileupload);
		} else {
			uploadId = fileUpdateMapper.updateFile(fileupload);			
		}
		logger.info("After fileUpload the return value is: " + uploadId + "        " + fileupload.getUploadId());
		logger.info("EXITING FileUploadServiceImpl::insertFile");
		if (uploadId == 0) {
			uploadResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			uploadResponse.setStatus("File Not Upoaded");
		} else 
		{
			fileupload.setContent(null);
			uploadResponse.setStatusCode(HttpStatus.OK.value());
			uploadResponse.setStatus("Success");
			uploadResponse.setResponse(fileupload);
		}		
		return uploadResponse;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public Response deleteFile(Integer fileId) throws Exception {
		Response deleteResponse = new Response();
		logger.info("STARTED FileUploadServiceImpl::deleteFile");

		int id = fileUpdateMapper.deleteFile(fileId);			
		if (id == 0) {
			logger.info("EXCEPTION - fileDelete - file not deleted " + fileId);
			throw new Exception("EXCEPTION - file not deleted");
		}
		deleteResponse.setStatusCode(HttpStatus.OK.value());
		deleteResponse.setStatus(HttpStatus.OK.toString());
		deleteResponse.setResponse("DeleteFile success for " + fileId);
		return deleteResponse;
	}
}
