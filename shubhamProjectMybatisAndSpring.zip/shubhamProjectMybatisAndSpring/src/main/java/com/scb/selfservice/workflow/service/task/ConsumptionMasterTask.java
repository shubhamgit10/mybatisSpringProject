/**
 * 
 */
package com.scb.selfservice.workflow.service.task;

import org.springframework.stereotype.Service;

import com.scb.selfservice.workflow.service.ExecutionContext;
import com.scb.selfservice.workflow.service.WorkflowServiceTask;

/**
 * Consumption Master Creation Task for Consumption Workflow
 * 
 * @author Amarnath BB
 *
 */
@Service(value = "consumptionMasterTask")
public class ConsumptionMasterTask implements WorkflowServiceTask {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.selfservice.workflow.service.WorkflowServiceTask#execute(com.scb.
	 * selfservice.workflow.service.ExecutionContext)
	 */
	@Override
	public String execute(ExecutionContext ctx) {
		System.out.println("Inside Consumption Master Task for " + ctx.getReqId() + " - " + ctx.getStepId());
		if ("APPROVE".equalsIgnoreCase(ctx.getAction())) {
			// moved the logic as part of Ranger Policy code
		}
		System.out.println("Inside Consumption Master Task for Request id " + ctx.getReqId());
		return "SUCCESS";
	}

}
