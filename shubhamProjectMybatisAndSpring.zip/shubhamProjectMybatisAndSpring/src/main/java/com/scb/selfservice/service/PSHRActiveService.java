package com.scb.selfservice.service;

import java.util.HashMap;
import java.util.List;

import com.scb.selfservice.domains.PSHRActive;
import com.scb.selfservice.util.Response;

public interface PSHRActiveService {
	
	public Response validate(HashMap<String, List<PSHRActive>> requestBody);
	public Response validated(String staffName);
}
