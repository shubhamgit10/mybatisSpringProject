package com.scb.selfservice.domains.databaseentity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class DBAppMetaData {

	private Integer itamId;
	private String appName;
	private String appDescription;
	private String businessSegment;
	private String productCategory;
	private String subCategory;
	private String supportedCountries;
	
	//Field added from ITAM_DETAILS Table
	@JsonInclude(Include.NON_NULL)
	private String impactedArea;
	
	
	public String getImpactedArea() {
		return impactedArea;
	}
	public void setImpactedArea(String impactedArea) {
		this.impactedArea = impactedArea;
	}
	public Integer getItamId() {
		return itamId;
	}
	public void setItamId(Integer itamId) {
		this.itamId = itamId;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getAppDescription() {
		return appDescription;
	}
	public void setAppDescription(String appDescription) {
		this.appDescription = appDescription;
	}
	public String getBusinessSegment() {
		return businessSegment;
	}
	public void setBusinessSegment(String businessSegment) {
		this.businessSegment = businessSegment;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public String getSubCategory() {
		return subCategory;
	}
	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}
	public String getSupportedCountries() {
		return supportedCountries;
	}
	public void setSupportedCountries(String supportedCountries) {
		this.supportedCountries = supportedCountries;
	}

}
