package com.scb.selfservice.workflow.service.task;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.selfservice.service.RangerPolicyServiceWrapper;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;
import com.scb.selfservice.web.authentication.UserPrincipal;
import com.scb.selfservice.workflow.service.ExecutionContext;
import com.scb.selfservice.workflow.service.WorkflowServiceTask;

/**
 * 
 * Ranger Policy Task for Consumption Workflow
 * 
 * @author 1610601
 *
 */

@Service(value="consumptionRangerPolicyTask")
public class RangerPolicyTask implements WorkflowServiceTask {
	
	@Autowired
	RangerPolicyServiceWrapper rangerPolicyWrapper;
	
	/* (non-Javadoc)
	 * @see com.scb.selfservice.workflow.service.WorkflowServiceTask#execute(com.scb.selfservice.workflow.service.ExecutionContext)
	 */
	@Override
	public String execute(ExecutionContext ctx) {
		if (ctx != null && "APPROVE".equalsIgnoreCase(ctx.getAction())) {
			UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
			rangerPolicyWrapper.handlePolicyCreation(ctx.getReqId(), ctx.getStepId(), loggedInUser.getUserId());
		}
		return "SUCCESS";
	}

}
 