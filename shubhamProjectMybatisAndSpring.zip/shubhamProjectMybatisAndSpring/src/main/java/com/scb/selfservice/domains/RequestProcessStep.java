package com.scb.selfservice.domains;

/*
 * pojo for
 *    static process_steps and workflow_request_steps
 */
public class RequestProcessStep {
	private String stepId;
	private String stepName;
	private String stepType;
	private String stepUserGroup;
	private String rejectStepId;
	private String serviceStepClass;
	private String parentStepId;
	private String nextStepId;
	private String reqStepId;
	private String status;
	private String stepAction;
	private Integer workflowId;
	private Integer stepSeq;
	private Integer reqId;
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getStepName() {
		return stepName;
	}
	public void setStepName(String stepName) {
		this.stepName = stepName;
	}
	public String getStepType() {
		return stepType;
	}
	public void setStepType(String stepType) {
		this.stepType = stepType;
	}
	public String getStepUserGroup() {
		return stepUserGroup;
	}
	public void setStepUserGroup(String stepUserGroup) {
		this.stepUserGroup = stepUserGroup;
	}
	public String getRejectStepId() {
		return rejectStepId;
	}
	public void setRejectStepId(String rejectStepId) {
		this.rejectStepId = rejectStepId;
	}
	public String getServiceStepClass() {
		return serviceStepClass;
	}
	public void setServiceStepClass(String serviceStepClass) {
		this.serviceStepClass = serviceStepClass;
	}
	public String getParentStepId() {
		return parentStepId;
	}
	public void setParentStepId(String parentStepId) {
		this.parentStepId = parentStepId;
	}
	public String getNextStepId() {
		return nextStepId;
	}
	public void setNextStepId(String nextStepId) {
		this.nextStepId = nextStepId;
	}
	public String getReqStepId() {
		return reqStepId;
	}
	public void setReqStepId(String reqStepId) {
		this.reqStepId = reqStepId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStepAction() {
		return stepAction;
	}
	public void setStepAction(String stepAction) {
		this.stepAction = stepAction;
	}
	public Integer getWorkflowId() {
		return workflowId;
	}
	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}
	public Integer getStepSeq() {
		return stepSeq;
	}
	public void setStepSeq(Integer stepSeq) {
		this.stepSeq = stepSeq;
	}
	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	@Override
	public String toString() {
		return "RequestProcessStep [stepId=" + stepId + ", stepName=" + stepName + ", stepType=" + stepType
				+ ", stepUserGroup=" + stepUserGroup + ", rejectStepId=" + rejectStepId + ", serviceStepClass="
				+ serviceStepClass + ", parentStepId=" + parentStepId + ", nextStepId=" + nextStepId + ", reqStepId="
				+ reqStepId + ", status=" + status + ", stepAction=" + stepAction + ", workflowId=" + workflowId
				+ ", stepSeq=" + stepSeq + ", reqId=" + reqId + "]";
	}
	
}
