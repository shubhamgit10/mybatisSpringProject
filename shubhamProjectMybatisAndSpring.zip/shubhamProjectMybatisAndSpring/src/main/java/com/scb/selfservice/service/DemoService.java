package com.scb.selfservice.service;

import java.sql.Timestamp;

/**
 * Service class
 * 
 * @author Amarnath BB
 *
 */
public interface DemoService {
	
	public Timestamp getCurrentTime();
	
	public Timestamp getCurrentTimeTeradata();
    
}
