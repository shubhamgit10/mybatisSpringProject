package com.scb.selfservice.scheduler;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.scb.selfservice.workflow.service.ExecutionContext;
import com.scb.selfservice.workflow.service.SlaEmailSerivice;


@Service(value = "timeScheduler")
public class EmailScheduler implements TimeScheduler {

	private static Logger logger = LogManager.getLogger(EmailScheduler.class);
	@Autowired
	SlaEmailSerivice sla;
	
	//@Scheduled(fixedRate = 50000)    //for every 50 seconds
	@Scheduled(cron = "0 7 * * 1-5 ?") //every week day 7am 
	//@Scheduled(cron = "* * * * * ?") //every min 
	public void scheduler() throws Exception {
		logger.info("Inside EmailScheduler starting....");
		sla.sendSlaEmail("CONSUMPTION");
		logger.info("Inside EmailScheduler exited!");
	}

	@Override
	public void display(ExecutionContext context) {
		
	}

}