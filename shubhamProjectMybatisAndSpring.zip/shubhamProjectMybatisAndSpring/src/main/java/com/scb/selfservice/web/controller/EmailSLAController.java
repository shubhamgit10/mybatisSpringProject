package com.scb.selfservice.web.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.util.Response;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;
import com.scb.selfservice.web.authentication.UserPrincipal;
import com.scb.selfservice.workflow.service.SlaEmailSerivice;

@RestController
@RequestMapping("/api/email")
public class EmailSLAController {

	private static Logger logger = LogManager.getLogger(EmailSLAController.class);

	@Autowired
	SlaEmailSerivice sla;

	@RequestMapping(path = "/sla", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> SlaSendmail(@RequestParam(name = "workflowType") String workflowType) throws Exception {
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response slaResponse =  new Response();
		try {
			if (loggedInUser != null) {
				logger.info("STARTED EmailSLAController - SlaSendmail");

				String status = sla.sendSlaEmail(workflowType);

				slaResponse.setStatus(HttpStatus.OK.toString());
				slaResponse.setStatusCode(HttpStatus.OK.value());
				slaResponse.setResponse(status);
				logger.info("EXITING EmailSLAController - SlaSendmail");	
			} else {
				slaResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
				slaResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
			}
		}catch (Exception ex) {
			slaResponse.setStatus(HttpStatus.NO_CONTENT.toString());
			slaResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			slaResponse.setResponse("Failed to send email on SLA");
		}
		return new ResponseEntity<Response> (slaResponse, HttpStatus.OK);
	}

}
