package com.scb.selfservice.service;

import com.scb.selfservice.domains.IngestionInput;
import com.scb.selfservice.util.Response;

public interface IngestionDynamicService {

	Response saveIngestionResp(IngestionInput ingestionInput) throws Exception;

}
