package com.scb.selfservice.service;

import java.util.List;

import com.scb.selfservice.domains.EDMPTabsCount;
import com.scb.selfservice.util.Response;

public interface CatalogueDataLoadService {

	public Response getDataSources();

	public Response getIngestionDS();

	public Response getIngestionDataSources();

//	public Response getDataSetCount(List<String> itamId,List<String> country);

	public Response getDataSetName(String itamId, List<String> country);

	public Response getAttributeName(String itamId, String tableName);

	public Response getDataSetCount(List<EDMPTabsCount> edmpTabsCount);
}
