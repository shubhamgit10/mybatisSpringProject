package com.scb.selfservice.domains;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class EDMPEstimationMetaData {
	private Integer sourceId;
	private String sourceType;
	private byte[] costEstimationTemplate;

	public Integer getSourceId() {
		return sourceId;
	}

	public void setSourceId(Integer sourceId) {
		this.sourceId = sourceId;
	}

	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public byte[] getCostEstimationTemplate() {
		return costEstimationTemplate;
	}

	public void setCostEstimationTemplate(byte[] costEstimationTemplate) {
		this.costEstimationTemplate = costEstimationTemplate;
	}

	@Override
	public String toString() {
		return "EDMPEstimationMetaData [sourceId=" + sourceId + ", sourceType=" + sourceType
				+ ", costEstimationTemplate=" + Arrays.toString(costEstimationTemplate) + "]";
	}

}
