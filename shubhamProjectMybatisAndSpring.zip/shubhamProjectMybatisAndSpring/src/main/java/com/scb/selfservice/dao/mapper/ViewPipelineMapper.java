package com.scb.selfservice.dao.mapper;

import java.util.List;

import com.scb.selfservice.domains.Pipelineview;
import com.scb.selfservice.domains.ViewPipeline;

public interface ViewPipelineMapper {

	// method to pull existing ViewPipelineController
	public List<Pipelineview> findByRequestId();

}
