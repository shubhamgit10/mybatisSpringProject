package com.scb.selfservice.web.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.domains.IngestionInput;
import com.scb.selfservice.service.IngestionDynamicService;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;
import com.scb.selfservice.web.authentication.UserPrincipal;

@RestController
@RequestMapping("/api/ingestionDynamic")
public class IngestionDynamicController {
	
	
	Logger logger = LogManager.getLogger(IngestionDynamicController.class);
	
	@Autowired
	IngestionDynamicService iDService;
	
	@PostMapping(path = "/call", consumes= MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> saveIngestion( @RequestBody IngestionInput ingestionInput) {
		
		
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response ingestionResponse = new Response();
		
		if (loggedInUser != null) {
			 Integer userId = Integer.valueOf(loggedInUser.getUserId());
			
			 ingestionInput.setUserId(userId);
			
			try {
						
				ingestionResponse = iDService.saveIngestionResp(ingestionInput);
			} catch (Exception ex) {
				ingestionResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
				ingestionResponse.setStatus(HttpStatus.NO_CONTENT.toString());
				logger.info("EXCEPTION IngestionDynamicController>saveIngestion: " + ex.getMessage());
			}
			
		} else {
			ingestionResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			ingestionResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
		

		return new ResponseEntity<Response>(ingestionResponse, HttpStatus.OK);
	}

}
