package com.scb.selfservice.domains;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;

@Component
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IngestionWorkflowResponse {

	
	private String stepName; 
	private Object workflowApprovalResponse;
	
	public String getStepName() {
		return stepName;

	}
	public void setStepName(String stepName) {
		this.stepName = stepName;
	}
	public Object getWorkflowApprovalResponse() {
		return workflowApprovalResponse;
	}
	public void setWorkflowApprovalResponse(Object workflowApprovalResponse) {
		this.workflowApprovalResponse = workflowApprovalResponse;
	}
	
	
	
	
}