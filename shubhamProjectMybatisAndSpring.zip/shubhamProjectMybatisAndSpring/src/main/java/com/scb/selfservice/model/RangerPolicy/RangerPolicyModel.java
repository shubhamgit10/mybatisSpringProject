package com.scb.selfservice.model.RangerPolicy;

import java.util.List;

/**
 * 
 * @author 1610601
 *
 */
public class RangerPolicyModel {
	
	private Long requestId;
	private Long policyId;
	private RangerPolicyRequestTypeEnum requestType;
	private String repositoryType;
	private String policyName;
	private String description;
	private String databases;
	private String tables;
	private String columns;
	private String users;
	private String groups;
	private String permissions;
	private String columnFamilies;
	private String resourceName;
	private List<RangerPolicyPermissionsList> permissionsMap;
	private String appName;
	
	/**
	 * 
	 */
	public RangerPolicyModel() {
	}
	
	/**
	 * 
	 * @param policyId
	 */
	public RangerPolicyModel(Long policyId) {
		this.policyId = policyId;
	}

	/**
	 * @param requestId
	 * @param policyId
	 * @param requestType
	 * @param repositoryType
	 * @param policyName
	 * @param description
	 * @param databases
	 * @param tables
	 * @param columns
	 * @param users
	 * @param groups
	 * @param permissions
	 * @param columnFamilies
	 * @param resourceName
	 * @param permissionsMap
	 * @param appName
	 */
	public RangerPolicyModel(Long requestId, Long policyId, RangerPolicyRequestTypeEnum requestType,
			String repositoryType, String policyName, String description, String databases, String tables,
			String columns, String users, String groups, String permissions, String columnFamilies, String resourceName,
			List<RangerPolicyPermissionsList> permissionsMap, String appName) {
		super();
		this.requestId = requestId;
		this.policyId = policyId;
		this.requestType = requestType;
		this.repositoryType = repositoryType;
		this.policyName = policyName;
		this.description = description;
		this.databases = databases;
		this.tables = tables;
		this.columns = columns;
		this.users = users;
		this.groups = groups;
		this.permissions = permissions;
		this.columnFamilies = columnFamilies;
		this.resourceName = resourceName;
		this.permissionsMap = permissionsMap;
		this.appName = appName;
	}

	/**
	 * @return the requestId
	 */
	public Long getRequestId() {
		return requestId;
	}

	/**
	 * @param requestId the requestId to set
	 */
	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	/**
	 * @return the requestType
	 */
	public RangerPolicyRequestTypeEnum getRequestType() {
		return requestType;
	}

	/**
	 * @param requestType the requestType to set
	 */
	public void setNewPolicy(RangerPolicyRequestTypeEnum requestType) {
		this.requestType = requestType;
	}

	/**
	 * @return the repositoryType
	 */
	public String getRepositoryType() {
		return repositoryType;
	}

	/**
	 * @param repositoryType the repositoryType to set
	 */
	public void setRepositoryType(String repositoryType) {
		this.repositoryType = repositoryType;
	}

	/**
	 * @return the policyName
	 */
	public String getPolicyName() {
		return policyName;
	}

	/**
	 * @param policyName the policyName to set
	 */
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the databases
	 */
	public String getDatabases() {
		return databases;
	}

	/**
	 * @param databases the databases to set
	 */
	public void setDatabases(String databases) {
		this.databases = databases;
	}

	/**
	 * @return the tables
	 */
	public String getTables() {
		return tables;
	}

	/**
	 * @param tables the tables to set
	 */
	public void setTables(String tables) {
		this.tables = tables;
	}

	/**
	 * @return the columns
	 */
	public String getColumns() {
		return columns;
	}

	/**
	 * @param columns the columns to set
	 */
	public void setColumns(String columns) {
		this.columns = columns;
	}

	/**
	 * @return the users
	 */
	public String getUsers() {
		return users;
	}

	/**
	 * @param users the users to set
	 */
	public void setUsers(String users) {
		this.users = users;
	}

	/**
	 * @return the groups
	 */
	public String getGroups() {
		return groups;
	}

	/**
	 * @param groups the groups to set
	 */
	public void setGroups(String groups) {
		this.groups = groups;
	}

	/**
	 * @return the permissions
	 */
	public String getPermissions() {
		return permissions;
	}

	/**
	 * @param permissions the permissions to set
	 */
	public void setPermissions(String permissions) {
		this.permissions = permissions;
	}

	/**
	 * @return the columnFamilies
	 */
	public String getColumnFamilies() {
		return columnFamilies;
	}

	/**
	 * @param columnFamilies the columnFamilies to set
	 */
	public void setColumnFamilies(String columnFamilies) {
		this.columnFamilies = columnFamilies;
	}

	/**
	 * @return the resourceName
	 */
	public String getResourceName() {
		return resourceName;
	}

	/**
	 * @param resourceName the resourceName to set
	 */
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	/**
	 * @return the policyId
	 */
	public Long getPolicyId() {
		return policyId;
	}

	/**
	 * @param policyId the policyId to set
	 */
	public void setPolicyId(Long policyId) {
		this.policyId = policyId;
	}

	/**
	 * @param requestType the requestType to set
	 */
	public void setRequestType(RangerPolicyRequestTypeEnum requestType) {
		this.requestType = requestType;
	}

	/**
	 * @return the permissionsMap
	 */
	public List<RangerPolicyPermissionsList> getPermissionsMap() {
		return permissionsMap;
	}

	/**
	 * @param permissionsMap the permissionsMap to set
	 */
	public void setPermissionsMap(List<RangerPolicyPermissionsList> permissionsMap) {
		this.permissionsMap = permissionsMap;
	}

	/**
	 * @return the appName
	 */
	public String getAppName() {
		return appName;
	}

	/**
	 * @param appName the appName to set
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}

	@Override
	public String toString() {
		return "RangerPolicyModel [requestId=" + requestId + ", policyId=" + policyId + ", requestType=" + requestType
				+ ", repositoryType=" + repositoryType + ", policyName=" + policyName + ", description=" + description
				+ ", databases=" + databases + ", tables=" + tables + ", columns=" + columns + ", users=" + users
				+ ", groups=" + groups + ", permissions=" + permissions + ", columnFamilies=" + columnFamilies
				+ ", resourceName=" + resourceName + ", permissionsMap=" + permissionsMap + ", appName=" + appName
				+ "]";
	}
	
}
