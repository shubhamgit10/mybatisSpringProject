package com.scb.selfservice.service;

import java.util.List;

import com.scb.selfservice.domains.DownloadFile;
import com.scb.selfservice.domains.EDMPEstimationMetaData;
import com.scb.selfservice.domains.IsdFileStore;

public interface EdmpFileDownloadService {

	// is to pull data for the xls preparation
	public List<DownloadFile> pullData(Integer reqId);

	// is to pull data for the xls preparation
	public EDMPEstimationMetaData pullIsdData(String sourceType);

	// is to pull data for the xls preparation
	public List<IsdFileStore> pullIsdFileStoreData(String reqId);

}
