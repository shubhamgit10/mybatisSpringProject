package com.scb.selfservice.isd.validate;

import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.scb.selfservice.isd.entity.ISDRequestDetails;
import com.scb.selfservice.isd.entity.ISDTemplateInfo;

/**
 * @author akuma400
 *
 */
public class ValidationUtil {
	private static Logger log = LogManager.getLogger(ValidationUtil.class);

	public static boolean validateSheetHeaderAsInDB(Sheet sheet, ISDTemplateInfo isdTemplateInfo, int headerRow,
			int initialColumn) {
		log.info("validateSheetHeaderAsInDB:start");
		return IntStream.range(initialColumn, isdTemplateInfo.getCellColumnNumber().size() + initialColumn - 1)
				.allMatch(cellIndex -> {
					String columnAddress = sheet.getRow(headerRow).getCell(cellIndex).getAddress().formatAsString();
					String headerColumn = (columnAddress.split("(?<=\\D)(?=\\d)"))[0];
					int index = isdTemplateInfo.getCellColumnNumber().indexOf(headerColumn);
					return sheet.getRow(headerRow).getCell(cellIndex).getStringCellValue().replaceAll("\\s", "")
							.contains(isdTemplateInfo.getColumnName().get(index).replaceAll("\\s", ""));
				});
	}

	public static boolean validateForNull(String rowID, ISDTemplateInfo isdTemplateInfo, int initialRaw,
			int initialColumn, Sheet sheet) {
		//log.debug("validateForNull:start");
		String headerColumn[] = (rowID.split("(?<=\\D)(?=\\d)"));
		int index = isdTemplateInfo.getCellColumnNumber().indexOf(headerColumn[0]);
		if(isdTemplateInfo.getColumnName().get(index).equalsIgnoreCase("Length") && isdTemplateInfo.getDbColumnName().get(index).equalsIgnoreCase("SOURCELENGTH")){
			return getResultForPrecisionOrLengthColumn(isdTemplateInfo, initialRaw, initialColumn, sheet, headerColumn, index, "DataType", "CHAR", "VARCHAR");
		}
		
		if(isdTemplateInfo.getColumnName().get(index).equalsIgnoreCase("Precision") && isdTemplateInfo.getDbColumnName().get(index).equalsIgnoreCase("SOURCEPRECISION")){
			return getResultForPrecisionOrLengthColumn(isdTemplateInfo, initialRaw, initialColumn, sheet, headerColumn, index, "DataType", "NUMBER", "DECIMAL");
		}
		boolean checkForNull = isdTemplateInfo.getNullable().get(index);
		//log.debug("validateForNull:end");
		return checkForNull;
	}
	
	private static boolean getResultForPrecisionOrLengthColumn(ISDTemplateInfo isdTemplateInfo, int initialRaw,
			int initialColumn, Sheet sheet, String headerColumn[],int index, String conditionalColumnName, String type1, String type2) {
		log.info("getResultForPrecisionOrLengthColumn:Start");
		if(isdTemplateInfo.getColumnName().contains(conditionalColumnName)) {
			int dataTypeIndex = isdTemplateInfo.getColumnName().indexOf(conditionalColumnName);
			String dataTypeHeaderColumn = isdTemplateInfo.getCellColumnNumber().get(dataTypeIndex);
			char ch2[] = dataTypeHeaderColumn.toCharArray();
			char ch1[] = headerColumn[0].toCharArray();
			int countOfch1 = charCount(ch1);
			int countOfch2 = charCount(ch2);
			
			if(sheet.getRow(initialRaw).getCell(initialColumn-(countOfch1-countOfch2)).getCellTypeEnum().toString().equalsIgnoreCase("String")) {
				String value = sheet.getRow(initialRaw).getCell(initialColumn-(countOfch1-countOfch2)).getStringCellValue();
				if(null != value && (value.equalsIgnoreCase(type1) || value.contains(type2))) {
					return isdTemplateInfo.getNullable().get(index);
				} else return !isdTemplateInfo.getNullable().get(index);
			} else return !isdTemplateInfo.getNullable().get(index);
			
			} else return false;
	}

	private static int charCount(char[] ch) {
		int count = 0;
		for(int i=0;i<ch.length;i++){
	        count=count+ch[i];
	    }
		return count;
	}

	public static boolean AllPrimarySheetsExists(Map<String, String> sheetNameAndsheetDBTableName, XSSFWorkbook workbook) {
		log.info("AllPrimarySheetsExists:Start");
		return sheetNameAndsheetDBTableName.keySet().stream().allMatch(sheetName -> workbook.getSheetIndex(sheetName)>0);
		
	}

	public static void validateForInvalidTableName(Sheet sheet, ISDTemplateInfo isdTemplateInfo, int initialRaw, int initialColumn, ISDRequestDetails isdInputs, List<String> columnNameForinvalidTableName, String checkFieldForTable ) {	
		log.debug("validateForInvalidTableName:start");
		int index = isdTemplateInfo.getColumnName().indexOf("Country");
		String cellId = isdTemplateInfo.getCellColumnNumber().get(index);
		String countryRowId = cellId + sheet.getRow(initialRaw).getCell(initialColumn).getAddress().formatAsString().split("(?<=\\D)(?=\\d)")[1];
				

		CellReference cr = new CellReference(countryRowId);
		String refValue = StringUtils.EMPTY;
		String refValue1 = StringUtils.EMPTY;
		if (sheet.getRow(cr.getRow()).getCell(cr.getCol()).getCellTypeEnum()
				.equals(CellType.STRING)) {
			try {
			refValue = sheet.getRow(cr.getRow()).getCell(cr.getCol())
					.getStringCellValue();
			String expectedTableNameFormat = isdInputs.getSystem() + "_" + refValue + "_";
			String actualTableNameFormat = sheet.getRow(initialRaw).getCell(initialColumn).getRichStringCellValue().getString();
			//****get column name of defective tableName
			if(!actualTableNameFormat.startsWith(expectedTableNameFormat)) {

				int index1 = isdTemplateInfo.getColumnName().indexOf("Column Name");
				String cellId1 = isdTemplateInfo.getCellColumnNumber().get(index1)
						+ sheet.getRow(initialRaw).getCell(initialColumn).getAddress().formatAsString().split("(?<=\\D)(?=\\d)")[1];

				CellReference cr1 = new CellReference(cellId1);
				
					refValue1 = sheet.getRow(cr1.getRow()).getCell(cr1.getCol())
							.getStringCellValue();
					columnNameForinvalidTableName.add(refValue1);
			}
			log.debug("validateForInvalidTableName:end");
			} catch(NullPointerException e) {
				log.info("validateForInvalidTableName:refValue1"+refValue1);
				columnNameForinvalidTableName.add(refValue1);
			}			
		}
	}

	public static void validateDateFormat(Sheet sheet, ISDTemplateInfo isdTemplateInfo, int initialRaw,
			int initialColumn, ISDRequestDetails isdInputs, List<String> invalidDateFormatInFile, String dateFormat,
			String headerColumnName) {
		log.debug("validateDateFormat:start");
		String refValue = StringUtils.EMPTY;
		try {
			if(!sheet.getRow(initialRaw).getCell(initialColumn).getStringCellValue().equals(dateFormat)) {
				int index = isdTemplateInfo.getColumnName().indexOf("TABLE NAME");
				String cellAddress = isdTemplateInfo.getCellColumnNumber().get(index)
				+ sheet.getRow(initialRaw).getCell(initialColumn).getAddress().formatAsString().split("(?<=\\D)(?=\\d)")[1];
				CellReference cr = new CellReference(cellAddress);
				refValue = sheet.getRow(cr.getRow()).getCell(cr.getCol())
						.getStringCellValue();
				invalidDateFormatInFile.add(refValue);
			}
			log.debug("validateDateFormat:end");	
		} catch (Exception e) {
			log.info("validateDateFormat:refValue"+refValue);
				invalidDateFormatInFile.add(refValue);
			}
		}
	}

