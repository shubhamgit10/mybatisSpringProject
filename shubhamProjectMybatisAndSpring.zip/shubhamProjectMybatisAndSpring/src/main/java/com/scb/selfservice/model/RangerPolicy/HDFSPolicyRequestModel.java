package com.scb.selfservice.model.RangerPolicy;

import java.util.List;

/**
 * 
 * @author Chenna
 *
 */
public class HDFSPolicyRequestModel {
	
	private String repositoryName;
	private String repositoryType = "hdfs";
	private String policyName;
	private String description;
	private List<RangerPolicyPermissionsList> permMapList;
	private boolean isAuditEnabled = true;
	private boolean isEnabled = true;
	private boolean isRecursive = true;
	private String resourceName;
	
	/**
	 * 
	 */
	public HDFSPolicyRequestModel() {
		super();
		this.repositoryType="hdfs";
		this.isAuditEnabled = true;
		this.isEnabled = true;
		this.isRecursive = true;
	}

	/**
	 * @param repositoryName
	 * @param policyName
	 * @param description
	 * @param permMapList
	 * @param resourceName
	 */
	public HDFSPolicyRequestModel(String repositoryName, String policyName, String description,
			List<RangerPolicyPermissionsList> permMapList, String resourceName) {
		super();
		this.repositoryName = repositoryName;
		this.policyName = policyName;
		this.description = description;
		this.permMapList = permMapList;
		this.resourceName = resourceName;
	}
	
	

	/**
	 * @param repositoryName
	 * @param repositoryType
	 * @param policyName
	 * @param description
	 * @param permMapList
	 * @param isAuditEnabled
	 * @param isEnabled
	 * @param isRecursive
	 * @param resourceName
	 */
	public HDFSPolicyRequestModel(String repositoryName, String repositoryType, String policyName, String description,
			List<RangerPolicyPermissionsList> permMapList, boolean isAuditEnabled, boolean isEnabled,
			boolean isRecursive, String resourceName) {
		super();
		this.repositoryName = repositoryName;
		this.repositoryType = repositoryType;
		this.policyName = policyName;
		this.description = description;
		this.permMapList = permMapList;
		this.isAuditEnabled = isAuditEnabled;
		this.isEnabled = isEnabled;
		this.isRecursive = isRecursive;
		this.resourceName = resourceName;
	}

	/**
	 * @return the repositoryName
	 */
	public String getRepositoryName() {
		return repositoryName;
	}

	/**
	 * @param repositoryName the repositoryName to set
	 */
	public void setRepositoryName(String repositoryName) {
		this.repositoryName = repositoryName;
	}

	/**
	 * @return the policyName
	 */
	public String getPolicyName() {
		return policyName;
	}

	/**
	 * @param policyName the policyName to set
	 */
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the permMapList
	 */
	public List<RangerPolicyPermissionsList> getPermMapList() {
		return permMapList;
	}

	/**
	 * @param permMapList the permMapList to set
	 */
	public void setPermMapList(List<RangerPolicyPermissionsList> permMapList) {
		this.permMapList = permMapList;
	}

	/**
	 * @return the resourceName
	 */
	public String getResourceName() {
		return resourceName;
	}

	/**
	 * @param resourceName the resourceName to set
	 */
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	/**
	 * @return the repositoryType
	 */
	public String getRepositoryType() {
		return repositoryType;
	}

	/**
	 * @param repositoryType the repositoryType to set
	 */
	public void setRepositoryType(String repositoryType) {
		this.repositoryType = repositoryType;
	}

	/**
	 * @return the isAuditEnabled
	 */
	public boolean isAuditEnabled() {
		return isAuditEnabled;
	}

	/**
	 * @param isAuditEnabled the isAuditEnabled to set
	 */
	public void setAuditEnabled(boolean isAuditEnabled) {
		this.isAuditEnabled = isAuditEnabled;
	}

	/**
	 * @return the isEnabled
	 */
	public boolean isEnabled() {
		return isEnabled;
	}

	/**
	 * @param isEnabled the isEnabled to set
	 */
	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}

	/**
	 * @return the isRecursive
	 */
	public boolean isRecursive() {
		return isRecursive;
	}

	/**
	 * @param isRecursive the isRecursive to set
	 */
	public void setRecursive(boolean isRecursive) {
		this.isRecursive = isRecursive;
	}

	@Override
	public String toString() {
		return "HDFSPolicyRequestModel [repositoryName=" + repositoryName + ", repositoryType=" + repositoryType
				+ ", policyName=" + policyName + ", description=" + description + ", permMapList=" + permMapList
				+ ", isAuditEnabled=" + isAuditEnabled + ", isEnabled=" + isEnabled + ", isRecursive=" + isRecursive
				+ ", resourceName=" + resourceName + "]";
	}

}
