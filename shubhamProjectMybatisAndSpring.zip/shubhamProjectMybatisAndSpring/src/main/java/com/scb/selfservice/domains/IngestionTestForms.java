package com.scb.selfservice.domains;

import java.sql.Date;
import java.sql.Timestamp;

public class IngestionTestForms {

	private Integer reqId;

	private String deploymentType;

	private String instanceToBeCovered;

	private Date validationStartDate;

	private Date validationEndDate;

	private String casesToBeTriggered;

	private String tablesToBeCovered;

	private String dataSource;

	private Integer day0LoadedSuccessfully;

	private Date day0Date;

	private Integer noOfDaysDataLoaded;

	private String dataLoadingType;

	private String remarks;

	private String userAction;

	private String stepId;

	private Integer workflowId;

	private Integer requestCreatedBy;

	private Timestamp requestCreatedAt;

	public Integer getReqId() {
		return reqId;
	}

	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}

	public String getDeploymentType() {
		return deploymentType;
	}

	public void setDeploymentType(String deploymentType) {
		this.deploymentType = deploymentType;
	}

	public String getInstanceToBeCovered() {
		return instanceToBeCovered;
	}

	public void setInstanceToBeCovered(String instanceToBeCovered) {
		this.instanceToBeCovered = instanceToBeCovered;
	}

	public Date getValidationStartDate() {
		return validationStartDate;
	}

	public void setValidationStartDate(Date validationStartDate) {
		this.validationStartDate = validationStartDate;
	}

	public Date getValidationEndDate() {
		return validationEndDate;
	}

	public void setValidationEndDate(Date validationEndDate) {
		this.validationEndDate = validationEndDate;
	}

	public String getCasesToBeTriggered() {
		return casesToBeTriggered;
	}

	public void setCasesToBeTriggered(String casesToBeTriggered) {
		this.casesToBeTriggered = casesToBeTriggered;
	}

	public String getTablesToBeCovered() {
		return tablesToBeCovered;
	}

	public void setTablesToBeCovered(String tablesToBeCovered) {
		this.tablesToBeCovered = tablesToBeCovered;
	}

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	public Integer getDay0LoadedSuccessfully() {
		return day0LoadedSuccessfully;
	}

	public void setDay0LoadedSuccessfully(Integer day0LoadedSuccessfully) {
		this.day0LoadedSuccessfully = day0LoadedSuccessfully;
	}

	public Date getDay0Date() {
		return day0Date;
	}

	public void setDay0Date(Date day0Date) {
		this.day0Date = day0Date;
	}

	public Integer getNoOfDaysDataLoaded() {
		return noOfDaysDataLoaded;
	}

	public void setNoOfDaysDataLoaded(Integer noOfDaysDataLoaded) {
		this.noOfDaysDataLoaded = noOfDaysDataLoaded;
	}

	public String getDataLoadingType() {
		return dataLoadingType;
	}

	public void setDataLoadingType(String dataLoadingType) {
		this.dataLoadingType = dataLoadingType;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getUserAction() {
		return userAction;
	}

	public void setUserAction(String userAction) {
		this.userAction = userAction;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}

	public Integer getRequestCreatedBy() {
		return requestCreatedBy;
	}

	public void setRequestCreatedBy(Integer requestCreatedBy) {
		this.requestCreatedBy = requestCreatedBy;
	}

	public Timestamp getRequestCreatedAt() {
		return requestCreatedAt;
	}

	public void setRequestCreatedAt(Timestamp requestCreatedAt) {
		this.requestCreatedAt = requestCreatedAt;
	}

	@Override
	public String toString() {
		return "IngestionTestForms [reqId=" + reqId + ", deploymentType=" + deploymentType + ", instanceToBeCovered="
				+ instanceToBeCovered + ", validationStartDate=" + validationStartDate + ", validationEndDate="
				+ validationEndDate + ", casesToBeTriggered=" + casesToBeTriggered + ", tablesToBeCovered="
				+ tablesToBeCovered + ", dataSource=" + dataSource + ", day0LoadedSuccessfully="
				+ day0LoadedSuccessfully + ", day0Date=" + day0Date + ", noOfDaysDataLoaded=" + noOfDaysDataLoaded
				+ ", dataLoadingType=" + dataLoadingType + ", remarks=" + remarks + ", userAction=" + userAction
				+ ", stepId=" + stepId + ", workflowId=" + workflowId + ", requestCreatedBy=" + requestCreatedBy
				+ ", requestCreatedAt=" + requestCreatedAt + "]";
	}

}
