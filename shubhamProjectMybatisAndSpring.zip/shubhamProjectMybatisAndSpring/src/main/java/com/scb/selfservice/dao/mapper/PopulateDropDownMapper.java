package com.scb.selfservice.dao.mapper;

import java.util.List;

import com.scb.selfservice.domains.EDMPLookupTable;
import com.scb.selfservice.domains.databaseentity.DBAdRoleGroup;
import com.scb.selfservice.util.Response;

public interface PopulateDropDownMapper {
	
	public List<EDMPLookupTable> getDropDownValues();
	
	public List<DBAdRoleGroup> getConsumerAdRole();

}
