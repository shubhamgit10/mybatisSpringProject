package com.scb.selfservice.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.selfservice.dao.mapper.RangerPolicyMapper;
import com.scb.selfservice.model.ConsumptionRequestModel;
import com.scb.selfservice.model.RangerPolicy.ConsumptionRangerPolicyModel;
import com.scb.selfservice.service.RangerPolicyService;

/**
 * 
 * @author 1610601
 *
 */
@Service
public class RangerPolicyServiceImpl implements RangerPolicyService {
	
	private static Logger logger = LogManager.getLogger(RangerPolicyServiceImpl.class);

    @Autowired
    RangerPolicyMapper rangerPolicyMapper;
	
    @Override
	public ConsumptionRangerPolicyModel getRangerPoliciesByRequestId(Long requestId) {
		logger.debug("Inside getRangerPoliciesByRequestId Service");
		List<ConsumptionRequestModel> reqDetails = rangerPolicyMapper.getRangerPoliciesByRequestId(requestId);
		ConsumptionRangerPolicyModel policy = null;
		if(null != reqDetails && !reqDetails.isEmpty()) {
			policy = new ConsumptionRangerPolicyModel();
			Map<String, Map<String, Map<String, Map<String, Set<String>>>>> policyDetails = 
					new HashMap<String, Map<String, Map<String, Map<String, Set<String>>>>> ();
			for(ConsumptionRequestModel req : reqDetails) {
				if(null == policy.getRequestId()) {
					policy.setRequestId(req.getRequestId());
					policy.setMetadataDetails(policyDetails);
					policy.setGroupName(req.getGroupName());
				}
				Map<String, Map<String, Map<String, Set<String>>>> policyMetadata = null;
				
				if(policyDetails.containsKey(req.getAppName().trim())) {
					policyMetadata = policyDetails.get(req.getAppName().trim());
				} else {
					policyMetadata = new HashMap<String, Map<String, Map<String, Set<String>>>> ();
					policyDetails.put(req.getAppName().trim(), policyMetadata);
				}
				
				Map<String, Map<String, Set<String>>> dbMetadata = null;
				
				if(policyMetadata.containsKey(req.getCountry().trim())) {
					dbMetadata = policyMetadata.get(req.getCountry().trim());
				} else {
					dbMetadata = new HashMap<String, Map<String, Set<String>>> ();
					policyMetadata.put(req.getCountry().trim(), dbMetadata);
				}
				
				Map<String, Set<String>> colTablesMap = null;
				
				if(dbMetadata.containsKey(req.getDatabaseName().trim())) {
					colTablesMap = dbMetadata.get(req.getDatabaseName().trim());
				} else {
					colTablesMap = new HashMap<String, Set<String>> ();
					dbMetadata.put(req.getDatabaseName().trim(), colTablesMap);
				}
				
				Set<String> tables = null;
				if(colTablesMap.containsKey(req.getColumnName().trim())) {
					tables = colTablesMap.get(req.getColumnName().trim());
				} else {
					tables = new HashSet<String> ();
					colTablesMap.put(req.getColumnName().trim(), tables);
				}
				tables.add(req.getTableName().trim());
			}
		} else {
			logger.error("Either error while fetching request details or no rows available in the request table");
		}
		logger.debug("Policy details : " + policy);
    	return policy;
	}
	
    @Override
	public void addRangerPolicyDetails(Long requestId, String appName, String country, 
			String groupName, String policyName, Long policyId, String policyCreateType, 
			String policyType, String status, String errorMsg, String repoType, 
			String createTime, String updateTime) {
    	logger.debug("Inside addRangerPolicyDetails Service");
    	rangerPolicyMapper.addRangerPolicyDetails(requestId, appName, country, 
    			groupName, policyName, policyId, policyCreateType, policyType, 
    			status, errorMsg, repoType, createTime, updateTime);
	}
    
    @Override
    public String getParentStepId(Long requestId, String stepId) {
    	logger.info("Inside getParentStepId service ");
    	return rangerPolicyMapper.getParentStepId(requestId, stepId);
    }
	
}
