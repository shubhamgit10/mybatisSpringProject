/**
 * 
 */
package com.scb.selfservice.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URI;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.atlassian.jira.rest.client.api.AuthenticationHandler;
import com.atlassian.jira.rest.client.api.IssueRestClient;
import com.atlassian.jira.rest.client.api.JiraRestClient;
import com.atlassian.jira.rest.client.api.domain.BasicIssue;
import com.atlassian.jira.rest.client.api.domain.Comment;
import com.atlassian.jira.rest.client.api.domain.Issue;
import com.atlassian.jira.rest.client.api.domain.IssueType;
import com.atlassian.jira.rest.client.api.domain.SearchResult;
import com.atlassian.jira.rest.client.api.domain.input.ComplexIssueInputFieldValue;
import com.atlassian.jira.rest.client.api.domain.input.IssueInput;
import com.atlassian.jira.rest.client.api.domain.input.IssueInputBuilder;
import com.atlassian.jira.rest.client.auth.BasicHttpAuthenticationHandler;
import com.atlassian.jira.rest.client.internal.async.AsynchronousJiraRestClientFactory;
import com.google.common.collect.ImmutableMap;
import com.scb.selfservice.config.PropertyConfigurer;

import io.atlassian.util.concurrent.Promise;

/**
 * Job to integrate JIRA Creation
 * 
 * @author Amarnath BB
 *
 */
public class JiraUtils {

	private HashMap<String, String> cMap = new HashMap<String, String>();
	private HashMap<String, String> aMap = new HashMap<String, String>();

	private String appStr = "ACBS|40780#ACR|40781#ACT|40782#ALM|40783#AMD|40784#AMD_KR|62630#APPS|40785#BANCA|62631#BBG|40786#BCRS|40787#BLOOMBERG|62632#BLUEPRINT|40788#BTS|40789#BVD|40790#CACS|62633#CAP|62634#CARD|40791#CAS|62636#CBDR|40792#CBDW|62637#CBMS|40793#CCCIS|40794#CCM|40795#CCMS|40796#CDS|40797#CEMSCTOM|62638#CEMSCVD|62639#CIMS|40798#CIS|40799#CITS|62640#CMS|40800#CMT|40801#COCOA|62641#COCOA|40802#COCOA|40803#COPE|40804#COS|40805#CREDITMATE|62642#CRES|40806#CRM|40807#CRMS|40808#CRMS_KOR|62643#CSS|40809#CTCS|59734#CTS|40810#CUPD|40811#CUPID|40812#DETICA|40813#DOTOPAL|40814#DTP|40815#DTPSTCH|40816#EBBS|40817#ECAPS|40818#ECDD+|40819#ECL|40820#ECM|40821#EDP|40822#EGLEX|40823#EINVESTMENTS|40824#ELOAN|40825#EOPS|40826#ESDS|40827#ESE|40828#ESIGCAP|62644#ESPEED|40829#FALCON|62645#FEDS|40830#FICONNECT|62646#FINANTIX|40831#FINETL|62647#FINIQ|40832#FME|40833#FMETAL|62648#FMRAW|40834#GEMFR|40835#GEMS|62649#GLEL DTP|40836#GLEL FEDS|40837#GLEL MUREX|40838#GLEL OPICS|40839#GLEL OTP|40840#GLEL RAZOR|40841#GLEL SOPHIS|40842#GNS|40843#GPS|40844#HOGAN|40845#HRDT|40846#IBS|40847#ICCS|62650#ICDD|62651#ICM|40848#ICMS|40849#IE|40850#IFIS|62652#IXT|40851#KEDW|40852#LAPS|40853#LLI|40854#LTP|40855#MANTAS|40856#MARCIS|40857#MARTINI|40858#MCS|40859#MICROGEN|62653#MRA|40860#MTS|40861#MUREX|40862#MVA|62654#MXCMS|40863#NBP|40864#NCS|40865#ODS|40866#OIPA|40867#OLTP|40868#ONTRACK|40869#OPICS|40870#OPICS PVB|40871#OTP|40872#PACT|40873#PCDB|40874#PCT|40875#PCT2|40876#PMI|40877#PROBE|40878#PSFTP|40879#PSGL|40880#PSHR|40881#RAH|40882#RAZOR|62655#RAZOR FX|40883#RAZOR MM|40884#RCMS|40885#RCMS|40886#RDM|40887#RFAS|40888#RFES|40889#RLS|40890#RLSBDW|40891#RLSCDW|40892#RLSPDW|40893#RMI|40894#RPT|40895#RTP|40896#S2B CUSTODY|62656#S2B TRADE|62657#SABRE|40897#SCI|40898#SCILL|40899#SCSTAR|40900#SECCURE|40901#SENTRY|40902#SOPHIS|40903#STA|40904#STRAUSS|40905#STS|40906#SWOT|40907#T24|40908#TANDEM|40909#TPS|40910#TRANSACT|40911#TSAAS|40912#UPI|62659#URS|40913#UTS|40914#WSD|40915#OPICS|87415#OPICS|87416#OPICS|87417#OPICS|87418#SECURE|87419#ECDPPRD|87420#CARDS|87421#LTPCDW|87422#OTPCDW|87423#GNSPRD|87424#BUREAUONE|87425#CLARITY|87426#COLT|87427#CONNECT|87428#ECDD|87429#EORP|87430#FAPSGL|87431#GNSRT|87432#M5SERIES|87433#PVB|87434#S2BCTD|87435#S2BETR|87436#S2BTRD|87437#TLM|87438";
	private String ctryStr = "AD|40379#|AE|40380#|AF|40381#|AG|40382#|AI|40383#|AL|40384#|ALL|49512#|AM|40385#|AN|40386#|AO|40387#|AQ|40388#|AR|40389#|AS|40390#|AT|40391#|AU|40392#|AW|40393#|AX|40394#|AZ|40395#|BA|40396#|BB|40397#|BD|40398#|BE|40399#|BF|40400#|BG|40401#|BH|40402#|BI|40403#|BJ|40404#|BL|40405#|BM|40406#|BN|40407#|BO|40408#|BQ|40409#|BR|40410#|BS|40411#|BT|40412#|BV|40413#|BW|40414#|BY|40415#|BZ|40416#|CA|40417#|CC|40418#|CD|40419#|CF|40420#|CG|40421#|CH|40422#|CI|40423#|CK|40424#|CL|40425#|CM|40426#|CN|40427#|CO|40428#|CR|40429#|CU|40430#|CV|40431#|CW|40432#|CX|40433#|CY|40434#|CZ|40435#|DE|40436#|DJ|40438#|DK|40439#|DM|40440#|DO|40441#|DZ|40442#|EC|40443#|EE|40444#|EG|40445#|EH|40446#|ER|40447#|ES|40448#|ET|40449#|FI|40450#|FJ|40451#|FK|40452#|FM|40453#|FO|40454#|FR|40455#|GA|40456#|GB|40457#|GD|40458#|GE|40459#|GF|40460#|GG|40461#|GH|40462#|GI|40463#|GL|40464#|GM|40465#|GN|40466#|GP|40467#|GQ|40468#|GR|40469#|GS|40470#|GT|40471#|GU|40472#|GW|40473#|GY|40474#|HK|40475#|HM|40476#|HN|40477#|HR|40478#|HT|40479#|HU|40480#|ID|40481#|IE|40482#|IL|40483#|IM|40484#|IN|40485#|IO|40486#|IQ|40487#|IR|40488#|IS|40489#|IT|40490#|JE|40491#|JM|40492#|JO|40493#|JP|40494#|KE|40495#|KG|40496#|KH|40497#|KI|40498#|KM|40499#|KN|40500#|KP|40501#|KR|40502#|KW|40503#|KY|40504#|KZ|40505#|LA|40506#|LB|40507#|LC|40508#|LI|40509#|LK|40510#|LR|40512#|LS|40513#|LT|40514#|LU|40515#|LV|40516#|LY|40517#|MA|40518#|MC|40519#|MD|40520#|ME|40521#|MF|40522#|MG|40523#|MH|40524#|MK|40525#|ML|40526#|MM|40527#|MN|40528#|MO|40529#|MP|40530#|MQ|40531#|MR|40532#|MS|40533#|MT|40534#|MU|40535#|MV|40536#|MW|40537#|MX|40538#|MY|40539#|MZ|40540#|NA|40541#|NC|40543#|NE|40544#|NF|40545#|NG|40546#|NI|40547#|NL|40548#|NO|40549#|NP|40550#|NR|40551#|NU|40552#|NZ|40553#|OM|40554#|PA|40555#|PE|40556#|PF|40557#|PG|40558#|PH|40559#|PK|40560#|PL|40561#|PM|40562#|PN|40563#|PR|40564#|PS|40565#|PT|40566#|PW|40567#|PY|40568#|QA|40569#|RE|40571#|RO|40572#|RS|40573#|RU|40574#|RW|40575#|SA|40576#|SB|40577#|SC|40578#|SD|40579#|SE|40580#|SG|40581#|SH|40582#|SI|40583#|SJ|40584#|SK|40585#|SL|40586#|SM|40587#|SN|40588#|SO|40589#|SR|40590#|SS|40591#|ST|40592#|SV|40593#|SX|40594#|SY|40595#|SZ|40596#|TC|40597#|TD|40598#|TF|40599#|TG|40600#|TH|40601#|TJ|40602#|TK|40603#|TL|40604#|TM|40605#|TN|40606#|TO|40607#|TR|40608#|TT|40609#|TV|40610#|TW|40611#|TZ|40612#|UA|40613#|UG|40614#|UM|40615#|US|40616#|UY|40617#|UZ|40618#|VA|40619#|VC|40620#|VE|40621#|VG|40622#|VI|40623#|VN|40624#|VU|40625#|WF|40626#|WS|40627#|XA|40628#|XB|40629#|XD|40630#|XK|40631#|XL|40632#|XX|40633#|YE|40634#|YT|40635#|YU|40636#|ZA|40637#|ZM|40638#|ZW|40639";

	public JiraUtils() {
		aMap = this.parseStr(appStr);
		cMap = this.parseStr(ctryStr);
	}

	/**
	 * Method to parse the JIRA KeyValue
	 * 
	 * @param a
	 * @return
	 */
	protected HashMap<String, String> parseStr(String a) {
		HashMap<String, String> aMap = new HashMap<String, String>();
		String[] arr = StringUtils.split(a, "#");
		for (String s : arr) {
			String[] val = StringUtils.split(s, "|");
			aMap.put(val[0], val[1]);
		}
		return aMap;
	}

	/**
	 * Utility class to create a New Consumption JIRA Request
	 * 
	 * @param reqInfo
	 * @return
	 */
	public String createConsumptionJiraRequest(String reqId, HashMap<String, String> reqInfo,
			List<HashMap<String, String>> tablesSubscribed, String requestor) throws Exception {
		String jiraURL = PropertyConfigurer.getProperty("JIRA.URL");
		String jiraUsername = PropertyConfigurer.getProperty("JIRA.USERNAME");
		String jiraPasswd = PropertyConfigurer.getProperty("JIRA.CREDENTIALS");

		try {
			URI jiraServerUri = URI.create(jiraURL);

			AsynchronousJiraRestClientFactory factory = new AsynchronousJiraRestClientFactory();

			AuthenticationHandler auth = new BasicHttpAuthenticationHandler(jiraUsername, jiraPasswd);
			JiraRestClient restClient = factory.create(jiraServerUri, auth);
			IssueRestClient issueClient = restClient.getIssueClient();
			IssueInputBuilder iib = new IssueInputBuilder();

			iib.setProjectKey("DSP");
			iib.setIssueType(new IssueType(null, new Long(14), "Change Request", false, null, null));

			iib.setSummary(reqInfo.get("REQ_SUMMARY") + " - " + reqId);
			iib.setDescription(formatDescription(reqInfo.get("DESCRIPTION"), tablesSubscribed));

			iib.setFieldValue("customfield_14722", new ComplexIssueInputFieldValue(
					ImmutableMap.<String, Object> of("value", "Data Consumption Request")));

			Object tDate = reqInfo.get("TARGET_DATE");
			iib.setFieldValue("customfield_19950",
					(tDate instanceof Timestamp) ? formatTimestamp((Timestamp) tDate) : formatDate((String) tDate)); // target
																														// Date

			// country access
			List<String> ctry = getJiraCtryLst(tablesSubscribed);
			List<Object> cList = new ArrayList<Object>();
			for (String c : ctry)
				cList.add(new ComplexIssueInputFieldValue(ImmutableMap.<String, Object> of("id", c)));
			iib.setFieldValue("customfield_10714", cList);

			// application access

			List<Object> appList = new ArrayList<Object>();
			List<String> apps = getJiraAppLst(tablesSubscribed);
			for (String a : apps)
				appList.add(new ComplexIssueInputFieldValue(ImmutableMap.<String, Object> of("id", a)));

			iib.setFieldValue("customfield_27741", appList);

			// business contact
			List<Object> busContacts = new ArrayList<Object>();
			busContacts.add(ComplexIssueInputFieldValue.with("name", reqInfo.get("CONSUMER_BUSINESS_OWNER")));
			iib.setFieldValue("customfield_12263", busContacts); // business
																	// contacts

			// business stream

			List<Object> busStream = new ArrayList<Object>();
			busStream.add(new ComplexIssueInputFieldValue(ImmutableMap.<String, Object> of("id", "43302")));
			iib.setFieldValue("customfield_10400", busStream);

			iib.setReporterName(requestor);

			IssueInput issue = iib.build();

			BasicIssue issueObj = issueClient.createIssue(issue).claim();

			System.out.println("Issue " + issueObj.getKey() + " created successfully ..");

			return issueObj.getKey();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Exception in creating the JIRA request for Request " + reqId);
			throw ex;			
		}
	}

	/**
	 * Method to get the JIRA Country Mapped
	 * 
	 * @param tablesSubscribed
	 * @return
	 */
	protected List<String> getJiraCtryLst(List<HashMap<String, String>> tablesSubscribed) {
		List<String> alist = new ArrayList<String>();
		for (HashMap<String, String> tables : tablesSubscribed) {
			String cty = cMap.get(tables.get("INSTANCE"));
			if (cty != null && !alist.contains(cty))
				alist.add(cty);
		}
		if (alist.isEmpty())
			alist.add("49512"); // adding ALL Country
		return alist;
	}

	/**
	 * Method to get the JIRA App Mapped
	 * 
	 * @param tablesSubscribed
	 * @return
	 */
	protected List<String> getJiraAppLst(List<HashMap<String, String>> tablesSubscribed) {
		List<String> alist = new ArrayList<String>();
		for (HashMap<String, String> tables : tablesSubscribed) {
			String appName = aMap.get(tables.get("APP_NAME"));
			if (appName != null && !alist.contains(appName))
				alist.add(appName);
		}
		if (alist.isEmpty())
			alist.add("40785"); // adding default APPS
		return alist;
	}

	/**
	 * Method to format the description with the details of the Tables
	 * subscribed
	 * 
	 * @param desc
	 * @param tables
	 * @return
	 */
	protected String formatDescription(String desc, List<HashMap<String, String>> tables) {
		StringBuilder sb = new StringBuilder();
		sb.append(desc);
		sb.append("\n\n");
		sb.append("Following tables are subscribed as part of Self Service Request");
		sb.append("\n\n");
		sb.append(
				"|*{color:#172b4d}Application Name{color}*|*{color:#172b4d}Instance{color}*|*{color:#172b4d}Table Name{color}*|");
		for (HashMap<String, String> tab : tables) {
			sb.append("\n");
			sb.append("|" + tab.get("APP_NAME") + "|" + tab.get("INSTANCE") + "|" + tab.get("TABLE_NAME") + "|");
		}
		sb.append("\n\n");
		return sb.toString();
	}

	/**
	 * Method to format the date
	 * 
	 * @param dValue
	 * @return
	 */
	private String formatTimestamp(Timestamp dValue) {
		try {
			return new SimpleDateFormat("yyyy-MM-dd").format(new Date(dValue.getTime()));
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Exception in formatting Date " + dValue + ex.getMessage());
			return null;
		}
	}

	/**
	 * Method to format the date
	 * 
	 * @param dValue
	 * @return
	 */
	private String formatDate(String dValue) {
		try {
			SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yy");
			Date formattedDt = df.parse(dValue);
			return new SimpleDateFormat("yyyy-MMM-dd").format(formattedDt);
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Exception in formatting Date " + dValue + ex.getMessage());
			return null;
		}
	}

	/**
	 * Method to add attachement to the JIRA
	 * 
	 * @param key
	 * @param fileName
	 * @param in
	 */
	public void addAttachement(String key, String fileName, InputStream in) {

		String jiraURL = PropertyConfigurer.getProperty("JIRA.URL");
		String jiraUsername = PropertyConfigurer.getProperty("JIRA.USERNAME");
		String jiraPasswd = PropertyConfigurer.getProperty("JIRA.CREDENTIALS");

		try {
			URI jiraServerUri = URI.create(jiraURL);

			AsynchronousJiraRestClientFactory factory = new AsynchronousJiraRestClientFactory();

			AuthenticationHandler auth = new BasicHttpAuthenticationHandler(jiraUsername, jiraPasswd);
			JiraRestClient restClient = factory.create(jiraServerUri, auth);
			IssueRestClient issueClient = restClient.getIssueClient();
			issueClient.addAttachment(new URI(jiraURL + "rest/api/2/issue/" + key + "/attachments"), in, fileName)
					.claim();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Exception in uploading the Attaching to the request for " + key);

		}
	}

	/**
	 * Method to add comments to the JIRA
	 * @param key
	 * @param response
	 * @param targetDate
	 */
	public void addComments(String key, HashMap<String, String> response, List<String> userActedBy) {
		String jiraURL = PropertyConfigurer.getProperty("JIRA.URL");
		String jiraUsername = PropertyConfigurer.getProperty("JIRA.USERNAME");
		String jiraPasswd = PropertyConfigurer.getProperty("JIRA.CREDENTIALS");

		try {
			URI jiraServerUri = URI.create(jiraURL);

			AsynchronousJiraRestClientFactory factory = new AsynchronousJiraRestClientFactory();

			AuthenticationHandler auth = new BasicHttpAuthenticationHandler(jiraUsername, jiraPasswd);
			JiraRestClient restClient = factory.create(jiraServerUri, auth);
			IssueRestClient issueClient = restClient.getIssueClient();
			StringBuilder sb = new StringBuilder();
			sb.append(response.get("REMARKS"));
			sb.append("\n");
			if (StringUtils.isNotEmpty(response.get("TARGET_DATE")))
				sb.append("Target Date - " + response.get("TARGET_DATE"));
			sb.append("\n");
			for (String users:userActedBy) 
				sb.append("[~" + users + "] ");
			
			issueClient.addComment( new URI(jiraURL + "rest/api/2/issue/" + key + "/comment"), Comment.valueOf(sb.toString())).claim();					
		}
		catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Exception in adding comments to the request for " + key);
			
		}
		
	}	
}
