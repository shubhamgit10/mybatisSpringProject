package com.scb.selfservice.model;

public class EmailContent {
    protected String reqId;
    protected String consumptionApplicationName;
    protected String purposeOfConsumption;
    protected String existingReqId;
    protected String targetDate;
    protected String reqSources;
    protected String reqCreatedBy;
    protected String reqCreatedOn;
    protected String lastActionBy;
    protected String lastActionOn;
    protected String reqPendingWith;
    protected String reqRemarks;
    protected String reqStatus;
    protected String consumptionRequest;
    protected String proposedSolution;
    protected String requestClassification;
    protected String lastActionedGroup;

    public String getReqId() {
        return reqId;
    }

    public void setReqId(String reqId) {
        this.reqId = reqId;
    }

    public String getConsumptionApplicationName() {
        return consumptionApplicationName;
    }

    public void setConsumptionApplicationName(String consumptionApplicationName) {
        this.consumptionApplicationName = consumptionApplicationName;
    }

    public String getPurposeOfConsumption() {
        return purposeOfConsumption;
    }

    public void setPurposeOfConsumption(String purposeOfConsumption) {
        this.purposeOfConsumption = purposeOfConsumption;
    }

    public String getExistingReqId() {
        return existingReqId;
    }

    public void setExistingReqId(String existingReqId) {
        this.existingReqId = existingReqId;
    }

    public String getTargetDate() {
        return targetDate;
    }

    public void setTargetDate(String targetDate) {
        this.targetDate = targetDate;
    }

    public String getReqSources() {
        return reqSources;
    }

    public void setReqSources(String reqSources) {
        this.reqSources = reqSources;
    }

    public String getReqCreatedBy() {
        return reqCreatedBy;
    }

    public void setReqCreatedBy(String reqCreatedBy) {
        this.reqCreatedBy = reqCreatedBy;
    }

    public String getReqCreatedOn() {
        return reqCreatedOn;
    }

    public void setReqCreatedOn(String reqCreatedOn) {
        this.reqCreatedOn = reqCreatedOn;
    }

    public String getLastActionBy() {
        return lastActionBy;
    }

    public void setLastActionBy(String lastActionBy) {
        this.lastActionBy = lastActionBy;
    }

    public String getLastActionOn() {
        return lastActionOn;
    }

    public void setLastActionOn(String lastActionOn) {
        this.lastActionOn = lastActionOn;
    }

    public String getReqPendingWith() {
        return reqPendingWith;
    }

    public void setReqPendingWith(String reqPendingWith) {
        this.reqPendingWith = reqPendingWith;
    }

    public String getReqRemarks() {
        return reqRemarks;
    }

    public void setReqRemarks(String reqRemarks) {
        this.reqRemarks = reqRemarks;
    }

    public String getReqStatus() {
        return reqStatus;
    }

    public void setReqStatus(String reqStatus) {
        this.reqStatus = reqStatus;
    }

    public String getConsumptionRequest() {
        return consumptionRequest;
    }

    public void setConsumptionRequest(String consumptionRequest) {
        this.consumptionRequest = consumptionRequest;
    }

    public String getProposedSolution() {
        return proposedSolution;
    }

    public void setProposedSolution(String proposedSolution) {
        this.proposedSolution = proposedSolution;
    }

    public String getRequestClassification() {
        return requestClassification;
    }

    public void setRequestClassification(String requestClassification) {
        this.requestClassification = requestClassification;
    }

	/**
	 * @return the lastActionedGroup
	 */
	public String getLastActionedGroup() {
		return lastActionedGroup;
	}

	/**
	 * @param lastActionedGroup the lastActionedGroup to set
	 */
	public void setLastActionedGroup(String lastActionedGroup) {
		this.lastActionedGroup = lastActionedGroup;
	}
}
