package com.scb.selfservice.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.ConsumptionRequest;
import com.scb.selfservice.domains.EDMPSelfServiceReq;
import com.scb.selfservice.domains.ItamTypeAhead;

public interface DataConsumptionRequestMapper {

	//method for save/insert the DataConsumptionRequest
	public int saveConsumptionRequest(@Param("ConsumptionRequest") ConsumptionRequest consumptionRequest);

	//method to pull existing DataConsumptionRequest based on reqId
	public ConsumptionRequest findByRequestId(@Param("reqId") Integer reqId);

	//method for updating DataConsumptionRequest
	public int updateConsumptionRequest(@Param("ConsumptionRequest") ConsumptionRequest consumptionRequest);

	//method for SubmitConsumption
	public int submitConsumptionRequest(@Param("submitConsumptionRequest")EDMPSelfServiceReq edmpSelfServiceReq);

	public List<ItamTypeAhead> getItamdetails(@Param("itam") String itam);

}
