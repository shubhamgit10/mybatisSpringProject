package com.scb.selfservice.service.impl;

import java.util.Map;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.scb.selfservice.service.MailService;

import freemarker.template.Configuration;
import freemarker.template.Template;

@Service(value="smtpMailService")
public class SMTPMailService  implements MailService {
    private static Logger logger = LogManager.getLogger(SMTPMailService.class);

    private JavaMailSenderImpl mailSender;

    @Autowired
    private Configuration freemarkerConfig;

    private String smtpHost;
    private String fromAddress;

    private JavaMailSenderImpl getSender() {
        if (null == mailSender) {
            mailSender = new JavaMailSenderImpl();
            mailSender.setHost(smtpHost);
            mailSender.setProtocol("smtp");
        }
        return mailSender;
    }

    public boolean sendMail(
            String senderAddress,
            String toAddress,
            String ccAddress,
            String subject,
            String template,
            Map<String, Object> params) {
        try {
            logger.info("preparing mail message content");
            // Prepare message using a Spring helper
            Template temp = freemarkerConfig.getTemplate(template);
            String htmlContent = FreeMarkerTemplateUtils.processTemplateIntoString(temp, params);

            logger.info(htmlContent);
            // Prepare message using a Spring helper
            final MimeMessage mimeMessage = getSender().createMimeMessage();
            mimeMessage.setContent(htmlContent, "text/html; charset=utf-8");
            final MimeMessageHelper message = new MimeMessageHelper(mimeMessage, "UTF-8");
            message.setSubject(subject);
            if(StringUtils.isNotEmpty(senderAddress)) {
                message.setFrom(senderAddress);
            }else {
                message.setFrom(this.fromAddress);
            }
            message.setTo(InternetAddress.parse(toAddress));
            if(StringUtils.isNotEmpty(ccAddress)) {
                message.setCc(InternetAddress.parse(ccAddress));
            }
            getSender().send(mimeMessage);
        } catch (Exception ex) {
            logger.error("Error sending mail", ex);
            return false;
        }

        return true;
    }

	/**
	 * @return the smtpHost
	 */
	public String getSmtpHost() {
		return smtpHost;
	}

	/**
	 * @param smtpHost the smtpHost to set
	 */
	public void setSmtpHost(String smtpHost) {
		this.smtpHost = smtpHost;
	}

	/**
	 * @return the fromAddress
	 */
	public String getFromAddress() {
		return fromAddress;
	}

	/**
	 * @param fromAddress the fromAddress to set
	 */
	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}
}
