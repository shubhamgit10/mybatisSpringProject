package com.scb.selfservice.domains;

/*
 * pojo for
 * WORKFLOW_PROCESS
 */

public class WorkflowProcess {

	private Integer workflowId;
	private String processName; 
	private String status;
	private Integer version;

	public Integer getWorkflowId() { 
		return workflowId;
	}
	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId; 
	}
	public String getProcessName() { 
		return processName; 
	} 
	public void	setProcessName(String processName) { 
		this.processName = processName; 
	} 
	public	String getStatus() { 
		return status; 
	} 
	public void setStatus(String status) {
		this.status = status; 
	}
	public Integer getVersion() { 
		return version;
	} 
	public void	setVersion(Integer version) { 
		this.version = version;
	}

	@Override
	public String toString() {
		return "WorkflowProcess [workflowId=" + workflowId + ", processName=" + processName + ", status=" + status
				+ ", version=" + version + "]";
	}

}
