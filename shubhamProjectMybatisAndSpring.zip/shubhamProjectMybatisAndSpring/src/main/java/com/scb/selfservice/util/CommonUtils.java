package com.scb.selfservice.util;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.http.HttpStatus;

import com.scb.selfservice.domains.FileData;
import com.scb.selfservice.domains.FilterRequest;
import com.scb.selfservice.domains.SearchDataSource;
import com.scb.selfservice.domains.SearchDataSourceCustomize;
import com.scb.selfservice.domains.Upject;
import com.scb.selfservice.domains.WorkflowRequest;
import com.scb.selfservice.web.authentication.UserPrincipal;
import com.scb.selfservice.web.controller.SearchController;

//Place for common method across application
public class CommonUtils {

	private static Logger logger = LogManager.getLogger(SearchController.class);

	public static String prepareSql(FilterRequest filterRequest) {
		logger.info("ApplyFilter received is: " + filterRequest);

		StringBuffer whereClause = new StringBuffer();
		if(StringUtils.isNotEmpty(filterRequest.getDataSource())) {
			whereClause.append(" app.itam_id=" + filterRequest.getDataSource().trim() + " AND ");
		}
		if (StringUtils.isNotEmpty(filterRequest.getCountries())) {
			whereClause.append(" tabs.country");
			whereClause.append(prepareInClause(filterRequest.getCountries().trim(), "IN"));
		}
		if (StringUtils.isNotEmpty(filterRequest.getSegments())) {
			whereClause.append(prepareLikeClause(filterRequest.getSegments().trim(), "LIKE", " app.business_segment"));
		}
		if (StringUtils.isNotEmpty(filterRequest.getDatasets())) {
			whereClause.append(prepareLikeClause(filterRequest.getDatasets().trim(), "LIKE", " tabs.table_name_t"));
		}
		if (StringUtils.isNotEmpty(filterRequest.getCertified())) {
			whereClause.append(" tabs.certified");
			whereClause.append(prepareInClause(filterRequest.getCertified().trim(), "IN"));
		}
		String preparedClause = whereClause.toString();
		if (preparedClause.endsWith("AND ")) {
			preparedClause = preparedClause.substring(0, preparedClause.lastIndexOf("AND"));
		}
		logger.info("WHERE CLAUSE prepared is: " + preparedClause);

		return preparedClause;
	}

	private static String prepareInClause(String strs, String type) {
		logger.info("Started preparing for: " + strs + " for [" + type + "]");
		StringBuffer clause = new StringBuffer();
		if (type.equals("IN")) {
			clause.append(" in (");
			for (String item : strs.split(",")) {
				clause.append("'" + item.trim() + "',");
			}

			String str = clause.toString();
			if (str.endsWith(",")) {
				str = str.substring(0, str.lastIndexOf(","));
			}
			str += (") AND ");
			logger.info("==" + str);
			return str;
		} else {
			clause = new StringBuffer();
			String like = " app.business_segment like '%";
			String likeClause = "";
			for (String item : strs.split(",")) {
				likeClause += like + item.trim()  + "%' OR ";
			}
			if (likeClause.endsWith("OR "))
				likeClause = likeClause.substring(0,  likeClause.lastIndexOf("OR"));
			clause.append("(" + likeClause + ")");
			clause.append(" AND ");
		}

		logger.info("Ending preparation: " + clause.toString());
		return clause.toString();
	}
	private static String prepareLikeClause(String strs, String type, String col) {
		logger.info("Started preparing for: " + strs + " for [" + type + "]");
		StringBuffer clause = new StringBuffer();

		clause = new StringBuffer();
		String like = col + " like '%";
		String likeClause = "";
		for (String item : strs.split(",")) {
			likeClause += like + item.trim()  + "%' OR ";
		}
		if (likeClause.endsWith("OR "))
			likeClause = likeClause.substring(0,  likeClause.lastIndexOf("OR"));
		clause.append("(" + likeClause + ")");
		clause.append(" AND ");

		logger.info("Ending preparation: " + clause.toString());
		return clause.toString();
	}
	
	//method to transform searchResponse to customized searchResponse
	public static Response processSearchResults(List<SearchDataSource> searchResults) {
		Response searchResponse = new Response();
		if (searchResults.isEmpty()) {
			searchResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			searchResponse.setStatus("204 No Content");
		} else {
			logger.info("Starting processing of: [" + searchResults.size() + "] records.");
			List<SearchDataSourceCustomize> dsCustom = new ArrayList<SearchDataSourceCustomize>();
			try {
				for (SearchDataSource item : searchResults) {
					SearchDataSourceCustomize dsCustomLocal = new SearchDataSourceCustomize();
					List<String> countriesList = Arrays.asList(item.getSupportedCountries().split(",")).stream().distinct().collect(Collectors.toList()); 
					List<String> bussinessSegmentList = Arrays.asList(item.getBusinessSegment().split(",")).stream().distinct().collect(Collectors.toList());

					dsCustomLocal.setAppName(item.getAppName());
					dsCustomLocal.setBusinessSegment(bussinessSegmentList);
					dsCustomLocal.setCertified(item.getCertified());
					dsCustomLocal.setHasPiiCols(item.getHasPiiCols());
					dsCustomLocal.setItamId(item.getItamId());
					dsCustomLocal.setNoOfCols(item.getNoOfCols());
					dsCustomLocal.setSupportedCountries(countriesList); 
					dsCustomLocal.setTableName(item.getTableName());
					dsCustomLocal.setAppDescription(item.getAppDescription());
					dsCustomLocal.setTableDescription(item.getTableDescription());

					dsCustom.add(dsCustomLocal);     
				}
			} catch(Exception ex) {
				searchResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
				searchResponse.setStatus(HttpStatus.NO_CONTENT.toString());
				return searchResponse;
			}
			searchResponse.setStatusCode(HttpStatus.OK.value());
			searchResponse.setStatus("Success");
			searchResponse.setResponse(dsCustom);
		}
		return searchResponse;
	}

	//return context
	public static ApplicationContext getContext() {
		String fileName = "bean-map/beans.xml";
		ClassLoader classLoader = new CommonUtils().getClass().getClassLoader();

		File file = new File(classLoader.getResource(fileName).getFile());
		ApplicationContext context = new FileSystemXmlApplicationContext
				(file.getAbsolutePath());

		return context;
	}

	//prepare map for service type WF
	public static Map<String, String> serviceMapUpdate(Upject upject) {
		//UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Map<String, String> serviceParams = new HashMap<String, String>();
		serviceParams.put("reqId", String.valueOf(upject.getReqId()));
		serviceParams.put("stepId", String.valueOf(upject.getStepId()));
		serviceParams.put("status", String.valueOf(upject.getStatus()));
		serviceParams.put("userId", String.valueOf(upject.getUserId()));

		return serviceParams;
	}

	public static Map<String, String> serviceMapInitial(WorkflowRequest wfr, UserPrincipal loggedInUser) {
		Map<String, String> serviceParams = new HashMap<String, String>();
		serviceParams.put("reqId", String.valueOf(wfr.getReqId()));
		serviceParams.put("stepId", String.valueOf(wfr.getLastActedStepId()));
		serviceParams.put("status", String.valueOf(wfr.getStatus()));
		serviceParams.put("userId", String.valueOf(loggedInUser.getUserId()));

		return serviceParams;
	}
	private static String formattedDate() {
		DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

		LocalDateTime localDateTime = LocalDateTime.now();

		String dateTime = format.format(localDateTime);
		logger.info("The formatted date is: " + dateTime);

		return dateTime;
	}

	//method for download xls headers (part of snapshot)
	private static List<String> colHeaders() {
		String[] str = {"Data Consumption Request Id", "Source Instance Request Ref No", "Request Status", "ITAM", "ITAM Description", "Data Source", "Data Source Description", "Instance", "Category", "Database Name", "Dataset Name", "Dataset Description", "Attribute Name", "Attribute Description", "GDS Term", "GDS Description", "Data Certified", "PII indicator", "CDE Indicator", "Data Type", "Data Length", "Data Lineage", "Data Profiling Link"};
		List<String> headers = Arrays.asList(str);
		return headers;
	}

	public static ByteArrayInputStream  prepareXlsx(List<FileData> fileData) throws IOException {
		logger.info("starting CommonUtils::prepareXlsx");
		XSSFWorkbook workbook = null;
		ByteArrayOutputStream out = null;
		try {
			workbook = new XSSFWorkbook();
			out = new ByteArrayOutputStream();
			XSSFSheet sheet = workbook.createSheet("Consumption Request"); 

			int rownum = 0; 
			int cellnum = 0; 
			Row row = sheet.createRow(rownum++); 
			CellStyle cellStyle = getHeaderCellStyle(workbook);

			for (String header : colHeaders()) { 
				Cell cell = row.createCell(cellnum++);

				cell.setCellValue(header); 
				cell.setCellStyle(cellStyle);
			}
			row = sheet.createRow(rownum); 
			cellnum = 0; //row first cell
			cellStyle = getCellStyle(workbook);
			if (fileData.isEmpty() || (null == fileData)) {
				row = sheet.createRow(rownum++);
				Cell cell = row.createCell(cellnum);

				cell.setCellValue("DATA NOT AVAILABLE"); 
				sheet.addMergedRegion(new CellRangeAddress(rownum + 2, rownum + 2, 0, 2));
				logger.info("CommonUtils::prepareXlsx DATA NOT AVAILABLE");
			} else {
				logger.info("CommonUtils::prepareXlsx WRITING " + fileData.size() + " rows");
				for (FileData item : fileData) {
					row = sheet.createRow(rownum++);
					cellnum = 0;
					logger.info("CommonUtils::prepareXlsx starting row " + (rownum - 1));
					for (String str : item.getGetters(item)) {
						Cell cell = row.createCell(cellnum++);
						if (StringUtils.isBlank(str) || str.equals("null"))
							cell.setCellValue("-");
						else
							cell.setCellValue(str);
						cell.setCellStyle(cellStyle);
					}
					logger.info("CommonUtils::prepareXlsx done with row " + (rownum - 1));
				}
				logger.info("CommonUtils::prepareXlsx DATA WRITTEN");
			}
			row = sheet.createRow(rownum + 2); //
			Cell cell = row.createCell(0);  
			cell.setCellValue("<End of Report >");
			sheet.addMergedRegion(new CellRangeAddress(rownum + 1, rownum + 1, 0, 2));  
			workbook.write(out);
			logger.info("exiting CommonUtils::prepareXlsx");
			return new ByteArrayInputStream(out.toByteArray());
		} catch (Exception ex){
			logger.info("EXCEPTION occuered while preparing xlsx " + ex.getMessage());
			return null;
		} finally {
			if (null != out)
				out.close();
			if (null != workbook)
				workbook.close();
		}
	}
	public static String fileName (int reqId) {
		String fileName = "EDMp" + reqId + "_" + formattedDate() + ".xlsx";
		return fileName;
	}
	private static CellStyle getHeaderCellStyle(XSSFWorkbook workbook) {
		CellStyle style = workbook.createCellStyle();  
		//style.setFillBackgroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
		style.setBorderBottom(BorderStyle.THIN);
		style.setBorderLeft(BorderStyle.THIN);
		style.setBorderRight(BorderStyle.THIN);
		style.setBorderTop(BorderStyle.THIN);
		style.setWrapText(true);
		style.setAlignment(HorizontalAlignment.LEFT);
		style.setVerticalAlignment(VerticalAlignment.TOP);
		style.setFont(boldFont(workbook, true));

		return style;
	}

	private static CellStyle getCellStyle(XSSFWorkbook workbook) {
		CellStyle style = workbook.createCellStyle();  
		style.setBorderBottom(BorderStyle.THIN);
		style.setBorderLeft(BorderStyle.THIN);
		style.setBorderRight(BorderStyle.THIN);
		style.setBorderTop(BorderStyle.THIN);
		style.setWrapText(true);

		style.setFont(boldFont(workbook, false));

		return style;
	}
	private static Font boldFont(XSSFWorkbook workbook, boolean boldFont) {
		Font font = workbook.createFont();  
		font.setFontHeightInPoints((short)7);  
		font.setFontName("Segoe UI");
		if (boldFont)
			font.setBold(true);
		else
			font.setBold(false);
		return font;
	}

	public static String getFiledataString(FileData fileData) {

		return fileData.toString();
	}

	public static ByteArrayInputStream prepareFileData(byte[] content) {
		logger.info("starting CommonUtils::prepareFileData");
		ByteArrayInputStream fileContent = new ByteArrayInputStream(content);
		logger.info("exiting CommonUtils::prepareFileData");
		return fileContent;
	}

	public static HttpStatus httpStatus(Response response) {
		switch(response.getStatusCode()) {
		case 200: return HttpStatus.OK;
		case 204: return HttpStatus.NO_CONTENT;
		case 206: return HttpStatus.PARTIAL_CONTENT;
		default : return HttpStatus.NOT_FOUND;
		}
	}
	
	public static String setDecimalPrecision(double val, String fmt) {
		DecimalFormat df =null;
		if(fmt==null || "".equals(fmt)){
			df =new DecimalFormat("###########0.00");			
		}
		else {
			df=new DecimalFormat(fmt);
		}
	
		String s=df.format(val);
		return s;
	}

}
