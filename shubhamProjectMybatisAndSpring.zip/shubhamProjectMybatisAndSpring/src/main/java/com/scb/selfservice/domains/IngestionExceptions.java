package com.scb.selfservice.domains;

public class IngestionExceptions {
	
	
	private Integer reqId;
	
	private Integer releaseId;
	
	private String stepId;
	
	private String environment;
	
	private Integer exceptionNum;
	
	private String exceptionDetails;

	public Integer getReqId() {
		return reqId;
	}

	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}

	public Integer getReleaseId() {
		return releaseId;
	}

	public void setReleaseId(Integer releaseId) {
		this.releaseId = releaseId;
	}

	public Integer getExceptionNum() {
		return exceptionNum;
	}

	public void setExceptionNum(Integer exceptionNum) {
		this.exceptionNum = exceptionNum;
	}

	public String getExceptionDetails() {
		return exceptionDetails;
	}

	public void setExceptionDetails(String exceptionDetails) {
		this.exceptionDetails = exceptionDetails;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	@Override
	public String toString() {
		return "IngestionExceptions [reqId=" + reqId + ", releaseId=" + releaseId + ", stepId=" + stepId
				+ ", environment=" + environment + ", exceptionNum=" + exceptionNum + ", exceptionDetails="
				+ exceptionDetails + "]";
	}

}
