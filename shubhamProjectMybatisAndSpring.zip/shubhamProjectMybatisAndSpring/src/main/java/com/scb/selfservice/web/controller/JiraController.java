package com.scb.selfservice.web.controller;


import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.workflow.service.ExecutionContext;
import com.scb.selfservice.workflow.service.task.JiraIntegrationTask;

@RestController
@RequestMapping("/api/jira")
public class JiraController {

    @Autowired
    private JiraIntegrationTask jiraIntegrationTask;
    /**
     * Method to send mail to the approval group for the given workflowid
     * @param reqid
     * @param stepid
     * @param stepaction
     * @return
     */

    @RequestMapping(path = "/process", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, String> process(@RequestHeader Map<String, String> header,
                                        @RequestParam(name = "reqid") int reqid,
                                        @RequestParam(name = "stepid") String stepid,
                                        @RequestParam(name = "stepaction") String stepaction,
                                        HttpServletRequest request) {

        Map<String, String> result = new HashMap<String, String>();
        ExecutionContext ctx = new ExecutionContext();
        ctx.setReqId(reqid+"");
        ctx.setStepId(stepid);
        ctx.setAction(stepaction);
        jiraIntegrationTask.execute(ctx);
        
        result.put("status","200");
        return result;
    }

}
