package com.scb.selfservice.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.scb.selfservice.domains.WorkflowRequestStep;

public class WorkflowConstants {
	public static final String COMPLETED   = "COMPLETED";
	public static final String PENDING     = "PENDING";
	public static final String NOT_STARTED = "NOT STARTED";
	public static final String SUBMITTED   = "SUBMITTED";
	public static final String APPROVE     = "APPROVE";
	public static final String CANCELLED   = "CANCELLED";
	public static final String REJECTED    = "REJECTED";
	public static final String FAILURE     = "FAILURE";
	public static final String ACTIVE      = "ACTIVE";
	//public static final String REQUESTOR   = "S0";
	public static final String SUCCESS     = "SUCCESS";
	public static final String LMUSER	   = "LM";
	public static final String DMUSER	   = "DM";
	public static final String SDUSER	   = "SOLUTION_DESIGNER";
	public static final String CAUSER	   = "CHANGE_APPROVER";
	public static final String REQUESTOR   = "Requestor";
	public static final String AUTOAPPROVED= "AUTO APPROVED";
	public static final String SKIPPED	   = "SKIPPED";
	

	private static Logger logger = LogManager.getLogger(WorkflowConstants.class);

	public static List<WorkflowRequestStep> wfReqSteps (int reqId, String remarks, int stepPendingUser, int stepActionedBy) {
		logger.info("-=-=-=" + reqId + " " + remarks + "  " + stepPendingUser + "  " + stepActionedBy);
		logger.info("STARTED-> WorkflowConstants::wfReqSteps");
		List<WorkflowRequestStep> initSteps = new ArrayList<>();
		

		logger.info("EXITING-> WorkflowConstants::wfReqSteps");
		return initSteps;
	}
}
