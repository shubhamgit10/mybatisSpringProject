/**
 * 
 */
package com.scb.selfservice.service.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.scb.selfservice.http.RangerPolicyV2Util;
import com.scb.selfservice.model.ConsumptionRequestInfo;
import com.scb.selfservice.service.ConsumptionMasterService;
import com.scb.selfservice.service.RangerPolicyServiceWrapper;
import com.scb.selfservice.workflow.service.task.ConsumptionMasterTask;

/**
 * Wrapper Service to execute in the Async way
 * 
 * @author 1565003
 *
 */
@Service
public class RangerPolicyServiceWrapperImpl implements RangerPolicyServiceWrapper {

	@Autowired
	RangerPolicyV2Util rangerPolicyUtil;
	
	@Autowired
	private ConsumptionMasterService consumpMstService;
	
	private static Logger logger = LogManager.getLogger(RangerPolicyServiceWrapperImpl.class);
	
	/**
	 * Method to handle for Policy Creation and execute in Async way
	 */
	@Override
	@Async
	public void handlePolicyCreation(String reqId, String stepId, String userId) {
		logger.debug("Inside Ranger Policy creation for " + reqId + " " + stepId);
		String status = rangerPolicyUtil.processRangerPolicyRequest(reqId, stepId, userId);
		logger.debug("Inside Ranger Policy creation for " + reqId + " and status is " + status);
		if ("SUCCESS".equalsIgnoreCase(status)) {
			logger.debug("Inside Consmuption Master creation for " + reqId );
			String remarks = null;
			try {
				ConsumptionRequestInfo data = consumpMstService.retrieveRequestDetails(reqId);
				remarks = consumpMstService.createOrUpdateConsumerMaster(reqId, data);
			} catch (Exception ex) {
				ex.printStackTrace();
				remarks = "Error while creating Consumer Master Entries. Pls check application log";
				status = "FAILURE";
			}
			consumpMstService.createAuditTrailsData(Integer.valueOf(reqId), stepId,	userId, status, remarks);	
			logger.debug("Inside Consmuption Master creation for " + reqId + " stauts is " + status);
		}
	}
}
