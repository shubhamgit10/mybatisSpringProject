package com.scb.selfservice.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.FileUpload;

/*
 * interface to map file upload related logic
 */
public interface FileUploadMapper {

	public int insertFile(@Param("insertFile") FileUpload insertFile);
	
	public int updateFile(@Param("updateFile") FileUpload updateFile);

	//mapper to delete the uploaded file based on uploaded fileId
	public int deleteFile(@Param("fileId") Integer fileId);

}
