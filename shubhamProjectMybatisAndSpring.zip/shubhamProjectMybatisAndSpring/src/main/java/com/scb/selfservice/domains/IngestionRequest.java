package com.scb.selfservice.domains;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

/*
 * pojo for
 * EDMP_INGESTION_REQUEST
 */
public class IngestionRequest {
	private Integer reqId;
	private String sourceName;
	private String instanceName;
	private String yearsOfHistoryIsReq;
	private Integer approxHistoryDataSize;
	private String historyStorageType;
	private String frequency;
	private Integer approxIncrementalDataSize;
	private String incrementalStorageType;
	private Date expectedDeliveryDate;
	private Integer expectedNoOfFiles;
	private Integer expectedNoOfAttributes;
	private String priority;
	private Integer itamNumber;
	private String projectName;
	private String businessStream;
	private String fundingAvenue;
	private String benefitCatagory;
	private String benefitDetails;
	private String requestSummary;
	@JsonIgnore
	private Integer requestCreatedBy;
	@JsonIgnore
	private Timestamp requestCreatedAt;
	@JsonIgnore
	private Timestamp requestModifiedAt;
	@JsonIgnore
	private Integer requestModifiedBy;
	private String userAction;
	private String sourceType;
	private Integer estimationId;
	private Double proposedCost;
	private String subSourceType;
	private Integer rejectedFlag;

	public Integer getReqId() {
		return reqId;
	}

	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}

	public String getSourceName() {
		return sourceName;
	}

	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}

	public String getInstanceName() {
		return instanceName;
	}

	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}

	public String getYearsOfHistoryIsReq() {
		return yearsOfHistoryIsReq;
	}

	public void setYearsOfHistoryIsReq(String yearsOfHistoryIsReq) {
		this.yearsOfHistoryIsReq = yearsOfHistoryIsReq;
	}

	public Integer getApproxHistoryDataSize() {
		return approxHistoryDataSize;
	}

	public void setApproxHistoryDataSize(Integer approxHistoryDataSize) {
		this.approxHistoryDataSize = approxHistoryDataSize;
	}

	public String getHistoryStorageType() {
		return historyStorageType;
	}

	public void setHistoryStorageType(String historyStorageType) {
		this.historyStorageType = historyStorageType;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public Integer getApproxIncrementalDataSize() {
		return approxIncrementalDataSize;
	}

	public void setApproxIncrementalDataSize(Integer approxIncrementalDataSize) {
		this.approxIncrementalDataSize = approxIncrementalDataSize;
	}

	public String getIncrementalStorageType() {
		return incrementalStorageType;
	}

	public void setIncrementalStorageType(String incrementalStorageType) {
		this.incrementalStorageType = incrementalStorageType;
	}

	public Date getExpectedDeliveryDate() {
		return expectedDeliveryDate;
	}

	public void setExpectedDeliveryDate(Date expectedDeliveryDate) {
		this.expectedDeliveryDate = expectedDeliveryDate;
	}

	public Integer getExpectedNoOfFiles() {
		return expectedNoOfFiles;
	}

	public void setExpectedNoOfFiles(Integer expectedNoOfFiles) {
		this.expectedNoOfFiles = expectedNoOfFiles;
	}

	public Integer getExpectedNoOfAttributes() {
		return expectedNoOfAttributes;
	}

	public void setExpectedNoOfAttributes(Integer expectedNoOfAttributes) {
		this.expectedNoOfAttributes = expectedNoOfAttributes;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public Integer getItamNumber() {
		return itamNumber;
	}

	public void setItamNumber(Integer itamNumber) {
		this.itamNumber = itamNumber;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getBusinessStream() {
		return businessStream;
	}

	public void setBusinessStream(String businessStream) {
		this.businessStream = businessStream;
	}

	public String getFundingAvenue() {
		return fundingAvenue;
	}

	public void setFundingAvenue(String fundingAvenue) {
		this.fundingAvenue = fundingAvenue;
	}

	public String getBenefitCatagory() {
		return benefitCatagory;
	}

	public void setBenefitCatagory(String benefitCatagory) {
		this.benefitCatagory = benefitCatagory;
	}

	public String getBenefitDetails() {
		return benefitDetails;
	}

	public void setBenefitDetails(String benefitDetails) {
		this.benefitDetails = benefitDetails;
	}

	public String getRequestSummary() {
		return requestSummary;
	}

	public void setRequestSummary(String requestSummary) {
		this.requestSummary = requestSummary;
	}

	public Integer getRequestCreatedBy() {
		return requestCreatedBy;
	}

	public void setRequestCreatedBy(Integer requestCreatedBy) {
		this.requestCreatedBy = requestCreatedBy;
	}

	public Timestamp getRequestCreatedAt() {
		return requestCreatedAt;
	}

	public void setRequestCreatedAt(Timestamp requestCreatedAt) {
		this.requestCreatedAt = requestCreatedAt;
	}

	public Timestamp getRequestModifiedAt() {
		return requestModifiedAt;
	}

	public void setRequestModifiedAt(Timestamp requestModifiedAt) {
		this.requestModifiedAt = requestModifiedAt;
	}

	public Integer getRequestModifiedBy() {
		return requestModifiedBy;
	}

	public void setRequestModifiedBy(Integer requestModifiedBy) {
		this.requestModifiedBy = requestModifiedBy;
	}

	public String getUserAction() {
		return userAction;
	}

	public void setUserAction(String userAction) {
		this.userAction = userAction;
	}

	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public Integer getEstimationId() {
		return estimationId;
	}

	public void setEstimationId(Integer estimationId) {
		this.estimationId = estimationId;
	}

	public Double getProposedCost() {
		return proposedCost;
	}

	public void setProposedCost(Double proposedCost) {
		this.proposedCost = proposedCost;
	}

	public String getSubSourceType() {
		return subSourceType;
	}

	public void setSubSourceType(String subSourceType) {
		this.subSourceType = subSourceType;
	}

	
	public Integer getRejectedFlag() {
		return rejectedFlag;
	}

	public void setRejectedFlag(Integer rejectedFlag) {
		this.rejectedFlag = rejectedFlag;
	}
	
	
	@Override
	public String toString() {
		return "IngestionRequest [reqId=" + reqId + ", sourceName=" + sourceName + ", instanceName=" + instanceName
				+ ", yearsOfHistoryIsReq=" + yearsOfHistoryIsReq + ", approxHistoryDataSize=" + approxHistoryDataSize
				+ ", historyStorageType=" + historyStorageType + ", frequency=" + frequency
				+ ", approxIncrementalDataSize=" + approxIncrementalDataSize + ", incrementalStorageType="
				+ incrementalStorageType + ", expectedDeliveryDate=" + expectedDeliveryDate + ", expectedNoOfFiles="
				+ expectedNoOfFiles + ", expectedNoOfAttributes=" + expectedNoOfAttributes + ", priority=" + priority
				+ ", itamNumber=" + itamNumber + ", projectName=" + projectName + ", businessStream=" + businessStream
				+ ", fundingAvenue=" + fundingAvenue + ", benefitCatagory=" + benefitCatagory + ", benefitDetails="
				+ benefitDetails + ", requestSummary=" + requestSummary + ", requestCreatedBy=" + requestCreatedBy
				+ ", requestCreatedAt=" + requestCreatedAt + ", requestModifiedAt=" + requestModifiedAt
				+ ", requestModifiedBy=" + requestModifiedBy + ", userAction=" + userAction + ", sourceType="
				+ sourceType + ", estimationId=" + estimationId + ", proposedCost=" + proposedCost + ", subSourceType="
				+ subSourceType + ", rejectedFlag=" + rejectedFlag + "]";
	}

	public List<String> getGetters(IngestionRequest item) {
		List<String> filedata = new ArrayList<>();
		filedata.add(Integer.toString(item.getReqId()));
		filedata.add(item.getSourceName());
		filedata.add(item.getInstanceName());
		filedata.add(item.getYearsOfHistoryIsReq());
		filedata.add(String.valueOf(item.getApproxHistoryDataSize()));
		filedata.add(item.getHistoryStorageType());
		filedata.add(item.getFrequency());
		filedata.add(String.valueOf(item.getApproxIncrementalDataSize()));
		filedata.add(item.getIncrementalStorageType());
		filedata.add(String.valueOf(item.getExpectedDeliveryDate()));
		filedata.add(String.valueOf(item.getExpectedNoOfFiles()));
		filedata.add(String.valueOf(item.getExpectedNoOfAttributes()));
		filedata.add(item.getPriority());
		filedata.add(String.valueOf(item.getItamNumber()));
		filedata.add(item.getProjectName());
		filedata.add(item.getBusinessStream());
		filedata.add(item.getFundingAvenue());
		filedata.add(item.getBenefitCatagory());
		filedata.add(item.getBenefitDetails());
		filedata.add(item.getRequestSummary());
		filedata.add(String.valueOf(item.getRequestCreatedBy()));
		filedata.add(String.valueOf(item.getRequestCreatedAt()));
		filedata.add(String.valueOf(item.getRequestModifiedAt()));
		filedata.add(String.valueOf(item.getRequestModifiedBy()));
		filedata.add(item.getUserAction());
		filedata.add(item.getSourceType());
		filedata.add(String.valueOf(item.getEstimationId()));
		return filedata;
	}

}
