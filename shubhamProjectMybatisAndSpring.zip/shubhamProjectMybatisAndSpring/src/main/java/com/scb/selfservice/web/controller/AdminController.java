package com.scb.selfservice.web.controller;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.util.Response;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;
import com.scb.selfservice.web.authentication.UserPrincipal;
import com.scb.selfservice.workflow.service.AdminService;

@RestController
@RequestMapping("/api/admin")
public class AdminController {
	private static Logger logger = LogManager.getLogger(MyApprovalController.class);

	@Autowired
	AdminService adminService;

	@GetMapping (path="/approvalLists", produces=MediaType.APPLICATION_JSON_VALUE)
	public  ResponseEntity<Response> getAdminApprovalLists(@RequestParam("workflowType") String workflowType) {
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response myApprovalList =  new Response();
		if (loggedInUser != null) {
			logger.info("STARTED AdminController - getAdminApprovalLists");
			myApprovalList = adminService.getAdminApprovalList(workflowType);
			logger.info("EXITING AdminController - getAdminApprovalLists");	
		} else {
			myApprovalList.setStatus(HttpStatus.UNAUTHORIZED.toString());
			myApprovalList.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
		
		return new ResponseEntity<Response> (myApprovalList, HttpStatus.OK);
	}

	@PostMapping (path="/reassign", produces=MediaType.APPLICATION_JSON_VALUE)
	public  ResponseEntity<Response> adminReAssign(@RequestBody HashMap<String, String> reAssignMap) {
		
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response response =  new Response();
		if (loggedInUser != null) {
			logger.info("STARTED AdminController - adminReAssign");
			try {
				response = adminService.adminReAssign(reAssignMap);
			} catch (Exception ex) {
				logger.info("EXCEPTION AdminController - adminReAssign: " + ex.getMessage());
				response.setStatus(HttpStatus.NO_CONTENT.toString());
				response.setStatusCode(HttpStatus.NO_CONTENT.value());
			}
			logger.info("EXITING AdminController - adminReAssign");	
		} else {
			response.setStatus(HttpStatus.UNAUTHORIZED.toString());
			response.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
		
		return new ResponseEntity<Response> (response, HttpStatus.OK);
	}
}
