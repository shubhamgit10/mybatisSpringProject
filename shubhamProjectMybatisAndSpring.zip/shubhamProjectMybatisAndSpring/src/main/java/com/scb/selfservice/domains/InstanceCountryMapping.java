package com.scb.selfservice.domains;

public class InstanceCountryMapping {
	private Integer itamNo;
	private String itamName;
	private String itamDesc;
	private String instanceName;
	private String countries;
	public Integer getItamNo() {
		return itamNo;
	}
	public void setItamNo(Integer itamNo) {
		this.itamNo = itamNo;
	}
	public String getItamName() {
		return itamName;
	}
	public void setIamName(String itamName) {
		this.itamName = itamName;
	}
	public String getItamDesc() {
		return itamDesc;
	}
	public void setItamDesc(String itamDesc) {
		this.itamDesc = itamDesc;
	}
	public String getInstanceName() {
		return instanceName;
	}
	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}
	public String getCountries() {
		return countries;
	}
	public void setCountries(String countries) {
		this.countries = countries;
	}
	
	@Override
	public String toString() {
		return "InstanceCountryMapping [itamNo=" + itamNo + ", itamName=" + itamName + ", itamDesc=" + itamDesc
				+ ", instanceName=" + instanceName + ", countries=" + countries + "]";
	}
	
	

}
