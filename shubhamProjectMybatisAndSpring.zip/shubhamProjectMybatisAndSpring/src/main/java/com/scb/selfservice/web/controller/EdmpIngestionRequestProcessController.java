package com.scb.selfservice.web.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.domains.BizAnylstResponse;
import com.scb.selfservice.domains.IngestionDmApproval;
import com.scb.selfservice.domains.IngestionRequestorResp;
import com.scb.selfservice.domains.IngestionSolArchApproval;
import com.scb.selfservice.service.EdmpIngestionRequestProcessService;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;
import com.scb.selfservice.web.authentication.UserPrincipal;

@RestController
@RequestMapping("/api/ingestionRequestProcess")
public class EdmpIngestionRequestProcessController {

	Logger logger = LogManager.getLogger(EdmpIngestionRequestProcessController.class);

	@Autowired
	EdmpIngestionRequestProcessService edmpirps;

	@PutMapping(path = "/SolArchResp", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> saveIngestionProcessRequest(
			@RequestBody IngestionSolArchApproval ingestionSolArchApproval) {

		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response ingestionResponse = new Response();

		if (loggedInUser != null) {
			Integer userId = Integer.valueOf(loggedInUser.getUserId());
			ingestionSolArchApproval.setRequestCreatedBy(userId);

			try {

				ingestionResponse = edmpirps.saveSolutionArchResp(ingestionSolArchApproval, userId);
			} catch (Exception ex) {
				ingestionResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
				ingestionResponse.setStatus(HttpStatus.NO_CONTENT.toString());
				logger.info(
						"EXCEPTION EdmpIngestionReqProcessController>saveIngestionProcessRequest: " + ex.getMessage());
			}

		} else {
			ingestionResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			ingestionResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}

		return new ResponseEntity<Response>(ingestionResponse, HttpStatus.OK);
	}

	@PutMapping(path = "/IngestionRequestorResp", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> saveIngestionRequestorResp(
			@RequestBody IngestionRequestorResp ingestionRequestorResp) {

		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response ingestionResponse = new Response();

		if (loggedInUser != null) {
			Integer userId = Integer.valueOf(loggedInUser.getUserId());
			ingestionRequestorResp.setRequestCreatedBy(userId);

			try {

				ingestionResponse = edmpirps.saveIngestionRequestorResp(ingestionRequestorResp, userId);
			} catch (Exception ex) {
				ingestionResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
				ingestionResponse.setStatus(HttpStatus.NO_CONTENT.toString());
				logger.info("EXCEPTION EdmpIngRequestorRespController>saveIngestionProcessRequest: " + ex.getMessage());
			}
		} else {
			ingestionResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			ingestionResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}

		return new ResponseEntity<Response>(ingestionResponse, HttpStatus.OK);
	}

	@PutMapping(path = "/DmResp", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> saveDmApprovalRequest(@RequestBody IngestionDmApproval ingestionDmApproval) {

		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response ingestionResponse = new Response();

		if (loggedInUser != null) {
			Integer userId = Integer.valueOf(loggedInUser.getUserId());
			ingestionDmApproval.setRequestCreatedBy(userId);

			try {

				ingestionResponse = edmpirps.saveDmApprovalResp(ingestionDmApproval, userId);
			} catch (Exception ex) {
				ingestionResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
				ingestionResponse.setStatus(HttpStatus.NO_CONTENT.toString());
				logger.info(
						"EXCEPTION EdmpIngestionReqProcessController>saveIngestionProcessRequest: " + ex.getMessage());
			}

		} else {
			ingestionResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			ingestionResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}

		return new ResponseEntity<Response>(ingestionResponse, HttpStatus.OK);
	}

	@PutMapping(path = "/BizAnlystResp", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> saveIngestionProcessRequest(@RequestBody BizAnylstResponse bizAnResponse) {

		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response ingestionResponse = new Response();

		if (loggedInUser != null) {
			Integer userId = Integer.valueOf(loggedInUser.getUserId());
			bizAnResponse.setRequestCreatedBy(userId);

			try {

				ingestionResponse = edmpirps.savebizAnalystResp(bizAnResponse, userId);
			} catch (Exception ex) {
				ingestionResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
				ingestionResponse.setStatus(HttpStatus.NO_CONTENT.toString());
				logger.info(
						"EXCEPTION EdmpIngestionReqProcessController>saveIngestionProcessRequest: " + ex.getMessage());
			}

		} else {
			ingestionResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			ingestionResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}

		return new ResponseEntity<Response>(ingestionResponse, HttpStatus.OK);
	}
	

	// GetMethod for getCostApproval in Ingestion
		@RequestMapping(path = "/getCostApproval", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<Response> getIngestionRequestorResp(@RequestParam("reqId") Integer reqId) {
			
			logger.info("getCostApproval ");
			Response dataSourceResponse = new Response();
			
			try {
			 dataSourceResponse = edmpirps.getIngestionRequestorResp(reqId);
			} catch(Exception ex) {
				logger.info("EXCEPTION EdmpIngestionRequestProcessController::getCostApproval: " + ex.getMessage());
				dataSourceResponse.setStatus(HttpStatus.NO_CONTENT.toString());
				dataSourceResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			}
			return new ResponseEntity<Response>(dataSourceResponse,HttpStatus.OK);
		}
}