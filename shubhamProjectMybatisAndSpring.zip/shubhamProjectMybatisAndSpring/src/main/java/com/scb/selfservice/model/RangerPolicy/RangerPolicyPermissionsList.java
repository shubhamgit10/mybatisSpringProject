package com.scb.selfservice.model.RangerPolicy;

import java.util.ArrayList;
import java.util.List;

public class RangerPolicyPermissionsList {
	
	private List<String> userList;
	private List<String> groupList;
	private List<String> permList;
	
	/**
	 * 
	 */
	public RangerPolicyPermissionsList() {
		super();
		userList = new ArrayList<String> ();
		groupList = new ArrayList<String>();
		permList = new ArrayList<String>();
	}

	/**
	 * @param userList
	 * @param groupList
	 * @param permList
	 */
	public RangerPolicyPermissionsList(List<String> userList, List<String> groupList, List<String> permList) {
		super();
		this.userList = userList;
		this.groupList = groupList;
		this.permList = permList;
	}

	/**
	 * @return the userList
	 */
	public List<String> getUserList() {
		return userList;
	}

	/**
	 * @param userList the userList to set
	 */
	public void setUserList(List<String> userList) {
		this.userList = userList;
	}

	/**
	 * @return the groupList
	 */
	public List<String> getGroupList() {
		return groupList;
	}

	/**
	 * @param groupList the groupList to set
	 */
	public void setGroupList(List<String> groupList) {
		this.groupList = groupList;
	}

	/**
	 * @return the permList
	 */
	public List<String> getPermList() {
		return permList;
	}

	/**
	 * @param permList the permList to set
	 */
	public void setPermList(List<String> permList) {
		this.permList = permList;
	}

	@Override
	public String toString() {
		return "RangerPolicyPermissionsList [userList=" + userList + ", groupList=" + groupList + ", permList="
				+ permList + "]";
	}

}
