package com.scb.selfservice.web.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.domains.IngestionRequest;
import com.scb.selfservice.service.EdmpIngestionRequestService;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;
import com.scb.selfservice.web.authentication.UserPrincipal;

@RestController
@RequestMapping("/api/ingestionMapping")
public class EdmpIngestionRequestController {

	Logger logger = LogManager.getLogger(EdmpIngestionRequestController.class);

	@Autowired
	EdmpIngestionRequestService edmpIngestionRequestService;

	@PutMapping(path = "/ingestionReq", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> saveIngestionRequest(@RequestBody IngestionRequest ingestionRequest) {

		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response ingestionResponse = new Response();
		if (loggedInUser != null) {
			Integer userId = Integer.valueOf(loggedInUser.getUserId());
			ingestionRequest.setRequestCreatedBy(userId);
			try {
				ingestionResponse = edmpIngestionRequestService.saveIngestionRequest(ingestionRequest,userId);
			} catch (Exception ex) {
				ingestionResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
				ingestionResponse.setStatus(HttpStatus.NO_CONTENT.toString());
				logger.info("EXCEPTION EdmpIngestionRequestController>saveIngestionRequest: " + ex.getMessage());
			}
		} else {
			ingestionResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			ingestionResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}

		return new ResponseEntity<Response>(ingestionResponse, HttpStatus.OK);
	}
	
	@GetMapping(path = "/ingestionReq", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getIngestionRequest(@RequestParam("reqId") Integer reqId) {
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response getingestionresponse = new Response();
		if (loggedInUser != null) {
			getingestionresponse = edmpIngestionRequestService.findByReqId(reqId);
		} else {
			getingestionresponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			getingestionresponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
		return new ResponseEntity<Response>(getingestionresponse, HttpStatus.OK);
	}

}
