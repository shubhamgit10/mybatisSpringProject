package com.scb.selfservice.sdmtech.dtoEntity;

public class SDMTablename {

	private Integer reqId;
	private String tableName;
	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	@Override
	public String toString() {
		return "SDMTablename [reqId=" + reqId + ", tableName=" + tableName + "]";
	}
	
}
