package com.scb.selfservice.service.impl;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.scb.selfservice.dao.mapper.WorkflowMapper;
import com.scb.selfservice.dao.mapper.WorkflowRespTableMapper;
import com.scb.selfservice.domains.IngestionInput;
import com.scb.selfservice.domains.Upject;
import com.scb.selfservice.domains.WorkflowIdType;
import com.scb.selfservice.domains.WorkflowRespTableMapping;
import com.scb.selfservice.service.IngestionDynamicService;
import com.scb.selfservice.service.UserResponseService;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.workflow.service.impl.WorkflowRequestServiceImpl;

/**
 * @author cpedada
 *
 */
@Service
public class IngestionDynamicImpl implements IngestionDynamicService {

	Logger logger = LogManager.getLogger(IngestionDynamicImpl.class);

	@Autowired
	WorkflowRespTableMapper wfrTableMapper;

	@Autowired
	ApplicationContext applicationContext;

	@Autowired
	WorkflowMapper workflowMapper;

	@Autowired
	WorkflowRequestServiceImpl wfrsi;

	@Autowired
	MyRequestServiceImpl mrServiceImpl;

	@Override
	public Response saveIngestionResp(IngestionInput ingestionInput) throws Exception {

		Response isaResponse = new Response();
		Integer reqId = 0;
		String stepId = ingestionInput.getStepId();

		WorkflowIdType workflowIdType = workflowMapper.getWorkflowId(ingestionInput.getWorkflowType());

		Integer workflowId = workflowIdType.getWorkflowId();

		WorkflowRespTableMapping crObj = wfrTableMapper.findByStepId(workflowId, stepId);

		Response res = null;

		if (null != crObj) {

			String stepClassName = crObj.getStepClassName();

			UserResponseService userResponseService = (UserResponseService) applicationContext.getBean(stepClassName);

			AutowireCapableBeanFactory factory = applicationContext.getAutowireCapableBeanFactory();
			factory.autowireBean(userResponseService);
			factory.initializeBean(userResponseService, stepClassName);
			res = userResponseService.executeSave(ingestionInput);
			
		}

		if (res == null || res.getStatusCode() == 200) {

			reqId = ingestionInput.getReqId();

			String userAction = ingestionInput.getUserAction();
			int userId = ingestionInput.getUserId();

			Upject upject = new Upject();

			upject.setReqId(reqId);
			upject.setStepId(stepId);
			upject.setWorkflowId(workflowId);
			upject.setStatus(userAction);
			
			if(null != ingestionInput.getRemarks() ) {
			upject.setRemarks(ingestionInput.getRemarks());
			} else {
				upject.setRemarks("");
			}
			upject.setUserId(userId);

			if ("APPROVED".equalsIgnoreCase(userAction)) {

				try {
					wfrsi.workflowApprove(upject, null);
					logger.info("in Workflow Approve");

				} catch (Exception e) {

					logger.info("Exception in workflowApprove" + e);
				}

			} else if ("REJECTED".equalsIgnoreCase(userAction)) {

				try {
					wfrsi.workflowReject(upject, null);

					logger.info("in Workflow Reject");
				} catch (Exception e) {
					

					logger.info("Exception in workflowReject" + e);
				}

			} else if ("CANCEL".equalsIgnoreCase(userAction)) {

				try {

					HashMap<String, String> cancelMap = new HashMap<String, String>();

					cancelMap.put("reqId", String.valueOf(upject.getReqId()));
					cancelMap.put("stepId", upject.getStepId());
					cancelMap.put("status", upject.getStatus());
					cancelMap.put("remarks", upject.getRemarks());
					cancelMap.put("userId", String.valueOf(upject.getUserId()));
					cancelMap.put("workflowType", ingestionInput.getWorkflowType());

					mrServiceImpl.cancelRequest(cancelMap);

					logger.info("in Workflow Cancel");
				} catch (Exception e) {

					logger.info("Exception in workflow Cancelled" + e.getMessage());
				}

			}

		} else {

			logger.info("respone is not OK");

		}
		if(res== null) {
		isaResponse.setStatusCode(HttpStatus.OK.value());
		isaResponse.setStatus("Success");
		isaResponse.setResponse("Workflow UPDATE/APPROVE is SUCCESS");
		} else {
			isaResponse=res;
		}
		logger.info("EXIT IngestionDynamicImpl::saveIngestionResp");

		return isaResponse;
	}

	
}
