package com.scb.selfservice.model.RangerPolicy;

import java.util.List;

public class PolicyDetailsResp {
	
	private int totalCount;
	private int resultSize;
	private List<PolicyResp> vXPolicies;
	
	/**
	 * 
	 */
	public PolicyDetailsResp() {
		super();
	}

	/**
	 * @param totalCount
	 * @param resultSize
	 * @param vXPolicies
	 */
	public PolicyDetailsResp(int totalCount, int resultSize, List<PolicyResp> vXPolicies) {
		super();
		this.totalCount = totalCount;
		this.resultSize = resultSize;
		this.vXPolicies = vXPolicies;
	}

	/**
	 * @return the totalCount
	 */
	public int getTotalCount() {
		return totalCount;
	}

	/**
	 * @param totalCount the totalCount to set
	 */
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	/**
	 * @return the resultSize
	 */
	public int getResultSize() {
		return resultSize;
	}

	/**
	 * @param resultSize the resultSize to set
	 */
	public void setResultSize(int resultSize) {
		this.resultSize = resultSize;
	}

	/**
	 * @return the vXPolicies
	 */
	public List<PolicyResp> getvXPolicies() {
		return vXPolicies;
	}

	/**
	 * @param vXPolicies the vXPolicies to set
	 */
	public void setvXPolicies(List<PolicyResp> vXPolicies) {
		this.vXPolicies = vXPolicies;
	}

	@Override
	public String toString() {
		return "PolicyDetailsResp [totalCount=" + totalCount + ", resultSize=" + resultSize + ", vXPolicies="
				+ vXPolicies + "]";
	}
	
}
