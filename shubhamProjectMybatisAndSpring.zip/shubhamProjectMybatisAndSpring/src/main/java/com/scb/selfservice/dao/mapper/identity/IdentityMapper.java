/**
 * 
 */
package com.scb.selfservice.dao.mapper.identity;

import java.util.HashMap;
import java.util.Map;

import com.scb.selfservice.model.UserDetails;

/**
 * @author 1565003
 *
 */
public interface IdentityMapper {
	
	/**
	 * Method to insert into User Login Details
	 * @param userLoginDetails
	 */
	public void insertUserLoginDetails(HashMap<String, String> userLoginDetails);
	
	/**
	 * Method to get User Details of the login User
	 * @param userId
	 * @return
	 */
	public UserDetails getUserDetails(String userId);
	
	/**
	 * Method to createUser in the System after successful login
	 * @param details
	 */
	public void createUserDetails(UserDetails details);
	
	/**
	 * Method to get UsetLastLoginDetails
	 * @param userId
	 * @return
	 */
	public Map<String,String> getUserLastLoginDetails(String userId);

}
