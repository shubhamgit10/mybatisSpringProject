package com.scb.selfservice.web.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.model.CostEstimationRequest;
import com.scb.selfservice.service.CostEstimationSummaryService;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;
import com.scb.selfservice.web.authentication.UserPrincipal;

/**
 * 
 * @author shubhasi
 *
 */
@RestController
@RequestMapping("api/estimate")
public class CostEstimationSummaryController {
	private static Logger logger = LogManager.getLogger(CostEstimationSummaryController.class);

	@Autowired
	private CostEstimationSummaryService estimateService;

	@RequestMapping(path = "/cost", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response getEstimatedCost(@RequestBody CostEstimationRequest costEstimationRequest) {
		logger.info("STARTED CostEstimationSummaryController:: getEstimatedCost");
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response costResponse = new Response();

		try {
			if (loggedInUser != null) {
				Integer userId = Integer.valueOf(loggedInUser.getUserId());
				logger.info("Cost estimation request ::" + costEstimationRequest);
				costResponse = estimateService.getEstimatedCost(costEstimationRequest, userId);
			} else {
				costResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
				costResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
			}
		} catch (Exception e) {
			costResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			costResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
			logger.error("Exception in CostEstimationSummaryController:: getEstimatedCost" + e.getMessage());
		}

		return costResponse;
	}

	/*
	 * @GetMapping(path = "/estimatedCost/{estimationId}", produces =
	 * MediaType.APPLICATION_JSON_VALUE) public ResponseEntity<Response>
	 * readEstimatedCost(@PathVariable("estimationId") Integer estimationId) {
	 * UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
	 * Response saveCostResponse = new Response(); if (loggedInUser != null) {
	 * saveCostResponse = estimateService.readEstimatedCost(estimationId); } else {
	 * saveCostResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
	 * saveCostResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value()); } return new
	 * ResponseEntity<Response>(saveCostResponse, HttpStatus.OK); }
	 */
	@GetMapping(path = "/estimatedCost/{estimationId}/{workflowType}/{stepId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getEstimatedCostFromDb(@PathVariable("estimationId") Integer estimationId,
			@PathVariable("workflowType") String workflowType, @PathVariable("stepId") String stepId) {
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response getEstimatedCostById = new Response();
		if (loggedInUser != null) {
			getEstimatedCostById = estimateService.getEstimatedCostFromDb(estimationId, workflowType, stepId);
		} else {
			getEstimatedCostById.setStatus(HttpStatus.UNAUTHORIZED.toString());
			getEstimatedCostById.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
		return new ResponseEntity<Response>(getEstimatedCostById, HttpStatus.OK);
	}
}