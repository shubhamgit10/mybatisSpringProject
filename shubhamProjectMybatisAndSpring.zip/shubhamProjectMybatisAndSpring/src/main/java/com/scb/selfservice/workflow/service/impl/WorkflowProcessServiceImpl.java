package com.scb.selfservice.workflow.service.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.WorkflowMapper;
import com.scb.selfservice.domains.WorkflowProcess;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.workflow.service.WorkflowProcessService;

/*
 * service for pulling all the possible workflow process available
 */

@Service
public class WorkflowProcessServiceImpl implements WorkflowProcessService {

	private static Logger logger = LogManager.getLogger(WorkflowProcessServiceImpl.class);

	@Autowired
	WorkflowMapper workflowMapper;

	@Override
	@Transactional
	//public List<WorkflowProcess> getWorkflowProcessDetails() {
	public Response getWorkflowProcessDetails() {

		logger.info("STARTED WorkflowProcessServiceImpl::getWorkflowProcesses");
		Response response = new Response();
		try {
		List<WorkflowProcess> wfProcsList = workflowMapper.getWorkflowProcessDetails();
		if (wfProcsList.isEmpty()) {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
        } else {
        	logger.info("There are: [" + wfProcsList.size() + "] records.");
        	response.setStatusCode(HttpStatus.OK.value());
        	response.setStatus("Success");
        	response.setResponse(wfProcsList);
        }
		}catch (Exception e) {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
		}
		logger.info("EXITING WorkflowProcessServiceImpl::getWorkflowProcesses");

		return response;
	}

	@Override
	@Transactional
	public WorkflowProcess getWorkflowProcessDetailById(Integer workflowId) {
		logger.info("STARTED WorkflowProcessServiceImpl::getWorkflowProcessDetail");
		
		WorkflowProcess workflowProcess = workflowMapper.getWorkflowProcessDetailById(workflowId);
		
		logger.info("EXITING WorkflowProcessServiceImpl::getWorkflowProcessDetail");

		return workflowProcess;
	}
}
