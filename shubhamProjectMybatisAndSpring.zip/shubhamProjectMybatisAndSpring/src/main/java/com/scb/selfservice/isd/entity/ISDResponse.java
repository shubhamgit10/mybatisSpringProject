package com.scb.selfservice.isd.entity;

import java.util.List;

/**
 * @author akuma400
 *
 */
public class ISDResponse {

	private List<ISDVerificationStatus> listIsdVarificationStatus;
	private List<ISDSummary> isdSummary;
	public List<ISDVerificationStatus> getListIsdVarificationStatus() {
		return listIsdVarificationStatus;
	}
	public void setListIsdVarificationStatus(List<ISDVerificationStatus> listIsdVarificationStatus) {
		this.listIsdVarificationStatus = listIsdVarificationStatus;
	}
	public List<ISDSummary> getIsdSummary() {
		return isdSummary;
	}
	public void setIsdSummary(List<ISDSummary> isdSummary) {
		this.isdSummary = isdSummary;
	}
	@Override
	public String toString() {
		return "ISDResponse [listIsdVarificationStatus=" + listIsdVarificationStatus + ", isdSummary=" + isdSummary
				+ "]";
	}
	
	

	
	
}
