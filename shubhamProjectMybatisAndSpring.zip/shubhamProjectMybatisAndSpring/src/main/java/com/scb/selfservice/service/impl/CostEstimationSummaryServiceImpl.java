
package com.scb.selfservice.service.impl;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.WorkflowMapper;
import com.scb.selfservice.dao.mapper.ingestion.CostEstimationSummaryMapper;
import com.scb.selfservice.domains.WorkflowIdType;
import com.scb.selfservice.model.CostEstimation;
import com.scb.selfservice.model.CostEstimationRequest;
import com.scb.selfservice.model.CostEstimationSummary;
import com.scb.selfservice.model.CostEstimationTemplate;
import com.scb.selfservice.service.CostEstimationSummaryService;
import com.scb.selfservice.util.CommonUtils;
import com.scb.selfservice.util.Response;

/**
 * 
 * @author shubhasi
 * 
 *         Implementation class of logic to calculate cost estimation summary
 */
@Service
public class CostEstimationSummaryServiceImpl implements CostEstimationSummaryService {

	private static Logger logger = LogManager.getLogger(CostEstimationSummaryServiceImpl.class);
	@Autowired
	CostEstimationSummaryMapper estimateMapper;
	@Autowired
	private WorkflowMapper workflowMapper;

	@Override
	@Transactional
	public Response getEstimatedCost(CostEstimationRequest costEstimationRequest, int userId) {
		logger.info("Calculating the effort estimated cost :: getEstimatedCost()");
		CostEstimation writeCostEstimation = new CostEstimation();
		CostEstimationTemplate costTemplate = searchCostTemplate(costEstimationRequest, userId);
		Response costResponse = new Response();
		CostEstimationSummary costMetaData = new CostEstimationSummary();

		if (costTemplate == null) {
			costResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			costResponse.setStatus(HttpStatus.NO_CONTENT.toString());
		} else {
			logger.info("Fetched cost template from the db :: searchCostTemplate()");
		
			CostEstimationTemplate ct = costTemplate;
			ByteArrayInputStream bis = new ByteArrayInputStream(ct.getEffortSheet());
			try {
				XSSFWorkbook workbook = new XSSFWorkbook(bis);
				logger.info("source type" + costEstimationRequest.getSourceType());
				if ("New Sourcing".equalsIgnoreCase(costEstimationRequest.getSourceType())) {
					XSSFSheet sheetForNewSourcing = workbook.getSheet("Effort Estimation");
					XSSFSheet sheetForStorageDetail = workbook.getSheet("Storage Detail");

					sheetForNewSourcing.setForceFormulaRecalculation(true);
					sheetForStorageDetail.setForceFormulaRecalculation(true);
					// **** setting excel input values for new sourcing type ***//
					logger.info("Setting the input  as per the request " + costEstimationRequest);
					if (costEstimationRequest.getSourceName() != null
							&& !"".equals(costEstimationRequest.getSourceName()))
						sheetForNewSourcing.getRow(1).getCell(2).setCellValue(costEstimationRequest.getSourceName());
					if (costEstimationRequest.getInstances() != null
							&& !"".equals(costEstimationRequest.getInstances()))
						sheetForNewSourcing.getRow(2).getCell(2).setCellValue(costEstimationRequest.getInstances());
					if (costEstimationRequest.getSourcingType() != null
							&& !"".equals(costEstimationRequest.getSourcingType()))
						sheetForNewSourcing.getRow(3).getCell(2).setCellValue(costEstimationRequest.getSourcingType());
					if (costEstimationRequest.getNumberOfInstances() != null
							&& costEstimationRequest.getNumberOfInstances().size() > 0)
						sheetForNewSourcing.getRow(4).getCell(2)
								.setCellValue(costEstimationRequest.getNumberOfInstances().size());
					if (costEstimationRequest.getNumberOfTables() > 0)
						sheetForNewSourcing.getRow(5).getCell(2)
								.setCellValue(costEstimationRequest.getNumberOfTables());
					if (costEstimationRequest.getNumberOfColumnsAccrossTable() > 0)
						sheetForNewSourcing.getRow(6).getCell(2)
								.setCellValue(costEstimationRequest.getNumberOfColumnsAccrossTable());
					if (costEstimationRequest.getSourceDataSystem() != null
							&& !"".equals(costEstimationRequest.getSourceDataSystem()))
						sheetForNewSourcing.getRow(8).getCell(2)
								.setCellValue(costEstimationRequest.getSourceDataSystem());
					if (costEstimationRequest.getFileFormat() != null
							&& !"".equals(costEstimationRequest.getFileFormat()))
						sheetForNewSourcing.getRow(9).getCell(2).setCellValue(costEstimationRequest.getFileFormat());
					if (costEstimationRequest.getDownstreamOlaRequired() != null
							&& !"".equals(costEstimationRequest.getDownstreamOlaRequired()))
						sheetForNewSourcing.getRow(10).getCell(2)
								.setCellValue(costEstimationRequest.getDownstreamOlaRequired());
					if (costEstimationRequest.getNewTransformationRulesRequired() != null
							&& !"".equals(costEstimationRequest.getNewTransformationRulesRequired()))
						sheetForNewSourcing.getRow(11).getCell(2)
								.setCellValue(costEstimationRequest.getNewTransformationRulesRequired());
					if (costEstimationRequest.getLevelOfFrameworkCustomizationRequired() != null
							&& !"".equals(costEstimationRequest.getLevelOfFrameworkCustomizationRequired()))
						sheetForNewSourcing.getRow(12).getCell(2)
								.setCellValue(costEstimationRequest.getLevelOfFrameworkCustomizationRequired());
					if (costEstimationRequest.getSourceSystemCommunication() != null
							&& !"".equals(costEstimationRequest.getSourceSystemCommunication()))
						sheetForNewSourcing.getRow(13).getCell(2)
								.setCellValue(costEstimationRequest.getSourceSystemCommunication());
					if (costEstimationRequest.getPlannedGoLiveMonth() != null
							&& !"".equals(costEstimationRequest.getPlannedGoLiveMonth()))
						sheetForNewSourcing.getRow(14).getCell(2)
								.setCellValue(convertDateToMonth(costEstimationRequest.getPlannedGoLiveMonth()));

					logger.info("Conversion of MB to GB");
					if (costEstimationRequest.getHistoryData() > 0 && costEstimationRequest.getHistoryData()!=0
							&& "MB".equalsIgnoreCase(costEstimationRequest.getHistoryStorageType())) {
						sheetForStorageDetail.getRow(7).getCell(14)
								.setCellValue(costEstimationRequest.getHistoryData() / 1024.0);
					} else if (costEstimationRequest.getHistoryData()!=0){
						sheetForStorageDetail.getRow(7).getCell(14)
								.setCellValue(costEstimationRequest.getHistoryData());
					}
					if (costEstimationRequest.getIncrementalData() > 0 && costEstimationRequest.getIncrementalData()!=0
							&& "MB".equalsIgnoreCase(costEstimationRequest.getIncrementalStorageType())) {
						sheetForStorageDetail.getRow(7).getCell(15)
								.setCellValue(costEstimationRequest.getIncrementalData() / 1024.0);
					} else if (costEstimationRequest.getIncrementalData()!=0){
						sheetForStorageDetail.getRow(7).getCell(15)
								.setCellValue(costEstimationRequest.getIncrementalData());
					}
					double o8 = sheetForStorageDetail.getRow(7).getCell(14).getNumericCellValue();
					double dayOneData = sheetForStorageDetail.getRow(7).getCell(15).getNumericCellValue();

					logger.info("Raw Data on Day-0 =" + o8);
					logger.info("Raw Data on Day-1 =" + dayOneData);
					logger.info("One day processing size  "
							+ sheetForStorageDetail.getRow(7).getCell(16).getNumericCellValue());
					double maxDataSize = o8 + dayOneData;
					logger.info("One day processing size set to " + maxDataSize);
					logger.info("Cell value for input fields has been set as per request ::" + costEstimationRequest);
					List<CostEstimationSummary> costSourcce = new ArrayList<CostEstimationSummary>();
					XSSFFormulaEvaluator.evaluateAllFormulaCells(workbook);
					logger.info("<-- Started evaluating/calculating the cost for new sourcing -->");
					costMetaData.setPersonDaysCost(CommonUtils
							.setDecimalPrecision(sheetForNewSourcing.getRow(17).getCell(5).getNumericCellValue(), ""));
					costMetaData.setInfraNASCost(CommonUtils
							.setDecimalPrecision(sheetForNewSourcing.getRow(18).getCell(6).getNumericCellValue(), ""));
					costMetaData.setInfraHAASCost(CommonUtils
							.setDecimalPrecision(sheetForNewSourcing.getRow(19).getCell(6).getNumericCellValue(), ""));
					costMetaData.setNifiAllocationCost(CommonUtils
							.setDecimalPrecision(sheetForNewSourcing.getRow(20).getCell(6).getNumericCellValue(), ""));
					costMetaData.setiMFTMaintenanceCost(CommonUtils
							.setDecimalPrecision(sheetForNewSourcing.getRow(21).getCell(6).getNumericCellValue(), ""));
					costMetaData.setDevelopmentSITRegression(CommonUtils
							.setDecimalPrecision(sheetForNewSourcing.getRow(22).getCell(5).getNumericCellValue(), ""));
					costMetaData.setSourceSystemCosting(CommonUtils
							.setDecimalPrecision(sheetForNewSourcing.getRow(24).getCell(5).getNumericCellValue(), ""));
					costMetaData.setTotalDownstreamCosting(CommonUtils.setDecimalPrecision(0, ""));
					costMetaData.setOtherCosts(CommonUtils
							.setDecimalPrecision(sheetForNewSourcing.getRow(25).getCell(5).getNumericCellValue(), ""));
					costMetaData.setEstimatedCost(CommonUtils
							.setDecimalPrecision(sheetForNewSourcing.getRow(27).getCell(5).getNumericCellValue(), ""));
					costSourcce.add(costMetaData);
				} else {
					XSSFSheet sheetForIncremental = workbook.getSheet("Effort Estimation");
					sheetForIncremental.setForceFormulaRecalculation(true);

					logger.info("instance= " + costEstimationRequest.getSourceSystemCommunication());
					if (costEstimationRequest.getSourceName() != null
							&& !"".equals(costEstimationRequest.getSourceName()))
						sheetForIncremental.getRow(1).getCell(2).setCellValue(costEstimationRequest.getSourceName());
					logger.info("instance= " + sheetForIncremental.getRow(2).getCell(2).getRawValue());
					if (costEstimationRequest.getInstances() != null
							&& !"".equals(costEstimationRequest.getInstances()))
						sheetForIncremental.getRow(2).getCell(2).setCellValue(costEstimationRequest.getInstances());
					if (costEstimationRequest.getSourcingType() != null
							&& !"".equals(costEstimationRequest.getSourcingType()))
						sheetForIncremental.getRow(3).getCell(2).setCellValue(costEstimationRequest.getSourcingType());
					if (costEstimationRequest.getNumberOfInstances() != null
							&& costEstimationRequest.getNumberOfInstances().size() > 0)
						sheetForIncremental.getRow(4).getCell(2)
								.setCellValue(costEstimationRequest.getNumberOfInstances().size());
					logger.info("test no instance" + costEstimationRequest.getNumberOfTables());
					if (costEstimationRequest.getNumberOfTables() > 0)
						sheetForIncremental.getRow(5).getCell(2)
								.setCellValue(costEstimationRequest.getNumberOfTables());
					logger.info("test no columns" + costEstimationRequest.getNumberOfColumnsAccrossTable());
					if (costEstimationRequest.getNumberOfColumnsAccrossTable() > 0)
						sheetForIncremental.getRow(6).getCell(2)
								.setCellValue(costEstimationRequest.getNumberOfColumnsAccrossTable());
					if (costEstimationRequest.getSourceDataSystem() != null
							&& !"".equals(costEstimationRequest.getSourceDataSystem()))
						sheetForIncremental.getRow(8).getCell(2)
								.setCellValue(costEstimationRequest.getSourceDataSystem());
					if (costEstimationRequest.getFileFormat() != null
							&& !"".equals(costEstimationRequest.getFileFormat()))
						sheetForIncremental.getRow(9).getCell(2).setCellValue(costEstimationRequest.getFileFormat());
					if (costEstimationRequest.getSourceSystemCommunication() != null
							&& !"".equals(costEstimationRequest.getSourceSystemCommunication()))
						sheetForIncremental.getRow(10).getCell(2)
								.setCellValue(costEstimationRequest.getSourceSystemCommunication());
					if (costEstimationRequest.getPlannedGoLiveMonth() != null
							&& !"".equals(costEstimationRequest.getPlannedGoLiveMonth())) {
						sheetForIncremental.getRow(11).getCell(2)
								.setCellValue(convertDateToMonth(costEstimationRequest.getPlannedGoLiveMonth()));
					}
					// ** Setting the value for Infra NAS Cost,Infra HAAS Cost, Nifi allocation Cost
					// and IMFT Maintenance Cost to No **//
					logger.info(
							"Setting Cell value for Infra NAS Cost,Infra HAAS Cost, Nifi allocation Cost and IMFT Maintenance Cost set to default value NO");

					sheetForIncremental.getRow(15).getCell(5).setCellValue("No");
					sheetForIncremental.getRow(16).getCell(5).setCellValue("No");
					sheetForIncremental.getRow(17).getCell(5).setCellValue("No");
					sheetForIncremental.getRow(19).getCell(5).setCellValue("No");

					List<CostEstimationSummary> costSourcce = new ArrayList<CostEstimationSummary>();
					XSSFFormulaEvaluator.evaluateAllFormulaCells(workbook);
					logger.info("<-- Started evaluating/calculating the cost for incremental sourcing -->");
					costMetaData.setPersonDaysCost(CommonUtils
							.setDecimalPrecision(sheetForIncremental.getRow(14).getCell(5).getNumericCellValue(), ""));
					costMetaData.setInfraNASCost(CommonUtils
							.setDecimalPrecision(sheetForIncremental.getRow(15).getCell(6).getNumericCellValue(), ""));
					costMetaData.setInfraHAASCost(CommonUtils
							.setDecimalPrecision(sheetForIncremental.getRow(16).getCell(6).getNumericCellValue(), ""));
					costMetaData.setNifiAllocationCost(CommonUtils
							.setDecimalPrecision(sheetForIncremental.getRow(17).getCell(6).getNumericCellValue(), ""));
					costMetaData.setiMFTMaintenanceCost(CommonUtils
							.setDecimalPrecision(sheetForIncremental.getRow(18).getCell(6).getNumericCellValue(), ""));
					costMetaData.setDevelopmentSITRegression(CommonUtils
							.setDecimalPrecision(sheetForIncremental.getRow(19).getCell(5).getNumericCellValue(), ""));
					costMetaData.setSourceSystemCosting(CommonUtils
							.setDecimalPrecision(sheetForIncremental.getRow(21).getCell(5).getNumericCellValue(), ""));
					costMetaData.setTotalDownstreamCosting(CommonUtils
							.setDecimalPrecision(sheetForIncremental.getRow(22).getCell(5).getNumericCellValue(), ""));
					costMetaData.setOtherCosts(CommonUtils
							.setDecimalPrecision(sheetForIncremental.getRow(23).getCell(5).getNumericCellValue(), ""));
					costMetaData.setEstimatedCost(CommonUtils
							.setDecimalPrecision(sheetForIncremental.getRow(25).getCell(5).getNumericCellValue(), ""));
					costSourcce.add(costMetaData);

				}

				// **** evaluating and getting values from excel ***//
				// save method for saving workbook
				logger.info("write and save the cost copy to the db table :: cloneCostTemplate");
				ByteArrayOutputStream baos = new ByteArrayOutputStream();

				workbook.write(baos);
				byte cloneCostTemplate[] = baos.toByteArray();
				logger.info("Est Id :: -->" + costTemplate.getEstimationId());
				if (costTemplate.getEstimationId() != null && costTemplate.getEstimationId() > 0) {
					writeCostEstimation.setEstimationId(costTemplate.getEstimationId());
				} else {
					writeCostEstimation.setEstimationId(0);
				}
				writeCostEstimation.setCreatedBy(userId);

				writeCostEstimation.setCostEstimationCopy(cloneCostTemplate);
				writeCostEstimation.setReqId(costEstimationRequest.getReqId());
				writeCostEstimation.setStatus("");
				writeCostEstimation.setSourceType(costEstimationRequest.getSourceType());
				writeCostEstimation.setPersonDaysCost(costMetaData.getPersonDaysCost());
				writeCostEstimation.setInfraNASCost(costMetaData.getInfraNASCost());
				writeCostEstimation.setInfraHAASCost(costMetaData.getInfraHAASCost());
				writeCostEstimation.setNifiAllocationCost(costMetaData.getNifiAllocationCost());
				writeCostEstimation.setiMFTMaintenanceCost(costMetaData.getiMFTMaintenanceCost());
				writeCostEstimation.setDevelopmentSITRegression(costMetaData.getDevelopmentSITRegression());
				writeCostEstimation.setSourceSystemCosting(costMetaData.getSourceSystemCosting());
				writeCostEstimation.setTotalDownstreamCosting(costMetaData.getTotalDownstreamCosting());
				writeCostEstimation.setOtherCosts(costMetaData.getOtherCosts());
				writeCostEstimation.setEstimatedCost(costMetaData.getEstimatedCost());
				Response insertIntoDb = insertEstimatedCostCopy(writeCostEstimation);
				Response insertIntoDb2 = insertAndUpdateEstimatedCostToDb(writeCostEstimation,
						costEstimationRequest.getWorkflowType(), costEstimationRequest.getStepId());
				System.out.println("estid  " + writeCostEstimation.getEstimationId());
				costMetaData.setEstimationId(writeCostEstimation.getEstimationId());

				costResponse.setStatusCode(HttpStatus.OK.value());
				costResponse.setStatus("Success");
				costResponse.setResponse(costMetaData);

				bis.close();
				baos.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return costResponse;
	}

	private CostEstimationTemplate searchCostTemplate(CostEstimationRequest costEstimationRequest, int userId) {
		logger.info(
				"Started searchCostTemplate method to find the cost template as per reqId and userId  :: searchCostTemplate()");

		CostEstimation costTemplateById = null;
		List<CostEstimationTemplate> costTemplate = null;
		CostEstimationTemplate returnVal = null;
		if (costEstimationRequest.getEstimationId() == 0) {
			costTemplateById = estimateMapper.searchTemplate(userId, costEstimationRequest.getSourceType(),
					costEstimationRequest.getEstimationId());

		} else {
			costTemplateById = estimateMapper.searchByRequestId(costEstimationRequest.getEstimationId(),
					costEstimationRequest.getSourceType());
//			costTemplateById.setEstimationId(costEstimationRequest.getEstimationId());

		}
		logger.info("Get cost template by id::" + costTemplateById);
		if (costTemplateById == null) {
//		 costTemplate = estimateMapper.getEstimatedCost(1);
			logger.info("source type " + costEstimationRequest.getSourceType());

			costTemplate = estimateMapper.getTemplateBySourceType(costEstimationRequest.getSourceType());
			try {
				returnVal = costTemplate.get(0);
				returnVal.setEstimationId(costEstimationRequest.getEstimationId());

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else {
			returnVal = new CostEstimationTemplate();
			returnVal.setEstimationId(costTemplateById.getEstimationId());
			returnVal.setEffortSheet(costTemplateById.getCostEstimationCopy());
		}
		logger.info("Return value for cost  -->>" + returnVal.toString());
		return returnVal;

	}

	public Response insertEstimatedCostCopy(CostEstimation costEstimation) {

		logger.info("START ::insertEstimatedCostCopy");
		Response retResponse = new Response();
		if (costEstimation.getEstimationId() == 0) {
			logger.info("START it is a new entry for new request..." + costEstimation.getEstimationId());
			int saveStatus = estimateMapper.insertEstimatedCostCopy(costEstimation);
			retResponse = getActionStatus("insert/save", saveStatus, costEstimation.getEstimationId());
			logger.info("EXIT save request");
			logger.info("Sucessfully Inserted into edmp estimation request table -->");

		} else {
			logger.info("START it an existing request for estimationId :: " + costEstimation.getEstimationId());
			int updateStatus = estimateMapper.updateEstimatedCostCopy(costEstimation);
			retResponse = getActionStatus("update", updateStatus, costEstimation.getEstimationId());
			logger.info("EXIT update request, data saved to EDMP_ESTIMATON_REQ");
		}
		return retResponse;

	}

	public Response insertAndUpdateEstimatedCostToDb(CostEstimation costEstimation, String workflowType,
			String stepId) {
		WorkflowIdType workflowIdType = new WorkflowIdType();
		logger.info("START ::insertEstimatedCostToDb");
		logger.info(workflowType + ":::" + stepId);
		Response ret1Response = new Response();
		workflowIdType = workflowMapper.getWorkflowId(workflowType);
		Integer workflowId = workflowIdType.getWorkflowId();
		CostEstimationSummary getCostSummary = estimateMapper.getEstimatedCostFromDb(costEstimation.getEstimationId(),
				workflowId, stepId);
		System.out.println("total cost =" + getCostSummary);
		if (getCostSummary == null) {
			logger.info("START it is a new entry for new request..." + costEstimation.getEstimationId());
			int saveStatus = estimateMapper.insertEstimatedCostToDb(costEstimation, workflowId, stepId);
			ret1Response = getActionStatus("insert/save", saveStatus, costEstimation.getEstimationId());
			logger.info("EXIT saving the request");
			logger.info("Sucessfully Inserted into edmp estimation request details table -->");

		} else {
			logger.info("START it an existing request for estimationId :: " + costEstimation.getEstimationId());
			int updateStatus = estimateMapper.updateEstimatedCostToDb(costEstimation, workflowId, stepId);
			ret1Response = getActionStatus("update", updateStatus, costEstimation.getEstimationId());
			logger.info("EXIT update request, data saved to EDMP_ESTIMATON_REQ_DETAILS");
		}
		return ret1Response;

	}

	private Response getActionStatus(String type, int saveStatus, int estimationId) {
		logger.info("<--Getting status of saving cost template in db-->");
		{
			Response response = new Response();
			if (saveStatus == 1) {
				response.setResponse(estimationId + "estimation id " + (type.equals("save") ? "INSERTED" : "UPDATED"));
			} else {
				response.setResponse("!!!Action not taken!!!");
			}
			return response;
		}
	}

	@Override
	public Response readEstimatedCost(Integer estimationId) {
		logger.info("<--Getting cost estimation response as per estimatonid ::" + estimationId);

		Response saveCostEstimate = new Response();
		if (!estimationId.equals(0)) {
			saveCostEstimate.setStatusCode(HttpStatus.OK.value());
			saveCostEstimate.setStatus("Success");
			saveCostEstimate.setResponse(estimateMapper.readEstimatedCost(estimationId));
		} else {
			saveCostEstimate.setResponse("No Content!! please pass valid estimationId");
		}
		return saveCostEstimate;

	}

	public String convertDateToMonth(String date) throws ParseException {
		HashMap<Integer, String> monthValue = new HashMap<>();

		monthValue.put(1, "01-January");
		monthValue.put(2, "02-February");
		monthValue.put(3, "03-March");
		monthValue.put(4, "04-April");
		monthValue.put(5, "05-May");
		monthValue.put(6, "06-June");
		monthValue.put(7, "07-July");
		monthValue.put(8, "08-August");
		monthValue.put(9, "09-September");
		monthValue.put(10, "10-October");
		monthValue.put(11, "11-November");
		monthValue.put(12, "12-December");

		LocalDate ld = LocalDate.parse(date);
		String resValue = monthValue.get(ld.getMonthValue());
		return resValue;
	}

	@Override
	public Response getEstimatedCostFromDb(Integer estimationId, String workflowType, String stepId) {
		logger.info("<--Getting cost estimation response as per estimatonid ::" + estimationId);
		Response getCostEstimatefromdb = new Response();
		WorkflowIdType workflowIdType = new WorkflowIdType();
		logger.info("START ::insertEstimatedCostToDb");
		workflowIdType = workflowMapper.getWorkflowId(workflowType);
		Integer workflowId = workflowIdType.getWorkflowId();
		if (!estimationId.equals(0)) {
			CostEstimationSummary estimatedCostFromDb=estimateMapper.getEstimatedCostFromDb(estimationId, workflowId, stepId);
        if(estimatedCostFromDb ==null) {
	    estimatedCostFromDb=estimateMapper.getEstimatedCostFromDbById(estimationId);
        }
			getCostEstimatefromdb.setStatusCode(HttpStatus.OK.value());
			getCostEstimatefromdb.setStatus("Success");
			getCostEstimatefromdb.setResponse(estimatedCostFromDb);
		} else {
			getCostEstimatefromdb.setStatusCode(HttpStatus.NO_CONTENT.value());
			getCostEstimatefromdb.setStatus("Failed");
			getCostEstimatefromdb.setResponse("No Content!! please pass valid estimationId");
		}
		return getCostEstimatefromdb;
	}
}
