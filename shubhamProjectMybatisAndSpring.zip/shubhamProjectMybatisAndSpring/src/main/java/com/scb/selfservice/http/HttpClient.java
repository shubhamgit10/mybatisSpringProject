package com.scb.selfservice.http;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.PasswordAuthentication;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.codec.binary.Base64;

import com.google.gson.Gson;
import com.scb.selfservice.model.ServerResponse;
import com.scb.selfservice.model.RangerPolicy.PolicyDetailsResp;
import com.scb.selfservice.model.RangerPolicy.PolicyResp;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyV2ReqModel;

/**
 * 
 * @author 1610601
 *
 */
public class HttpClient {

    private final String user;
    private final String password;
    
    /**
	 * 
	 */
	public HttpClient() {
		this.user = null;
		this.password = null;
	}

	public HttpClient(String user, String password) {
        this.user = user;
        this.password = password;
    }

    public ServerResponse sendRequestWithAuthHeader(String url, String requestMethod, 
    		String jsonStr, String cookie) throws IOException, ProtocolException, MalformedURLException {
        HttpURLConnection connection = null;
        BufferedReader reader = null;
        StringBuilder sb = null;
        try {
            connection = createConnection(url, requestMethod, jsonStr, cookie);
//            connection.setRequestProperty("Cookie", cookie);
//            connection.setRequestProperty("Authorization", createBasicAuthHeaderValue());
//            connection.setReadTimeout(100000);
            connection.connect();
            System.out.println("Connection details : " +connection.toString());
            int statusCode = connection.getResponseCode();
            String statusMsg = connection.getResponseMessage();
            if(statusCode >= 400) {
            	sb = new StringBuilder();
            	reader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
            	String str = reader.readLine();
            	while(str != null) {
            		sb.append(str).append("/n");
            	}
            	System.out.println("Error Stream : " +sb.toString());
            }
            ServerResponse resp = new ServerResponse(statusCode, statusMsg);
            if(null != connection.getInputStream()) {
            	reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            	resp.setDataReader(reader);
            }
            System.out.println("sendRequestWithAuthHeader response :::: " +resp);
            return resp;
        } catch(Exception e) {
        	System.out.println("Error while executing the request : " +e.getMessage());
        	e.printStackTrace(); 
        	throw e;
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
            if(reader != null) {
            	try {
            		reader.close();
            	} catch(IOException e) {
            		e.printStackTrace();
            	}
            }
        }
    }

//    public ServerResponse sendRquestWithAuthenticator(String url, String requestMethod, 
//    		String jsonStr, Long policyId) throws IOException {
//        setAuthenticator();
//
//        HttpURLConnection connection = null;
//        try {
//            connection = createConnection(url, requestMethod, jsonStr);
//            connection.setReadTimeout(10000);
//            connection.connect();
//            ServerResponse resp = new ServerResponse(connection.getResponseCode(), connection.getResponseMessage());
//            return resp;
//        } finally {
//            if (connection != null) {
//                connection.disconnect();
//            }
//        }
//    }

    private HttpURLConnection createConnection(String urlString, String requestMethod, 
    		String jsonStr, String cookie) throws MalformedURLException, IOException, ProtocolException {
        URL url = new URL(String.format(urlString));
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        
//        return setHttpRequestMethod(requestMethod, connection, jsonStr);
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("content-type", "*/*");
        connection.setRequestProperty("Authorization", createBasicAuthHeaderValue());
        connection.setReadTimeout(10000);
        connection.setDoOutput(true);
        if(cookie != null) {
        	connection.setRequestProperty("Cookie", cookie);
        }
        switch(requestMethod.toUpperCase()) {
		case "GET" : 
			connection.setRequestMethod("GET");
			connection.setDoOutput(false);
			break;
		case "POST" : 
			connection.setRequestMethod("POST");
//			connection.setDoInput(true);
			connection.setRequestProperty("content-type", "application/json");
			if(null != jsonStr) {
//				connection.setDoOutput(true);
				try(OutputStream os = connection.getOutputStream()){
					byte[] input = jsonStr.getBytes("utf-8");
					os.write(input, 0, input.length);			
				}
			}
			break;
		case "PUT" : 
			connection.setRequestMethod("PUT");
//			connection.setDoInput(true);
			connection.setRequestProperty("content-type", "application/json");
			if(null != jsonStr) {
//				connection.setDoOutput(true);
				try(OutputStream os = connection.getOutputStream()){
					byte[] input = jsonStr.getBytes("utf-8");
					os.write(input, 0, input.length);			
				}
			}
			break;
		case "DELETE" : 
			connection.setRequestMethod("DELETE");
			connection.setDoOutput(false);
			break;
		}
        
        return connection;
    }

    private String createBasicAuthHeaderValue() {
        String auth = user + ":" + password;
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.UTF_8));
        String authHeaderValue = "Basic " + new String(encodedAuth);
        return authHeaderValue;
    }

//    private void setAuthenticator() {
//        Authenticator.setDefault(new BasicAuthenticator());
//    }
//
//    private final class BasicAuthenticator extends Authenticator {
//        protected PasswordAuthentication getPasswordAuthentication() {
//            return new PasswordAuthentication(user, password.toCharArray());
//        }
//    }
    
//    private HttpURLConnection setHttpRequestMethod(String requestMethod, 
//    		HttpURLConnection connection, String jsonStr) throws IOException {
//    	if(connection != null && (requestMethod != null || !requestMethod.trim().isEmpty())) {
//    		switch(requestMethod.toUpperCase()) {
//    		case "GET" : 
//    			connection.setRequestMethod("GET");
//    			connection.setDoOutput(true);
//    			break;
//    		case "POST" : 
//    			connection.setRequestMethod("POST");
//    			if(null != jsonStr) {
//    				connection.setDoOutput(true);
//    				try(OutputStream os = connection.getOutputStream()){
//    					byte[] input = jsonStr.getBytes("utf-8");
//    					os.write(input, 0, input.length);			
//    				}
//    			}
//    			break;
//    		case "PUT" : 
//    			connection.setRequestMethod("PUT");
//    			if(null != jsonStr) {
//    				connection.setDoOutput(true);
//    				try(OutputStream os = connection.getOutputStream()){
//    					byte[] input = jsonStr.getBytes("utf-8");
//    					os.write(input, 0, input.length);			
//    				}
//    			}
//    			break;
//    		case "DELETE" : 
//    			connection.setRequestMethod("DELETE");
////    			connection.setDoOutput(true);
//    			break;
//    		}
//    	}
//    	return connection;
//    }
    
    public ServerResponse getCookieWithReqAuthHeader(String url, String requestMethod, 
    		String jsonStr, String cookieName) throws IOException, ProtocolException, MalformedURLException {
        HttpURLConnection connection = null;
        BufferedReader reader = null;
        ServerResponse resp = new ServerResponse();
        try {
            connection = createConnection(url, requestMethod, jsonStr, null);
//            connection.setRequestProperty("Authorization", createBasicAuthHeaderValue());
//            connection.setReadTimeout(10000);
//            connection.setDoOutput(true);
            connection.connect();
            resp.setStatusCode(connection.getResponseCode());
        	resp.setStatusMessage(connection.getResponseMessage());
            String cookieValue = null;
            if(connection.getResponseCode() == 200) {
            	
            	Map<String, List<String>> headerFields = connection.getHeaderFields();
                
                Set<String> headerFieldsSet = headerFields.keySet();
                Iterator<String> hearerFieldsIter = headerFieldsSet.iterator();
                 
                while (hearerFieldsIter.hasNext()) {
                     
                     String headerFieldKey = hearerFieldsIter.next();
                     
//                     System.out.println("Header Fileds Keys : " +headerFieldKey);
                      
                     if ("Set-Cookie".equalsIgnoreCase(headerFieldKey)) {
                          
                         List<String> headerFieldValue = headerFields.get(headerFieldKey);
                         
//                         System.out.println("Header Field value : " + headerFieldValue);
                          
                         for (String headerValue : headerFieldValue) {
                              
//                            System.out.println("Cookie Found...");
                              
                            String[] fields = headerValue.split(";\\s*");
         
                            cookieValue = fields[0];
//                            String expires = null;
//                            String path = null;
//                            String domain = null;
//                            boolean secure = false;
//                             
//                            // Parse each field
//                            for (int j = 1; j < fields.length; j++) {
//                                if ("secure".equalsIgnoreCase(fields[j])) {
//                                    secure = true;
//                                }
//                                else if (fields[j].indexOf('=') > 0) {
//                                    String[] f = fields[j].split("=");
//                                    if ("expires".equalsIgnoreCase(f[0])) {
//                                        expires = f[1];
//                                    }
//                                    else if ("domain".equalsIgnoreCase(f[0])) {
//                                        domain = f[1];
//                                    }
//                                    else if ("path".equalsIgnoreCase(f[0])) {
//                                        path = f[1];
//                                    }
//                                }
//                                 
//                            }
                             
//                            System.out.println("cookieValue:" + cookieValue);
//                            System.out.println("expires:" + expires);
//                            System.out.println("path:" + path);
//                            System.out.println("domain:" + domain);
//                            System.out.println("secure:" + secure);
                              
//                            System.out.println("*****************************************");
                            resp.setOutput(cookieValue);
                         }
                          
                     }
                     
                }
            } else {
            	StringBuilder sb = new StringBuilder();
            	reader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
            	String str = null;
            	while((str = reader.readLine())!= null) {
            		sb.append(str).append("/n");
            	}
//            	System.out.println("Error Stream : " +sb.toString());
            	resp.setOutput(sb.toString());
            }
            return resp;
        } catch(Exception e) {
//        	System.out.println("Error while executing the request : " +e.getMessage());
        	e.printStackTrace(); 
        	throw e;
        } finally {
            if (connection != null) {
                connection.disconnect();
//                System.out.println("Cookie Connection closed");
            }
            if(reader != null) {
            	try {
            		reader.close();
            	} catch(IOException e) {
            		e.printStackTrace();
            	}
            }
        }
    }
    
    public ServerResponse doRequestWithAuthHeader(String url, String requestMethod, 
    		String jsonStr, String cookie, boolean isToFetchOnePolicy) throws IOException, ProtocolException, MalformedURLException {
        HttpURLConnection connection = null;
        BufferedReader reader = null;
        StringBuilder sb = null;
        try {
            connection = createConnection(url, requestMethod, jsonStr, cookie);
//            connection.setRequestProperty("Cookie", cookie);
//            connection.setRequestProperty("Authorization", createBasicAuthHeaderValue());
//            connection.setReadTimeout(100000);
//            connection.setDoOutput(true);
            connection.connect();
//            System.out.println("Connection details : " +connection.toString());
            ServerResponse resp = new ServerResponse(connection.getResponseCode(), connection.getResponseMessage());
            if(connection.getResponseCode() == 200) {
            	if(null != connection.getInputStream()) {
                	if(requestMethod.equalsIgnoreCase("get")) {
                		if(isToFetchOnePolicy) {
                			PolicyResp policy = new Gson().fromJson(new BufferedReader(new InputStreamReader(connection.getInputStream())), PolicyResp.class);
                			resp.setOutput(policy);
                		} else {
                			PolicyDetailsResp policyDtls = new Gson().fromJson(new BufferedReader(new InputStreamReader(connection.getInputStream())), 
                					PolicyDetailsResp.class);
                			resp.setOutput(policyDtls);
                		}
                	} else {
                		if(null != connection.getInputStream()) {
                			sb = new StringBuilder();
                        	reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                        	String str = null;
                        	while((str = reader.readLine()) != null) {
                        		sb.append(str).append("/n");
                        	}
                        	resp.setOutput(str);
                		}
                	}
                }
            }
            
            else {
            	if(null != connection.getErrorStream()) {
            		sb = new StringBuilder();
                	reader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                	String str = null;
                	while((str = reader.readLine())!= null) {
                		sb.append(str).append("/n");
                	}
//                	System.out.println("Error Stream : " +sb.toString());
                	resp.setOutput(sb.toString());
            	}
            }
//            System.out.println("sendRequestWithAuthHeader response :::: " +resp);
            return resp;
        } catch(Exception e) {
//        	System.out.println("Error while executing the request : " +e.getMessage());
        	e.printStackTrace(); 
        	throw e;
        } finally {
            if (connection != null) {
                connection.disconnect();
//                System.out.println("Connection closed");
            }
            if(reader != null) {
            	try {
            		reader.close();
            	} catch(IOException e) {
            		e.printStackTrace();
            	}
            }
        }
    }
     
}
