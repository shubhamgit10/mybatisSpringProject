package com.scb.selfservice.isd.entity;

public class ISDSummaryResponse {

	
	private int reqId;
	private String systemName;
	private String country;
	private int countRow;
	
	public int getCountRow() {
		return countRow;
	}

	public void setCountRow(int countRow) {
		this.countRow = countRow;
	}

	public int getReqId() {
		return reqId;
	}

	public void setReqId(int reqId) {
		this.reqId = reqId;
	}

	public String getSystemName() {
		return systemName;
	}

	public void setSourceSystemName(String systemName) {
		this.systemName = systemName;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	

}
