package com.scb.selfservice.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.CatalogueDataLoadMapper;
import com.scb.selfservice.domains.EDMPAppMetaData;
import com.scb.selfservice.domains.EDMPColsMetaData;
import com.scb.selfservice.domains.EDMPTabsCount;
import com.scb.selfservice.domains.EDMPTabsMetaData;
import com.scb.selfservice.domains.InstanceCountryMapping;
import com.scb.selfservice.domains.databaseentity.DBAppMetaData;
import com.scb.selfservice.domains.databaseentity.DBTabsMetaData;
import com.scb.selfservice.service.CatalogueDataLoadService;
import com.scb.selfservice.util.Response;

@Service
public class CatalogueDataLoadServiceImpl implements CatalogueDataLoadService {

	private static Logger logger = LogManager.getLogger(CatalogueDataLoadServiceImpl.class);

	@Autowired
	private CatalogueDataLoadMapper consumptionMapper;
	boolean condition = false;

	@Override
	@Transactional
	public Response getDataSources() {
		// TODO Auto-generated method stub
		logger.info("Inside ConsumptionServiceImpl::getAPPMetaData()");
		List<DBAppMetaData> dbAppMetaDataList = consumptionMapper.getDataSources();
		Response dataSourceResponse = new Response();
		if (dbAppMetaDataList.isEmpty()) {
			dataSourceResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			dataSourceResponse.setStatus(HttpStatus.NO_CONTENT.toString());
		} else {
			List<EDMPAppMetaData> dataSources = new ArrayList<EDMPAppMetaData>();
			for (DBAppMetaData dbAppMetaData : dbAppMetaDataList) {
				// need to add country description with code
				List<String> countriesList = Arrays.asList(dbAppMetaData.getSupportedCountries().split("\\s*,\\s*"))
						.stream().sorted().collect(Collectors.toList());
				List<String> bussinessSegmentList = Arrays.asList(dbAppMetaData.getBusinessSegment().split("\\s*,\\s*"))
						.stream().distinct().collect(Collectors.toList());
				EDMPAppMetaData appMetaData = new EDMPAppMetaData();
				appMetaData.setItamId(dbAppMetaData.getItamId());
				appMetaData.setAppDescription(dbAppMetaData.getAppDescription());
				appMetaData.setAppName(dbAppMetaData.getAppName());
				appMetaData.setProductCategory(dbAppMetaData.getProductCategory());
				appMetaData.setSubCategory(dbAppMetaData.getSubCategory());
				appMetaData.setBusinessSegment(bussinessSegmentList);
				appMetaData.setSupportedCountries(countriesList);

				dataSources.add(appMetaData);
			}

			dataSourceResponse.setStatusCode(HttpStatus.OK.value());
			dataSourceResponse.setStatus("Success");
			dataSourceResponse.setResponse(dataSources);
		}

		return dataSourceResponse;
	}

	@Override
	@Transactional
	public Response getIngestionDataSources() {
		// TODO Auto-generated method stub
		logger.info("Inside ConsumptionServiceImpl::getIngestionDataSources:: getAPPMetaData()");
		List<DBAppMetaData> dbAppMetaDataList = consumptionMapper.getIngestionDataSources();
		List<InstanceCountryMapping> instanceCountryMapping = consumptionMapper.getInstanceCountryMap();
		Response dataSourceResponse = new Response();
		List<String> countriesList = null;
		List<String> impactedArea = null;
		List<String> bussinessSegmentList = null;
		if (dbAppMetaDataList.isEmpty()) {
			dataSourceResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			dataSourceResponse.setStatus(HttpStatus.NO_CONTENT.toString());
		} else {
			List<EDMPAppMetaData> dataSources = new ArrayList<EDMPAppMetaData>();
			for (DBAppMetaData dbAppMetaData : dbAppMetaDataList) {
				// need to add country description with code

				if (dbAppMetaData.getSupportedCountries() != null
						&& !"".equals(dbAppMetaData.getSupportedCountries())) {
					countriesList = Arrays.asList(dbAppMetaData.getSupportedCountries().split("\\s*;\\s+|,\\s*")).stream()
							.sorted().collect(Collectors.toList());
					
				} else {
					countriesList = new ArrayList<String>();
				}
				if (dbAppMetaData.getBusinessSegment() != null && !"".equals(dbAppMetaData.getBusinessSegment())) {
					bussinessSegmentList = Arrays.asList(dbAppMetaData.getBusinessSegment().split("\\s*;\\s*")).stream()
							.distinct().collect(Collectors.toList());
				} else {
					bussinessSegmentList = new ArrayList<String>();
				}
				
				if (dbAppMetaData.getImpactedArea() != null && !"".equals(dbAppMetaData.getImpactedArea())) {

					/*********************************/
					// new field added for populating impacted areas(all countries) from ITAM_
					// Details Table
					impactedArea = Arrays.asList(dbAppMetaData.getImpactedArea().split("\\s*;\\s*")).stream().sorted()
							.collect(Collectors.toList());
					/*********************************/
				} else {

					impactedArea = new ArrayList<String>();
				}
				boolean instance = false;
				List<String> updatedSuppCountries = new ArrayList<>();
				List<String> updatedImpactCountries = new ArrayList<>();
				for(String countries: countriesList) {
					for(InstanceCountryMapping instanceCountry :instanceCountryMapping) {
						if(instanceCountry.getInstanceName().equals(countries)&&instanceCountry.getItamNo()==dbAppMetaData.getItamId()) { 
							instance = true;
							updatedSuppCountries.add(instanceCountry.getCountries());
						}
					}
					if(instance==false) {
						updatedSuppCountries.add(countries);
					}
					instance = false;
				}
				
				for(String impactCountry: impactedArea) {
					for(InstanceCountryMapping instanceCountry :instanceCountryMapping) {
						if(instanceCountry.getInstanceName().equals(impactCountry)&&instanceCountry.getItamNo()==dbAppMetaData.getItamId()) { 
							instance = true;
							updatedImpactCountries.add(instanceCountry.getCountries());
						}
					}
					if(instance==false) {
						updatedImpactCountries.add(impactCountry);
					}
					instance = false;
				}
				
				List<String> finalSuppCountries = updatedImpactCountries.stream()
                        .filter(i -> !updatedSuppCountries.contains(i))
                        .collect (Collectors.toList());
					
				
				if(null !=finalSuppCountries && finalSuppCountries.size()>0) {
				finalSuppCountries.replaceAll(String::trim);
				}
			
				List<String> impactCountries = updatedImpactCountries.stream()
                        .filter(i -> updatedSuppCountries.contains(i))
                        .collect (Collectors.toList());
				
				
				EDMPAppMetaData appMetaData = new EDMPAppMetaData();
				appMetaData.setItamId(dbAppMetaData.getItamId());
				appMetaData.setAppDescription(dbAppMetaData.getAppDescription());
				appMetaData.setAppName(dbAppMetaData.getAppName());
				appMetaData.setProductCategory(dbAppMetaData.getProductCategory());
				appMetaData.setSubCategory(dbAppMetaData.getSubCategory());
				appMetaData.setBusinessSegment(bussinessSegmentList);
				appMetaData.setSupportedCountries(finalSuppCountries);
				appMetaData.setImpactedArea(impactCountries);

				if(null !=finalSuppCountries && finalSuppCountries.size()>0) {
				dataSources.add(appMetaData);
				}
			}

			dataSourceResponse.setStatusCode(HttpStatus.OK.value());
			dataSourceResponse.setStatus("Success");
			dataSourceResponse.setResponse(dataSources);
		}

		return dataSourceResponse;
	}

	@Override
	@Transactional
	public Response getDataSetCount(List<EDMPTabsCount> edmpTabsCounts) {
		// TODO Auto-generated method stub
		logger.info("Inside ConsumptionServiceImpl::getTabCount()");
		List<EDMPTabsCount> tableCount = consumptionMapper.getDataSetCount(edmpTabsCounts);
		Response tableCountResponse = new Response();
		if (tableCount.isEmpty()) {
			tableCountResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			tableCountResponse.setStatus(HttpStatus.NO_CONTENT.toString());
		} else {
			tableCountResponse.setStatusCode(HttpStatus.OK.value());
			tableCountResponse.setStatus("Success");
			tableCountResponse.setResponse(tableCount);
		}
		return tableCountResponse;
	}

	@Override
	@Transactional
	public Response getDataSetName(String itamId, List<String> country) {
		// TODO Auto-generated method stub
		logger.info("Inside ConsumptionServiceImpl::getTabMetaData()");
		List<DBTabsMetaData> dbTabsMetaDataList = consumptionMapper.getDataSetName(itamId, country);
		Response dataSetNameResponse = new Response();
		if (dbTabsMetaDataList.isEmpty()) {
			dataSetNameResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			dataSetNameResponse.setStatus(HttpStatus.NO_CONTENT.toString());
		} else {
			List<EDMPTabsMetaData> tabsMetaDataList = new ArrayList<EDMPTabsMetaData>();
			for (DBTabsMetaData dbTabsMetaData : dbTabsMetaDataList) {
				EDMPTabsMetaData edmpTabsMetaData = new EDMPTabsMetaData();
				List<String> countriesList = Arrays.asList(dbTabsMetaData.getCountry().split("\\s*,\\s*"));
				edmpTabsMetaData.setItamId(dbTabsMetaData.getItamId());
				edmpTabsMetaData.setTableName(dbTabsMetaData.getTableName());
				edmpTabsMetaData.setTableDescription(dbTabsMetaData.getTableDescription());
				edmpTabsMetaData.setHasPiiCols(dbTabsMetaData.getHasPiiCols());
				edmpTabsMetaData.setCountry(countriesList);
				edmpTabsMetaData.setNoOfCols(dbTabsMetaData.getNoOfCols());
				tabsMetaDataList.add(edmpTabsMetaData);
			}

			dataSetNameResponse.setStatusCode(HttpStatus.OK.value());
			dataSetNameResponse.setStatus("Success");
			dataSetNameResponse.setResponse(tabsMetaDataList);
		}

		return dataSetNameResponse;
	}

	@Override
	@Transactional
	public Response getAttributeName(String itamId, String tableName) {
		// TODO Auto-generated method stub
		logger.info("Inside ConsumptionServiceImpl::getColMetaData()");
		List<EDMPColsMetaData> colsMetaDatas = consumptionMapper.getAttributeName(itamId, tableName);
		Response colsNameResponse = new Response();
		if (colsMetaDatas.isEmpty()) {
			colsNameResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			colsNameResponse.setStatus(HttpStatus.NO_CONTENT.toString());
		} else {
			colsNameResponse.setStatusCode(HttpStatus.OK.value());
			colsNameResponse.setStatus("Success");
			colsNameResponse.setResponse(colsMetaDatas);
		}
		return colsNameResponse;
	}

	@Override
	public Response getIngestionDS() {

		// TODO Auto-generated method stub
		logger.info("Inside ConsumptionServiceImpl::getIngestionDataSources:: getAPPMetaData()");
		List<DBAppMetaData> dbAppMetaDataList = consumptionMapper.getIngestionDS();
		Response dataSourceResponse = new Response();
		List<String> countriesList = null;
		List<String> impactedArea = null;
		List<String> bussinessSegmentList = null;
		if (dbAppMetaDataList.isEmpty()) {
			dataSourceResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			dataSourceResponse.setStatus(HttpStatus.NO_CONTENT.toString());
		} else {
			
			
			List<EDMPAppMetaData> dataSources = new ArrayList<EDMPAppMetaData>();
			for (DBAppMetaData dbAppMetaData : dbAppMetaDataList) { // need to add country description with code

				if (dbAppMetaData.getSupportedCountries() != null
						&& !"".equals(dbAppMetaData.getSupportedCountries())) {
					countriesList = Arrays.asList(dbAppMetaData.getSupportedCountries().split("\\s*,\\s*")).stream()
							.sorted().collect(Collectors.toList());
				} else {
					countriesList = new ArrayList<String>();
				}
				if (dbAppMetaData.getBusinessSegment() != null && !"".equals(dbAppMetaData.getBusinessSegment())) {
					bussinessSegmentList = Arrays.asList(dbAppMetaData.getBusinessSegment().split("\\s*;\\s*")).stream()
							.distinct().collect(Collectors.toList());
				} else {
					bussinessSegmentList = new ArrayList<String>();
				}
				if (dbAppMetaData.getImpactedArea() != null && !"".equals(dbAppMetaData.getImpactedArea())) {
					impactedArea = Arrays.asList(dbAppMetaData.getImpactedArea().split("\\s*,\\s*")).stream()
							.distinct().collect(Collectors.toList());
				} else {
					impactedArea = new ArrayList<String>();
				}
				EDMPAppMetaData appMetaData = new EDMPAppMetaData();
				appMetaData.setItamId(dbAppMetaData.getItamId());
				appMetaData.setAppDescription(dbAppMetaData.getAppDescription());
				appMetaData.setAppName(dbAppMetaData.getAppName());
				appMetaData.setProductCategory(dbAppMetaData.getProductCategory());
				appMetaData.setSubCategory(dbAppMetaData.getSubCategory());
				appMetaData.setBusinessSegment(bussinessSegmentList);
				appMetaData.setSupportedCountries(countriesList);
				appMetaData.setImpactedArea(impactedArea);

				if (dbAppMetaData.getImpactedArea() != null && !"".equals(dbAppMetaData.getImpactedArea())) {
			  
			 /*********************************/
			
			  //new field added for populating impacted areas(all countries) from ITAM_Details Table impactedArea =
			  Arrays.asList(dbAppMetaData.getImpactedArea().split("\\s*;\\s*")).stream().
			  sorted().collect(Collectors.toList());
			 /*********************************/
													  } else {
													  
													  impactedArea = new ArrayList<String>(); }
													  
													  appMetaData.setImpactedArea(impactedArea);
													  
													  dataSources.add(appMetaData); }
													 

			dataSourceResponse.setStatusCode(HttpStatus.OK.value());
			dataSourceResponse.setStatus("Success");
			dataSourceResponse.setResponse(dataSources);
			//dataSourceResponse.setResponse(dbAppMetaDataList);
		}

		return dataSourceResponse;
	}

}
