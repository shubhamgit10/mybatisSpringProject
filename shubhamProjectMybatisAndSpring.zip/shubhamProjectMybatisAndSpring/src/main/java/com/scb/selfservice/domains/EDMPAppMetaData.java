package com.scb.selfservice.domains;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


public class EDMPAppMetaData  {

	private Integer itamId;
	private String appName;
	private String appDescription;
	private List<String> businessSegment;
	private String productCategory;
	private String subCategory;
	
	
	private List<String> supportedCountries;
	
	// Field added from ITAM_Details Table
	@JsonInclude(Include.NON_NULL)
	private List<String> impactedArea;

	public Integer getItamId() {
		return itamId;
	}
	public void setItamId(Integer itamId) {
		this.itamId = itamId;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getAppDescription() {
		return appDescription;
	}
	public void setAppDescription(String appDescription) {
		this.appDescription = appDescription;
	}
	public List<String> getBusinessSegment() {
		return businessSegment;
	}
	public void setBusinessSegment(List<String> businessSegment) {
		this.businessSegment = businessSegment;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public String getSubCategory() {
		return subCategory;
	}
	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}
	public List<String> getSupportedCountries() {
		return supportedCountries;
	}
	public void setSupportedCountries(List<String> supportedCountries) {
		this.supportedCountries = supportedCountries;
	}
	public List<String> getImpactedArea() {
		return impactedArea;
	}
	public void setImpactedArea(List<String> impactedArea) {
		this.impactedArea = impactedArea;
	}
		
}
