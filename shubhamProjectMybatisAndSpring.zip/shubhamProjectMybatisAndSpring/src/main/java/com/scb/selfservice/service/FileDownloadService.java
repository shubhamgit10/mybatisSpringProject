package com.scb.selfservice.service;

import java.util.List;

import com.scb.selfservice.domains.FileData;
import com.scb.selfservice.domains.FileUpload;

/*
 * interface for file download service
 */
public interface FileDownloadService {

	//is to pull data for the xls preparation
	public List<FileData> pullData(Integer reqId);

	//is to get existing blob data and then to file
	public FileUpload pullFile(Integer uploadId);
}
