package com.scb.selfservice.domains;

import java.sql.Date;

public class IngestionRequestorResp {
	
	private Integer reqId;
	
	private String approvedCost;
	
	private String clarityId;
	
	private String projectCostCenter;
	
	private String costCenterOwner;
	
	private String infraCostCenter;
	
	private String additionalComments;
	
	private Integer requestCreatedBy;
	
	private String userAction;
	
	private String stepId;
	
	private String workflowType;
	
	private String stepName;
	
	private Integer expectedNoOfFiles;
	
	private Integer expectedNoOfAttributes;
	
	private String yearsOfHistoryIsReq;
	
	private Integer approxHistoryDataSize;
	
	private String historyStorageType;
	
	private String frequency;
	
	private Integer approxIncrementalDataSize;
	
	private String incrementalStorageType;
	
	private Date expectedDeliveryDate;
	
	private String priority;
	
	private Integer itamNumber;
	
	private String projectName;
	
	private String businessStream;
	
	private String fundingAvenue;
	
	private String benefitCatagory;
	
	private String benefitDetails;
	
	private String requestSummary;
	
	private Double proposedCost;
	
	private String fileName;
			
	public String getStepName() {
		return stepName;
	}

	public void setStepName(String stepName) {
		this.stepName = stepName;
	}

	public String getWorkflowType() {
		return workflowType;
	}

	public void setWorkflowType(String workflowType) {
		this.workflowType = workflowType;
	}

	public Integer getReqId() {
		return reqId;
	}

	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}

	public String getApprovedCost() {
		return approvedCost;
	}

	public void setApprovedCost(String approvedCost) {
		this.approvedCost = approvedCost;
	}

	public String getClarityId() {
		return clarityId;
	}

	public void setClarityId(String clarityId) {
		this.clarityId = clarityId;
	}

	public String getProjectCostCenter() {
		return projectCostCenter;
	}

	public void setProjectCostCenter(String projectCostCenter) {
		this.projectCostCenter = projectCostCenter;
	}

	public String getCostCenterOwner() {
		return costCenterOwner;
	}

	public void setCostCenterOwner(String costCenterOwner) {
		this.costCenterOwner = costCenterOwner;
	}

	public String getInfraCostCenter() {
		return infraCostCenter;
	}

	public void setInfraCostCenter(String infraCostCenter) {
		this.infraCostCenter = infraCostCenter;
	}

	public String getAdditionalComments() {
		return additionalComments;
	}

	public void setAdditionalComments(String additionalComments) {
		this.additionalComments = additionalComments;
	}

	public Integer getRequestCreatedBy() {
		return requestCreatedBy;
	}

	public void setRequestCreatedBy(Integer requestCreatedBy) {
		this.requestCreatedBy = requestCreatedBy;
	}

	public String getUserAction() {
		return userAction;
	}

	public void setUserAction(String userAction) {
		this.userAction = userAction;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public Integer getExpectedNoOfFiles() {
		return expectedNoOfFiles;
	}

	public void setExpectedNoOfFiles(Integer expectedNoOfFiles) {
		this.expectedNoOfFiles = expectedNoOfFiles;
	}

	public Integer getExpectedNoOfAttributes() {
		return expectedNoOfAttributes;
	}

	public void setExpectedNoOfAttributes(Integer expectedNoOfAttributes) {
		this.expectedNoOfAttributes = expectedNoOfAttributes;
	}

	public String getYearsOfHistoryIsReq() {
		return yearsOfHistoryIsReq;
	}

	public void setYearsOfHistoryIsReq(String yearsOfHistoryIsReq) {
		this.yearsOfHistoryIsReq = yearsOfHistoryIsReq;
	}

	public Integer getApproxHistoryDataSize() {
		return approxHistoryDataSize;
	}

	public void setApproxHistoryDataSize(Integer approxHistoryDataSize) {
		this.approxHistoryDataSize = approxHistoryDataSize;
	}

	public String getHistoryStorageType() {
		return historyStorageType;
	}

	public void setHistoryStorageType(String historyStorageType) {
		this.historyStorageType = historyStorageType;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public Integer getApproxIncrementalDataSize() {
		return approxIncrementalDataSize;
	}

	public void setApproxIncrementalDataSize(Integer approxIncrementalDataSize) {
		this.approxIncrementalDataSize = approxIncrementalDataSize;
	}

	public String getIncrementalStorageType() {
		return incrementalStorageType;
	}

	public void setIncrementalStorageType(String incrementalStorageType) {
		this.incrementalStorageType = incrementalStorageType;
	}

	public Date getExpectedDeliveryDate() {
		return expectedDeliveryDate;
	}

	public void setExpectedDeliveryDate(Date expectedDeliveryDate) {
		this.expectedDeliveryDate = expectedDeliveryDate;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public Integer getItamNumber() {
		return itamNumber;
	}

	public void setItamNumber(Integer itamNumber) {
		this.itamNumber = itamNumber;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getBusinessStream() {
		return businessStream;
	}

	public void setBusinessStream(String businessStream) {
		this.businessStream = businessStream;
	}

	public String getFundingAvenue() {
		return fundingAvenue;
	}

	public void setFundingAvenue(String fundingAvenue) {
		this.fundingAvenue = fundingAvenue;
	}

	public String getBenefitCatagory() {
		return benefitCatagory;
	}

	public void setBenefitCatagory(String benefitCatagory) {
		this.benefitCatagory = benefitCatagory;
	}

	public String getBenefitDetails() {
		return benefitDetails;
	}

	public void setBenefitDetails(String benefitDetails) {
		this.benefitDetails = benefitDetails;
	}

	public String getRequestSummary() {
		return requestSummary;
	}

	public void setRequestSummary(String requestSummary) {
		this.requestSummary = requestSummary;
	}

	public Double getProposedCost() {
		return proposedCost;
	}

	public void setProposedCost(Double proposedCost) {
		this.proposedCost = proposedCost;
	}
	
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@Override
	public String toString() {
		return "IngestionRequestorResp [reqId=" + reqId + ", approvedCost=" + approvedCost + ", clarityId=" + clarityId
				+ ", projectCostCenter=" + projectCostCenter + ", costCenterOwner=" + costCenterOwner
				+ ", infraCostCenter=" + infraCostCenter + ", additionalComments=" + additionalComments
				+ ", requestCreatedBy=" + requestCreatedBy + ", userAction=" + userAction + ", stepId=" + stepId
				+ ", workflowType=" + workflowType + ", stepName=" + stepName + ", expectedNoOfFiles="
				+ expectedNoOfFiles + ", expectedNoOfAttributes=" + expectedNoOfAttributes + ", yearsOfHistoryIsReq="
				+ yearsOfHistoryIsReq + ", approxHistoryDataSize=" + approxHistoryDataSize + ", historyStorageType="
				+ historyStorageType + ", frequency=" + frequency + ", approxIncrementalDataSize="
				+ approxIncrementalDataSize + ", incrementalStorageType=" + incrementalStorageType
				+ ", expectedDeliveryDate=" + expectedDeliveryDate + ", priority=" + priority + ", itamNumber="
				+ itamNumber + ", projectName=" + projectName + ", businessStream=" + businessStream
				+ ", fundingAvenue=" + fundingAvenue + ", benefitCatagory=" + benefitCatagory + ", benefitDetails="
				+ benefitDetails + ", requestSummary=" + requestSummary + ", proposedCost=" + proposedCost
				+ ", fileName=" + fileName + "]";
	}
		
}