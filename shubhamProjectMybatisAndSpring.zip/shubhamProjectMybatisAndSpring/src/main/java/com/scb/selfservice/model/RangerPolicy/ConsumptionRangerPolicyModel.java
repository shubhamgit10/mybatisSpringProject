package com.scb.selfservice.model.RangerPolicy;

import java.util.Map;
import java.util.Set;

public class ConsumptionRangerPolicyModel {
	
	private Long requestId;
	private String policyId;
	private String policyName;
	private String groupName;
	
//	Map<APP_NAME, Map<Country, Map<DBName, Map<ColumnName, Set<TableName>>>>>
	private Map<String, Map<String, Map<String, Map<String, Set<String>>>>> metadataDetails ;
	
	
	/**
	 * 
	 */
	public ConsumptionRangerPolicyModel() {
	}

	/**
	 * @param requestId
	 * @param appName
	 * @param policyId
	 * @param policyName
	 * @param countries
	 * @param dbMetadata
	 * @param groupName
	 */
	public ConsumptionRangerPolicyModel(Long requestId, String policyId, String policyName,
			String groupName, Map<String, Map<String, Map<String, Map<String, Set<String>>>>> metadataDetails) {
		super();
		this.requestId = requestId;
		this.policyId = policyId;
		this.policyName = policyName;
		this.groupName = groupName;
		this.metadataDetails = metadataDetails;
	}

	/**
	 * @return the requestId
	 */
	public Long getRequestId() {
		return requestId;
	}

	/**
	 * @param requestId the requestId to set
	 */
	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	/**
	 * @return the policyId
	 */
	public String getPolicyId() {
		return policyId;
	}

	/**
	 * @param policyId the policyId to set
	 */
	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}

	/**
	 * @return the policyName
	 */
	public String getPolicyName() {
		return policyName;
	}

	/**
	 * @param policyName the policyName to set
	 */
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	/**
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}

	/**
	 * @param groupName the groupName to set
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	/**
	 * @return the metadataDetails
	 */
	public Map<String, Map<String, Map<String, Map<String, Set<String>>>>> getMetadataDetails() {
		return metadataDetails;
	}

	/**
	 * @param metadataDetails the metadataDetails to set
	 */
	public void setMetadataDetails(Map<String, Map<String, Map<String, Map<String, Set<String>>>>> metadataDetails) {
		this.metadataDetails = metadataDetails;
	}

	@Override
	public String toString() {
		return "ConsumptionRangerPolicyModel [requestId=" + requestId + ", policyId=" + policyId + ", policyName="
				+ policyName + ", groupName=" + groupName + ", metadataDetails=" + metadataDetails + "]";
	}

}
