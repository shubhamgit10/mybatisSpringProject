package com.scb.selfservice.model.RangerPolicy;

import java.io.Serializable;

/**
 * Created by 1610601 on 7/30/2020.
 */

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;

@JsonAutoDetect(fieldVisibility = Visibility.ANY)
public class RangerPolicyHdfsResourcesModel extends RangerPolicyResourcesModel  implements Serializable {

    private RangerPolicyResourceSupportingModel path;

    public RangerPolicyHdfsResourcesModel() {
    	super();
        this.path = new RangerPolicyResourceSupportingModel();
        this.path.setRecursive(true);
    }

    public RangerPolicyHdfsResourcesModel(RangerPolicyResourceSupportingModel path) {
        this.path = path;
    }

    public RangerPolicyResourceSupportingModel getPath() {
        return path;
    }

    public void setPath(RangerPolicyResourceSupportingModel path) {
        this.path = path;
    }

    @Override
    public String toString() {
        return "RangerPolicyHdfsResourcesModel{" +
                "path=" + path +
                '}';
    }
}
