package com.scb.selfservice.service;

import java.util.HashMap;
import java.util.Map;

import com.scb.selfservice.model.UserDetails;

public interface IdentityService {
	
    public Map<String,Object> validateUser(String userId, String passWord);
    
    /**
     * Method to log User Login Details
     * @param details
     */
    public void logUserDetails(HashMap<String,String> details);
    
    /**
     * Method to getPSHR Data
     * @param userId
     */
    public UserDetails getPSHRData(String userId);
    
    
    /**
     * Method to create User if doesn't exists in UserDetails table
     * @param details
     */
    public void createUserIfNotExists(UserDetails details) ;
    
    /**
     * Method to getUserLastLoginDetails
     * @param userId
     * @return
     */
    public Map<String, String> getUserLastLoginDetails(String userId);
}
