package com.scb.selfservice.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.IngestionRequestorResp;

public interface EdmpIngRequestorRespMapper {
	
public int saveIngestionRequestorResp(@Param("IngestionRequestorResp") IngestionRequestorResp ingestionRequestorResp);
	
	//method to pull existing IngestionSolArchApproval based on reqId
		public IngestionRequestorResp findByRequestId(@Param("reqId") Integer reqId);
		
		//method for updating IngestionSolArchApproval Request
		public int updateIngestionRequestorResp(@Param("IngestionRequestorResp") IngestionRequestorResp ingestionRequestorResp);

		//for Get API for cost Approval
		public IngestionRequestorResp findIngReqById(@Param("reqId") Integer reqId);
		
}
