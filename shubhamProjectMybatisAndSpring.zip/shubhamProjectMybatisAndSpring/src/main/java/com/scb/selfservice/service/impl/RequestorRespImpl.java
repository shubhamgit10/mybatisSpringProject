package com.scb.selfservice.service.impl;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.scb.selfservice.dao.mapper.IngestionDynamicMapper;
import com.scb.selfservice.dao.mapper.WorkflowMapper;
import com.scb.selfservice.domains.IngestionInput;
import com.scb.selfservice.domains.IngestionRequestorResp;
import com.scb.selfservice.service.UserResponseService;
import com.scb.selfservice.util.Response;

/**
 * @author cpedada
 *
 */
@Service(value = "CostApproval")
public class RequestorRespImpl implements UserResponseService {

	private static Logger logger = LogManager.getLogger(RequestorRespImpl.class);

	@Autowired
	WorkflowMapper workflowMapper;

	@Autowired
	IngestionDynamicMapper idynMapper;

	/**
	 *
	 */
	@Override
	public Response executeSave(IngestionInput ingestionInput) {

		logger.info("inside RequestorRespImpl:: excuteSave Method");
		Response isaResponse = new Response();

		try {
			isaResponse = saveIngestionRequestorResp(ingestionInput);

		} catch (Exception e) {

			logger.info("Exception::" + e);
		}

		return isaResponse;
	}

	/**
	 * @param ingestionInput
	 * @return
	 * @throws Exception
	 */
	public Response saveIngestionRequestorResp(IngestionInput ingestionInput) throws Exception {

		logger.info("START EdmpIngestionRequestProcessServiceImpl::saveIngestionRequestorResp");
		Response isaResponse = new Response();

		HashMap<String, Object> hm = (HashMap<String, Object>) ingestionInput.getParams();

		hm.put("reqId", ingestionInput.getReqId());

		hm.put("stepId", ingestionInput.getStepId());

		hm.put("workflowType", ingestionInput.getWorkflowType());

		hm.put("userAction", ingestionInput.getUserAction());

		hm.put("requestCreatedBy", ingestionInput.getUserId());
		
		String str = (String) hm.get("expectedDeliveryDate");

		Date createdDate = Date.valueOf(str);
		logger.info("createdDate ::::::::::::::" +createdDate);
		
		hm.put("expectedDeliveryDate", createdDate);

		IngestionRequestorResp crObj = idynMapper.cAfindByRequestId(ingestionInput.getReqId());

		if (crObj == null) {
			logger.info("START it is a new entry for new request..." + ingestionInput.getReqId());

			int saveStatus = idynMapper.saveIngestionRequestorResp(hm); // insert

			isaResponse = getActionStatus("save", saveStatus, ingestionInput.getReqId());

			logger.info("EXIT save request");
		} else {
			logger.info("START it an existing request..." + ingestionInput.getReqId());

			int updateStatus = idynMapper.updateIngestionRequestorResp(hm); // update

			isaResponse = getActionStatus("update", updateStatus, ingestionInput.getReqId());

			logger.info("EXIT update request");
		}

		logger.info("EXIT EdmpIngestionRequestProcessServiceImpl::saveIngestionRequestorResp");
		return isaResponse;

	}

	/**
	 * @param type
	 * @param saveStatus
	 * @param reqId
	 * @return
	 */
	private Response getActionStatus(String type, int saveStatus, int reqId) {
		Response response = new Response();
		if (saveStatus == 1) {
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus(HttpStatus.OK.toString());
			response.setResponse(reqId + "Request id " + (type.equals("save") ? "INSERTED" : "UPDATED"));
		} else {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
			response.setResponse("!!!Action not taken!!!");
		}
		return response;
	}
	
	/**
	 *
	 */
	@Override
	public Response fetchApprovalResponse(IngestionInput ingestionInput) {
		IngestionRequestorResp costAppResponse = idynMapper.cAfindByRequestId(ingestionInput.getReqId());
		//Response costAppResponse = eiReqService.findByReqId(requestId);
		Response response = new Response();
		response.setResponse(costAppResponse);
		return response;
	}

}