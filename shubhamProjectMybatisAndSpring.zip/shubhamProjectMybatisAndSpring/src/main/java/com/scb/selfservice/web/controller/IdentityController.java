package com.scb.selfservice.web.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.model.UserDetails;
import com.scb.selfservice.service.IdentityService;
import com.scb.selfservice.util.JWTUtil;

@RestController
@RequestMapping("/api/login")
public class IdentityController {

    @Autowired
    IdentityService identityService;

    @Autowired
    JWTUtil jwtUtil;

    /**
     * Method to list the Task pending for the User or Group
      * @param id
      * @param password
      * @return
     */

    @RequestMapping(path = "/authenticate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> login(@RequestHeader Map<String, String> header, @RequestParam(name = "user") String user,
                                     @RequestParam(name = "password") String password,
                                     HttpServletRequest request) {
    	Map<String, Object> result = new HashMap<String, Object>();
    	if (StringUtils.isEmpty(user)) {
    		result.put("status","300");
    		result.put("message","User Id is Mandatory and Can't be blank");
    		return result;            
    	}
    	
    	if (StringUtils.isEmpty(password)) {
    		result.put("status","300");
    		result.put("message","Password is Mandatory and Can't be blank");
    		return result;            
    	}
    	if (user.length() < 7 || !StringUtils.isNumeric(user)) {
    		result.put("status","300");
    		result.put("message","User Id has to Numeric and should be 7 Digit bank Id");
    		return result; 
    	}

        result = identityService.validateUser(user,password);
        String lineManager = "NA";
        if ("200".equalsIgnoreCase((String)result.get("status"))) {
        	UserDetails userDetails = identityService.getPSHRData(user);
        	if (userDetails != null) {
        		lineManager = userDetails.getLineManager().getUserId();
        		identityService.createUserIfNotExists(userDetails);
        		result.put("userLoginDetails", identityService.getUserLastLoginDetails(user));
        	}
        	result.put("accessToken",jwtUtil.createJWT(user, (String)result.get("ROLES"), lineManager));
        	result.put("userDetails", userDetails);
        }
        HashMap<String,String> userDetails = new HashMap<String, String>();
        userDetails.put("USER_ID", user);
        userDetails.put("LOGIN_STATUS", "200".equalsIgnoreCase((String)result.get("status"))?"SUCCESS":"FAILURE");
        userDetails.put("LOGIN_IP", request.getRemoteAddr());
        userDetails.put("LOGIN_EXCEPTION", (String)result.get("message"));
        userDetails.put("USER_AGENT", header.get("user-agent"));
        
        identityService.logUserDetails(userDetails);
        result.remove("ROLES");
        return result;
    }
    
    /**
     * Method to validate the Authentication Token
     * @param header
     * @param token
     * @param request
     * @return
     */
    @RequestMapping(path = "/validate", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> login(@RequestHeader Map<String, String> header, HttpServletRequest request) {

    	String userToken = null;
    	String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
		if (StringUtils.isNotEmpty(authHeader))
			userToken = StringUtils.replace(authHeader, "Basic ", "").trim();
			
    	Map<String, Object> result = new HashMap<String, Object>();
    	if (StringUtils.isEmpty(userToken)) {
    		result.put("statusCode",204);
            result.put("status","IN-VALID TOKEN");
            return result;
    	}
    	String[] data = jwtUtil.verifyJWT(userToken);
    	if (data != null) {
    		UserDetails userDetails = identityService.getPSHRData(data[0]);
        	if (userDetails != null) {
        		Map<String, Object> innerMap = new HashMap<String, Object>();
        		innerMap.put("userLoginDetails", identityService.getUserLastLoginDetails(data[0]));
        		innerMap.put("userDetails", userDetails);
        		
        		HashMap<String,String> userLgDetails = new HashMap<String, String>();
        		userLgDetails.put("USER_ID", data[0]);
        		userLgDetails.put("LOGIN_STATUS", "SUCCESS");
        		userLgDetails.put("LOGIN_IP", request.getRemoteAddr());
        		userLgDetails.put("LOGIN_EXCEPTION", "LOGIN_SUCCESS");
        		userLgDetails.put("USER_AGENT", header.get("user-agent"));                
                identityService.logUserDetails(userLgDetails);
                result.put("statusCode",200);
                result.put("status","LOGIN_SUCCESS");
                result.put("response", innerMap);
        	}
    	}
    	else {
    		result.put("statusCode",204);
            result.put("status","IN-VALID TOKEN");
    	}
    	return result;
    }    
    
}
