package com.scb.selfservice.service;

import java.util.Map;

public interface FileService {

    public boolean createDirectory(String filePath);

    public boolean saveStringAsFile(String filePath, String fileName, String fileContent, boolean fileOverWrite);

    public boolean saveTemplateAsFile(String filePath,
                                      String fileName,
                                      String template,
                                      Map<String, Object> params,
                                      boolean fileOverWrite);

}
