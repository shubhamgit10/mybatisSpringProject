package com.scb.selfservice.isd.entity;

/**
 * @author akuma400
 *
 */
public class ExceptionCategory {
	
	private String issueCategory;
	private String tablesImpacted;
	private String columnsImpacted;
	private String description;
	
	public String getIssueCategory() {
		return issueCategory;
	}
	public void setIssueCategory(String issueCategory) {
		this.issueCategory = issueCategory;
	}
	public String getTablesImpacted() {
		return tablesImpacted;
	}
	public void setTablesImpacted(String tablesImpacted) {
		this.tablesImpacted = tablesImpacted;
	}
	public String getColumnsImpacted() {
		return columnsImpacted;
	}
	public void setColumnsImpacted(String columnsImpacted) {
		this.columnsImpacted = columnsImpacted;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "ExceptionCategory [issueCategory=" + issueCategory + ", tablesImpacted=" + tablesImpacted
				+ ", columnsImpacted=" + columnsImpacted + ", description=" + description + "]";
	}

}
