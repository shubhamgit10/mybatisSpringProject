package com.scb.selfservice.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.FileData;
import com.scb.selfservice.domains.FileUpload;

public interface FileDownloadMapper {

	//is to pull data for xls and then further download
	public List<FileData> pullData(@Param("reqId") Integer reqId);

	//is to pull blob (file) data and then further download
	public FileUpload pullFile(@Param("uploadId") Integer uploadId);
}
