package com.scb.selfservice.model.RangerPolicy;

/**
 * Created by 1610601 on 7/30/2020.
 */
public class RangerPolicyDataMask {

    private String dataMaskType;

    public RangerPolicyDataMask() {
    }

    public RangerPolicyDataMask(String dataMaskType) {
        this.dataMaskType = dataMaskType;
    }

    public String getDataMaskType() {
        return dataMaskType;
    }

    public void setDataMaskType(String dataMaskType) {
        this.dataMaskType = dataMaskType;
    }

    @Override
    public String toString() {
        return "RangerPolicyDataMask{" +
                "dataMaskType='" + dataMaskType + '\'' +
                '}';
    }
}
