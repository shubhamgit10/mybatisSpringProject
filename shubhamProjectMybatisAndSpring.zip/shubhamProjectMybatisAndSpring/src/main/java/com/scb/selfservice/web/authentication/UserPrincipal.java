/**
 * 
 */
package com.scb.selfservice.web.authentication;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

/**
 * User Principal POJO object
 * 
 * @author Amarnath
 *
 */
public class UserPrincipal extends UsernamePasswordAuthenticationToken {
	
	protected List<UserGroup> accessGroup = new ArrayList<UserGroup>();
	
	protected String userLM;
	
	/**
	 * Constructor
	 * @param userName
	 * @param authorities
	 */
	public UserPrincipal (String userName, List<UserGroup> authorities, String lm) {
		super(userName, "", authorities);
		this.accessGroup = authorities; 
		this.userLM = lm;
	}
	
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return this.getPrincipal().toString();
	}	
	
	/**
	 * @return the accessGroup
	 */
	
	public List<UserGroup> getAccessGroup() {
		return accessGroup;
	}
	
	/**
	 * Method to return User LM details
	 * @return
	 */
	public String getUserLM() {
		return userLM;
	}
	
	/**
	 * toString Method
	 */
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Principal -> " + getUserId() + " ");
		sb.append("Authorities - > [");
		List<UserGroup> ug = getAccessGroup();
		for (int i=0; i < ug.size(); i++)
			sb.append(ug.get(i) + ",");			
		sb.append("]");
		return sb.toString();
	}

}
