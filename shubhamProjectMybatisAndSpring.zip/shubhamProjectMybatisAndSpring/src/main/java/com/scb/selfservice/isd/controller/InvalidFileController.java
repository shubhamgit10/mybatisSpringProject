package com.scb.selfservice.isd.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.scb.selfservice.isd.exception.InvalidFileException;
import com.scb.selfservice.util.Response;

@ControllerAdvice
public class InvalidFileController {

	@ExceptionHandler(value = InvalidFileException.class)
	ResponseEntity<Response> handleInvalidFile(InvalidFileException fileException){
		Response response = new Response();
		response.setResponse(fileException.getMessage());
		response.setStatus(HttpStatus.PARTIAL_CONTENT.toString());
		response.setStatusCode(HttpStatus.PARTIAL_CONTENT.value());
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
}
