package com.scb.selfservice.model;

import java.util.ArrayList;
import java.util.List;

/*
 * pojo for admin related data
 * emailMapper.xml - getPendingMailCcListMap
 */
public class AdminData {
	private Integer roleId;
	private Integer userId;
	private String  roleName;
	private String  status;
	private String  emailAddress;
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	@Override
	public String toString() {
		return "AdminData [roleId=" + roleId + ", userId=" + userId + ", roleName=" + roleName + ", status=" + status
				+ ", emailAddress=" + emailAddress + "]";
	}

	public List<String> getAdminEmailIds(List<AdminData> data) {
		List<String> emails = new ArrayList<>();
		for (AdminData item : data) {
			emails.add(item.getEmailAddress());
		}
		return emails;
	}
}
