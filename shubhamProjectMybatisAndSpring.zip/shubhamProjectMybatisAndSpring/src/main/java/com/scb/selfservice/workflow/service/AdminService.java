package com.scb.selfservice.workflow.service;

import java.util.HashMap;

import com.scb.selfservice.util.Response;

/*
 * class related to ADMIN capabilities
 */
public interface AdminService {

	//method to pull approvalLists at ADMIN level
	public Response getAdminApprovalList(String workflowType);

	//method to process re-assign by the ADMIN
	public Response adminReAssign(HashMap<String, String> reAssignMap) throws Exception;
}
