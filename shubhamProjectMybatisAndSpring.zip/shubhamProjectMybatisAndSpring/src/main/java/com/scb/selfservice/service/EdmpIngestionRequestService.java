package com.scb.selfservice.service;

import com.scb.selfservice.domains.IngestionRequest;
import com.scb.selfservice.util.Response;

public interface EdmpIngestionRequestService {

	// method for save/insert the EdmpIngestionRequest
	public Response saveIngestionRequest(IngestionRequest ingestionRequest, Integer userId);

	// method to pull existing EdmpIngestionRequest based on reqId
	public Response findByReqId(Integer reqId);

	// method for update the EdmpIngestionRequest public Response
	public Response updateProposedCost(Integer reqId, Integer userId, Double proposedCost);

}
