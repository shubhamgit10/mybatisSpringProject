package com.scb.selfservice.domains;

import java.util.List;

public class AdRoleGroup {
	
	public String bizFunctId;
	
	public String bizFuncName;
	
	public List<String> adGroupName;

	public String getBizFunctId() {
		return bizFunctId;
	}

	public void setBizFunctId(String bizFunctId) {
		this.bizFunctId = bizFunctId;
	}

	public String getBizFuncName() {
		return bizFuncName;
	}

	public void setBizFuncName(String bizFuncName) {
		this.bizFuncName = bizFuncName;
	}

	public List<String> getAdGroupName() {
		return adGroupName;
	}

	public void setAdGroupName(List<String> adGroupName) {
		this.adGroupName = adGroupName;
	}

}
