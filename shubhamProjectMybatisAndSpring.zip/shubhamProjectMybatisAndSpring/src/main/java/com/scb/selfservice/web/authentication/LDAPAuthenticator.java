/**
 * 
 */
package com.scb.selfservice.web.authentication;

import java.text.MessageFormat;

import javax.naming.NamingEnumeration;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.springframework.ldap.BadLdapGrammarException;
import org.springframework.ldap.core.support.BaseLdapPathContextSource;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.ldap.DefaultSpringSecurityContextSource;

/**
 * LDAPAuthenticator to authenticate the user using LDAP
 * 
 * @author Amarnath BB
 *
 */

public class LDAPAuthenticator {
	
	protected DefaultSpringSecurityContextSource contextSource;

	protected String userDNPattern;
	
	protected String ldapURL;
	
	/**
	 * Method to get userDN Pattern
	 * @return
	 */
	public String getUserDNPattern() {
		return userDNPattern;
	}


	public void setUserDNPattern(String userDNPattern) {
		this.userDNPattern = userDNPattern;
	}


	/**
	 * Method to authenticate the user using LDAP
	 * @param UserId
	 * @param password
	 * @return
	 */
	public boolean authenticate(String userId, String password) throws Exception {
		String filter = "(objectclass=scbPerson)";
		DirContext ctx = null;
		String userDn = new MessageFormat(userDNPattern).format(new String[] { userId });

		try {
			if (contextSource == null) {
				contextSource = new DefaultSpringSecurityContextSource(ldapURL);
				contextSource.afterPropertiesSet();
			}
			ctx = contextSource.getContext(userDn, password);
			SearchControls ctls = new SearchControls();
			ctls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			ctls.setReturningAttributes(new String[] { "logindisabled", "uid" });

			NamingEnumeration<SearchResult> searchResults = ctx.search(userDn, filter, ctls);
			if (searchResults.hasMoreElements()) { // get the first result
				SearchResult r = searchResults.next();
				if (ctx != null) ctx.close();
				return true;
			}
			throw new AuthenticationCredentialsNotFoundException("LDAP User attributes couldn't be fetched");

		} catch (javax.naming.NamingException e) {
			e.printStackTrace();
			if (e.getClass().equals(javax.naming.AuthenticationException.class)) {
				throw new BadCredentialsException("Invalid UserId or Password");				
			}
			else {
				throw new BadCredentialsException("Invalid UserId or Password");
			}
		} catch (org.springframework.ldap.AuthenticationException ae) {
			ae.printStackTrace();
			String msg = ae.getMessage();
			if (msg.contains("locked"))
				throw new BadCredentialsException("The Account has been locked due to too many Authentication Failure.");
			throw new BadCredentialsException("Invalid UserId or Password");
		}
		catch (org.springframework.ldap.CommunicationException ce) {
			ce.printStackTrace();
			throw new BadLdapGrammarException("Unable to Connect to LDAP/OUD Server");
		}
		catch (Exception ex) {
			ex.printStackTrace();
			throw new AuthenticationCredentialsNotFoundException ("Error in User Authentication to LDAP");

		} finally {
			try {
				if (ctx != null)
					ctx.close();
			} catch (Exception ex) {
			}
		}
	}


	/**
	 * @return the contextSource
	 */
	public BaseLdapPathContextSource getContextSource() {
		return contextSource;
	}


	/**
	 * @param contextSource the contextSource to set
	 */
	public void setContextSource(DefaultSpringSecurityContextSource contextSource) {
		this.contextSource = contextSource;
	}
	
	/**
	 * @return the ldapURL
	 */
	public String getLdapURL() {
		return ldapURL;
	}


	/**
	 * @param ldapURL the ldapURL to set
	 */
	public void setLdapURL(String ldapURL) {
		this.ldapURL = ldapURL;
	}

}
