package com.scb.selfservice.service.impl;

import java.sql.Timestamp;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.DemoMapper;
import com.scb.selfservice.dao.td.mapper.DemoTDMapper;
import com.scb.selfservice.service.DemoService;

@Service
public class DemoServiceImpl implements DemoService {

	private static Logger logger = LogManager.getLogger(DemoServiceImpl.class);

	@Autowired
	DemoMapper demoMapper;

	@Autowired
	DemoTDMapper demoTDMapper;

	public Timestamp getCurrentTime() {
		logger.debug("Inside getCurrentTime Service");
		return demoMapper.getCurrentTime();
	}

	/**
	 * Method to invoked Teradata DB Mapper
	 * 
	 * @return
	 */
	@Transactional(value = "transactionManagerTD", propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public Timestamp getCurrentTimeTeradata() {
		return demoTDMapper.getCurrentTime();
	}

}
