package com.scb.selfservice.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
	@ComponentScan(basePackages = "com.scb.selfservice.config")
	@PropertySource("classpath:application.properties")
	public class PropertyFileCongifuration {
	  @Value("${db.driverClassName}")
	  private String driverClassName;
	  @Value("${db.url}")
	  private String url;
	  @Value("${db.username}")
	  private String userName;
	  @Value("${db.password}")
	  private String pwd;
//		private PropertyFileCongifuration(String driverClassName,String url,String userName,String pwd) {
//			this.driverClassName=driverClassName;
//			this.url=url;
//			this.userName=userName;
//			this.pwd=pwd;
//		}
	  @Bean
	  public DataSource dataSource() {
	    DriverManagerDataSource ds = new DriverManagerDataSource();
	    ds.setDriverClassName(driverClassName);
	    ds.setUrl(url);
	    ds.setUsername(userName);
	    ds.setPassword(pwd);
	    return ds;
	  }
	}

