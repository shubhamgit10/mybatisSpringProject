package com.scb.selfservice.model.RangerPolicy;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;

/**
 * 
 * @author 1610601
 *
 */

@JsonAutoDetect(fieldVisibility = Visibility.ANY)
public class RangerPolicyHbaseResourcesModel extends RangerPolicyResourcesModel implements Serializable  {

    private RangerPolicyResourceSupportingModel columnFamily;
    private RangerPolicyResourceSupportingModel column;
    private RangerPolicyResourceSupportingModel table;

    /**
     *
     */
    public RangerPolicyHbaseResourcesModel() {
        super();
        this.columnFamily = new RangerPolicyResourceSupportingModel();
        this.column = new RangerPolicyResourceSupportingModel();
        this.table = new RangerPolicyResourceSupportingModel();
    }

    /**
     * @param database
     * @param column
     * @param table
     */
    public RangerPolicyHbaseResourcesModel(RangerPolicyResourceSupportingModel columnFamily,
                                      RangerPolicyResourceSupportingModel column, 
                                      RangerPolicyResourceSupportingModel table) {
        super();
        this.columnFamily = columnFamily;
        this.column = column;
        this.table = table;
    }

    public RangerPolicyResourceSupportingModel getColumnFamily() {
        return columnFamily;
    }

    public void setColumnFamily(RangerPolicyResourceSupportingModel columnFamily) {
        this.columnFamily = columnFamily;
    }

    public RangerPolicyResourceSupportingModel getColumn() {
        return column;
    }

    public void setColumn(RangerPolicyResourceSupportingModel column) {
        this.column = column;
    }

    public RangerPolicyResourceSupportingModel getTable() {
        return table;
    }

    public void setTable(RangerPolicyResourceSupportingModel table) {
        this.table = table;
    }

    @Override
    public String toString() {
        return "RangerPolicyHbaseResourcesModel [columnFamily=" + columnFamily + ", column=" + column + ", table=" + table + "]";
    }
}
