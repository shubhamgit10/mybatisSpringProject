/**
 * 
 */
package com.scb.selfservice.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Amarnath BB
 *
 */
public class UserDetails {
	
	protected String userId;
	protected String firstName;
	protected String lastName;
	protected String emailAddress;
	protected String status;
	protected UserDetails lineManager;
	protected List<Roles> roles = new ArrayList<Roles>();
	
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}
	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the roles
	 */
	public List<Roles> getRoles() {
		return roles;
	}
	/**
	 * @param roles the roles to set
	 */
	public void setRoles(List<Roles> roles) {
		this.roles = roles;
	}
	/**
	 * @return the lineManager
	 */
	public UserDetails getLineManager() {
		return lineManager;
	}
	/**
	 * @param lineManager the lineManager to set
	 */
	public void setLineManager(UserDetails lineManager) {
		this.lineManager = lineManager;
	}

}
