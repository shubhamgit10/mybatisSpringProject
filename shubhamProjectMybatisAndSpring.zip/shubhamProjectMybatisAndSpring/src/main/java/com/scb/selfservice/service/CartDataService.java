package com.scb.selfservice.service;

import java.util.List;

import com.scb.selfservice.domains.DeleteCart;
import com.scb.selfservice.domains.EDMPCartConsumptionRequest;
import com.scb.selfservice.util.Response;

public interface CartDataService {

	public Response addToCart(List<EDMPCartConsumptionRequest> eDMPCartConsumptionRequest,Integer userId);
	
	public Response getCartData(Integer requestId);
	
	//method to deleteCart (that is already added to Cart)
	public Response deleteCart(DeleteCart deleteCart);
}
