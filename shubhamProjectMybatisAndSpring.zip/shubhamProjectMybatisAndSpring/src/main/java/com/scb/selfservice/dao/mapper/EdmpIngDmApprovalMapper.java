package com.scb.selfservice.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.IngestionDmApproval;


public interface EdmpIngDmApprovalMapper {
	
	
public int saveDmApprovalRequest(@Param("IngestionDmApproval") IngestionDmApproval ingestionDmApproval);
	
	//method to pull existing IngestionSolArchApproval based on reqId
		public IngestionDmApproval findByRequestId(@Param("reqId") Integer reqId);
		
		//method for updating IngestionSolArchApproval Request
		public int updateDmApprovalRequest(@Param("IngestionDmApproval") IngestionDmApproval ingestionDmApproval);
	

}
