package com.scb.selfservice.scheduler;

import com.scb.selfservice.workflow.service.ExecutionContext;

public interface TimeScheduler {
	 
	   public void display(ExecutionContext context);

}
