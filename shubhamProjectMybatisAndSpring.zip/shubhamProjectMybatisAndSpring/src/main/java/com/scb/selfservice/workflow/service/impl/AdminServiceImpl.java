package com.scb.selfservice.workflow.service.impl;

import static com.scb.selfservice.util.WorkflowConstants.DMUSER;

import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.AdminMapper;
import com.scb.selfservice.dao.mapper.WorkflowMapper;
import com.scb.selfservice.domains.MyApprovalList;
import com.scb.selfservice.domains.MyrequestData;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.workflow.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {

	private static Logger logger = LogManager.getLogger(AdminServiceImpl.class);
	
	@Autowired
	WorkflowRequestServiceImpl workflowRequestService;
	@Autowired
	AdminMapper adminMapper;
	@Autowired
	WorkflowMapper workflowMapper;

	/*
	 * implementation for getting all approvals for ADMIN
	 */
	@Override
	public Response getAdminApprovalList(String workflowType) {
		Response response = new Response();
		logger.info("STARTED getAdminApprovalList");
		try {
			Integer workflowId = workflowRequestService.getWorkflowId(workflowType);
			List<MyApprovalList> myApprovalList = adminMapper.getAdminRequests(workflowId,workflowType);
			logger.info("EXITING getAdminApprovalList");
			if (myApprovalList.isEmpty() || null== myApprovalList) {
				response.setStatusCode(HttpStatus.NO_CONTENT.value());
				response.setStatus("NO CONTENT");
				response.setResponse("No data found for the user");
			} else {
				response.setStatusCode(HttpStatus.OK.value());
				response.setStatus("SUCCESS");
				response.setResponse(myApprovalList);
			}
		} catch (Exception ex) {
			logger.info("AdminServiceImpl getAdminApprovalList exception for " +
						workflowType + " with " + ex.getMessage());
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus("NO CONTENT");
			response.setResponse("No data found for the user");
		}
		
		return response;
	}

	/*
	 * implementation for re-assign scenarios by the ADMIN
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public Response adminReAssign(HashMap<String, String> reAssignMap) throws Exception {
		logger.info("STARTED adminReAssign");
		//update workflow_request_steps
		Integer respNo = adminMapper.updateWorkflowRequestSteps(Integer.parseInt(reAssignMap.get("psid")),
				Integer.parseInt(reAssignMap.get("requestId")),
				reAssignMap.get("stepId"));
		if (respNo == 0) {
			logger.info("EXCEPTION - adminReAssign with updateWorkflowRequestSteps");
			throw new Exception ("Admin - Updating WorkflowRequestSteps failed");
		}

		if (StringUtils.isNotEmpty(reAssignMap.get("stepPendingGrp")) && 
				reAssignMap.get("stepPendingGrp").equalsIgnoreCase(DMUSER)) {
			//update edmp_consumption_request
			respNo = adminMapper.updateEdmpConsumptionRequest(reAssignMap.get("psid"),
					Integer.parseInt(reAssignMap.get("requestId")));
			if (respNo == 0) {
				logger.info("EXCEPTION - adminReAssign with EdmpConsumptionRequest");
				throw new Exception ("Admin - Updating Edmp_Consumption_Request failed");
			}
		}
		
		logger.info("STARTED adminReAssign");
		Response response = new Response();
		response.setStatusCode(HttpStatus.OK.value());
		response.setStatus("SUCCESS");
		response.setResponse("Admin - workflow - reassign - succcessful");
		return response;
	}

}
