package com.scb.selfservice.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.ViewPipelineMapper;
import com.scb.selfservice.domains.EDMPLookupTable;
import com.scb.selfservice.domains.IngestionRequest;
import com.scb.selfservice.domains.Pipelineview;
import com.scb.selfservice.domains.ViewPipeline;
import com.scb.selfservice.service.PopulateDropDownService;
import com.scb.selfservice.service.ViewPipelineService;
import com.scb.selfservice.util.Response;

@Service
public class ViewPipelineServiceImpl implements ViewPipelineService {

	private static Logger logger = LogManager.getLogger(FileDownloadServiceImpl.class);

	@Autowired
	ViewPipelineMapper viewPipelineMapper;

	@Autowired
	PopulateDropDownService populateDropDownService;

	private HashMap<String, String> getLookupData() {
		logger.info("STARTED EdmpFileDownloadServiceImpl::getLookupData");
		HashMap<String, String> dropDownData = new HashMap<>();
		Response response = populateDropDownService.getDropDownValues();
		List<EDMPLookupTable> lookupTables = (List<EDMPLookupTable>) response.getResponse();
		String key = null;
		String value = null;
		for (EDMPLookupTable edmpLookupTable : lookupTables) {
			key = edmpLookupTable.getTableName() + edmpLookupTable.getCode();
			value = edmpLookupTable.getDescription();
			dropDownData.put(key, value);
		}
		return dropDownData;
	}

	@Override
	public List<Pipelineview> pullData() {
		logger.info("STARTED ViewPipelineController::pullData");
		HashMap<String, String> dropDownData = getLookupData();
		List<Pipelineview> fileData = viewPipelineMapper.findByRequestId();
		List<Pipelineview> fileData1 = new ArrayList<>();
		String key = StringUtils.EMPTY;
		String value = StringUtils.EMPTY;

		for (Pipelineview pipelineView : fileData) {

			key = pipelineView.getBusinessStream();
			value = dropDownData.get("Business Stream" + key);
			pipelineView.setBusinessStream(value);

			key = pipelineView.getFundingAvenue();
			value = dropDownData.get("Funding Avenue" + key);
			pipelineView.setFundingAvenue(value);

			key = pipelineView.getBenefitCatagory();
			value = dropDownData.get("Benefit Category" + key);
			pipelineView.setBenefitCatagory(value);

			fileData1.add(pipelineView);
		}
		logger.info("EXITING EdmpFileDownloadServiceImpl::pullData");
		return fileData1;
	}

}
