/**
 * 
 */
package com.scb.selfservice.dao.mapper;

import java.sql.Timestamp;

/**
 * @author Amarnath
 *
 */
public interface DemoMapper {
	
	public Timestamp getCurrentTime();

}
