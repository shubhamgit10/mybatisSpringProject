package com.scb.selfservice.domains;

public class IngestionSolArchApproval {
	
	private Integer reqId;
	
	private String proposedSolution;
	
	private String srcDataSys;
	
	private String srcSysCommunications;
	
	private String solutionComments;
	
	private Integer requestCreatedBy;
	
	private String userAction;
	
	private String stepId;
	
	private String stepName;
	
	private String workflowType;
	
	private Integer estimationId;
	
	private String sourceType;
	
	
	
	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public Integer getReqId() {
		return reqId;
	}

	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}

	public String getProposedSolution() {
		return proposedSolution;
	}

	public void setProposedSolution(String proposedSolution) {
		this.proposedSolution = proposedSolution;
	}

	public String getSrcDataSys() {
		return srcDataSys;
	}

	public void setSrcDataSys(String srcDataSys) {
		this.srcDataSys = srcDataSys;
	}

	public String getSrcSysCommunications() {
		return srcSysCommunications;
	}

	public void setSrcSysCommunications(String srcSysCommunications) {
		this.srcSysCommunications = srcSysCommunications;
	}

	public String getSolutionComments() {
		return solutionComments;
	}

	public void setSolutionComments(String solutionComments) {
		this.solutionComments = solutionComments;
	}

	public Integer getRequestCreatedBy() {
		return requestCreatedBy;
	}

	public void setRequestCreatedBy(Integer requestCreatedBy) {
		this.requestCreatedBy = requestCreatedBy;
	}

	public String getUserAction() {
		return userAction;
	}

	public void setUserAction(String userAction) {
		this.userAction = userAction;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public String getStepName() {
		return stepName;
	}

	public void setStepName(String stepName) {
		this.stepName = stepName;
	}

	public String getWorkflowType() {
		return workflowType;
	}

	public void setWorkflowType(String workflowType) {
		this.workflowType = workflowType;
	}
	
	public Integer getEstimationId() {
		return estimationId;
	}

	public void setEstimationId(Integer estimationId) {
		this.estimationId = estimationId;
	}

	@Override
	public String toString() {
		return "IngestionSolArchApproval [reqId=" + reqId + ", proposedSolution=" + proposedSolution + ", srcDataSys="
				+ srcDataSys + ", srcSysCommunications=" + srcSysCommunications + ", solutionComments="
				+ solutionComments + ", requestCreatedBy=" + requestCreatedBy + ", userAction=" + userAction
				+ ", stepId=" + stepId + ", stepName=" + stepName + ", workflowType=" + workflowType + ", estimationId="
				+ estimationId + ", sourceType=" + sourceType + "]";
	}

	
	
}
