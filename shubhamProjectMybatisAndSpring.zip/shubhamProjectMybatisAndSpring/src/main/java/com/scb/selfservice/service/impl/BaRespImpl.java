package com.scb.selfservice.service.impl;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.scb.selfservice.dao.mapper.IngestionDynamicMapper;
import com.scb.selfservice.dao.mapper.WorkflowMapper;
import com.scb.selfservice.domains.BizAnylstResponse;
import com.scb.selfservice.domains.IngestionInput;
import com.scb.selfservice.domains.WorkflowIdType;
import com.scb.selfservice.service.UserResponseService;
import com.scb.selfservice.util.Response;

@Service(value = "BizAnalystResp")
public class BaRespImpl implements UserResponseService {
	
	
	private static Logger logger = LogManager.getLogger(BaRespImpl.class);

	@Autowired
	WorkflowMapper workflowMapper;

	@Autowired
	IngestionDynamicMapper idynMapper;

	/**
	 *
	 */
	@Override
	public Response executeSave(IngestionInput ingestionInput) {

		logger.info("inside BaRespImpl:: excuteSave Method");

		Response isaResponse = new Response();

		try {
			isaResponse = saveBaResp(ingestionInput);

		} catch (Exception e) {

			logger.info("Exception::" + e);
		}

		return isaResponse;
	}

	/**
	 * @param ingestionInput
	 * @return
	 * @throws Exception
	 */
	public Response saveBaResp(IngestionInput ingestionInput) throws Exception {

		logger.info("START BaRespImpl::saveBaResp");
		Response isaResponse = new Response();

		HashMap<String, Object> hm = (HashMap<String, Object>) ingestionInput.getParams();

		hm.put("reqId", ingestionInput.getReqId());

		hm.put("stepId", ingestionInput.getStepId());

		WorkflowIdType workflowId = workflowMapper.getWorkflowId(ingestionInput.getWorkflowType());

		int Id = workflowId.getWorkflowId();

		hm.put("workflowId", Id);

		hm.put("userAction", ingestionInput.getUserAction());

		hm.put("requestCreatedBy", ingestionInput.getUserId());
		
		
		hm.put("remarks", ingestionInput.getRemarks());


		BizAnylstResponse crObj = idynMapper.bAfindByReqId(ingestionInput.getReqId());

		if (crObj == null) {
			logger.info("START it is a new entry for new request..." + ingestionInput.getReqId());

			int saveStatus = idynMapper.saveBaRequest(hm); // insert

			isaResponse = getActionStatus("save", saveStatus, ingestionInput.getReqId());

			logger.info("EXIT save request");
		} else {
			logger.info("START it an existing request..." + ingestionInput.getReqId());

			int updateStatus = idynMapper.updateBaRequest(hm); // update

			isaResponse = getActionStatus("update", updateStatus, ingestionInput.getReqId());

			logger.info("EXIT update request");
		}

		logger.info("EXIT BaRespImpl::saveDmApprovalResp");
		return isaResponse;

	}

	/**
	 * @param type
	 * @param saveStatus
	 * @param reqId
	 * @return
	 */
	private Response getActionStatus(String type, int saveStatus, int reqId) {
		Response response = new Response();
		if (saveStatus == 1) {
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus(HttpStatus.OK.toString());
			response.setResponse(reqId + "Request id " + (type.equals("save") ? "INSERTED" : "UPDATED"));
		} else {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
			response.setResponse("!!!Action not taken!!!");
		}
		return response;
	}
	
	/**
	 *
	 */
	@Override
	public Response fetchApprovalResponse(IngestionInput ingestionInput) {
		BizAnylstResponse dmResponse = idynMapper.bAfindByReqId(ingestionInput.getReqId());
		//Response dmResponse = eiReqService.findByReqId(requestId);
		Response response = new Response();
		response.setResponse(dmResponse);
		return response;
	}	

}
