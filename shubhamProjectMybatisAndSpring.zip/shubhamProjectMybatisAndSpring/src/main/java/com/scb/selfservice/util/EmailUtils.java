package com.scb.selfservice.util;

import java.sql.Timestamp;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.selfservice.dao.mapper.email.EmailMapper;
import com.scb.selfservice.model.ConsumptionPending;
import com.scb.selfservice.workflow.service.impl.WorkflowRequestServiceImpl;

@Service
public class EmailUtils {

	private static Logger logger = LogManager.getLogger(EmailUtils.class);
	
	@Autowired
	EmailMapper emailMapper;

	@Autowired
	WorkflowRequestServiceImpl impl;

	public void process() throws Exception {
		List<ConsumptionPending> cplist= emailMapper.getConsumptionPendingReqs(impl.getWorkflowId("CONSUMPTION"));
		for (ConsumptionPending item : cplist) {
			logger.info("--->" + item);
//			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
//		    Date firstDate = sdf.parse("06/24/2017");
//		    Date secondDate = sdf.parse("06/30/2017");
		 
		    //long diffInMillies = Math.abs(item.getStartTime().getTime() - LocalTime.now().minusHours(24));
		    //long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
		}

	}
	public static void main(String[] args ) throws Exception {
		EmailUtils obj = new EmailUtils();
		obj.process();
	}
//	public static void main(String[] args) throws Exception {
//		System.out.println(LocalTime.now());
//		System.out.println(LocalTime.now().minusHours(24));
//		System.out.println(new Timestamp(System.currentTimeMillis()));
//		List<ConsumptionPending> cplist= new ArrayList<>();
//		//.getConsumptionPendingReqs(impl.getWorkflowId("CONSUMPTION"));
//		java.util.Date date = new java.util.Date();
//		Timestamp timestamp1 = new Timestamp(date.getTime());
//
//		// create a second time stamp
//		Timestamp timestamp2 = getTS("2020-09-24 05:20:29.187000000");
//
//		long milliseconds = timestamp2.getTime() - timestamp1.getTime();
//		int seconds = (int) milliseconds / 1000;
//
//		int hours = seconds / 3600;
//		int minutes = (seconds % 3600) / 60;
//		seconds = (seconds % 3600) % 60;
//
//		System.out.println("timestamp1: " + timestamp1);
//		System.out.println("timestamp2: " + timestamp2);
//
//		System.out.println("Difference: ");
//		System.out.println(" Hours: " + hours);
//		System.out.println(" Minutes: " + minutes);
//		System.out.println(" Seconds: " + seconds);
//		
//		
//		
//		
//		
//		
//		ConsumptionPending cp = new ConsumptionPending();
//		cp.setStartTime(getTS("24-09-20 05:20:29.187000000 AM"));
//		cp.setLapsedTime(24);
//		cplist.add(cp);
//		cp.setStartTime(getTS("25-09-20 07:08:19.047000000 AM"));
//		cp.setLapsedTime(24);
//		cplist.add(cp);
//		cp.setStartTime(getTS("26-09-20 03:57:59.411000000 PM"));
//		cp.setLapsedTime(24);
//		cplist.add(cp);
//		cp.setStartTime(getTS("26-09-20 05:06:33.299000000 PM"));
//		cp.setLapsedTime(24);
//		cplist.add(cp);
//		cp.setStartTime(getTS("29-09-20 05:15:11.166000000 PM"));
//		cp.setLapsedTime(24);
//		cplist.add(cp);
//		cp.setStartTime(getTS("28-09-20 02:24:02.731000000 PM"));
//		cp.setLapsedTime(24);
//		cplist.add(cp);
//		
//		//process(cplist);
//	}
	private static Timestamp getTS(String dt) {
		Timestamp ts = Timestamp.valueOf(dt);
		return ts;
	}
}
