package com.scb.selfservice.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.SearchDataSource;

public interface SearchMapper {

	//Search based on DataSource
	public List<SearchDataSource> searchDataSource(@Param("dsSearchItem") String dsSearchItem , @Param("startNum") int startNum, @Param("endNum") int endNum);

	//Search based on DataSet
	public List<SearchDataSource> searchDataSet(@Param("searchDataSet") String searchDataSet,@Param("startNum") int startNum, @Param("endNum") int endNum);

	//Search based on Attributes
	public List<SearchDataSource> searchAttribute(@Param("searchAttribute") String searchAttribute,@Param("startNum") int startNum, @Param("endNum") int endNum);
	
	//Search based on ApplyFilter
	public List<SearchDataSource> searchApplyFilter(@Param("whereClause") String whereClause,@Param("startNum") int startNum, @Param("endNum") int endNum);
}
