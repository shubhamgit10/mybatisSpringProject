package com.scb.selfservice.service;

import com.scb.selfservice.domains.FileUpload;
import com.scb.selfservice.util.Response;

/*
 * interface for file upload service
 */
public interface FileUploadService {

//	public Response upsertFile(List<FileUpload> upsertList);
	
	public Response uploadFile(FileUpload fileUpload);

	//methor to delete the uploaded file
	public Response deleteFile(Integer uploadId) throws Exception;
}
