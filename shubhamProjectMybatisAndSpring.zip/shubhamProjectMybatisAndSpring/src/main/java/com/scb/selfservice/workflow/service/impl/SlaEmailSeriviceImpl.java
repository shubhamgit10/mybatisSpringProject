package com.scb.selfservice.workflow.service.impl;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.email.EmailMapper;
import com.scb.selfservice.model.AuditEmailSLA;
import com.scb.selfservice.model.ConsumptionPending;
import com.scb.selfservice.service.ConsumerRequestEmailService;
import com.scb.selfservice.workflow.service.SlaEmailSerivice;

/*
 * Class for workflowRequest related services like 
 * 	initial steps
 *  reject
 *  approve
 */
@Service
public class SlaEmailSeriviceImpl implements SlaEmailSerivice {
	
	private static Logger logger = LogManager.getLogger(SlaEmailSeriviceImpl.class);
	
	@Autowired
	EmailMapper emailMapper;

	@Autowired
	WorkflowRequestServiceImpl impl;

	@Autowired
	ConsumerRequestEmailService cres;

	@Override
	@Transactional(rollbackFor=Exception.class)
	public String sendSlaEmail(String workflowType) throws Exception {
		String status = "SUCCESS";

		//all the pending reqs//
		List<ConsumptionPending> cplist= emailMapper.getConsumptionPendingReqs(impl.getWorkflowId(workflowType));
		try {
		for (ConsumptionPending item : cplist) {
			logger.info("--->" + item);
			LocalDateTime date = LocalDateTime.now();
			
			//if falling on Monday - consider Sat/Sun day also//
			if (date.getDayOfWeek().getValue() == 1)
				item.setLapsedTime(item.getLapsedTime() * 3);

			Duration duration = Duration.between(item.getStartTime().toLocalDateTime(), date);

			if(item.getStartTime().toLocalDateTime().isAfter(date)) {

				logger.info("Mail can't be sent");
			} else if((item.getStartTime().toLocalDateTime().isBefore(date)) && (duration.toHours() > item.getLapsedTime())) {
				if (null == item.getAttempt() || item.getAttempt() < 3) {
					cres.sendStatusMail(item.getReqId(),item.getStepId(), "PENDING");
					//its time to update workflow_request_steps for attempt no//
					AuditEmailSLA audit = popolateAuditEmailSLA(item);
					int update = emailMapper.updateWorkflowRequestSteps(item.getReqId(), item.getStepId(), audit.getAttempt());
					if (update == 0) {
						logger.info("email sla ---- update failed for wrs");
					}
					logger.info("AUDIT EMAIL STEP - " + audit);
					int row = emailMapper.insertAuditEmailSla(audit);
					logger.info("Mail Sent");
				} else {
					logger.info("Mail NOT Sent being already reached the max no of atempts for " + item);
				}
			}
			else
				logger.info(" mail not sent");   
		} 
		}catch (Exception ex) {
			logger.info("EXCEPTION while processing email on SLA" + ex.getMessage());
			throw ex;
		}
		return status;
	}

	//populate audit object for auditing email sla table
	private AuditEmailSLA popolateAuditEmailSLA(ConsumptionPending item) {
		AuditEmailSLA obj = new AuditEmailSLA();
		if (null == item.getAttempt()) {
			obj.setAttempt(1);
		} else {
			obj.setAttempt(item.getAttempt() + 1);
		}
		obj.setEmailStatus("SUCCESS");
		obj.setReqId(item.getReqId());
		obj.setStepId(item.getStepId());
		obj.setWorkflowId(item.getWorkflowId());
		return obj;
	}
}
