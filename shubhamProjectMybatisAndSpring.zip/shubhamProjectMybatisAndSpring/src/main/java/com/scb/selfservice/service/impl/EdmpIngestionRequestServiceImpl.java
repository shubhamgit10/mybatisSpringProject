package com.scb.selfservice.service.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.CartDataMapper;
import com.scb.selfservice.dao.mapper.EdmpIngestionRequestMapper;
import com.scb.selfservice.domains.EDMPSelfServiceReq;
import com.scb.selfservice.domains.IngestionRequest;
import com.scb.selfservice.domains.WorkflowRequest;
import com.scb.selfservice.service.EdmpIngestionRequestService;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.workflow.service.WorkflowRequestService;

@Service
public class EdmpIngestionRequestServiceImpl implements EdmpIngestionRequestService {

	private static Logger logger = LogManager.getLogger(EdmpIngestionRequestServiceImpl.class);

	@Autowired
	private EdmpIngestionRequestMapper eirMapper;

	@Autowired
	private CartDataMapper cartDataMapper;

	@Autowired
	WorkflowRequestService WorkflowRequestService;

	@Override
	@Transactional
	public Response saveIngestionRequest(IngestionRequest ingestionRequest, Integer userId) {

		logger.info("START EdmpIngestionRequestServiceImpl::saveIngestionRequest");
		Response ingestionResponse = new Response();
		Response response = new Response();
		Integer reqId = 0;
		Integer reqCreatedBy = 0;
		String userAction = ingestionRequest.getUserAction();
		EDMPSelfServiceReq edmpSsReq = new EDMPSelfServiceReq();
		logger.info("Expected delivery date..." + ingestionRequest.getExpectedDeliveryDate());

		ingestionRequest.setRequestCreatedBy(userId);
		IngestionRequest irObj = eirMapper.findByRequestId(ingestionRequest.getReqId());

		if (irObj == null) {
			logger.info("START it is a new entry for new request..." + ingestionRequest.getReqId());

			/*
			 * if ("SAVE".equalsIgnoreCase(userAction)) { edmpSsReq.setStatus("DRAFT"); }
			 * else { edmpSsReq.setStatus("SUMBITTED"); }
			 */
			edmpSsReq.setStatus(userAction);
			edmpSsReq.setRequestCreatedBy(ingestionRequest.getRequestCreatedBy());
			edmpSsReq.setWorkflowType("INGESTION");
			logger.info("RequestID geenrated for cart: " + edmpSsReq);

			int edmp_ss_req_value = cartDataMapper.insertEDMPSelfService(edmpSsReq);
			logger.info("RequestID geenrated for cart: " + edmp_ss_req_value);
			response = validate(edmpSsReq.getReqId());
			reqId = edmpSsReq.getReqId();
			if (response.getStatusCode() == 200) {
				ingestionRequest.setReqId(edmpSsReq.getReqId());
				logger.info("It is a new entry for new request saveIngestionRequest" + ingestionRequest);
				int saveStatus = eirMapper.saveIngestionRequest(ingestionRequest); // insert
				ingestionResponse = getActionStatus("save", saveStatus, ingestionRequest.getReqId());
				logger.info("Done with inserting tables...EDMP_SERLFSERVICE_REQ and EDMP_INJESTION_REQ_DETAILS");

			} else {
				logger.info("Failed to insert into: EDMP_SERLFSERVICE_REQ and EDMP_INJESTION_REQ_DETAILS");
				logger.info(response);
			}
			logger.info("EXIT save request");
		} else {
			reqId = ingestionRequest.getReqId();
			// edmpSsReq.setStatus(userAction);
			int status = eirMapper.updateEDMPSelfService(ingestionRequest);
			logger.info("START it an existing request..." + ingestionRequest.getReqId());
			int updateStatus = eirMapper.updateIngestionRequest(ingestionRequest); // update
			ingestionResponse = getActionStatus("update", updateStatus, ingestionRequest.getReqId());
			logger.info("EXIT update request");
		}
		if ("SUBMITTED".equalsIgnoreCase(userAction)) {
			reqCreatedBy = ingestionRequest.getRequestCreatedBy();
			String summary = ingestionRequest.getRequestSummary();
			WorkflowRequest WorkflowRequest = prepareWorkflowRequest(reqId, reqCreatedBy,summary);
			try {
				WorkflowRequestService.insertWorkFlowRequest(WorkflowRequest, 0);
			} catch (Exception e) {
				logger.info("EXCEPTION while iniating workflow: " + e.getMessage());
			}
		}

		logger.info("EXIT EdmpIngestionRequestServiceImpl::saveIngestionRequest");
		return ingestionResponse;
	}

	private WorkflowRequest prepareWorkflowRequest(Integer reqId, Integer requestCreatedBy,String summary ) {

		WorkflowRequest WorkflowRequest = new WorkflowRequest();

		WorkflowRequest.setReqId(reqId);
		WorkflowRequest.setWorkflowId(102);
		WorkflowRequest.setStatus("PENDING");
		WorkflowRequest.setRemarks(summary);
		WorkflowRequest.setRequestCreatedBy(requestCreatedBy);
		WorkflowRequest.setLastActedStepId("");
		logger.info("Prepareing for workflow Request");

		return WorkflowRequest;

	}

	private Response validate(int reqId) {
		Response response = new Response();
		if (reqId != 0) {
			IngestionRequest obj = new IngestionRequest();
			obj.setReqId(reqId);
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus("Success");
			response.setResponse(obj);
		} else {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus("FAILURE");
			response.setResponse("NA");
		}
		return response;
	}

	private Response getActionStatus(String type, int saveStatus, int reqId) {
		Response response = new Response();
		if (saveStatus == 1) {
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus(HttpStatus.OK.toString());
			response.setResponse(reqId + "Request id " + (type.equals("save") ? "INSERTED" : "UPDATED"));
		} else {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
			response.setResponse("!!!Action not taken!!!");
		}
		return response;
	}

	@Override
	@Transactional
	public Response findByReqId(Integer reqId) {
		IngestionRequest cr = eirMapper.findByRequestId(reqId);
		Response response = new Response();
		if (cr != null) {
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus(HttpStatus.OK.toString());
			response.setResponse(cr);
		} else {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
		}
		return response;
	}

	@Override
	@Transactional
	public Response updateProposedCost(Integer reqId, Integer userId, Double proposedCost) {
		int updateStatus = eirMapper.updateProposedCost(reqId, userId, proposedCost); // update
		Response response = new Response();
		if (updateStatus != 0) {
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus(HttpStatus.OK.toString());
			response.setResponse(updateStatus);
		} else {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
		}
		return response;
	}

}
