package com.scb.selfservice.service;

import java.util.Map;

public interface MailService {

    boolean sendMail(
            String fromAddress,
            String toAddress,
            String ccAddress,
            String subject,
            String template,
            Map<String, Object> params);
}
