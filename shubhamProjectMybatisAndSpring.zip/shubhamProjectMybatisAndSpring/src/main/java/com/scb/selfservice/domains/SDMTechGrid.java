package com.scb.selfservice.domains;

public class SDMTechGrid {
	
	private String reconDatasetName;
	private String reconSourceValue;
	private String reconTargetValue;
	
	public String getReconDatasetName() {
		return reconDatasetName;
	}
	public void setReconDatasetName(String reconDatasetName) {
		this.reconDatasetName = reconDatasetName;
	}
	public String getReconSourceValue() {
		return reconSourceValue;
	}
	public void setReconSourceValue(String reconSourceValue) {
		this.reconSourceValue = reconSourceValue;
	}
	public String getReconTargetValue() {
		return reconTargetValue;
	}
	public void setReconTargetValue(String reconTargetValue) {
		this.reconTargetValue = reconTargetValue;
	}
	@Override
	public String toString() {
		return "SDMTechGrid [reconDatasetName=" + reconDatasetName + ", reconSourceValue=" + reconSourceValue
				+ ", reconTargetValue=" + reconTargetValue + "]";
	}	
	
}
	
	