/**
 * 
 */
package com.scb.selfservice.service.impl;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.FileDownloadMapper;
import com.scb.selfservice.dao.mapper.RequestDetailsMapper;
import com.scb.selfservice.domains.FileData;
import com.scb.selfservice.domains.FileUpload;
import com.scb.selfservice.domains.WorkflowReqStepsAt;
import com.scb.selfservice.service.FileDownloadService;
import com.scb.selfservice.service.JIRAIntegrationService;
import com.scb.selfservice.util.CommonUtils;
import com.scb.selfservice.util.JiraUtils;
import com.scb.selfservice.workflow.service.WorkflowRequestService;

/**
 * @author 1565003
 *
 */
@Service
public class JIRAIntegrationServiceImpl implements JIRAIntegrationService {

	@Autowired
	private RequestDetailsMapper requestDetailsMapper;

	@Autowired
	FileDownloadService fileDownloadService;

	@Autowired
	FileDownloadMapper fileDownloadMapper;

	@Autowired
	WorkflowRequestService workflowRequestService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.selfservice.service.JIRAIntegrationService#createConsumptionJIRA(
	 * java.util.HashMap)
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	@Async
	public String createOrUpdateJiraDetails(String reqId, String stepId, String userId) {
		try {
			Thread.sleep(30000); // sleep for 30 sec so that outer transaction
									// is completed
		} catch (Exception ex) {
		}

		HashMap<String, String> requestInfo = requestDetailsMapper.getRequestDetails(reqId);
		HashMap<String, String> parentUserStep = requestDetailsMapper.getParentUserTypeStep(reqId, stepId);
		String jiraKey = null;
		if (requestInfo != null && requestInfo.get("JIRA_KEY") == null && parentUserStep != null
				&& "S0".equalsIgnoreCase(parentUserStep.get("STEP_ID"))) {
			List<HashMap<String, String>> tablesSubscribed = requestDetailsMapper.getDatasetSubscribed(reqId);
			JiraUtils jiraTask = new JiraUtils();
			try {
				jiraKey = jiraTask.createConsumptionJiraRequest(reqId, requestInfo, tablesSubscribed, userId);
				List<FileData> fileData = fileDownloadService.pullData(Integer.parseInt(reqId));
				ByteArrayInputStream in = CommonUtils.prepareXlsx(fileData);
				String fileName = CommonUtils.fileName(Integer.parseInt(reqId));
				jiraTask.addAttachement(jiraKey, fileName, in);
				requestDetailsMapper.updateJiraKey(jiraKey, reqId);
				createWorkRequestAuditEntry(reqId, userId, stepId, "SUCCESS",
						"JIRA - " + jiraKey + " created successfully");
			} catch (Exception ex) {
				createWorkRequestAuditEntry(reqId, userId, stepId, "FAILED", ex.getMessage());
			}
		} else if (requestInfo != null && requestInfo.get("JIRA_KEY") != null) {
			List<HashMap<String, String>> stepUserResponse = requestDetailsMapper.getStepUserResponse(reqId,
					parentUserStep.get("STEP_ID"));
			HashMap<String, String> commentsData = new HashMap<String, String>();
			Object stepActionedBy = (Object) parentUserStep.get("STEP_ACTIONED_BY");
			String userActioned = null;
			if (stepActionedBy != null && stepActionedBy instanceof BigDecimal)
				userActioned = ((BigDecimal) stepActionedBy).toString();
			String remarks = getUserResponse(stepUserResponse, "remarks");
			if (StringUtils.isEmpty(remarks))
				remarks = getUserResponse(stepUserResponse, "additionalRemarks");
			if (StringUtils.isEmpty(remarks))
				remarks = "";
			commentsData.put("REMARKS", parentUserStep.get("STEP_NAME") + " (" + userActioned + ") - " + remarks);
			String targetDate = getUserResponse(stepUserResponse, "date");
			if (StringUtils.isEmpty(targetDate))
				targetDate = getUserResponse(stepUserResponse, "revisedTargetDate"); 
			commentsData.put("TARGET_DATE", targetDate);
			String uploadedFile = getUserResponse(stepUserResponse, "FILE_ID");
			FileUpload uploadData = null;
			if (StringUtils.isNotEmpty(uploadedFile))
				uploadData = fileDownloadMapper.pullFile(Integer.parseInt(uploadedFile));

			List<String> reqActedUsers = requestDetailsMapper.getReqActedUsers(reqId);
			JiraUtils jiraTask = new JiraUtils();
			jiraTask.addComments(requestInfo.get("JIRA_KEY"), commentsData, reqActedUsers);
			if (uploadData != null) {
				jiraTask.addAttachement(requestInfo.get("JIRA_KEY"), uploadData.getFileName(),
						new ByteArrayInputStream(uploadData.getContent()));
			}
		}
		return jiraKey;
	}

	/**
	 * Iterate thru the response based on the attribute and retrieve the
	 * appropriate value
	 * 
	 * @param stepUserResponse
	 * @param attName
	 * @return
	 */
	protected String getUserResponse(List<HashMap<String, String>> stepUserResponse, String attName) {
		for (HashMap<String, String> resp : stepUserResponse) {
			Set<String> keys = resp.keySet();
			if (keys.contains("PROPERTY_NAME")) {
				String propName = resp.get("PROPERTY_NAME");
				if (propName.contains(attName) && StringUtils.isNotEmpty(resp.get("PROPERTY_VALUE")))
					return resp.get("PROPERTY_VALUE");
			}
		}
		return null;
	}

	/**
	 * Method to create workflow Request Audit
	 * 
	 * @param reqId
	 * @param userId
	 * @param stepId
	 * @param status
	 * @param remarks
	 */
	protected void createWorkRequestAuditEntry(String reqId, String userId, String stepId, String status,
			String remarks) {
		WorkflowReqStepsAt workflowReqStepsAt = new WorkflowReqStepsAt();
		workflowReqStepsAt.setReqId(Integer.parseInt(reqId));

		workflowReqStepsAt.setStepActionedBy(Integer.valueOf(userId));
		workflowReqStepsAt.setWorkflowId(workflowRequestService.getWorkflowRequestWorkflowId(Integer.parseInt(reqId)));
		workflowReqStepsAt.setStepId(stepId);
		workflowReqStepsAt.setStartTime(new Timestamp(System.currentTimeMillis()));
		workflowReqStepsAt.setStepPendingGrp(null);
		workflowReqStepsAt.setStatus("SUCCESS".equalsIgnoreCase(status) ? "COMPLETED" : status);
		workflowReqStepsAt.setRemarks(remarks);
		workflowRequestService.insertIntoWorkflowReqStepsAt(workflowReqStepsAt);
	}

}
