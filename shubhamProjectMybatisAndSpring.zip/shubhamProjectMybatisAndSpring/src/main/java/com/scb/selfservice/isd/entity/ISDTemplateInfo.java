package com.scb.selfservice.isd.entity;

import java.util.List;

/**
 * @author akuma400
 *
 */
public class ISDTemplateInfo {

	private String isdId;
	private String sheetName;
	private List<String> cellColumnNumber;
	private List<String> sequenceNumber;
	private List<String> columnName;
	private List<String> dbColumnName;
	private List<Boolean> nullable;
	
	public String getIsdId() {
		return isdId;
	}
	public void setIsdId(String isdId) {
		this.isdId = isdId;
	}
	public String getSheetName() {
		return sheetName;
	}
	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}
	public List<String> getCellColumnNumber() {
		return cellColumnNumber;
	}
	public void setCellColumnNumber(List<String> cellColumnNumber) {
		this.cellColumnNumber = cellColumnNumber;
	}
	public List<String> getSequenceNumber() {
		return sequenceNumber;
	}
	public void setSequenceNumber(List<String> sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}
	public List<String> getColumnName() {
		return columnName;
	}
	public void setColumnName(List<String> columnName) {
		this.columnName = columnName;
	}
	public List<String> getDbColumnName() {
		return dbColumnName;
	}
	public void setDbColumnName(List<String> dbColumnName) {
		this.dbColumnName = dbColumnName;
	}
	public List<Boolean> getNullable() {
		return nullable;
	}
	public void setNullable(List<Boolean> nullable) {
		this.nullable = nullable;
	}
	@Override
	public String toString() {
		return "ISDTemplateInfo [isdId=" + isdId + ", sheetName=" + sheetName + ", cellColumnNumber=" + cellColumnNumber
				+ ", sequenceNumber=" + sequenceNumber + ", columnName=" + columnName + ", dbColumnName=" + dbColumnName
				+ ", nullable=" + nullable + "]";
	}
	
	
	
	
	
	
}
