package com.scb.selfservice.dao.mapper.ingestion;

import java.util.List;

import org.apache.ibatis.annotations.Param;

/**
 * 
 * @author shubhasi Mapper Interface having methods to return
 */
public interface ISDSummaryMapper {

	public List<String> getNoExistingDatasets(@Param("itamId") Integer itamId, @Param("systemName") String systemName,
			@Param("reqId") int reqId);

	public List<String> getNoNewDatasets(@Param("itamId") Integer itamId, @Param("systemName") String systemName,
			@Param("reqId") int reqId);

	public List<String> getNoExistingAttributes(@Param("itamId") Integer itamId, @Param("systemName") String systemName,
			@Param("reqId") int reqId);

	public List<String> getNoNewAttributes(@Param("itamId") Integer itamId, @Param("systemName") String systemName,
			@Param("reqId") int reqId);

	public Integer getItamId(@Param("reqId") int reqId);
	
	public List<String> getTableNamesByReqId(@Param("reqId") Integer reqId);

}