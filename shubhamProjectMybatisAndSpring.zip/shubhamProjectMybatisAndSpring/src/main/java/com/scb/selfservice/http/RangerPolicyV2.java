package com.scb.selfservice.http;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.scb.selfservice.config.PropertyConfigurer;
import com.scb.selfservice.model.ServerResponse;
import com.scb.selfservice.model.RangerPolicy.HDFSPolicyRequestModel;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyAccesses;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyHdfsResourcesModel;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyModel;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyPolicyItems;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyRequestTypeEnum;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyResourcesModel;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyV2ReqModel;
import com.scb.selfservice.model.RangerPolicy.RepositoryTypeEnum;

/**
 * 
 * @author 1610601
 *
 */

@Service
public class RangerPolicyV2 {
	
	private static final String HOST_URL = "ranger_policy.url";
	private static final String RANGER_PATH_V2 = "ranger_policy.v2RangerPath";
	private static final String RANGER_ADMIN_SESSION_NAME = "RANGERADMINSESSIONID";
	private static final String USER_NAME = "ranger_policy.username";
	private static final String PASSWORD = "ranger_policy.password";
	private static final String HIVE_REPO = "ranger_policy.hiveRepo";
	private static final String HDFS_REPO = "ranger_policy.hdfsRepo";
	private static final String HIVE_PERMISSIONS = "ranger_policy.hivePermission";
	private static final String HDFS_PERMISSIONS = "ranger_policy.hdfsPermission";
	private static final String HDFS_BASE_DIR = "ranger_policy.hdfsBaseDir";
	private static final String HDFS_DATA_PATH_DIR = "ranger_policy.hdfsDataPath";
	private static final Gson gson = new Gson();
	
	private static Logger logger = LogManager.getLogger(RangerPolicy.class);
	
	private static String cookie;
	
	private String getPropertyValue(String requestFor) {
		return PropertyConfigurer.getProperty(requestFor);
		
//		switch(requestFor) {
//		case "ranger_policy.url":
//			return "http://hklvatapp330.global.standardchartered.com:6080";
//		case "ranger_policy.rangerPath":
//			return "/service/public/api/policy";
//		case "ranger_policy.v2RangerPath":
//			return "/service/public/v2/api/policy";
//		case "ranger_policy.username":
//			return "admin";
//		case "ranger_policy.password":
//			return "admin";
//		case "ranger_policy.hiveRepo":
//			return "POC_hive";
//		case "ranger_policy.hdfsRepo":
//			return "POC_hadoop";
//		case "ranger_policy.hivePermission" :
//			return "select";
//		case "ranger_policy.hdfsPermission":
//			return "read,execute";
//		case "ranger_policy.hdfsBaseDir":
//			return "/prd/sdm/hadoop/";
//		case "ranger_policy.hdfsDataPath" :
//			return "/hdata/";
//		default:
//			return "";
//		}
	}
	
	public ServerResponse getCookie() {
		HttpClient client = new HttpClient(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		ServerResponse resp = null;
		try {
			logger.info("Got request for getCookie. URL : " +
					getPropertyValue(HOST_URL) + ", Request Method : GET");
			resp = client.getCookieWithReqAuthHeader(getPropertyValue(HOST_URL), "GET", null, RANGER_ADMIN_SESSION_NAME);
			if(resp.getStatusCode() == 200) {
				if(resp.getOutput() != null) {
					cookie = (String) resp.getOutput();
				}
			}
		} catch (IOException e) {
			logger.error("Error while processing getCookie :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		} catch (Exception e) {
			logger.error("Error while processing getCookie :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
		logger.info("Request for getCookie :::: " +cookie);
		return resp;
	}

	public ServerResponse processRequest(RangerPolicyModel rangerPolicyModel) {
		
		if(rangerPolicyModel != null) {
			logger.info("processRequest -- rangerPolicyModel : " +rangerPolicyModel);
			RangerPolicyRequestTypeEnum requestType = rangerPolicyModel.getRequestType();
			ServerResponse resp = getCookie();
			if(resp.getStatusCode() != 200) {
				return resp;
			}
			switch(requestType) {
			case GET_POLICIES:
				return getAllPolicies();
				
			case GET_POLICY_BY_ID:
				return getPolicy(rangerPolicyModel.getPolicyId());
				
			case GET_POLICIES_BY_TYPE:
				return getAllPoliciesByType(rangerPolicyModel.getRepositoryType());
				
//			case DELETE_POLICY:
//				return deletePolicy(rangerPolicyModel.getPolicyId());
				
			case GET_POLICIES_BY_GROUP:
				return getAllPoliciesByGroup(rangerPolicyModel.getGroups());
				
			case GET_POLICIES_BY_TYPE_AND_GROUP:
				return getAllPoliciesByTypeAndGroup(rangerPolicyModel.getRepositoryType(), rangerPolicyModel.getGroups());
				
			case GET_POLICIES_BY_TYPE_AND_GROUP_AND_POLICYNAME:
				return getAllPoliciesByTypeAndGroupAndPolicyName(rangerPolicyModel.getRepositoryType(), 
						rangerPolicyModel.getGroups(), rangerPolicyModel.getPolicyName());
			}
		}
		return new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Missing details to fetch policies");
	}
	
	public ServerResponse processRequest(RangerPolicyV2ReqModel policy, Set<String> pathValues, 
			RepositoryTypeEnum repoType, RangerPolicyRequestTypeEnum reqType, String appName, Long requestId) {
		
		if(null != policy) {
			
			ServerResponse resp = getCookie();
			if(resp.getStatusCode() != 200) {
				return resp;
			}
			
			List<RangerPolicyPolicyItems> policyItems = policy.getPolicyItems();
			List<RangerPolicyAccesses> accesses = policyItems.get(0).getAccesses();
			String[] permissions = null;
			switch (repoType) {
			case HIVE:
				policy.setService(getPropertyValue(HIVE_REPO));
				permissions = getPropertyValue(HIVE_PERMISSIONS).split(",");
				break;
				
			case HDFS:
				policy.setService(getPropertyValue(HDFS_REPO));
				permissions = getPropertyValue(HDFS_PERMISSIONS).split(",");
				if(pathValues != null) {
					RangerPolicyResourcesModel resources = policy.getResources();
					if(resources instanceof RangerPolicyHdfsResourcesModel) {
						Set<String> existingPathValues = new HashSet<String> (((RangerPolicyHdfsResourcesModel) resources).getPath().getValues());
						for(String pathValue : pathValues) {
							existingPathValues.add(getPropertyValue(HDFS_BASE_DIR) + 
									appName.toLowerCase().trim() + 
									getPropertyValue(HDFS_DATA_PATH_DIR) + 
									pathValue.trim());
						}
						((RangerPolicyHdfsResourcesModel) resources).getPath().setValues(new ArrayList<String>(existingPathValues));
					}
				}
				break;

			default:
				break;
			}
			
			RangerPolicyAccesses access = null;
			for(String permission : permissions) {
				if(permission != null && !permission.trim().isEmpty()) {
					access = new RangerPolicyAccesses(permission.trim(), true);
					if (!accesses.contains(access)) {
						accesses.add(access);
					}
				}
			}
			
			return createOrUpdatePolicy(policy, (reqType == RangerPolicyRequestTypeEnum.UPDATE_POLICY) ? true : false, 
					repoType, requestId);
			
		}
		
		return new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Missing details to create or update policy");
	}
	
	public ServerResponse getPolicy(Long policyId) {
		HttpClientV2 client = new HttpClientV2(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		ServerResponse resp = null;
		try {
			resp = client.doRequestWithAuthHeader(getPropertyValue(HOST_URL) + getPropertyValue(RANGER_PATH_V2) 
				+ "/" + policyId, "GET", null, cookie, true);
//			if(resp.getDataReader() != null) {
//				StringBuilder sb = new StringBuilder();
//				String line = null;
//				while((line = resp.getDataReader().readLine()) != null) {
//					sb.append(line);
//				}
//				logger.info("GetPolicy data : " +sb.toString());
//				resp.setOutput((Object) gson.fromJson(sb.toString(), PolicyResp.class));
//			}
			logger.info("Request for getPolicy for policy id : " + policyId + " :::: " +resp);
		} catch (IOException e) {
			logger.error("Error while processing getPolicy for the policy id : " 
					+policyId + " :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		} catch (Exception e) {
			logger.error("Error while processing getPolicy for the policy id : " 
					+policyId + " :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
		return resp;
	}
	
	public ServerResponse getAllPolicies() {
		HttpClientV2 client = new HttpClientV2(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		ServerResponse resp = null;
		logger.info("Got request for getAllPolicies:");
		try {
			resp = client.doRequestWithAuthHeader(getPropertyValue(HOST_URL) + getPropertyValue(RANGER_PATH_V2) , "GET", null, cookie, false);
//			if(resp.getDataReader() != null) {
//				resp.setOutput((Object) gson.fromJson(resp.getDataReader(), PolicyDetailsResp.class));
//			}
		} catch (IOException e) {
			logger.error("Error while processing getPolicies :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		} catch (Exception e) {
			logger.error("Error while processing getPolicies :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
		logger.info("Request for getAllPolicies : " +resp);
		return resp;
	}
	
	public ServerResponse getAllPoliciesByType(String repoType) {
		HttpClientV2 client = new HttpClientV2(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		try {
			if(repoType == null || repoType.trim().isEmpty()) {
				repoType = "all";
			}
			ServerResponse resp = client.doRequestWithAuthHeader(
					getPropertyValue(HOST_URL) + getPropertyValue(RANGER_PATH_V2) 
					+ ((repoType.equalsIgnoreCase("all")) ? "" : "?serviceType=" + repoType), 
					"GET", null, cookie, false);
//			if(resp.getDataReader() != null) {
//				resp.setOutput((Object) gson.fromJson(resp.getDataReader(), PolicyDetailsResp.class));
//			}
			return resp;
		} catch (IOException e) {
			logger.error("Error while processing getAllPoliciesByType for type : " + repoType +" :::: " +e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			logger.error("Error while processing getAllPoliciesByType for type : " + repoType + ":::: " +e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	public ServerResponse getAllPoliciesByGroup(String group) {
		HttpClientV2 client = new HttpClientV2(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		try {
			ServerResponse resp = client.doRequestWithAuthHeader(
					getPropertyValue(HOST_URL) + getPropertyValue(RANGER_PATH_V2)
					+ "?group=" + group, "GET", null, cookie, false);
//			if(resp.getDataReader() != null) {
//				resp.setOutput((Object) gson.fromJson(resp.getDataReader(), PolicyDetailsResp.class));
//			}
			return resp;
		} catch (IOException e) {
			logger.error("Error while processing getAllPoliciesByGroup for group : " + group +" :::: " +e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			logger.error("Error while processing getAllPoliciesByGroup for group : " + group + ":::: " +e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	public ServerResponse getAllPoliciesByTypeAndGroup(String type, String group) {
		HttpClientV2 client = new HttpClientV2(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		ServerResponse resp = null;
		try {
			logger.info("Processing getAllPoliciesByTypeAndGroup for repository : " 
					+type + ", group : " +group);
			resp = client.doRequestWithAuthHeader(
					getPropertyValue(HOST_URL) + getPropertyValue(RANGER_PATH_V2) 
					+ "?serviceType=" + type + "&group=" +group, "GET", null, cookie, false);
//			if(resp.getDataReader() != null) {
//				resp.setOutput((Object) gson.fromJson(resp.getDataReader(), PolicyDetailsResp.class));
//			}
		} catch (IOException e) {
			logger.error("Error while processing getAllPoliciesByTypeAndGroup for type : " 
					+type + " and group : " +group + " :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		} catch (Exception e) {
			logger.error("Error while processing getAllPoliciesByTypeAndGroup for type : " 
					+type + " and group : " +group + ":::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
		logger.info("Request for getAllPoliciesByTypeAndGroup for type : " +type 
				+ " and group : " +group +" :::: " +resp);
		return resp;
	}
	
	public ServerResponse getAllPoliciesByTypeAndGroupAndPolicyName(String type, String group, String policyName) {
		HttpClientV2 client = new HttpClientV2(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		ServerResponse resp = null;
		try {
			logger.info("Processing getAllPoliciesByTypeAndGroupAndPolicyName URL : " +
					getPropertyValue(HOST_URL) + getPropertyValue(RANGER_PATH_V2) + 
					"?serviceType=" + type + "&group=" +group +"&policyName=" +policyName +
					", Request Method : GET");
			resp = client.doRequestWithAuthHeader(
					getPropertyValue(HOST_URL) + getPropertyValue(RANGER_PATH_V2) 
					+ "?serviceType=" + type + "&group=" +group +"&policyName=" +policyName, "GET", null, cookie, false);
//			if(resp.getDataReader() != null) {
//				resp.setOutput((Object) gson.fromJson(resp.getDataReader(), PolicyDetailsResp.class));
//			}
		} catch (IOException e) {
			logger.error("Error while processing getAllPoliciesByTypeAndGroupAndPolicyName for type : " 
					+type + " and group : " +group + " :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		} catch (Exception e) {
			logger.error("Error while processing getAllPoliciesByTypeAndGroupAndPolicyName for type : " 
					+type + " and group : " +group + ":::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
		logger.info("Request for getAllPoliciesByTypeAndGroupAndPolicyName for type : " +type + " and group : " +group +" :::: " +resp);
		return resp;
	}
	
	public ServerResponse createOrUpdatePolicy(RangerPolicyV2ReqModel policy, boolean isToUpdateExistingPolicy, 
			RepositoryTypeEnum repoType, Long requestId) {
		ServerResponse resp = null;
		HttpClientV2 client = new HttpClientV2(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		String requestMethod = "POST";
		String url = getPropertyValue(HOST_URL) + getPropertyValue(RANGER_PATH_V2);
		if(isToUpdateExistingPolicy) {
			requestMethod = "PUT";
			url = url + "/" + policy.getId();
		} 
		
		try {
			logger.info("createOrUpdatePolicy request payload : " +policy +
					", url : " +url + ", Request Method : " +requestMethod);
			resp = client.doRequestWithAuthHeader(url, requestMethod, 
					gson.toJson(policy, RangerPolicyV2ReqModel.class), cookie, false);
//			logger.info("createOrUpdatePolicy response : " +resp);
		} catch (IOException e) {
			logger.error("Error while processing createOrUpdatePolicy for the request id : " 
					+requestId + " :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		} catch (Exception e) {
			logger.error("Error while processing createOrUpdateHDFSPolicy for the request id : " 
					+requestId + " :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
		logger.info("Request for createOrUpdatePolicy for the request id :  : " +requestId + " :::: " + resp);
		return resp;
	}
	
}
