package com.scb.selfservice.serviceType;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EndConsumptionWF implements ServiceCall {

	private static Logger logger = LogManager.getLogger(EndConsumptionWF.class);
	@Override
	public String execute(Map<String, String> params) {
		logger.info("Returning from EndConsumptionWF...");
		return "SUCCESS";
	}

}
