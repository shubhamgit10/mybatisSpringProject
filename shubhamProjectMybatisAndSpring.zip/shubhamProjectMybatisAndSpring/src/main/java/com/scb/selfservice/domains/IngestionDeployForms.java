package com.scb.selfservice.domains;

import java.sql.Timestamp;

public class IngestionDeployForms {
	
	
	private Integer reqId;
	
	private String instanceToBeCovered;
	
	private String environmentToDeploy;
	
	private String dataSource;
	
	private String releaseSummary;
	
	private String remarks;
	
	private Integer ratReferenceNum;
	
	private Integer rmsReferenceNum;
	
	private Integer crNumber;
	
	private Integer remedyReferenceNumber;
	
	private Integer lcApprovalTaken;
	
	private Integer boApprovalTaken;
	
	private String userAction;
	
	private String stepId;
	
	private Integer workflowId;
	
	private Integer requestCreatedBy;
	
	private Timestamp requestCreatedAt;

	public Integer getReqId() {
		return reqId;
	}

	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}

	public String getInstanceToBeCovered() {
		return instanceToBeCovered;
	}

	public void setInstanceToBeCovered(String instanceToBeCovered) {
		this.instanceToBeCovered = instanceToBeCovered;
	}

	public String getEnvironmentToDeploy() {
		return environmentToDeploy;
	}

	public void setEnvironmentToDeploy(String environmentToDeploy) {
		this.environmentToDeploy = environmentToDeploy;
	}

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	public String getReleaseSummary() {
		return releaseSummary;
	}

	public void setReleaseSummary(String releaseSummary) {
		this.releaseSummary = releaseSummary;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getRatReferenceNum() {
		return ratReferenceNum;
	}

	public void setRatReferenceNum(Integer ratReferenceNum) {
		this.ratReferenceNum = ratReferenceNum;
	}

	public Integer getRmsReferenceNum() {
		return rmsReferenceNum;
	}

	public void setRmsReferenceNum(Integer rmsReferenceNum) {
		this.rmsReferenceNum = rmsReferenceNum;
	}

	public Integer getCrNumber() {
		return crNumber;
	}

	public void setCrNumber(Integer crNumber) {
		this.crNumber = crNumber;
	}

	public Integer getRemedyReferenceNumber() {
		return remedyReferenceNumber;
	}

	public void setRemedyReferenceNumber(Integer remedyReferenceNumber) {
		this.remedyReferenceNumber = remedyReferenceNumber;
	}

	public Integer getLcApprovalTaken() {
		return lcApprovalTaken;
	}

	public void setLcApprovalTaken(Integer lcApprovalTaken) {
		this.lcApprovalTaken = lcApprovalTaken;
	}

	public Integer getBoApprovalTaken() {
		return boApprovalTaken;
	}

	public void setBoApprovalTaken(Integer boApprovalTaken) {
		this.boApprovalTaken = boApprovalTaken;
	}

	public String getUserAction() {
		return userAction;
	}

	public void setUserAction(String userAction) {
		this.userAction = userAction;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}

	public Integer getRequestCreatedBy() {
		return requestCreatedBy;
	}

	public void setRequestCreatedBy(Integer requestCreatedBy) {
		this.requestCreatedBy = requestCreatedBy;
	}

	public Timestamp getRequestCreatedAt() {
		return requestCreatedAt;
	}

	public void setRequestCreatedAt(Timestamp requestCreatedAt) {
		this.requestCreatedAt = requestCreatedAt;
	}

	@Override
	public String toString() {
		return "IngestionDeployForms [reqId=" + reqId + ", instanceToBeCovered=" + instanceToBeCovered
				+ ", environmentToDeploy=" + environmentToDeploy + ", dataSource=" + dataSource + ", releaseSummary="
				+ releaseSummary + ", remarks=" + remarks + ", ratReferenceNum=" + ratReferenceNum
				+ ", rmsReferenceNum=" + rmsReferenceNum + ", crNumber=" + crNumber + ", remedyReferenceNumber="
				+ remedyReferenceNumber + ", lcApprovalTaken=" + lcApprovalTaken + ", boApprovalTaken="
				+ boApprovalTaken + ", userAction=" + userAction + ", stepId=" + stepId + ", workflowId=" + workflowId
				+ ", requestCreatedBy=" + requestCreatedBy + ", requestCreatedAt=" + requestCreatedAt + "]";
	}

}
