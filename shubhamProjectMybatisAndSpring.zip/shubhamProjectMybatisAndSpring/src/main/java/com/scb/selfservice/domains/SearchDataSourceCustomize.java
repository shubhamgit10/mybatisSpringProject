package com.scb.selfservice.domains;

import java.util.List;

/*
 * pojo for 
 *   SearchDataSource customization
 */
public class SearchDataSourceCustomize {

	private String itamId;
	private String appName;
	private List<String> businessSegment;
	private List<String> supportedCountries;
	private String hasPiiCols;
	private String tableName;
	private Integer noOfCols;
	private String Certified;
	private String appDescription;
	private String tableDescription;

	public String getItamId() {
		return itamId;
	}
	public void setItamId(String itamId) {
		this.itamId = itamId;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public List<String> getBusinessSegment() {
		return businessSegment;
	}
	public void setBusinessSegment(List<String> businessSegment) {
		this.businessSegment = businessSegment;
	}
	public List<String> getSupportedCountries() {
		return supportedCountries;
	}
	public void setSupportedCountries(List<String> supportedCountries) {
		this.supportedCountries = supportedCountries;
	}
	public String getHasPiiCols() {
		return hasPiiCols;
	}
	public void setHasPiiCols(String hasPiiCols) {
		this.hasPiiCols = hasPiiCols;
	}
	
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public Integer getNoOfCols() {
		return noOfCols;
	}
	public void setNoOfCols(Integer noOfCols) {
		this.noOfCols = noOfCols;
	}
	public String getCertified() {
		return Certified;
	}
	public void setCertified(String certified) {
		Certified = certified;
	}
	public String getAppDescription() {
		return appDescription;
	}
	public void setAppDescription(String appDescription) {
		this.appDescription = appDescription;
	}
	public String getTableDescription() {
		return tableDescription;
	}
	public void setTableDescription(String tableDescription) {
		this.tableDescription = tableDescription;
	}
	@Override
	public String toString() {
		return "SearchDataSourceCustomize [itamId=" + itamId + ", appName=" + appName + ", businessSegment="
				+ businessSegment + ", supportedCountries=" + supportedCountries + ", hasPiiCols=" + hasPiiCols
				+ ", tableName=" + tableName + ", noOfCols=" + noOfCols + ", Certified=" + Certified
				+ ", appDescription=" + appDescription + ", tableDescription=" + tableDescription + "]";
	}

}