package com.scb.selfservice.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.MyApprovalList;

public interface AdminMapper {

	List<MyApprovalList> getAdminRequests(@Param("workflowId") Integer workflowId, 
			@Param("workflowType") String workflowType);

	//mapper to update workflow_request_steps by the admin for re-assign
	Integer updateWorkflowRequestSteps(@Param("psid") Integer psid, @Param("requestId") Integer requestId, 
			@Param("stepId") String stepId);

	//mapper to update edmp_consumption
	//!!!!!below PSID is a string type!!!!
	Integer updateEdmpConsumptionRequest(@Param("psid") String psid, @Param("requestId") Integer requestId);

}
