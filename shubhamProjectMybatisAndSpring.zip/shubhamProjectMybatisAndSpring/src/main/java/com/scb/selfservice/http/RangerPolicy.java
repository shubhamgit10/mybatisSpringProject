package com.scb.selfservice.http;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.scb.selfservice.config.PropertyConfigurer;
import com.scb.selfservice.model.ServerResponse;
import com.scb.selfservice.model.RangerPolicy.HBasePolicyRequestModel;
import com.scb.selfservice.model.RangerPolicy.HDFSPolicyRequestModel;
import com.scb.selfservice.model.RangerPolicy.HivePolicyRequestModel;
import com.scb.selfservice.model.RangerPolicy.PolicyDetailsResp;
import com.scb.selfservice.model.RangerPolicy.PolicyResp;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyModel;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyPermissionsList;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyRequestTypeEnum;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyRespModel;
import com.scb.selfservice.model.RangerPolicy.RepositoryTypeEnum;

/**
 * 
 * @author 1610601
 *
 */

@Service
public class RangerPolicy {
	
	private static final String HOST_URL = "ranger_policy.url";
	private static final String RANGER_PATH = "ranger_policy.rangerPath";
	private static final String RANGER_ADMIN_SESSION_NAME = "RANGERADMINSESSIONID";
	private static final String USER_NAME = "ranger_policy.username";
	private static final String PASSWORD = "ranger_policy.password";
	private static final String HIVE_REPO = "ranger_policy.hiveRepo";
	private static final String HDFS_REPO = "ranger_policy.hdfsRepo";
	private static final String HIVE_PERMISSIONS = "ranger_policy.hivePermission";
	private static final String HDFS_PERMISSIONS = "ranger_policy.hdfsPermission";
	private static final String HDFS_BASE_DIR = "ranger_policy.hdfsBaseDir";
	private static final String HDFS_DATA_PATH_DIR = "ranger_policy.hdfsDataPath";
	private static final Gson gson = new Gson();
	
	private static Logger logger = LogManager.getLogger(RangerPolicy.class);
	
	private static String cookie;
	
	public ServerResponse processRequest(RangerPolicyModel rangerPolicyModel) {
		
		if(rangerPolicyModel != null) {
			logger.info("processRequest -- rangerPolicyModel : " +rangerPolicyModel);
			RangerPolicyRequestTypeEnum requestType = rangerPolicyModel.getRequestType();
			ServerResponse resp = getCookie();
			if(resp.getStatusCode() != 200) {
				return resp;
			}
			String repoType = rangerPolicyModel.getRepositoryType();
			switch(requestType) {
			case CREATE_POLICY:
				RangerPolicyPermissionsList new_permListMap = new RangerPolicyPermissionsList();
//				String new_users = rangerPolicyModel.getUsers();
				String new_groups = rangerPolicyModel.getGroups();
//				String new_permissions = rangerPolicyModel.getPermissions();
				
				//groups are mandatory
				if(null == new_groups || new_groups.trim().isEmpty()) {
					return new ServerResponse(HttpStatus.BAD_REQUEST, "Groups is mandatory");
				}
				
				List<String> new_usersList = new ArrayList<String> ();
//				if(null != new_users && !new_users.trim().isEmpty()) {
//					if(new_users.indexOf(",") > 0) {
//						new_usersList = Arrays.asList(new_users.split(","));
//					} else {
//						new_usersList.add(new_users);
//					}
//				}
				
				List<String> new_permList = new ArrayList<String> ();
//				if(null != new_permissions && !new_permissions.trim().isEmpty()) {
//					if(new_permissions.indexOf(",") > 0) {
//						new_permList = Arrays.asList(new_permissions.split(","));
//					} else {
//						new_permList.add(new_permissions);
//					}
//				}
				
				List<String> new_groupList = new ArrayList<String> ();
				if(null != new_groups && !new_groups.trim().isEmpty()) {
					String[] grpArr = new_groups.split(",");
					for(String grp : grpArr) {
						new_groupList.add(grp.trim());
					}
				}
				
				new_permListMap.setGroupList(new_groupList);
				new_permListMap.setPermList(new_permList);
				new_permListMap.setUserList(new_usersList);
				List<RangerPolicyPermissionsList> new_permMapList = new ArrayList<RangerPolicyPermissionsList> ();
				new_permMapList.add(new_permListMap);
				switch(repoType.toLowerCase()) {
				case "hive":
					if(getPropertyValue(HIVE_PERMISSIONS).indexOf(",") > 0) {
						new_permListMap.getPermList().addAll(Arrays.asList(getPropertyValue(HIVE_PERMISSIONS).split(",")));
					} else {
						new_permListMap.getPermList().add(getPropertyValue(HIVE_PERMISSIONS));
					}
					return createOrUpdateHivePolicy(rangerPolicyModel, false,
							rangerPolicyModel.getPolicyId(), new_permMapList);
					
				case "hdfs":
					String [] permissions = getPropertyValue(HDFS_PERMISSIONS).split(",");
					for(String permission : permissions) {
						new_permListMap.getPermList().add(permission.trim());
					}
					return createOrUpdateHDFSPolicy(rangerPolicyModel, false,
							rangerPolicyModel.getPolicyId(), new_permMapList);
					
				case "hbase":
					return createOrUpdateHBasePolicy(rangerPolicyModel, false,
							rangerPolicyModel.getPolicyId(), new_permMapList);
				}
				break;
				
			case UPDATE_POLICY:
				List<RangerPolicyPermissionsList> permMapList = rangerPolicyModel.getPermissionsMap();
				RangerPolicyPermissionsList permListMap = new RangerPolicyPermissionsList();
//				String users = rangerPolicyModel.getUsers();
				String groups = rangerPolicyModel.getGroups();
//				String permissions = rangerPolicyModel.getPermissions();
				
				//groups are mandatory
				if(null == groups || groups.trim().isEmpty()) {
					return new ServerResponse(HttpStatus.BAD_REQUEST, "Groups is mandatory");
				}
				
				List<String> usersList = new ArrayList<String> ();
//				if(null != users && !users.trim().isEmpty()) {
//					if(users.indexOf(",") > 0) {
//						usersList = Arrays.asList(users.split(","));
//					} else {
//						usersList.add(users);
//					}
//				}
				
				List<String> permList = new ArrayList<String> ();
//				if(null != permissions && !permissions.trim().isEmpty()) {
//					if(permissions.indexOf(",") > 0) {
//						permList = Arrays.asList(permissions.split(","));
//					} else {
//						permList.add(permissions);
//					}
//				}
				
				List<String> groupList = new ArrayList<String> ();
				if(null != groups && !groups.trim().isEmpty()) {
					String[] grpArr = groups.split(",");
					for(String grp : grpArr) {
						groupList.add(grp.trim());
					}
				}
				
				permListMap.setGroupList(groupList);
				permListMap.setPermList(permList);
				permListMap.setUserList(usersList);
				boolean isGroupExist = false;
				List<String> existingPermissions = null;
				for(RangerPolicyPermissionsList permissionList : permMapList) {
					if(permissionList.getGroupList().containsAll(groupList)) {
						isGroupExist = true;
						existingPermissions = permissionList.getPermList();
						break;
					}
				}
				if(!isGroupExist) {
					permMapList.add(permListMap);
				}
				switch(repoType.toLowerCase()) {
				case "hive":
					if(getPropertyValue(HIVE_PERMISSIONS).indexOf(",") > 0) {
						permListMap.getPermList().addAll(Arrays.asList(getPropertyValue(HIVE_PERMISSIONS).split(",")));
					} else {
						permListMap.getPermList().add(getPropertyValue(HIVE_PERMISSIONS));
					}
					if(isGroupExist) {
						if(!existingPermissions.containsAll(permListMap.getPermList())) {
							existingPermissions.addAll(permListMap.getPermList());
						}
					}
					return createOrUpdateHivePolicy(rangerPolicyModel, true,
							rangerPolicyModel.getPolicyId(), permMapList);
					
				case "hdfs":
					if(getPropertyValue(HDFS_PERMISSIONS).indexOf(",") > 0) {
						permListMap.getPermList().addAll(Arrays.asList(getPropertyValue(HDFS_PERMISSIONS).split(",")));
					} else {
						permListMap.getPermList().add(getPropertyValue(HDFS_PERMISSIONS));
					}
					if(isGroupExist) {
						if(!existingPermissions.containsAll(permListMap.getPermList())) {
							existingPermissions.addAll(permListMap.getPermList());
						}
					}
					return createOrUpdateHDFSPolicy(rangerPolicyModel, true,
							rangerPolicyModel.getPolicyId(), permMapList);
					
				case "hbase":
					return createOrUpdateHBasePolicy(rangerPolicyModel, true,
							rangerPolicyModel.getPolicyId(), permMapList);
				}
				break;
				
			case GET_POLICIES:
				return getAllPolicies();
				
			case GET_POLICY_BY_ID:
				return getPolicy(rangerPolicyModel.getPolicyId());
				
			case GET_POLICIES_BY_TYPE:
				return getAllPoliciesByType(rangerPolicyModel.getRepositoryType());
				
			case DELETE_POLICY:
				return deletePolicy(rangerPolicyModel.getPolicyId());
			case GET_POLICIES_BY_GROUP:
				return getAllPoliciesByGroup(rangerPolicyModel.getGroups());
			case GET_POLICIES_BY_TYPE_AND_GROUP:
				return getAllPoliciesByTypeAndGroup(rangerPolicyModel.getRepositoryType(), rangerPolicyModel.getGroups());
			case GET_POLICIES_BY_TYPE_AND_GROUP_AND_POLICYNAME:
				return getAllPoliciesByTypeAndGroupAndPolicyName(rangerPolicyModel.getRepositoryType(), 
						rangerPolicyModel.getGroups(), rangerPolicyModel.getPolicyName());
			}
		}
		return null;
	}
	
	public ServerResponse getPolicy(Long policyId) {
		HttpClient client = new HttpClient(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		ServerResponse resp = null;
		try {
			resp = client.doRequestWithAuthHeader(getPropertyValue(HOST_URL) + getPropertyValue(RANGER_PATH) 
				+ "/" + policyId, "GET", null, cookie, true);
//			if(resp.getDataReader() != null) {
//				StringBuilder sb = new StringBuilder();
//				String line = null;
//				while((line = resp.getDataReader().readLine()) != null) {
//					sb.append(line);
//				}
//				logger.info("GetPolicy data : " +sb.toString());
//				resp.setOutput((Object) gson.fromJson(sb.toString(), PolicyResp.class));
//			}
			logger.info("Request for getPolicy for policy id : " + policyId + " :::: " +resp);
		} catch (IOException e) {
			logger.error("Error while processing getPolicy for the policy id : " 
					+policyId + " :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		} catch (Exception e) {
			logger.error("Error while processing getPolicy for the policy id : " 
					+policyId + " :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
		return resp;
	}
	
	public ServerResponse getAllPolicies() {
		HttpClient client = new HttpClient(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		ServerResponse resp = null;
		logger.info("Got request for getAllPolicies:");
		try {
			resp = client.doRequestWithAuthHeader(getPropertyValue(HOST_URL) + getPropertyValue(RANGER_PATH) , "GET", null, cookie, false);
//			if(resp.getDataReader() != null) {
//				resp.setOutput((Object) gson.fromJson(resp.getDataReader(), PolicyDetailsResp.class));
//			}
		} catch (IOException e) {
			logger.error("Error while processing getPolicies :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		} catch (Exception e) {
			logger.error("Error while processing getPolicies :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
		logger.info("Request for getAllPolicies : " +resp);
		return resp;
	}
	
//	public ServerResponse getPoliciesByType(String repoType) {
//		ServerResponse resp = getAllPolicies();
//		
//		if(resp != null && repoType != null && !repoType.trim().isEmpty()) {
//			PolicyDetailsResp policyDetailsResp = (PolicyDetailsResp) resp.getOutput();
//			if(null != policyDetailsResp) {
//				List<PolicyResp> policiesList = policyDetailsResp.getvXPolicies();
//				if(null != policiesList) {
//					for(PolicyResp policy : policiesList) {
//						if(!policy.getRepositoryType().equalsIgnoreCase(repoType)) {
//							policiesList.remove(policy);
//						}
//					}
//					policyDetailsResp.setResultSize(policiesList.size());
//					policyDetailsResp.setTotalCount(policiesList.size());
//				}
//			}
//		}
//		logger.info("Request for getAllPoliciesByType for repository type : " +repoType + " :::: " +resp);
//		return resp;
//	}
	
	public ServerResponse deletePolicy(Long policyId) {
		HttpClient client = new HttpClient(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		ServerResponse resp = null;
		try {
			logger.info("Got request for deletePolicy for Policy Id : " +policyId);
			resp = client.doRequestWithAuthHeader(getPropertyValue(HOST_URL) + getPropertyValue(RANGER_PATH)
				+ "/"+policyId, "DELETE", null, cookie, false);
		} catch (IOException e) {
			logger.error("Error while processing deletePolicy for the policy id : " 
					+policyId + " :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		} catch (Exception e) {
			logger.error("Error while processing deletePolicy for the policy id : " 
					+policyId + " :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
		logger.info("Request for deletePolicy for policyId : " +policyId + " :::: " + resp);
		return resp;
	}
	
	public ServerResponse createOrUpdateHivePolicy(RangerPolicyModel rangerPolicyModel, boolean isToUpdateExistingPolicy, 
			Long policyId, List<RangerPolicyPermissionsList> permMapList) {
		ServerResponse resp = null;
		HivePolicyRequestModel hiveReq = new HivePolicyRequestModel();
		hiveReq.setRepositoryName(getPropertyValue(HIVE_REPO));
		hiveReq.setDescription(rangerPolicyModel.getDescription());
		hiveReq.setColumns(rangerPolicyModel.getColumns());
		hiveReq.setDatabases(rangerPolicyModel.getDatabases());
		hiveReq.setPolicyName(rangerPolicyModel.getPolicyName());
		hiveReq.setTables(rangerPolicyModel.getTables());
		HttpClient client = new HttpClient(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		String requestMethod = "POST";
		String url = getPropertyValue(HOST_URL) + getPropertyValue(RANGER_PATH);
		if(isToUpdateExistingPolicy) {
			requestMethod = "PUT";
			url = url + "/" + rangerPolicyModel.getPolicyId();
		} 
//		else {
//			List<RangerPolicyPermissionsList> permissionsMap = permMapList;
//			for(RangerPolicyPermissionsList permission : permissionsMap) {
//				if(HIVE_PERMISSIONS.indexOf(",") > 0) {
//					permission.getPermList().addAll(Arrays.asList(HIVE_PERMISSIONS.split(",")));
//				} else {
//					permission.getPermList().add(HIVE_PERMISSIONS);
//				}
//			}
//		}
		hiveReq.setPermMapList(permMapList);
		logger.info("Request for createOrUpdateHivePolicy for the request id : " 
				+rangerPolicyModel.getRequestId() + ", with payload : " + hiveReq);
		try {
			resp = client.doRequestWithAuthHeader(url, requestMethod, 
					gson.toJson(hiveReq, HivePolicyRequestModel.class), cookie, false);
		} catch (IOException e) {
			logger.error("Error while processing createOrUpdateHivePolicy for the request id : " 
					+rangerPolicyModel.getRequestId() + " :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		} catch (Exception e) {
			logger.error("Error while processing createOrUpdateHivePolicy for the request id : " 
					+rangerPolicyModel.getRequestId() + " :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
		logger.info("Request for createOrUpdateHivePolicy for the request id :  : " +rangerPolicyModel.getRequestId() + " :::: " + resp);
		return resp;
	}
	
	public ServerResponse createOrUpdateHDFSPolicy(RangerPolicyModel rangerPolicyModel, boolean isToUpdateExistingPolicy, 
			Long policyId, List<RangerPolicyPermissionsList> permMapList) {
		ServerResponse resp = null;
		HDFSPolicyRequestModel hdfsReq = new HDFSPolicyRequestModel();
		hdfsReq.setRepositoryName(getPropertyValue(HDFS_REPO));
		hdfsReq.setPolicyName(rangerPolicyModel.getPolicyName());
		hdfsReq.setDescription(rangerPolicyModel.getDescription());
		HttpClient client = new HttpClient(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		String requestMethod = "POST";
		String url = getPropertyValue(HOST_URL) + getPropertyValue(RANGER_PATH);
		
		StringBuilder resources = new StringBuilder((rangerPolicyModel.getResourceName() == null) ? "" : rangerPolicyModel.getResourceName());
		
		String [] resrces = rangerPolicyModel.getTables().split(",");
		for(String resrc : resrces) {
			if(resources.length() > 0) {
				resources.append(",");
			}
			resources.append(getPropertyValue(HDFS_BASE_DIR)).append(rangerPolicyModel.getAppName().toLowerCase().trim())
				.append(getPropertyValue(HDFS_DATA_PATH_DIR)).append(resrc.trim());
		}
		
		rangerPolicyModel.setResourceName(resources.toString());
		hdfsReq.setResourceName(rangerPolicyModel.getResourceName());
		if(isToUpdateExistingPolicy) {
			requestMethod = "PUT";
			url = url + "/" + rangerPolicyModel.getPolicyId();
		} 
//		else {
//			List<RangerPolicyPermissionsList> permissionsMap = permMapList;
//			for(RangerPolicyPermissionsList permission : permissionsMap) {
//				if(HDFS_PERMISSIONS.indexOf(",") > 0) {
//					permission.getPermList().addAll(Arrays.asList(HDFS_PERMISSIONS.split(",")));
//				} else {
//					permission.getPermList().add(HDFS_PERMISSIONS);
//				}
//			}
//		}
		hdfsReq.setPermMapList(permMapList);
		try {
			logger.info("createOrUpdateHDFSPolicy request payload : " +hdfsReq);
			resp = client.doRequestWithAuthHeader(url, requestMethod, 
					gson.toJson(hdfsReq, HDFSPolicyRequestModel.class), cookie, false);
			logger.info("createOrUpdateHDFSPolicy response : " +resp);
		} catch (IOException e) {
			logger.error("Error while processing createOrUpdateHDFSPolicy for the request id : " 
					+rangerPolicyModel.getRequestId() + " :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		} catch (Exception e) {
			logger.error("Error while processing createOrUpdateHDFSPolicy for the request id : " 
					+rangerPolicyModel.getRequestId() + " :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
		logger.info("Request for createOrUpdateHDFSPolicy for the request id :  : " +rangerPolicyModel.getRequestId() + " :::: " + resp);
		return resp;
	}
	
	public ServerResponse createOrUpdateHBasePolicy(RangerPolicyModel rangerPolicyModel, boolean isToUpdateExistingPolicy, 
			Long policyId, List<RangerPolicyPermissionsList> permMapList) {
		HBasePolicyRequestModel hbaseReq = new HBasePolicyRequestModel();
		hbaseReq.setRepositoryName("POC_hbase");
		hbaseReq.setPolicyName(rangerPolicyModel.getPolicyName());
		hbaseReq.setColumnFamilies(rangerPolicyModel.getColumnFamilies());
		hbaseReq.setColumns(rangerPolicyModel.getColumns());
		hbaseReq.setDescription(rangerPolicyModel.getDescription());
		hbaseReq.setTables(rangerPolicyModel.getTables());
		HttpClient client = new HttpClient(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		String requestMethod = "POST";
		String url = getPropertyValue(HOST_URL) + getPropertyValue(RANGER_PATH);
		if(isToUpdateExistingPolicy) {
			requestMethod = "PUT";
			url = url + "/" + rangerPolicyModel.getPolicyId();
		} else {
			List<RangerPolicyPermissionsList> permissionsMap = permMapList;
			for(RangerPolicyPermissionsList permission : permissionsMap) {
				permission.getGroupList().addAll(Arrays.asList(HDFS_PERMISSIONS.split(",")));
			}
		}
		hbaseReq.setPermMapList(permMapList);
		try {
			return client.sendRequestWithAuthHeader(url, requestMethod, 
					gson.toJson(hbaseReq, HBasePolicyRequestModel.class), cookie);
		} catch (IOException e) {
			logger.error("Error while processing createOrUpdateHBasePolicy for the request id : " 
					+rangerPolicyModel.getRequestId() + " :::: " +e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			logger.error("Error while processing createOrUpdateHBasePolicy for the request id : " 
					+rangerPolicyModel.getRequestId() + " :::: " +e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	public ServerResponse getAllPoliciesByType(String repoType) {
		HttpClient client = new HttpClient(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		try {
			if(repoType == null || repoType.trim().isEmpty()) {
				repoType = "all";
			}
			ServerResponse resp = client.doRequestWithAuthHeader(
					getPropertyValue(HOST_URL) + getPropertyValue(RANGER_PATH) 
					+ ((repoType.equalsIgnoreCase("all")) ? "" : "?repositoryType=" + repoType), 
					"GET", null, cookie, false);
//			if(resp.getDataReader() != null) {
//				resp.setOutput((Object) gson.fromJson(resp.getDataReader(), PolicyDetailsResp.class));
//			}
			return resp;
		} catch (IOException e) {
			logger.error("Error while processing getAllPoliciesByType for type : " + repoType +" :::: " +e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			logger.error("Error while processing getAllPoliciesByType for type : " + repoType + ":::: " +e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	public ServerResponse getAllPoliciesByGroup(String group) {
		HttpClient client = new HttpClient(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		try {
			ServerResponse resp = client.doRequestWithAuthHeader(
					getPropertyValue(HOST_URL) + getPropertyValue(RANGER_PATH)
					+ "?groupName=" + group, "GET", null, cookie, false);
//			if(resp.getDataReader() != null) {
//				resp.setOutput((Object) gson.fromJson(resp.getDataReader(), PolicyDetailsResp.class));
//			}
			return resp;
		} catch (IOException e) {
			logger.error("Error while processing getAllPoliciesByGroup for group : " + group +" :::: " +e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			logger.error("Error while processing getAllPoliciesByGroup for group : " + group + ":::: " +e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	public ServerResponse getAllPoliciesByTypeAndGroup(String type, String group) {
		HttpClient client = new HttpClient(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		ServerResponse resp = null;
		try {
			logger.info("Processing getAllPoliciesByTypeAndGroup for repository : " 
					+type + ", group : " +group);
			resp = client.doRequestWithAuthHeader(
					getPropertyValue(HOST_URL) + getPropertyValue(RANGER_PATH) 
					+ "?repositoryType=" + type + "&groupName=" +group, "GET", null, cookie, false);
//			if(resp.getDataReader() != null) {
//				resp.setOutput((Object) gson.fromJson(resp.getDataReader(), PolicyDetailsResp.class));
//			}
		} catch (IOException e) {
			logger.error("Error while processing getAllPoliciesByTypeAndGroup for type : " 
					+type + " and group : " +group + " :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		} catch (Exception e) {
			logger.error("Error while processing getAllPoliciesByTypeAndGroup for type : " 
					+type + " and group : " +group + ":::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
		logger.info("Request for getAllPoliciesByTypeAndGroup for type : " +type 
				+ " and group : " +group +" :::: " +resp);
		return resp;
	}
	
	public ServerResponse getAllPoliciesByTypeAndGroupAndPolicyName(String type, String group, String policyName) {
		HttpClient client = new HttpClient(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		ServerResponse resp = null;
		try {
			logger.info("Processing getAllPoliciesByTypeAndGroupAndPolicyName for repository : " 
					+type + ", group : " +group +", policyName : " +policyName);
			resp = client.doRequestWithAuthHeader(
					getPropertyValue(HOST_URL) + getPropertyValue(RANGER_PATH) 
					+ "?repositoryType=" + type + "&groupName=" +group +"&policyName=" +policyName, "GET", null, cookie, false);
//			if(resp.getDataReader() != null) {
//				resp.setOutput((Object) gson.fromJson(resp.getDataReader(), PolicyDetailsResp.class));
//			}
		} catch (IOException e) {
			logger.error("Error while processing getAllPoliciesByTypeAndGroupAndPolicyName for type : " 
					+type + " and group : " +group + " :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		} catch (Exception e) {
			logger.error("Error while processing getAllPoliciesByTypeAndGroupAndPolicyName for type : " 
					+type + " and group : " +group + ":::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
		logger.info("Request for getAllPoliciesByTypeAndGroupAndPolicyName for type : " +type + " and group : " +group +" :::: " +resp);
		return resp;
	}
	
	public ServerResponse getCookie() {
		HttpClient client = new HttpClient(getPropertyValue(USER_NAME), getPropertyValue(PASSWORD));
		ServerResponse resp = null;
		try {
			logger.info("Got request for getCookie.");
			resp = client.getCookieWithReqAuthHeader(getPropertyValue(HOST_URL), "GET", null, RANGER_ADMIN_SESSION_NAME);
			if(resp.getStatusCode() == 200) {
				if(resp.getOutput() != null) {
					cookie = (String) resp.getOutput();
				}
			}
		} catch (IOException e) {
			logger.error("Error while processing getCookie :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		} catch (Exception e) {
			logger.error("Error while processing getCookie :::: " +e.getMessage());
			e.printStackTrace();
			resp = new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
		logger.info("Request for getCookie :::: " +cookie);
		return resp;
	}
	
	private String getPropertyValue(String requestFor) {
		return PropertyConfigurer.getProperty(requestFor);
		
//		switch(requestFor) {
//		case "ranger_policy.url":
//			return "http://hklvatapp330.global.standardchartered.com:6080";
//		case "ranger_policy.rangerPath":
//			return "/service/public/api/policy";
//		case "ranger_policy.username":
//			return "admin";
//		case "ranger_policy.password":
//			return "admin";
//		case "ranger_policy.hiveRepo":
//			return "POC_hive";
//		case "ranger_policy.hdfsRepo":
//			return "POC_hadoop";
//		case "ranger_policy.hivePermission" :
//			return "select";
//		case "ranger_policy.hdfsPermission":
//			return "read,execute";
//		case "ranger_policy.hdfsBaseDir":
//			return "/prd/sdm/hadoop/";
//		case "ranger_policy.hdfsDataPath" :
//			return "/hdata/";
//		default:
//			return "";
//		}
	}

}
