package com.scb.selfservice.domains;

/*
 * pojo for
 *    workflowId and corresponding workflowType
 *    (workflow_process)
 */
public class WorkflowIdType {

	private Integer workflowId;
	private String  workflowType;
	private Integer version;

	public Integer getWorkflowId() {
		return workflowId;
	}
	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}
	public String getWorkflowType() {
		return workflowType;
	}
	public void setWorkflowType(String workflowType) {
		this.workflowType = workflowType;
	}
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	@Override
	public String toString() {
		return "WorkflowIdType [workflowId=" + workflowId + ", workflowType=" + workflowType + ", version=" + version
				+ "]";
	}

}
