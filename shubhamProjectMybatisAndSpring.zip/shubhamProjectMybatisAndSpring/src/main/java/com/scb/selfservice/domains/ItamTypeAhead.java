package com.scb.selfservice.domains;

public class ItamTypeAhead {
	
	private Integer itamId;
	private String itamName;
	public Integer getItamId() {
		return itamId;
	}
	public void setItamId(Integer itamId) {
		this.itamId = itamId;
	}
	public String getItamName() {
		return itamName;
	}
	public void setItamName(String itamName) {
		this.itamName = itamName;
	}

}
