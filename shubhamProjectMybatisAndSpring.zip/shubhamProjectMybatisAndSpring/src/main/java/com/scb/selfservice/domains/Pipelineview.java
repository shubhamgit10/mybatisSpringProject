package com.scb.selfservice.domains;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class Pipelineview {
	private Integer reqId;
	private String sourceName;
	private String instanceName;
	private String expectedDeliveryDate;
	private Integer expectedNoOfFiles;
	private Integer expectedNoOfAttributes;
	private Integer itamNumber;
	private String projectName;
	private String businessStream;
	private String fundingAvenue;
	private String benefitCatagory;
	private String benefitDetails;
	private String requestSummary;
	private String sourceType;

	public Integer getReqId() {
		return reqId;
	}

	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}

	public String getSourceName() {
		return sourceName;
	}

	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}

	public String getInstanceName() {
		return instanceName;
	}

	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}

	public String getExpectedDeliveryDate() {
		return expectedDeliveryDate;
	}

	public void setExpectedDeliveryDate(String expectedDeliveryDate) {
		this.expectedDeliveryDate = expectedDeliveryDate;
	}

	public Integer getExpectedNoOfFiles() {
		return expectedNoOfFiles;
	}

	public void setExpectedNoOfFiles(Integer expectedNoOfFiles) {
		this.expectedNoOfFiles = expectedNoOfFiles;
	}

	public Integer getExpectedNoOfAttributes() {
		return expectedNoOfAttributes;
	}

	public void setExpectedNoOfAttributes(Integer expectedNoOfAttributes) {
		this.expectedNoOfAttributes = expectedNoOfAttributes;
	}

	public Integer getItamNumber() {
		return itamNumber;
	}

	public void setItamNumber(Integer itamNumber) {
		this.itamNumber = itamNumber;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getBusinessStream() {
		return businessStream;
	}

	public void setBusinessStream(String businessStream) {
		this.businessStream = businessStream;
	}

	public String getFundingAvenue() {
		return fundingAvenue;
	}

	public void setFundingAvenue(String fundingAvenue) {
		this.fundingAvenue = fundingAvenue;
	}

	public String getBenefitCatagory() {
		return benefitCatagory;
	}

	public void setBenefitCatagory(String benefitCatagory) {
		this.benefitCatagory = benefitCatagory;
	}

	public String getBenefitDetails() {
		return benefitDetails;
	}

	public void setBenefitDetails(String benefitDetails) {
		this.benefitDetails = benefitDetails;
	}

	public String getRequestSummary() {
		return requestSummary;
	}

	public void setRequestSummary(String requestSummary) {
		this.requestSummary = requestSummary;
	}

	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	@Override
	public String toString() {
		return "Pipelineview [reqId=" + reqId + ", sourceName=" + sourceName + ", instanceName=" + instanceName
				+ ", expectedDeliveryDate=" + expectedDeliveryDate + ", expectedNoOfFiles=" + expectedNoOfFiles
				+ ", expectedNoOfAttributes=" + expectedNoOfAttributes + ", itamNumber=" + itamNumber + ", projectName="
				+ projectName + ", businessStream=" + businessStream + ", fundingAvenue=" + fundingAvenue
				+ ", benefitCatagory=" + benefitCatagory + ", benefitDetails=" + benefitDetails + ", requestSummary="
				+ requestSummary + ", sourceType=" + sourceType + "]";
	}

	public List<String> getGetters(Pipelineview item) {
		List<String> filedata = new ArrayList<>();
		filedata.add(Integer.toString(item.getReqId()));
		filedata.add(item.getSourceName());
		filedata.add(item.getInstanceName());
		filedata.add(item.getExpectedDeliveryDate());
		filedata.add(String.valueOf(item.getExpectedNoOfFiles()));
		filedata.add(String.valueOf(item.getExpectedNoOfAttributes()));
		filedata.add(String.valueOf(item.getItamNumber()));
		filedata.add(item.getProjectName());
		filedata.add(item.getBusinessStream());
		filedata.add(item.getFundingAvenue());
		filedata.add(item.getBenefitCatagory());
		filedata.add(item.getBenefitDetails());
		filedata.add(item.getRequestSummary());
		filedata.add(item.getSourceType());

		return filedata;
	}
}