package com.scb.selfservice.domains;

/*
 * pojo for
 * WORKFLOW_REQEUST
 */
public class WorkflowRequest {

	private Integer reqId;
	private Integer workflowId;
	private String  status;
	private String  remarks;
	Integer requestCreatedBy;
	//Timestamp requestCreatedAt; //this is set @db level as part of default value
	private String  lastActedStepId;

	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	public Integer getWorkflowId() {
		return workflowId;
	}
	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Integer getRequestCreatedBy() {
		return requestCreatedBy;
	}
	public void setRequestCreatedBy(Integer requestCreatedBy) {
		this.requestCreatedBy = requestCreatedBy;
	}
	/*
	 * public Timestamp getRequestCreatedAt() { return requestCreatedAt; } public
	 * void setRequestCreatedAt(Timestamp requestCreatedAt) { this.requestCreatedAt
	 * = requestCreatedAt; }
	 */
	public String getLastActedStepId() {
		return lastActedStepId;
	}
	public void setLastActedStepId(String lastActedStepId) {
		this.lastActedStepId = lastActedStepId;
	}
	@Override
	public String toString() {
		return "WorkflowRequest [reqId=" + reqId + ", workflowId=" + workflowId + ", status=" + status
				+ ", remarks=" + remarks + ", requestCreatedBy=" + requestCreatedBy + ", lastActedStepId="
				+ lastActedStepId + "]";
	}

}
