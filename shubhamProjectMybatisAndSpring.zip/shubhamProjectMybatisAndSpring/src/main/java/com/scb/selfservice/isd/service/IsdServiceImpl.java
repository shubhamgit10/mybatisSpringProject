package com.scb.selfservice.isd.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.selfservice.dao.mapper.ingestion.ISDSummaryMapper;
import com.scb.selfservice.isd.dao.ISDDaoImpl;
import com.scb.selfservice.isd.entity.ExceptionCategory;
import com.scb.selfservice.isd.entity.ISDConfiguration;
import com.scb.selfservice.isd.entity.ISDRequestDetails;
import com.scb.selfservice.isd.entity.ISDSummary;
import com.scb.selfservice.isd.entity.ISDTemplateInfo;
import com.scb.selfservice.isd.entity.ISDVerificationStatus;
import com.scb.selfservice.isd.entity.ViewExceptions;
import com.scb.selfservice.isd.exception.InvalidFileException;
import com.scb.selfservice.isd.validate.ValidationUtil;
import com.scb.selfservice.util.EDMpUtil;

/**
 * @author akuma400
 *
 */
@Service
public class IsdServiceImpl {

	private static Logger log = LogManager.getLogger(IsdServiceImpl.class);

	@Autowired
	private ISDDaoImpl isdDaoImpl;

	/*
	 * @Autowired private ISDServiceMapper isdServiceMapper;
	 */

	@Autowired
	private ISDSummaryMapper isdSummaryMapper;
	// private List<String> invalidCellsForNullCheck = new ArrayList<String>();
	/*
	 * validation error stored in map as per sheet(key), value is of type map where
	 * key is type of error and value is list of columns where this error type is
	 * coming
	 */
	private Map<String, Map<String, List<String>>> validationPerSheet = new HashMap<>();
	private Map<String, Map<String, String>> refValueOfNullCheckPerSheet = new HashMap<>();
	private Map<String, Map<String, String>> isdConfigDetailsPerSheet = new HashMap<>();
	

	public ISDVerificationStatus performOperationOnISD(XSSFWorkbook workbook, ISDRequestDetails isdInputs,
			Integer latestVersion) {
		log.info("Start:performOperationOnISD");
		Map<String, String> sheetNameAndsheetDBTableName = isdDaoImpl.getAllSheets();
		if (!ValidationUtil.AllPrimarySheetsExists(sheetNameAndsheetDBTableName, workbook)) {
			log.error("performOperationOnISD:sheets in uploaded excel doesnot match with the sheets descibed in DB");  
			return null;
		}
		
		List<ISDConfiguration> isdConfig = isdDaoImpl.getIsdCongiguration();
		log.debug("performOperationOnISD:isdConfig"+isdConfig);
		isdConfigDetailsPerSheet = arrangeIsdConfig(isdConfig);
		sheetNameAndsheetDBTableName.forEach((sheetName, sheetDBTableName) -> {
			log.info("sheetName=" + sheetName + " , sheetDBTableName=" + sheetDBTableName);
			ISDTemplateInfo isdTemplateInfo = isdDaoImpl.findAll(sheetName);
			List<Map<String, String>> listOfRecords = readISD(workbook, isdTemplateInfo, sheetName, isdInputs,
					validationPerSheet, isdConfigDetailsPerSheet);

			isdDaoImpl.saveISDRecord(isdInputs.getReqId(), listOfRecords, isdTemplateInfo, sheetDBTableName);
		});

		log.info("performOperationOnISD:validationPerSheet:" + validationPerSheet);
		ISDVerificationStatus varificationStatus = null;
		boolean sheetWithExceptions = validationPerSheet.values().stream().allMatch(x -> {
			return x.values().stream().allMatch(y -> y.isEmpty());
		});

		log.info("performOperationOnISD:sheetWithExceptions:" + sheetWithExceptions);
		 SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	//	SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
		if (sheetWithExceptions) {
			varificationStatus = new ISDVerificationStatus.Builder().updatedDate(fmt.format(new Date()))
					.systemName(isdInputs.getSystem()).countries(isdInputs.getCountry())
					.isdUploadStatus("Upload Successful").isdVarificationstatus("Passed").exceptionDetails(false)
					.versionNo(latestVersion).Build();
		}

		else {
			 isdDaoImpl.mapExceptions(isdInputs.getReqId(),
					validationPerSheet, latestVersion, refValueOfNullCheckPerSheet);
			varificationStatus = new ISDVerificationStatus.Builder().updatedDate(fmt.format(new Date()))
					.systemName(isdInputs.getSystem()).countries(isdInputs.getCountry())
					.isdUploadStatus("Upload Successful").isdVarificationstatus("Denied").exceptionDetails(true)
					.versionNo(latestVersion).Build();
		}
		isdDaoImpl.saveVarificationStatus(!sheetWithExceptions, isdInputs.getReqId(), varificationStatus,
				latestVersion);
		log.info("performOperationOnISD:end");
		return varificationStatus;
	}

	private Map<String, Map<String, String>> arrangeIsdConfig(List<ISDConfiguration> isdConfig) {
		log.info("arrangeIsdConfig:start");
		Map<String, Map<String, String>> config = new HashMap<>();
		for(ISDConfiguration configuration : isdConfig) {
			if(!config.containsKey(configuration.getSheetName())) {
				 Map<String, String> configValues = new HashMap<>();
				 configValues.put(configuration.getConfigKey(), configuration.getConfigValue());
				 config.put(configuration.getSheetName(), configValues);
			} else {
				config.get(configuration.getSheetName()).put(configuration.getConfigKey(), configuration.getConfigValue());
			}
		}
		log.info("arrangeIsdConfig:end");
		return config;
	}

	private List<Map<String, String>> readISD(XSSFWorkbook workbook, ISDTemplateInfo isdTemplateInfo, String sheetName,
			ISDRequestDetails isdInputs, Map<String, Map<String, List<String>>> validationPerSheet, Map<String, Map<String, String>> isdConfigDetailsPerSheet) {
		log.info("readISD:start");
		List<Map<String, String>> list = new LinkedList<>();
		Map<String, List<String>> errorRecord = new HashMap<>();
		List<String> columnNameForinvalidTableName = new LinkedList<>();
		List<String> columnNameForinvalidTargetTableName = new LinkedList<>();
		List<String> invalidDateFormatInFileName = new LinkedList<>();
		List<String> invalidDateFormatInData = new LinkedList<>();
		List<String> invalidCellsForNullCheck = new ArrayList<String>();
		Map<String, String> refValueOfNullCheck = new ConcurrentHashMap<>();

		try {
			Sheet sheet = workbook.getSheet(sheetName);
			int initialHeaderRaw = Integer.parseInt(isdConfigDetailsPerSheet.get(sheetName).get("initialHeaderRow"));
			int initialHeaderColumn = Integer.parseInt(isdConfigDetailsPerSheet.get(sheetName).get("initialHeaderColumn"));
			int initialRaw = Integer.parseInt(isdConfigDetailsPerSheet.get(sheetName).get("initialRow"));
			int initialColumn = Integer.parseInt(isdConfigDetailsPerSheet.get(sheetName).get("initialColumn"));
			int lastColumn = initialColumn;
			log.info("readISD:sheetName:"+sheetName);
			log.info("readISD:initialHeaderRaw:"+initialHeaderRaw);
			log.info("readISD:initialHeaderColumn:"+initialHeaderColumn);
			log.info("readISD:initialRaw:"+initialRaw);
			log.info("readISD:initialColumn:"+initialColumn);

			int instanceDetailsSheetLastRowNum = 0;
			if (sheetName.equals("Instance Details")) {
				instanceDetailsSheetLastRowNum = (int) sheet.getRow(Integer.parseInt(isdConfigDetailsPerSheet.get(sheetName).get("Total_Number_of_Instances_Value_Row")))
						.getCell(Integer.parseInt(isdConfigDetailsPerSheet.get(sheetName).get("Total_Number_of_Instances_Value_Cell"))).getNumericCellValue();
				log.info("readISD:instanceDetailsSheetLastRowNum:"+instanceDetailsSheetLastRowNum);
			}

			boolean flag = false;
		lastColumn = isdTemplateInfo.getColumnName().size();
		log.info("readISD:lastColumn:"+lastColumn);
			initialColumn = Integer.parseInt(isdConfigDetailsPerSheet.get(sheetName).get("initialColumn"));
			try {
					flag = ValidationUtil.validateSheetHeaderAsInDB(sheet, isdTemplateInfo, initialHeaderRaw,
							initialHeaderColumn);
					log.info("readISD:validateSheetHeaderAsInDB_flag:"+flag);
			} catch (Exception e) {
				log.error("readISD:columns of sheet doesnot match as descirbed in data base"+e.getStackTrace());
				throw new InvalidFileException("Sheet columns mismatch");
			}
			if (flag) {
				boolean dataInRow = true;
				// while(0.0!=sheet.getRow(initialRaw).getCell(firstColumn).getNumericCellValue())
				// {
				while (dataInRow) {
					Map<String, String> map = new LinkedHashMap<>();
					while (initialColumn <= lastColumn) {
						CellType cellType = sheet.getRow(initialRaw).getCell(initialColumn).getCellTypeEnum();
						switch (cellType) {
						case STRING:
							map.put(sheet.getRow(initialRaw).getCell(initialColumn).getAddress().formatAsString(), sheet
									.getRow(initialRaw).getCell(initialColumn).getRichStringCellValue().getString());
							
							String cellColumnId = sheet.getRow(initialRaw).getCell(initialColumn).getAddress().formatAsString().split("(?<=\\D)(?=\\d)")[0];
							String headerColumnName = isdTemplateInfo.getColumnName().get(isdTemplateInfo.getCellColumnNumber().indexOf(cellColumnId));
							/* Validation only for BA */
							if(isdConfigDetailsPerSheet.get("userType").get("BA").equals(isdInputs.getStepId())) {
							if (headerColumnName.equalsIgnoreCase("Table Name")
									&& sheetName.equalsIgnoreCase("Source_Field_Layout_Target Map")) {
								ValidationUtil.validateForInvalidTableName(sheet, isdTemplateInfo, initialRaw, initialColumn, isdInputs, columnNameForinvalidTableName, headerColumnName );
						}
							
							if (headerColumnName.equalsIgnoreCase("TableName")
									&& sheetName.equalsIgnoreCase("Source_Field_Layout_Target Map")) {
								ValidationUtil.validateForInvalidTableName(sheet, isdTemplateInfo, initialRaw, initialColumn, isdInputs, columnNameForinvalidTargetTableName, headerColumnName );
						}
							
							if(headerColumnName.equalsIgnoreCase("Date Format in File Name")
									&& sheetName.equalsIgnoreCase("Source_Table layout")) {
								String dateFormat = isdConfigDetailsPerSheet.get(sheetName).get("DateFormat");
								ValidationUtil.validateDateFormat(sheet, isdTemplateInfo, initialRaw, initialColumn, isdInputs, invalidDateFormatInFileName, dateFormat, headerColumnName);
							}
							
							if(headerColumnName.equalsIgnoreCase("Date Format in Data")
									&& sheetName.equalsIgnoreCase("Source_Table layout")) {
								String dateFormat = isdConfigDetailsPerSheet.get(sheetName).get("DateFormat");
								ValidationUtil.validateDateFormat(sheet, isdTemplateInfo, initialRaw, initialColumn, isdInputs, invalidDateFormatInData, dateFormat, headerColumnName);
							}
							}
							initialColumn++;

							break;
						case NUMERIC:
							map.put(sheet.getRow(initialRaw).getCell(initialColumn).getAddress().formatAsString(),
									String.valueOf((int) sheet.getRow(initialRaw).getCell(initialColumn)
											.getNumericCellValue()));
						initialColumn++;
							break;
						default:
							String rowID = sheet.getRow(initialRaw).getCell(initialColumn).getAddress()
									.formatAsString();
							// Validation for null is done here
							boolean checkForNull = ValidationUtil.validateForNull(rowID, isdTemplateInfo, initialRaw,
									initialColumn, sheet);
							if (checkForNull) {
								String value = sheet.getRow(initialRaw).getCell(initialColumn).getRichStringCellValue()
										.getString();
								if (null == value || value.isBlank()) {
									invalidCellsForNullCheck.add(rowID);
									String[] rowAndCell = rowID.split("(?<=\\D)(?=\\d)");
									if (isdTemplateInfo.getColumnName().contains("TABLE NAME")
											&& sheetName.equalsIgnoreCase("Source_Table layout")) {
										int index = isdTemplateInfo.getColumnName().indexOf("TABLE NAME");
										String cellId = isdTemplateInfo.getCellColumnNumber().get(index)
												+ rowAndCell[1];

										CellReference cr = new CellReference(cellId);
										String refValue = StringUtils.EMPTY;
										if (sheet.getRow(cr.getRow()).getCell(cr.getCol()).getCellTypeEnum()
												.equals(CellType.STRING)) {
											refValue = sheet.getRow(cr.getRow()).getCell(cr.getCol())
													.getStringCellValue();
											refValueOfNullCheck.put(rowID, refValue);
										}
										else
											refValueOfNullCheck.put(rowID, refValue);

									}

									if (isdTemplateInfo.getColumnName().contains("Column Name")
											&& sheetName.equalsIgnoreCase("Source_Field_Layout_Target Map")) {
										int index = isdTemplateInfo.getColumnName().indexOf("Column Name");
										String cellId = isdTemplateInfo.getCellColumnNumber().get(index)
												+ rowAndCell[1];

										CellReference cr = new CellReference(cellId);
										String refValue = StringUtils.EMPTY;
										if (sheet.getRow(cr.getRow()).getCell(cr.getCol()).getCellTypeEnum()
												.equals(CellType.STRING)) {
											refValue = sheet.getRow(cr.getRow()).getCell(cr.getCol())
													.getStringCellValue();
											refValueOfNullCheck.put(rowID, refValue);
										}
										else
											refValueOfNullCheck.put(rowID, refValue);
									}
								}
							}

							map.put(sheet.getRow(initialRaw).getCell(initialColumn).getAddress().formatAsString(),
									null);
							initialColumn++;
							break;
						}
					}

					if (!sheetName.equals("Instance Details")) {
						if (map.values().stream().allMatch(x -> null == x || x.trim().isEmpty())) {
							dataInRow = false;
							if (!invalidCellsForNullCheck.isEmpty()) {
								String removeEmptyRowError = invalidCellsForNullCheck
										.get(invalidCellsForNullCheck.size() - 1);
								String filter = (removeEmptyRowError.split("(?<=\\D)(?=\\d)"))[1];
								invalidCellsForNullCheck.removeIf(x -> x.endsWith(filter));
							}

							if (!refValueOfNullCheck.isEmpty() && !invalidCellsForNullCheck.isEmpty()) {
								String removeEmptyRowError = invalidCellsForNullCheck
										.get(invalidCellsForNullCheck.size() - 1);
								String filter = String.valueOf(
										Integer.valueOf((removeEmptyRowError.split("(?<=\\D)(?=\\d)"))[1]) + 1);
								refValueOfNullCheck.keySet().stream().filter(x -> {
									return x.endsWith(filter);
								}).forEach(y -> {
									if (refValueOfNullCheck.containsKey(y))
										refValueOfNullCheck.remove(y);
								});
							}
						}
					}

					if (dataInRow) {
						list.add(map);
						initialColumn = Integer.parseInt(isdConfigDetailsPerSheet.get(sheetName).get("initialColumn"));
						initialRaw++;
					}

					if (sheetName.equals("Instance Details") && initialRaw >= instanceDetailsSheetLastRowNum) {
						dataInRow = false;
					}
						}
				log.info("readISD:after reading all row");
				errorRecord.put("nullException", invalidCellsForNullCheck);
				errorRecord.put("invalidTableName", columnNameForinvalidTableName);
				errorRecord.put("invalidTargetTableName", columnNameForinvalidTargetTableName);
				errorRecord.put("invalidDateFormatInFileName", invalidDateFormatInFileName);
				errorRecord.put("invalidDateFormatInData", invalidDateFormatInData);
				
				if (sheetName.equals("Source_Table layout")) {
					// the inputs of the form will be validated against the ISD for its correctness
					// - Number of Files
					int numberOfTables = (int) list.stream().filter(x -> {
						String suffix = (String) x.keySet().toArray()[0];
						String key = isdTemplateInfo.getCellColumnNumber()
								.get(isdTemplateInfo.getColumnName().indexOf("TABLE NAME"))
								+ suffix.split("(?<=\\D)(?=\\d)")[1];
						return null != x.get(key) && !x.get(key).isEmpty();
					}).count();
					log.info("readISD:number Of Tables impacted:"+numberOfTables);
					List<String> listNoOfTables = new ArrayList<String>();
					listNoOfTables.add(String.valueOf(isdInputs.getFilesCount() - numberOfTables));
					errorRecord.put("filesCountError", listNoOfTables);

					List<String> listOfcountriesInput = Arrays.asList(isdInputs.getCountry().split(","));
					List<String> listOfcountriesSourceTable = list.stream().filter(x -> {
						String suffix = (String) x.keySet().toArray()[0];
						String key = isdTemplateInfo.getCellColumnNumber()
								.get(isdTemplateInfo.getColumnName().indexOf("Country"))
								+ suffix.split("(?<=\\D)(?=\\d)")[1];
						return null != x.get(key) && !x.get(key).isEmpty();
					}).map(x -> {
						String suffix = (String) x.keySet().toArray()[0];
						String key = isdTemplateInfo.getCellColumnNumber()
								.get(isdTemplateInfo.getColumnName().indexOf("Country"))
								+ suffix.split("(?<=\\D)(?=\\d)")[1];
						return x.get(key);
					}).distinct().collect(Collectors.toList());
					if (!listOfcountriesSourceTable.containsAll(listOfcountriesInput)) {
						int count = (int) listOfcountriesInput.stream()
								.filter(x -> !listOfcountriesSourceTable.contains(x)).count();
						List<String> requestedCountyExceptionCount = new ArrayList<String>();
						requestedCountyExceptionCount.add(String.valueOf(Math.abs(count)));
						errorRecord.put("requestedCountyException", requestedCountyExceptionCount);
					}
				}

				if (sheetName.equals("Source_Field_Layout_Target Map")) {
					/*
					 * implementation for the inputs of the form will be validated against the ISD
					 * for its correctness - Number of attributes
					 */
					int numberOfTables = (int) list.stream().filter(x -> {
						String suffix = (String) x.keySet().toArray()[0];
						String key = isdTemplateInfo.getCellColumnNumber()
								.get(isdTemplateInfo.getColumnName().indexOf("Column Name"))
								+ suffix.split("(?<=\\D)(?=\\d)")[1];
						return null != x.get(key) && !x.get(key).isEmpty();
					}).count();
					List<String> listNoOfTables = new ArrayList<String>();
					listNoOfTables.add(String.valueOf(isdInputs.getAttributesCount() - numberOfTables));
					errorRecord.put("attributesCountError", listNoOfTables);
				}

				validationPerSheet.put(sheetName, errorRecord);
				refValueOfNullCheckPerSheet.put(sheetName, refValueOfNullCheck);
			} else {
				/*
				 * this can happen if any excel sheet header which is defined in db(column_name)
				 * is not mapped correctly in parallel to cell_column_number in db
				 */
				log.error("readISD:Invalid header columns in sheet:"+sheetName);
				throw new InvalidFileException("Invalid header columns in sheet "+ sheetName);
			}

			log.info("readISD:Sheet read Over");
			workbook.close();
			

		} catch (IOException e) {
			log.error("readISD:Improper excel file uploaded:"+e.getStackTrace());
			throw new InvalidFileException("Improper excel file uploaded");
		}
		log.info("readISD:end");
		return list;
	}

	public void saveISDFile(byte[] bytes, ISDRequestDetails isdInputs, String fileName) {

		try {

			log.info("Start:saveISDFile");
			isdDaoImpl.saveExcel(bytes, isdInputs, fileName);
			log.info("END:saveISDFile");
		} catch (Exception e) {
			log.error("saveISDFile: error saving file in db:"+e.getStackTrace());
		}
	}

	public List<ISDVerificationStatus> getVerificationStatus(ISDRequestDetails isdInputs) {
		log.info("getVarificationStatus");
		return isdDaoImpl.getVerificationStatus(isdInputs);
	}

	public List<ISDSummary> getISDSummary(ISDRequestDetails isdInputs) {
		log.info("<--Getting ISD  response for request Id ::" + isdInputs.getReqId());
		ISDSummary isdSummary = null;
		Integer itamId=isdSummaryMapper.getItamId(isdInputs.getReqId());
        log.info("Itam id = "+ itamId);

		List<ISDSummary> isdListSummary = new ArrayList<>();
		List<String> countriesList = Arrays.asList(isdInputs.getCountry().split("\\s*,\\s*"));
		
		if (itamId !=null) {
		List<String> noOfExDataset = isdSummaryMapper.getNoExistingDatasets(itamId,isdInputs.getSystem(), isdInputs.getReqId());
		List<String> noOfNewDataset = isdSummaryMapper.getNoNewDatasets(itamId,isdInputs.getSystem(), isdInputs.getReqId());
		List<String> noOfExAttribute = isdSummaryMapper.getNoExistingAttributes(itamId,isdInputs.getSystem(), isdInputs.getReqId());
		List<String> noOfNewAttribute = isdSummaryMapper.getNoNewAttributes(itamId,isdInputs.getSystem(), isdInputs.getReqId());
		
		String str = StringUtils.EMPTY;

		for (int i = 0; i < countriesList.size(); i++) {

			isdSummary = new ISDSummary();
			isdSummary.setInstanceName(countriesList.get(i));
			String s1 = countriesList.get(i);

			if (noOfExDataset != null && noOfExDataset.size() > 0) {
				str = noOfExDataset.stream().filter(s -> s.contains(s1)).collect(Collectors.toList()).toString();
				if (str != null && !"[]".equals(str)) {
					isdSummary.setExistingDatasets(str.substring(4, str.length() - 1));
				} else {
					isdSummary.setExistingDatasets("0");
				}
			} else {
				isdSummary.setExistingDatasets("0");
			}

			if (noOfNewDataset != null && noOfNewDataset.size() > 0) {
				str = noOfNewDataset.stream().filter(s -> s.contains(s1)).collect(Collectors.toList()).toString();
				if (str != null && !"[]".equals(str)) {
					isdSummary.setNewDatasets(str.substring(4, str.length() - 1));
				} else {
					isdSummary.setNewDatasets("0");
				}
			} else {
				isdSummary.setNewDatasets("0");
			}

			if (noOfExAttribute != null && noOfExAttribute.size() > 0) {
				str = noOfExAttribute.stream().filter(s -> s.contains(s1)).collect(Collectors.toList()).toString();
				if (str != null && !"[]".equals(str)) {
					isdSummary.setExistingAttributes(str.substring(4, str.length() - 1));
				} else {
					isdSummary.setExistingAttributes("0");
				}
			} else {
				isdSummary.setExistingAttributes("0");
			}

			if (noOfNewAttribute != null && noOfNewAttribute.size() > 0) {
				str = noOfNewAttribute.stream().filter(s -> s.contains(s1)).collect(Collectors.toList()).toString();
				if (str != null && !"[]".equals(str)) {
					isdSummary.setNewAttributes(str.substring(4, str.length() - 1));
				} else {
					isdSummary.setNewAttributes("0");
				}
			} else {				
				isdSummary.setNewAttributes("0");
			}
			isdSummary.setReqId(isdInputs.getReqId());
			isdListSummary.add(isdSummary);

		}
		}
		return isdListSummary;
	}

	public List<ViewExceptions> retrieveException(int reqId, Integer versionNo) {
		log.info("retrieveException:Start");
		return isdDaoImpl.getAllException(reqId, versionNo);

	}

	public Integer getLatestVersion(Integer reqId) {
		log.info("getLatestVersion:Start");
		return isdDaoImpl.getISDVersion(reqId);
	}

	public ByteArrayInputStream prepareFileForException(int reqId, Integer versionNo) {
		log.info("prepareFileForException:Start");
		List<ExceptionCategory> exceptionDetails = isdDaoImpl.getExceptionDetails(reqId, versionNo);

		// XSSFWorkbook workbook = null;
		// ByteArrayOutputStream out = null;
		try (XSSFWorkbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			XSSFSheet sheet = workbook.createSheet("ISDExceptions");

			int rownum = 0;
			int cellnum = 0;
			Row row = sheet.createRow(rownum++);
			CellStyle cellStyle = EDMpUtil.getHeaderCellStyle(workbook);
			Cell cell = row.createCell(cellnum++);

			cell.setCellValue("S.No.");
			cell.setCellStyle(cellStyle);

			cell = row.createCell(cellnum++);
			cell.setCellValue("Exception Type");
			cell.setCellStyle(cellStyle);

			cell = row.createCell(cellnum++);
			cell.setCellValue("Tables/Columns Impacted");
			cell.setCellStyle(cellStyle);

			cell = row.createCell(cellnum);
			cell.setCellValue("Description");
			cell.setCellStyle(cellStyle);

			for (ExceptionCategory exceptions : exceptionDetails) {
				cellnum = 0;
				row = sheet.createRow(rownum++);
				cell = row.createCell(cellnum++);
				cell.setCellValue(rownum - 1);
				cell = row.createCell(cellnum++);
				cell.setCellValue(exceptions.getIssueCategory());
				cell = row.createCell(cellnum++);
				cell.setCellValue(
						!exceptions.getTablesImpacted().equals("NA") ? "Tables Impacted" : "Columns Impacted");
				cell = row.createCell(cellnum);
				cell.setCellValue(exceptions.getDescription());

			}
			workbook.write(out);
			log.info("prepareFileForException:end");
			return new ByteArrayInputStream(out.toByteArray());

		} catch (Exception e) {
			log.error("prepareFileForException exception:"+ e.getStackTrace());
			return null;
		}
	}

	public void updateFlagForApproval(int reqId) {
		isdDaoImpl.updateFlag(reqId);
		
	}
}
