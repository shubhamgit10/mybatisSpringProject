/**
 * 
 */
package com.scb.selfservice.workflow.service.task;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.selfservice.service.ConsumerRequestEmailService;
import com.scb.selfservice.workflow.service.ExecutionContext;
import com.scb.selfservice.workflow.service.WorkflowServiceTask;

/**
 * Mail Notification Task for Consumption Workflow
 * 
 * @author Amarnath BB
 *
 */
@Service(value = "consumptionMailNotifTask")
public class MailNotificationTask implements WorkflowServiceTask {

	@Autowired
	private ConsumerRequestEmailService consumerRequestEmailService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.selfservice.workflow.service.WorkflowServiceTask#execute(com.scb.
	 * selfservice.workflow.service.ExecutionContext)
	 */
	@Override
	public String execute(ExecutionContext context) {
		System.out.println("Inside Mail Notification Task for " + context.getReqId() + " - " + context.getStepId());
		consumerRequestEmailService.sendStatusMail(Integer.parseInt(context.getReqId()),
				context.getStepId(), context.getAction());		
		System.out.println("Inside Mail Notification Task for Request id " + context.getReqId());		
		return "SUCCESS";
	}
	

}
