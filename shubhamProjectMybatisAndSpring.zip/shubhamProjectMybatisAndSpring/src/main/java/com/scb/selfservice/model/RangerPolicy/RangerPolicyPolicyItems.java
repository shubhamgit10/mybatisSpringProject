package com.scb.selfservice.model.RangerPolicy;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 1610601 on 7/30/2020.
 */
public class RangerPolicyPolicyItems {

    private List<RangerPolicyAccesses> accesses;
    private List<String> users;
    private List<String> groups;
    private List<RangerPolicyAccesses> conditions;
    private boolean delegateAdmin;
    private RangerPolicyDataMask dataMaskInfo;

    public RangerPolicyPolicyItems() {
    	this.accesses = new ArrayList<RangerPolicyAccesses>();
    	this.users = new ArrayList<String>();
    	this.groups = new ArrayList<String>();
    	this.conditions = new ArrayList<RangerPolicyAccesses>();
    	this.delegateAdmin = false;
    }

    public RangerPolicyPolicyItems(List<RangerPolicyAccesses> accesses,
                                   List<String> users, List<String> groups,
                                   List<RangerPolicyAccesses> conditions, boolean delegateAdmin) {
        this.accesses = accesses;
        this.users = users;
        this.groups = groups;
        this.conditions = conditions;
        this.delegateAdmin = delegateAdmin;
    }

    public List<RangerPolicyAccesses> getAccesses() {
        return accesses;
    }

    public void setAccesses(List<RangerPolicyAccesses> accesses) {
        this.accesses = accesses;
    }

    public List<String> getUsers() {
        return users;
    }

    public void setUsers(List<String> users) {
        this.users = users;
    }

    public List<String> getGroups() {
        return groups;
    }

    public void setGroups(List<String> groups) {
        this.groups = groups;
    }

    public List<RangerPolicyAccesses> getConditions() {
        return conditions;
    }

    public void setConditions(List<RangerPolicyAccesses> conditions) {
        this.conditions = conditions;
    }

    public boolean isDelegateAdmin() {
        return delegateAdmin;
    }

    public void setDelegateAdmin(boolean delegateAdmin) {
        this.delegateAdmin = delegateAdmin;
    }

    public RangerPolicyDataMask getDataMaskInfo() {
        return dataMaskInfo;
    }

    public void setDataMaskInfo(RangerPolicyDataMask dataMaskInfo) {
        this.dataMaskInfo = dataMaskInfo;
    }

    @Override
    public String toString() {
        return "RangerPolicyPolicyItems{" +
                "accesses=" + accesses +
                ", users=" + users +
                ", groups=" + groups +
                ", conditions=" + conditions +
                ", delegateAdmin=" + delegateAdmin +
                ", dataMaskInfo=" + dataMaskInfo +
                '}';
    }
}
