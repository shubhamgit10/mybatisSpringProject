package com.scb.selfservice.web.controller;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.service.MyRequestService;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;
import com.scb.selfservice.web.authentication.UserPrincipal;

@RestController
@RequestMapping("/api/request")
public class MyRequestController {

	private static Logger logger = LogManager.getLogger(MyRequestController.class);
	
	@Autowired
	private MyRequestService requestService;
	
	@GetMapping(path = "/getRequests", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getMyRequest(@RequestParam("workflowType") String workflowType) {
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response requestListResponse = new Response();
		if (loggedInUser != null) {
			requestListResponse = requestService.getMyRequest(Integer.valueOf(loggedInUser.getUserId()), workflowType);	
		} else {
			requestListResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			requestListResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
		return new ResponseEntity<Response>(requestListResponse,HttpStatus.OK);
	}
	
	@GetMapping(path = "/getApprovalWorkflow", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getApprovalWorkflow(@RequestParam("requestId") Integer requestId, 
			@RequestParam("workflowType") String workflowType) {
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response approvalWorkFlowResponse = new Response();
		if (loggedInUser != null) {
			try {
				approvalWorkFlowResponse = requestService.getApprovalWorkflow(requestId, workflowType);
			} catch (Exception ex) {
				logger.info("EXCEPTION MyRequestController::getApprovalWorkflow: " + ex.getMessage());
				approvalWorkFlowResponse.setStatus(HttpStatus.NO_CONTENT.toString());
				approvalWorkFlowResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			}	
		} else {
			approvalWorkFlowResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			approvalWorkFlowResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
		return new ResponseEntity<Response>(approvalWorkFlowResponse,HttpStatus.OK);
	}

	@PostMapping(path = "/cancelRequest", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> cancelRequest(@RequestBody HashMap<String, String> cancelMap) {
		logger.info("STARTED MyRequestController::cancelRequest");
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response approvalWorkFlowResponse = new Response();
		if (loggedInUser != null) {
			try {
				cancelMap.put("userId", loggedInUser.getUserId());
				
				approvalWorkFlowResponse = requestService.cancelRequest(cancelMap);
			} catch (Exception ex) {
				logger.info("EXCEPTION MyRequestController::cancelRequest: " + ex.getMessage());
				approvalWorkFlowResponse.setStatus(HttpStatus.NO_CONTENT.toString());
				approvalWorkFlowResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			}	
		} else {
			approvalWorkFlowResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			approvalWorkFlowResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
		logger.info("EXITING MyRequestController::cancelRequest");
		return new ResponseEntity<Response>(approvalWorkFlowResponse,HttpStatus.OK);
	}
	
	/**
	 * Ingestion - fetch list of user request
	 * @param workflowType
	 * @return
	 */
	@GetMapping(path = "/getIngestionRequest", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getIngestionRequest(@RequestParam("workflowType") String workflowType){
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response requestListResponse = new Response();
		if (loggedInUser != null) {
			try {
				requestListResponse = requestService.getMyIngestionRequest(Integer.valueOf(loggedInUser.getUserId()), workflowType);
			} catch (Exception ex) {
				logger.info("EXCEPTION MyRequestController::getIngestionRequest: " + ex.getMessage());
				requestListResponse.setStatus(HttpStatus.NO_CONTENT.toString());
				requestListResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			}	
		} else {
			requestListResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			requestListResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
		return new ResponseEntity<Response>(requestListResponse,HttpStatus.OK);
	}

	/**
	 * 
	 * Ingestion - 
	 * @param requestId
	 * @param workflowType
	 * @return
	 */
	@GetMapping(path = "/getIngestionApprovalWorkflow", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getIngestionApprovalWorkflow(@RequestParam("requestId") Integer requestId, 
			@RequestParam("workflowType") String workflowType) {
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response approvalWorkFlowResponse = new Response();
		if (loggedInUser != null) {
			try {
				approvalWorkFlowResponse = requestService.getIngestionApprovalWorkflow(requestId, workflowType);
			} catch (Exception ex) {
				logger.info("EXCEPTION MyRequestController::getIngestionApprovalWorkflow: " + ex.getMessage());
				approvalWorkFlowResponse.setStatus(HttpStatus.NO_CONTENT.toString());
				approvalWorkFlowResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			}	
		} else {
			approvalWorkFlowResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			approvalWorkFlowResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
		return new ResponseEntity<Response>(approvalWorkFlowResponse,HttpStatus.OK);
	}
}
