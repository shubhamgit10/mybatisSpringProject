package com.scb.selfservice.model;

import java.sql.Timestamp;

/*
 * pojo for pulling all pending requests
 * along with LapsedTime for SLA EMAIL
 */
public class ConsumptionPending {

	private Integer reqId;
	private String  stepId;
	private String  status;
	private Timestamp startTime;
	private Integer lapsedTime;
	private Integer workflowId;
	private Integer attempt;

	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Timestamp getStartTime() {
		return startTime;
	}
	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}
	public Integer getLapsedTime() {
		return lapsedTime;
	}
	public void setLapsedTime(Integer lapsedTime) {
		this.lapsedTime = lapsedTime;
	}
	public Integer getWorkflowId() {
		return workflowId;
	}
	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}
	public Integer getAttempt() {
		return attempt;
	}
	public void setAttempt(Integer attempt) {
		this.attempt = attempt;
	}
	@Override
	public String toString() {
		return "ConsumptionPending [reqId=" + reqId + ", stepId=" + stepId + ", status=" + status + ", startTime="
				+ startTime + ", lapsedTime=" + lapsedTime + ", workflowId=" + workflowId + ", attempt=" + attempt
				+ "]";
	}
}
