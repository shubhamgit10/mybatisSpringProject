package com.scb.selfservice.service.impl;

import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.scb.selfservice.dao.mapper.IngestionDynamicMapper;
import com.scb.selfservice.dao.mapper.WorkflowMapper;
import com.scb.selfservice.domains.IngestionDeployForms;
import com.scb.selfservice.domains.IngestionInput;
import com.scb.selfservice.domains.IngestionTestForms;
import com.scb.selfservice.domains.IngestionTestIterations;
import com.scb.selfservice.domains.WorkflowIdType;
import com.scb.selfservice.service.UserResponseService;
import com.scb.selfservice.util.Response;

@Service(value = "ProdTrailRunVerification")
public class IngestionSitVerfImpl implements UserResponseService {

	
	private static Logger logger = LogManager.getLogger(IngestionSitVerfImpl.class);

	@Autowired
	IngestionDynamicMapper idynMapper;

	@Autowired
	WorkflowMapper workflowMapper;

	@Override
	public Response executeSave(IngestionInput ingestionInput) {
		// TODO Auto-generated method stub

		logger.info("inside IngestionSitVerfImpl :: executeSave method");

		Response isaResponse = new Response();

		try {
			isaResponse = saveSitVerfResp(ingestionInput);

		} catch (Exception e) {

			logger.info("Exception::" + e);
		}

		return isaResponse;
	}

	private Response saveSitVerfResp(IngestionInput ingestionInput) throws Exception {
		// TODO Auto-generated method stub
		logger.info("START IngestionSitVerfImpl::saveSitResp");

		Response isaResponse = new Response();

		HashMap<String, Object> hm = (HashMap<String, Object>) ingestionInput.getParams();

		hm.put("reqId", ingestionInput.getReqId());

		hm.put("stepId", ingestionInput.getStepId());

		WorkflowIdType workflowId = workflowMapper.getWorkflowId(ingestionInput.getWorkflowType());

		int Id = workflowId.getWorkflowId();

		hm.put("workflowId", Id);

		hm.put("userAction", ingestionInput.getUserAction());

		hm.put("requestCreatedBy", ingestionInput.getUserId());
		
		hm.put("executionStatus", "In Process");

		IngestionTestForms irObj = idynMapper.sitVerffindByReqId(ingestionInput.getReqId(),ingestionInput.getStepId());

		if (irObj == null) {
			logger.info("START it is a new entry for new request..." + ingestionInput.getReqId());

			int saveStatus = idynMapper.saveSitVerfReq(hm); // insert

			isaResponse = getActionStatus("save", saveStatus, ingestionInput.getReqId());

			logger.info("EXIT save request at userAction equals null");
		} else {

			int updateStatus = idynMapper.updateSitVerfReq(hm); // update

			isaResponse = getActionStatus("update", updateStatus, ingestionInput.getReqId());

		}

		logger.info("START it is a new entry for new request..." + ingestionInput.getReqId());

		Response res = new Response();

		List<IngestionTestIterations> irObjNew = null;

		if (isaResponse.getStatusCode() == 200) {

			if (null == ingestionInput.getUserAction()) {

				// insert into IngestionDeployIterations table
				int saveStatusIterations = idynMapper.saveSitVerfIterationReq(hm); // insert
				
				res = getActionStatus("update", saveStatusIterations, ingestionInput.getReqId());
				
				logger.info("EXIT save data into Sit Iterations table when userAction equals null");
			}
	
					irObjNew = idynMapper.verficationfindByReqId(ingestionInput.getReqId(),ingestionInput.getStepId());

					logger.info("EXIT save data into Sit Iterations table when userAction equals null");

						isaResponse.setResponse(irObjNew);

				if(irObjNew==null) {
					
					isaResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
					isaResponse.setStatus(HttpStatus.NO_CONTENT.toString());
					isaResponse.setResponse("!!! failed to fetch record!!!");
					
				}
			
		}
		logger.info("EXIT IngestionSitVerfImpl::saveSitVerfResp");

		return isaResponse;
	}

	/**
	 * @param type
	 * @param saveStatus
	 * @param reqId
	 * @return
	 */
	private Response getActionStatus(String type, int saveStatus, int reqId) {
		Response response = new Response();
		if (saveStatus == 1) {
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus(HttpStatus.OK.toString());
			response.setResponse(reqId + "Request id " + (type.equals("save") ? "INSERTED" : "UPDATED"));
		} else {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
			response.setResponse("!!!Action not taken!!!");
		}
		return response;
	}
	
	/**
	 *
	 */
	@Override
	public Response fetchApprovalResponse(IngestionInput ingestionInput) {
		//IngestionRequestorResp costAppResponse = idynMapper.CAfindByRequestId(requestId);
		//IngestionDeployForms sitAppResponse = idynMapper.SitfindByRequestId(requestId);
		//IngestionTestForms sitVerifyResp = idynMapper.sitVfindByReqId(ingestionInput.getReqId());
		IngestionTestForms sitVerifyResp = idynMapper.sitVerffindByReqId(ingestionInput.getReqId(), ingestionInput.getStepId());
		//Response costAppResponse = eiReqService.findByReqId(requestId);
		Response response = new Response();
		response.setResponse(sitVerifyResp);
		return response;
	}


}
