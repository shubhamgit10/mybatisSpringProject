package com.scb.selfservice.dao.td.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.databaseentity.ImpactedConsumer;

public interface ImpactedConsumerTDMapper {

	public List<ImpactedConsumer>  findByImpactedConsumer(@Param("tableNames")List<String> tableNames);
	
}
