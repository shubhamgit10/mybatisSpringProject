package com.scb.selfservice.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.WorkflowRespTableMapping;

public interface WorkflowRespTableMapper {
	
		
	//method to pull existing WorkflowRespTableMapping based on reqId
		public WorkflowRespTableMapping findByStepId( @Param("workflowId") Integer workflowId,@Param("stepId") String stepId);

}
