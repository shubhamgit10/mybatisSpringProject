package com.scb.selfservice.domains;

/*
 * pojo for
 *    pulling Delivery Manager's PSID from
 *    edmp_consumption_request
 *    based on reqId (req_id)
 */
public class DMPsid {
	private Integer reqId;
	private String  psid;
	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	public String getPsid() {
		return psid;
	}
	public void setPsid(String psid) {
		this.psid = psid;
	}

}
