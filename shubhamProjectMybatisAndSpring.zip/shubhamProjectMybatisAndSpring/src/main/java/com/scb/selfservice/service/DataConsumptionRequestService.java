package com.scb.selfservice.service;


import com.scb.selfservice.domains.ConsumptionRequest;
import com.scb.selfservice.domains.EDMPSelfServiceReq;
import com.scb.selfservice.util.Response;

public interface DataConsumptionRequestService {

	//method for save/insert the DataConsumptionRequest
	public Response saveConsumptionRequest(ConsumptionRequest consumptionRequest);

	//method to pull existing DataConsumptionRequest based on reqId
	public Response findByReqId(Integer reqId);

	public Response submitConsumptionRequest(EDMPSelfServiceReq edmpSelfServiceReq) throws Exception;

	public Response getItamdetails(String itam);

}
