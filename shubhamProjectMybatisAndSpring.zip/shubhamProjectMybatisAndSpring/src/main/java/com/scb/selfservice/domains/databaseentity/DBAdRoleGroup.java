package com.scb.selfservice.domains.databaseentity;

public class DBAdRoleGroup {
	
	public String bizFunctId;
	
	public String bizFuncName;
	
	public String adGroupName;

	public String getBizFunctId() {
		return bizFunctId;
	}

	public void setBizFunctId(String bizFunctId) {
		this.bizFunctId = bizFunctId;
	}

	public String getBizFuncName() {
		return bizFuncName;
	}

	public void setBizFuncName(String bizFuncName) {
		this.bizFuncName = bizFuncName;
	}

	public String getAdGroupName() {
		return adGroupName;
	}

	public void setAdGroupName(String adGroupName) {
		this.adGroupName = adGroupName;
	}
	
}
