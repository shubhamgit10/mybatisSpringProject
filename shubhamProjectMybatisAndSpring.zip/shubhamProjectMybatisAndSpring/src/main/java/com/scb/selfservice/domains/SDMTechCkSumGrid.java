package com.scb.selfservice.domains;

public class SDMTechCkSumGrid {
	
	private String checksumDatasetName;
	private String checksumSourceValue;
	private String checksumTargetValue;
	
	public String getChecksumDatasetName() {
		return checksumDatasetName;
	}
	public void setChecksumDatasetName(String checksumDatasetName) {
		this.checksumDatasetName = checksumDatasetName;
	}
	public String getChecksumSourceValue() {
		return checksumSourceValue;
	}
	public void setChecksumSourceValue(String checksumSourceValue) {
		this.checksumSourceValue = checksumSourceValue;
	}
	public String getChecksumTargetValue() {
		return checksumTargetValue;
	}
	public void setChecksumTargetValue(String checksumTargetValue) {
		this.checksumTargetValue = checksumTargetValue;
	}
	@Override
	public String toString() {
		return "SDMTechCkSumGrid [checksumDatasetName=" + checksumDatasetName + ", checksumSourceValue="
				+ checksumSourceValue + ", checksumTargetValue=" + checksumTargetValue + "]";
	}
	
}
