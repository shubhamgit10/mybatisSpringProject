package com.scb.selfservice.isd.entity;

/**
 * @author akuma400
 *
 */
public class ISDVerificationStatus {
	
	private String updatedDate;
	private String system;
	private String countries;
	private String isdUploadStatus;
	private String isdVarificationstatus;
	private Boolean exceptionDetails;
	private Integer versionNo;
	
	private ISDVerificationStatus() {}
	
	public String getUpdatedDate() {
		return updatedDate;
	}

	public String getSystem() {
		return system;
	}

	public String getCountries() {
		return countries;
	}

	public String getIsdUploadStatus() {
		return isdUploadStatus;
	}

	public String getIsdVarificationstatus() {
		return isdVarificationstatus;
	}

	public Boolean getExceptionDetails() {
		return exceptionDetails;
	}

	public Integer getVersionNo() {
		return versionNo;
	}

	public static class Builder{

	private String updatedDate;
	private String system;
	private String countries;
	private String isdUploadStatus;
	private String isdVarificationstatus;
	private Boolean exceptionDetails;
	private Integer versionNo;
	
	public Builder() {}
	
	public Builder updatedDate(String date) {
		this.updatedDate = date;
		return this;
	}
	
	public Builder systemName(String system) {
		this.system = system;
		return this;
	}
	
	public Builder countries(String countries) {
		this.countries = countries;
		return this;
	}

	public Builder isdUploadStatus(String isdUploadStatus) {
		this.isdUploadStatus = isdUploadStatus;
		return this;
	}

	public Builder isdVarificationstatus(String isdVarificationstatus) {
		this.isdVarificationstatus = isdVarificationstatus;
		return this;
	}

	public Builder exceptionDetails(Boolean exceptionDetails) {
		this.exceptionDetails = exceptionDetails;
		return this;
	}
	public Builder versionNo(Integer versionNo) {
		this.versionNo = versionNo;
		return this;
	}
	public ISDVerificationStatus Build() {
		ISDVerificationStatus varificationStatus = new ISDVerificationStatus();
		varificationStatus.updatedDate = this.updatedDate;
		varificationStatus.system = this.system;
		varificationStatus.countries = this.countries;
		varificationStatus.isdUploadStatus = this.isdUploadStatus;
		varificationStatus.isdVarificationstatus = this.isdVarificationstatus;
		varificationStatus.exceptionDetails = this.exceptionDetails;
		varificationStatus.versionNo=this.versionNo;
		return varificationStatus;
	}

	}

	@Override
	public String toString() {
		return "ISDVarificationStatus [updatedDate=" + updatedDate + ", system=" + system + ", countries=" + countries
				+ ", isdUploadStatus=" + isdUploadStatus + ", isdVarificationstatus=" + isdVarificationstatus
				+ ", exceptionDetails=" + exceptionDetails + ", versionNo=" + versionNo + "]";
	}

	
}
