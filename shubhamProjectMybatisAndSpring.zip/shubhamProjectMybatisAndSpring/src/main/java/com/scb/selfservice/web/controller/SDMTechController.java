package com.scb.selfservice.web.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.service.SDMTechService;
import com.scb.selfservice.service.impl.SDMTechConfigImpl;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;
import com.scb.selfservice.web.authentication.UserPrincipal;

/**
 * 
 * @author shubhasi
 * 
 *         Controller class for SDM Tech
 */
@RestController
@RequestMapping("/api/sdm")
public class SDMTechController {
	private static Logger logger = LogManager.getLogger(SDMTechController.class);

	@Autowired
	private SDMTechService sdmTechService;

	@Autowired
	private SDMTechConfigImpl urs;

	@RequestMapping(value = "/getTable/{reqId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> retreiveSDMTableName(@PathVariable("reqId") Integer reqId) {
		logger.info("Start:Controller");
		Response sdmTableResponse = new Response();
		try {
			sdmTableResponse = sdmTechService.getSDMTableName(reqId);
			sdmTableResponse.setStatusCode(HttpStatus.OK.value());
			sdmTableResponse.setStatus(HttpStatus.OK.toString());

		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ResponseEntity<Response>(sdmTableResponse, HttpStatus.OK);
	}
	
	@GetMapping(path = "/globalparameter", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getGlobalParameter() {
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response getglobalparamresponse = new Response();
		if (loggedInUser != null) {
			getglobalparamresponse = sdmTechService.findByReqGlobalParam();
		} else {
			getglobalparamresponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			getglobalparamresponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
		return new ResponseEntity<Response>(getglobalparamresponse, HttpStatus.OK);
	}
}
