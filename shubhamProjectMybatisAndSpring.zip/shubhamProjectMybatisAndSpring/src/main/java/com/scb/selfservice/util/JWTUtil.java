package com.scb.selfservice.util;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;

@Component
public class JWTUtil{
	
    private static Logger logger = LogManager.getLogger(JWTUtil.class);
    private final String JWT_SECRET_KEY="StAnDaRd#1";
    private final String JWT_SUBJECT="self-service";
    private final String JWT_AUDIENCE="edm-consumer";
    private final String JWT_ISSUER="edm-self-service.com";
    private final int DAY_DURATION = 1000 * 60 * 60; // 1 Hour
    

    private Map<String,Object> setHeader(){
    	Map<String,Object> jwtHeader = new HashMap<String,Object>();
        jwtHeader.put("typ","JWT");
        jwtHeader.put("alg","HCMAC256");
        return jwtHeader;
    }
    
    /**
     * Method to create JWT
     * @param userId
     * @return
     * @throws JWTCreationException
     */
    public String createJWT(String userId, String roles, String lineManager) throws JWTCreationException {
        logger.debug("Create JWT for user: "+ userId);
        Algorithm algorithm = Algorithm.HMAC256(JWT_SECRET_KEY);
        String jwt = JWT.create()
                .withSubject(JWT_SUBJECT)
                .withHeader(setHeader())
                .withIssuer(JWT_ISSUER)
                .withAudience(JWT_AUDIENCE)
                .withIssuedAt(new Date(new Date().getTime()))
                .withExpiresAt(new Date(new Date().getTime() + DAY_DURATION))
                .withClaim("USER_ID",userId)
                .withClaim("ROLES", roles)
                .withClaim("LINE_MANAGER", lineManager)
                .sign(algorithm);

        return jwt;
    }
    
    /**
     * Method to validate Token and retrieve UserId from the Token
     * @param userId
     * @param token
     * @return
     * @throws JWTCreationException
     */
    public String[] verifyJWT(String token) throws JWTCreationException {        
        try {
        	DecodedJWT decJwt = JWT.decode(token);  
        	String userId = decJwt.getClaim("USER_ID").asString();
        	String roles = decJwt.getClaim("ROLES").asString();
        	String lm = decJwt.getClaim("LINE_MANAGER").asString();
            Algorithm algorithm = Algorithm.HMAC256(JWT_SECRET_KEY);

            JWTVerifier verifier = JWT.require(algorithm)
                    .withIssuer(JWT_ISSUER)
                    .withAudience(JWT_AUDIENCE)
                    .withSubject(JWT_SUBJECT)                    
                    .withClaim("USER_ID",userId)
                    .build();

            verifier.verify(token);
            return new String[] {userId, roles, lm};

        } catch (JWTVerificationException ex){
            ex.printStackTrace();            
        }

        return null;
    }
    
    public static void main(String args[]) {
    	JWTUtil utl = new JWTUtil();
    	String token = utl.createJWT("test112", "DEFAULT", "TEST");
    	System.out.println("TOken is " + token);
    	System.out.println("Valid is " + utl.verifyJWT(token));
    }
}
