package com.scb.selfservice.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Joiner;
import com.scb.selfservice.config.PropertyConfigurer;
import com.scb.selfservice.dao.mapper.identity.IdentityMapper;
import com.scb.selfservice.dao.td.mapper.IdentityTDMapper;
import com.scb.selfservice.model.Roles;
import com.scb.selfservice.model.UserDetails;
import com.scb.selfservice.service.IdentityService;
import com.scb.selfservice.util.JWTUtil;
import com.scb.selfservice.web.authentication.LDAPAuthenticator;

@Service
public class IdentityServiceImpl implements IdentityService {
	
    private static Logger logger = LogManager.getLogger(IdentityServiceImpl.class);

    @Autowired
    JWTUtil jwtUtil;
    
    @Autowired
    LDAPAuthenticator authenticator;
    
    @Autowired
    IdentityMapper identityMapper;
    
    @Autowired
    IdentityTDMapper identityTDMapper;
    
    /**
     * Method to validate the user
     */
    public Map<String,Object> validateUser(String userId, String passWord){
        logger.debug("Inside Validate User:" +  userId);
        Map<String,Object> retValue = new HashMap<String, Object>();
        String decodedPassword = new String(Base64.decodeBase64(passWord.getBytes()));
        String ldapLoginDisabled = PropertyConfigurer.getProperty("ldap.login.disabled");
        if (ldapLoginDisabled != null && "true".equalsIgnoreCase(ldapLoginDisabled)) {
        	if ("abc123".equalsIgnoreCase(decodedPassword)) {
        		String[] details = getUserDetails(userId);
        		retValue.put("status","200");
                retValue.put("message","LOGIN_SUCCESS");
                retValue.put("ROLES", details[1]);
                return retValue;
        	}
        	else {
        		retValue.put("status","300");
                retValue.put("message","INVALID_PASSWORD");
                return retValue;
        	}
        }
        // perform LDAP Authentication
        try {
        	authenticator.authenticate(userId, decodedPassword);
        	String[] details = getUserDetails(userId);
        	retValue.put("status","200");
            retValue.put("message","LOGIN_SUCCESS");
            retValue.put("ROLES", details[1]);            
            return retValue;
        }
        catch (Exception ex) {
        	logger.error("Error occured during Authentication of User " + userId + " " + ex.getMessage());
        	ex.printStackTrace();
        	retValue.put("status","300");
            retValue.put("message",ex.getMessage());
        }

        return retValue;
    }
    
    /**
     * Method to get the User details.
     * @param userId
     * @return
     */
    protected String[] getUserDetails(String userId) {
    	String[] data = {userId, "PUBLIC_ROLE"};
    	UserDetails details = identityMapper.getUserDetails(userId);
    	if (details != null) {
    		List<Roles> roles = details.getRoles();
    		data[1] = Joiner.on(";").join(roles);
    	}    	
    	return data;
    }
    
    /**
     * Method to log User Login Details
     */
    @Transactional(propagation = Propagation.REQUIRED)
    public void logUserDetails(HashMap<String,String> details) {
    	try {
    		identityMapper.insertUserLoginDetails(details);
    	}
    	catch (Exception ex) {
    		ex.printStackTrace();
    		logger.error("Exception while inserting to User Login Details - " + ex.getMessage());
    	}
    }
    
    /**
     * Method to getPSHR Data
     * @param userId
     * @return
     */
    @Transactional(value = "transactionManagerTD", propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public UserDetails getPSHRData(String userId) {
    	try {
    		return identityTDMapper.getPSHRUserDetails(userId);
    	}
    	catch (Exception ex) {
    		ex.printStackTrace();
    		logger.error("Exception while retrieving PSHR Details - " + ex.getMessage());
    	}
    	return null;
    }
    
    /**
     * Method to Create User details in the system if it doesn't exist
     * @param details
     */
    @Transactional(propagation = Propagation.REQUIRED)
    public void createUserIfNotExists(UserDetails details) {
    	try {
    		identityMapper.createUserDetails(details);
    	}
    	catch (Exception ex) {
    		// handle the exception as the user creation should not block the Login
    		ex.printStackTrace();
    		logger.error("Exception while Creating User Details - " + ex.getMessage());
    	}
    }
    
    /**
     * Method to get User LastLogin Details
     * @param userId
     * @return
     */
    @Transactional(propagation = Propagation.REQUIRED)
    public Map<String, String> getUserLastLoginDetails(String userId) {
    	return identityMapper.getUserLastLoginDetails(userId);    	
    }

	/**
	 * @return the authenticator
	 */
	protected LDAPAuthenticator getAuthenticator() {
		return authenticator;
	}

	/**
	 * @param authenticator the authenticator to set
	 */
	protected void setAuthenticator(LDAPAuthenticator authenticator) {
		this.authenticator = authenticator;
	}
}
