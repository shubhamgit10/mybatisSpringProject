package com.scb.selfservice.service;

import com.scb.selfservice.domains.IngestionInput;
import com.scb.selfservice.util.Response;

public interface IngestionService {

	Response getIngestionSitData(Integer reqId, String stepId);

	Response updateDepIterations(IngestionInput ingestionInput);

	Response getSitExceptionDetails(Integer reqId, String stepId);

	Response getSitVerfData(Integer reqId, String stepId);

	Response updateVerifIterations(IngestionInput ingestionInput);

	Response findByImpactedConsumer(String reqId);

}
