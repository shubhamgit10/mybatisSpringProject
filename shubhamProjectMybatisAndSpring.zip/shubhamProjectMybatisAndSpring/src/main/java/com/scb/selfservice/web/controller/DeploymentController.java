package com.scb.selfservice.web.controller;

import com.scb.selfservice.dao.mapper.ingestion.SourceMapper;
import com.scb.selfservice.model.SourceDetails;
import com.scb.selfservice.service.IngestionConfigFileService;
import freemarker.template.Template;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.web.bind.annotation.*;
import freemarker.template.Configuration;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/deploy")
public class DeploymentController {
    
    private IngestionConfigFileService ingestionConfigFileService;

    @RequestMapping(path = "/genconfig", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, String> genConfig(@RequestHeader Map<String, String> header,
                                         @RequestParam(name = "sourceid") String sourceid,
                                        HttpServletRequest request) {
        Map<String, String> result = new HashMap<String, String>();

        ingestionConfigFileService.createDRPartitionFile(Integer.parseInt(sourceid));
        ingestionConfigFileService.createRetentionFile(Integer.parseInt(sourceid));

        result.put("status","200");
        result.put("sourceid",sourceid);
        return result;
    }
}
