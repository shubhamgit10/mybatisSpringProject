package com.scb.selfservice.domains;

public class WorkflowRespTableMapping {
	
	private Integer workflowId;
	
	private String stepId;
	
	private String stepType;
	
	private String tableName;
	
	private String stepClassName;
	
	
	public String getStepClassName() {
		return stepClassName;
	}

	public void setStepClassName(String stepClassName) {
		this.stepClassName = stepClassName;
	}

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public String getStepType() {
		return stepType;
	}

	public void setStepType(String stepType) {
		this.stepType = stepType;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	@Override
	public String toString() {
		return "WorkflowRespTableMapping [workflowId=" + workflowId + ", stepId=" + stepId + ", stepType=" + stepType
				+ ", tableName=" + tableName + ", stepClassName=" + stepClassName + "]";
	}

		
}
