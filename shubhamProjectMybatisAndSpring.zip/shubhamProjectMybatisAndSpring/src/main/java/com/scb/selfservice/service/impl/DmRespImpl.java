package com.scb.selfservice.service.impl;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.scb.selfservice.dao.mapper.EdmpIngestionRequestMapper;
import com.scb.selfservice.dao.mapper.IngestionDynamicMapper;
import com.scb.selfservice.dao.mapper.WorkflowMapper;
import com.scb.selfservice.domains.IngestionDmApproval;
import com.scb.selfservice.domains.IngestionInput;
import com.scb.selfservice.domains.SDMTechGrid;
import com.scb.selfservice.service.UserResponseService;
import com.scb.selfservice.util.Response;

/**
 * @author cpedada
 *
 */
@Service(value = "DmResp")
public class DmRespImpl implements UserResponseService {

	private static Logger logger = LogManager.getLogger(DmRespImpl.class);

	@Autowired
	WorkflowMapper workflowMapper;

	@Autowired
	IngestionDynamicMapper idynMapper;
	
	@Autowired
	private EdmpIngestionRequestMapper eirMapper;
	/**
	 *
	 */
	@Override
	public Response executeSave(IngestionInput ingestionInput) {

		logger.info("inside DmRespImpl:: excuteSave Method");

		Response isaResponse = new Response();

		try {
			isaResponse = saveDmApprovalResp(ingestionInput);

		} catch (Exception e) {

			logger.info("Exception::" + e);
		}

		return isaResponse;
	}

	/**
	 * @param ingestionInput
	 * @return
	 * @throws Exception
	 */
	public Response saveDmApprovalResp(IngestionInput ingestionInput) throws Exception {

		logger.info("START DmRespImpl::saveDmApprovalResp");
		Response isaResponse = new Response();
		
		Integer rejectedFlag =1;

		HashMap<String, Object> hm = (HashMap<String, Object>) ingestionInput.getParams();

		hm.put("reqId", ingestionInput.getReqId());

		hm.put("stepId", ingestionInput.getStepId());

		hm.put("workflowType", ingestionInput.getWorkflowType());

		hm.put("userAction", ingestionInput.getUserAction());

		hm.put("requestCreatedBy", ingestionInput.getUserId());

		if (null != hm.get("plannedReleaseDate")) {

			LocalDate ld = LocalDate.parse((String) hm.get("plannedReleaseDate"));

			hm.put("plannedReleaseDate", ld);
		}

		IngestionDmApproval crObj = idynMapper.dMfindByRequestId(ingestionInput.getReqId());

		if (crObj == null) {
			logger.info("START it is a new entry for new request..." + ingestionInput.getReqId());

			int saveStatus = idynMapper.saveDmApprovalRequest(hm); // insert

			isaResponse = getActionStatus("save", saveStatus, ingestionInput.getReqId());

			logger.info("EXIT save request");
		} else {
			logger.info("START it an existing request..." + ingestionInput.getReqId());

			int updateStatus = idynMapper.updateDmApprovalRequest(hm); // update

			isaResponse = getActionStatus("update", updateStatus, ingestionInput.getReqId());

			logger.info("EXIT update request");
		}

		
//DM Rejected Flag functionality::::
		 rejectedFlag =0;
		 
		 int status = eirMapper.updateIngestionflag(ingestionInput.getReqId(), rejectedFlag);
		 
				
		logger.info("EXIT DmRespImpl::saveDmApprovalResp");
		return isaResponse;

	}

	/**
	 * @param type
	 * @param saveStatus
	 * @param reqId
	 * @return
	 */
	private Response getActionStatus(String type, int saveStatus, int reqId) {
		Response response = new Response();
		if (saveStatus == 1) {
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus(HttpStatus.OK.toString());
			response.setResponse(reqId + "Request id " + (type.equals("save") ? "INSERTED" : "UPDATED"));
		} else {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
			response.setResponse("!!!Action not taken!!!");
		}
		return response;
	}
	
	/**
	 *
	 */
	@Override
	public Response fetchApprovalResponse(IngestionInput ingestionInput) {
		IngestionDmApproval dmResponse = idynMapper.dMfindByRequestId(ingestionInput.getReqId());
		//Response dmResponse = eiReqService.findByReqId(requestId);
		Response response = new Response();
		response.setResponse(dmResponse);
		return response;
	}
		
}
