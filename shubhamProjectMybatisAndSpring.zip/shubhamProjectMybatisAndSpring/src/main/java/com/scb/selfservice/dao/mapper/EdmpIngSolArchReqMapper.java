package com.scb.selfservice.dao.mapper;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.scb.selfservice.domains.IngestionRequest;
import com.scb.selfservice.domains.IngestionSolArchApproval;


public interface EdmpIngSolArchReqMapper {
	
	public int saveSolutionArchRequest(@Param("IngestionSolArchRequest") IngestionSolArchApproval ingestionSolArchApproval);
	
	//method to pull existing IngestionSolArchApproval based on reqId
		public IngestionSolArchApproval findByRequestId(@Param("reqId") Integer reqId);
		
		//method for updating IngestionSolArchApproval Request
		public int updateSolArchRequest(@Param("IngestionSolArchApproval") IngestionSolArchApproval ingestionSolArchApproval);
		

		
		

}
