package com.scb.selfservice.web.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.domains.Pipelineview;
import com.scb.selfservice.service.ViewPipelineService;
import com.scb.selfservice.util.EDMpUtil;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;
import com.scb.selfservice.web.authentication.UserPrincipal;

@RestController
@RequestMapping("/api")
public class ViewPipelineController {

	private static Logger logger = LogManager.getLogger(ViewPipelineController.class);

	@Autowired
	ViewPipelineService viewPipelineService;

	@GetMapping(path = "/pipelinedownload", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<InputStreamResource> getViewPipeline() throws IOException {
		logger.info("STARTING ViewPipelineController::getFile");
		List<Pipelineview> fileData = new ArrayList<Pipelineview>();

		fileData.addAll(viewPipelineService.pullData());

		ByteArrayInputStream in = EDMpUtil.preparePipelineXlsx(fileData);
		if (null == in) {
			return ResponseEntity.noContent().build();
		}

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=" + EDMpUtil.fileNameViewPipeline());
		logger.info("EXISTING ViewPipelineController::getFile");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

}
