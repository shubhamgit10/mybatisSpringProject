package com.scb.selfservice.dao.ps;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class ImportCostExcelToDb {
	public static void main(String args[]) throws Exception {
		Class.forName("oracle.jdbc.OracleDriver");
		Connection con;
		con = DriverManager.getConnection("jdbc:oracle:thin:@10.100.252.150:1521:orcl", "edmp_api", "edmp_api");
		PreparedStatement ps = con.prepareStatement(
				"insert into edmp_estimation_metadata(source_id, source_type, cost_estimation_template) values(?,?,?)");
		FileInputStream fis = new FileInputStream("C:\\Users\\shubhasi\\NewSourcing.xlsx");
		ps.setInt(1, 1);
		ps.setString(2, "New Sourcing");
		ps.setBlob(3, fis);

		ps.executeUpdate();
		System.out.println("New sourcing cost template inserted successfully");

	}
}
