package com.scb.selfservice.dao.mapper.ingestion;


import com.scb.selfservice.model.SourceDetails;

public interface SourceMapper {
    public SourceDetails getSourceDetails(int sourceId);
}
