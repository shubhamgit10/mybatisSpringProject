package com.scb.selfservice.workflow.service;

import java.util.HashMap;
import java.util.List;

import com.scb.selfservice.domains.EdmpConsumpReqUserResp;
import com.scb.selfservice.domains.Upject;
import com.scb.selfservice.domains.WorkflowReqStepsAt;
import com.scb.selfservice.domains.WorkflowRequest;
import com.scb.selfservice.domains.WorkflowRequestStep;
import com.scb.selfservice.domains.WorkflowRequestStepsNames;
import com.scb.selfservice.util.Response;

public interface WorkflowRequestService {
	/*
	 * one entry per request and keep updating the row for each approval process
	 * WORKFLOW_REQUEST
	 * (INITIAL)
	 *0209 snapshotId added
	 */
	public String insertWorkFlowRequest(WorkflowRequest workflowRequest, Integer snapshotId) throws Exception;

	/*
	 * method to return step_id (workflow_request_steps) along with step_name (workflow_process_steps)
	 * based on req_id (workflow_request_steps)
	 */
	public List<WorkflowRequestStepsNames> getWorkflowRequestStepsById(Integer reqId, String workflowType) throws Exception;

	//handle workflow_request(steps) to reject status
	public Response workflowReject(Upject upject,  List<EdmpConsumpReqUserResp> lst)  throws Exception;

	//handle workflow_request(steps) to approve status
	public Response workflowApprove(Upject upject,  List<EdmpConsumpReqUserResp> lst) throws Exception;

	//method to handle either Update (Approve) or Reject flow
	public Response initiateUpdateOrReject(HashMap<String, String> requestMap) throws Exception;

	//method to pull ApprovalList for the given/logged in user
	public Response getMyApprovalList(Integer userId, String workflowType);

	//method to get workflowId for the given workflowType
	public int getWorkflowId(String workflowType) throws Exception ;

	//method to bring the audit details of workflow_request_steps along with userName (from userId) 
	public Response getAuditWorkflowRequestSteps(HashMap<String, String> requestMap) throws Exception;

	//method to bring workflow_request workflowid from requestid
	public Integer getWorkflowRequestWorkflowId(int reqId);

	//method to pull workflowReqStepsAt
	public void insertIntoWorkflowReqStepsAt(WorkflowReqStepsAt workflowReqStepsAt);

	//method to pull workflowReqStep
	public void updateWorkflowReqSteps(WorkflowRequestStep workflowReqStep);
	
	// Fetch my ingestion approval list
	public Response getMyIngestionApproval(Integer userId, String workflowType) throws Exception;

}
