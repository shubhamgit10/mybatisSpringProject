package com.scb.selfservice.service;

import java.util.Map;

public interface IngestionConfigFileService {

    public boolean createDRPartitionFile(int sourceId);
    public boolean createRetentionFile(int sourceId);

}
