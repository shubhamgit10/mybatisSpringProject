package com.scb.selfservice.service.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.DataConsumptionRequestMapper;
import com.scb.selfservice.domains.ConsumptionRequest;
import com.scb.selfservice.domains.EDMPSelfServiceReq;
import com.scb.selfservice.domains.ItamTypeAhead;
import com.scb.selfservice.domains.WorkflowRequest;
import com.scb.selfservice.service.DataConsumptionRequestService;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.util.SnapshotUtils;
import com.scb.selfservice.workflow.service.WorkflowRequestService;

@Service
public class DataConsumptionRequestServiceImpl implements DataConsumptionRequestService {

	private static Logger logger = LogManager.getLogger(DataConsumptionRequestServiceImpl.class);

	@Autowired
	private DataConsumptionRequestMapper dcrMapper;

	@Autowired
	private WorkflowRequestService workflowRequestService;

	@Autowired
	private SnapshotUtils snapshotUtils;

	@Override
	@Transactional
	public Response saveConsumptionRequest(ConsumptionRequest consumptionRequest) {

		logger.info("START DataConsumptionRequestServiceImpl::saveConsumptionRequest");
		Response consumptionResponse = new Response();

		ConsumptionRequest crObj = dcrMapper.findByRequestId(consumptionRequest.getReqId());

		if(crObj == null) {
			logger.info("START it is a new entry for new request..." + consumptionRequest.getReqId());
			int saveStatus = dcrMapper.saveConsumptionRequest(consumptionRequest); //insert
			consumptionResponse = getActionStatus("save", saveStatus, consumptionRequest.getReqId());
			logger.info("EXIT save request");
		} else {
			logger.info("START it an existing request..." + consumptionRequest.getReqId());
			int updateStatus = dcrMapper.updateConsumptionRequest(consumptionRequest); //update
			consumptionResponse = getActionStatus("update", updateStatus, consumptionRequest.getReqId());
			logger.info("EXIT update request");
		}
		logger.info("EXIT DataConsumptionRequestServiceImpl::saveConsumptionRequest");
		return consumptionResponse;
	}

	private Response getActionStatus(String type, int saveStatus, int reqId) {
		Response response = new Response();
		if (saveStatus == 1) {
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus(HttpStatus.OK.toString());
			response.setResponse(reqId + "Request id " + (type.equals("save")? "INSERTED": "UPDATED"));
		} else {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
			response.setResponse("!!!Action not taken!!!");
		}
		return response;
	}

	@Override
	@Transactional
	public Response findByReqId(Integer reqId) {
		ConsumptionRequest cr = dcrMapper.findByRequestId(reqId);
		Response response = new Response();
		if (cr != null) {
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus(HttpStatus.OK.toString());
			response.setResponse(cr);
		} else {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
		}
		return response;
	} 

	@Override
	@Transactional(rollbackFor=Exception.class)
	public Response submitConsumptionRequest(EDMPSelfServiceReq edmpSelfServiceReq) throws Exception {

		WorkflowRequest wfReq = new WorkflowRequest();
		wfReq.setLastActedStepId("S0");
		wfReq.setReqId(edmpSelfServiceReq.getReqId());
		wfReq.setRequestCreatedBy(edmpSelfServiceReq.getRequestCreatedBy());
		wfReq.setWorkflowId(workflowRequestService.getWorkflowId(edmpSelfServiceReq.getWorkflowType()));
		wfReq.setRemarks(""); //changed after discussion on 17-Aug-2020
		logger.info("starting inserWorkFlowRequest with: "+ wfReq);
		Response consumptionRequest = new Response();
		try {
			int updateId = dcrMapper.submitConsumptionRequest(edmpSelfServiceReq); //draft to Submitted
			if (updateId == 0)
				throw new Exception("EXCEPTION while updating edmpSelfServiceReqDetails table");
			
			//time to create snapshot 0209
			int snapshotId = snapshotUtils.getSnapshot(edmpSelfServiceReq) ;
			String status = workflowRequestService.insertWorkFlowRequest(wfReq, snapshotId);
			
			if (status.equals("SUCCESS")) {
				consumptionRequest.setStatusCode(HttpStatus.OK.value());
				consumptionRequest.setStatus(HttpStatus.OK.toString());
				consumptionRequest.setResponse(edmpSelfServiceReq);
			} else {
				throw new Exception("EXCEPTION while updating EDMP_SELFSERVICE_REQ table");
			}
		} catch(Exception ex) {
			logger.info("EXCEPTION in submitConsumptionRequest: " + ex.getMessage());
			throw ex;
		}
		return consumptionRequest;
	}

	@Override
	public Response getItamdetails(String itam) {
		// TODO Auto-generated method stub
		
		List<ItamTypeAhead> itamTypeAhead = dcrMapper.getItamdetails(itam);
		Response itamTypeResponse = new Response();
		if (itamTypeAhead.isEmpty()) {
			itamTypeResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			itamTypeResponse.setStatus(HttpStatus.NO_CONTENT.toString());
		} else {
			itamTypeResponse.setResponse(itamTypeAhead);
			itamTypeResponse.setStatusCode(HttpStatus.OK.value());
			itamTypeResponse.setStatus(HttpStatus.OK.toString());
		}
		
		return itamTypeResponse;
	}

}
