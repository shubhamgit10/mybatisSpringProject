package com.scb.selfservice.elk.controller;

import java.util.HashMap;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.elk.domains.ElkData;
import com.scb.selfservice.elk.util.ELKUtil;
import com.scb.selfservice.service.SearchService;
import com.scb.selfservice.util.Response;

@RestController
@RequestMapping("/api/searchData")
public class ElkSearchController {

	@Autowired
	SearchService searchService;

	private static Logger logger = LogManager.getLogger(ElkSearchController.class);

	//ELK based search
	@PostMapping(path = "/elksearch", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> searchApplyFilter(@RequestBody HashMap<String, String> requestMap) {
		logger.info("Proceeding for ELK search on " + requestMap.get("searchItem"));
		Response response = new Response();
		if (StringUtils.isBlank(requestMap.get("searchItem"))) {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
			response.setResponse("");
		} else {
			ElkData elkData = ELKUtil.gridData(requestMap);
			if (null == elkData) {
				response.setStatusCode(HttpStatus.NO_CONTENT.value());
				response.setStatus(HttpStatus.NO_CONTENT.toString());
				response.setResponse(elkData);
			} else {
				response.setStatusCode(HttpStatus.OK.value());
				response.setStatus(HttpStatus.OK.toString());
				response.setResponse(elkData);
			}
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	//ELK based search typeahead
	@GetMapping(path = "/elktypeahead", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> typeAhead(@RequestParam String typeAhead) {
		logger.info("Proceeding for ELK typeahead on " + typeAhead);
		Response response = new Response();

		Set<String> hits = ELKUtil.typeAhead(typeAhead);
		if (null == hits) {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
		} else {
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus(HttpStatus.OK.toString());
			response.setResponse(hits);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
}
