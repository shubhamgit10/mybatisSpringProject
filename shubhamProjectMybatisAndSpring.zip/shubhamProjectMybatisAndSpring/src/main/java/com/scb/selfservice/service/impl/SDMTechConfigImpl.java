package com.scb.selfservice.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.ingestion.SDMTechMapper;
import com.scb.selfservice.domains.IngestionInput;
import com.scb.selfservice.domains.SDMTechCkSumGrid;
import com.scb.selfservice.domains.SDMTechGrid;
import com.scb.selfservice.domains.SDMTechResponse;
import com.scb.selfservice.elk.domains.GridData;
import com.scb.selfservice.service.UserResponseService;
import com.scb.selfservice.util.Response;

@Service(value = "SDMTechConfig")
public class SDMTechConfigImpl implements UserResponseService {

	private static Logger logger = LogManager.getLogger(SDMTechConfigImpl.class);

	@Autowired
	private SDMTechMapper sdmTechMapper;

	ArrayList gridList = new ArrayList();

	@Override
	public Response executeSave(IngestionInput ingestionInput) {
		logger.info("Inside SDMTechConfigImpl :: ExecuteSave Method");
		Response sdmResponse = new Response();
		System.out.println("Params=" + ingestionInput);
		try {
			sdmResponse = saveSDMRes(ingestionInput);
		} catch (Exception e) {
			logger.info("Exception::" + e);
		}
		return sdmResponse;
	}

	public Response saveSDMRes(IngestionInput ingestionInput) throws Exception {
		logger.info("START SDMTechConfigImpl::saveSDMRes");

		gridList.add("sourceReconLogicGrid");
		gridList.add("checksumLogicGrid");

		HashMap<String, Object> gridData = new HashMap<>();

		Response sdmResponse = new Response();
		try {
			HashMap<String, Object> hm = (HashMap<String, Object>) ingestionInput.getParams();
			hm.put("reqId", ingestionInput.getReqId());
			hm.put("stepId", ingestionInput.getStepId());
			hm.put("workflowType", ingestionInput.getWorkflowType());
			hm.put("userAction", ingestionInput.getUserAction());
			hm.put("requestCreatedBy", ingestionInput.getUserId());
//		SDMTechHDFSMetadata sdmHdfs = sdmTechMapper.getHdfsById(ingestionInput.getReqId());
			ArrayList<String> configName = null;
			SDMTechResponse sdmTechResponse = null;
			List<SDMTechResponse> sdmResponseList = new ArrayList<>();
			List<SDMTechResponse> sdmHdfs = sdmTechMapper.getSDMConfig(ingestionInput.getReqId());
			HashMap<String, Object> categoryDet = new HashMap<>();
			List<String> sdmCategory = sdmTechMapper.readConfigCategory();
			logger.info("sdmcytt" + sdmCategory);
			for (String sdmCategoryRes : sdmCategory) {
				categoryDet = (HashMap<String, Object>) hm.get(sdmCategoryRes);
				logger.info("CATEGORY" + categoryDet);
				if (categoryDet != null && !categoryDet.isEmpty()) {
					for (Map.Entry<String, Object> sdmMap : categoryDet.entrySet()) {

						String key = sdmMap.getKey();

						if (gridList.contains(key)) {

							gridData.put(key, sdmMap.getValue());
						} else {

							sdmTechResponse = new SDMTechResponse();
							String value = (String) sdmMap.getValue();
							sdmTechResponse.setConfigName(key);
							sdmTechResponse.setConfigValue(value);
							sdmTechResponse.setConfigCategory(sdmCategoryRes);
							sdmTechResponse.setReqId(ingestionInput.getReqId());
							sdmTechResponse.setStepId(ingestionInput.getStepId());
							sdmTechResponse.setCreatedBy(ingestionInput.getUserId());
							sdmTechResponse.setUserAction(ingestionInput.getUserAction());
//			    sdmTechResponse.setItamId(itamId);
							sdmResponseList.add(sdmTechResponse);
						}
					}
				}
			}
			logger.info("size of " + sdmResponseList.size());
			if (sdmResponseList != null) {
				int insertToAudit = sdmTechMapper.insertIntoAuditTable(ingestionInput.getReqId());// call audit
				sdmResponse = getActionStatus("insert/save", insertToAudit, ingestionInput.getReqId());
			}

			int deleteExisting = sdmTechMapper.deleteExistingrRecord(ingestionInput.getReqId());// call delete method
			sdmResponse = getActionStatus("insert/save", deleteExisting, ingestionInput.getReqId());

			int saveStatus = sdmTechMapper.saveSdmConfig(sdmResponseList);
			sdmResponse = getActionStatus("insert/save", saveStatus, ingestionInput.getReqId());
			
			updateGridData(saveStatus, ingestionInput, gridData);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return sdmResponse;

	}

	private Response getActionStatus(String type, int saveStatus, int reqId) {
		Response response = new Response();
		if (saveStatus > 0) {
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus(HttpStatus.OK.toString());
			response.setResponse("Request id: " + reqId + (type.equals(" save ") ? " INSERTED " : " UPDATED "));
		} else {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
			response.setResponse("!!!Action not taken!!!");
		}
		return response;
	}

	private void updateGridData(int saveStatus, IngestionInput ingestionInput, HashMap gridData) throws Exception {

		if (saveStatus > 0) {
			// UPDATING RECON LOGIC
			List<SDMTechGrid> reconLogicList = (List<SDMTechGrid>) gridData.get("sourceReconLogicGrid");

			if (reconLogicList != null && reconLogicList.size() > 0) {

				int updateSourceTable = sdmTechMapper.updateIntoSourceTable(ingestionInput.getReqId(), reconLogicList);// updating
																														// Source_table_layout

				logger.info("updateSourceTable ::	" + updateSourceTable);
			}

			// UPDATING CHECK SUM LOGIC
			List<SDMTechCkSumGrid> chkSumLogicList = (List<SDMTechCkSumGrid>) gridData.get("checksumLogicGrid");

			if (chkSumLogicList != null && chkSumLogicList.size() > 0) {

				int updateChkSumTable = sdmTechMapper.updateIntoCkSum(ingestionInput.getReqId(), chkSumLogicList);// updating
																														// Source_table_layout

				logger.info("updateChkSumTable ::	" + updateChkSumTable);
			}
		}
	}

	@Override
	@Transactional
	public Response fetchApprovalResponse(IngestionInput ingestionInput ) {
		Response response = new Response();
		logger.info("STARTED fetchApprovalResponse for SDM");
		try {
			List<String> sdmCategory = sdmTechMapper.readConfigCategory();
			List<SDMTechResponse> sdmTechHDFSRes = sdmTechMapper.getSDMConfig(ingestionInput.getReqId());
			HashMap<String, Object> caterogryDetails = null;
			HashMap<String, Object> categoryResponse = new HashMap<>();
			
			
	////////// fetch Data from SOurce_table_Layout
					List<SDMTechGrid> reconGridData = sdmTechMapper.readReconGridValues(ingestionInput.getReqId());
				
					List<SDMTechCkSumGrid> ckSumGridData = sdmTechMapper.readCkSumGridValues(ingestionInput.getReqId());
					
			
			for (String sdmCategoryNew : sdmCategory) {
				caterogryDetails = new HashMap<>();
				for (SDMTechResponse sdmTechHDFSResNew : sdmTechHDFSRes) {
					if (sdmTechHDFSResNew.getConfigCategory().equals(sdmCategoryNew)) {

						caterogryDetails.put(sdmTechHDFSResNew.getConfigName(), sdmTechHDFSResNew.getConfigValue());

					}
				}
				
				if(sdmCategoryNew.equals("recon")) {
					
					caterogryDetails.put("sourceReconLogicGrid", reconGridData);
					caterogryDetails.put("checksumLogicGrid",ckSumGridData);
				}
				
				categoryResponse.put(sdmCategoryNew, caterogryDetails);
				
				
			}
			categoryResponse.put("stepId", ingestionInput.getStepId());
			categoryResponse.put("reqId", ingestionInput.getReqId());
			categoryResponse.put("stepName", ingestionInput.getRemarks());
			logger.info("get sdm config detail :" + sdmTechHDFSRes);

			logger.info("EXITING fetchApprovalResponse");
			if (categoryResponse.isEmpty() || null == categoryResponse) {
				response.setStatusCode(HttpStatus.NO_CONTENT.value());
				response.setStatus("NO CONTENT");
				response.setResponse("No data found for this user");
			} else {
				response.setStatusCode(HttpStatus.OK.value());
				response.setStatus("SUCCESS");
				response.setResponse(categoryResponse);
			}

		} catch (Exception ex) {
			logger.info("SDMTech exception for request Id " + ingestionInput.getReqId() + " with " + ex.getMessage());
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus("NO CONTENT");
			response.setResponse("No data found for the user");
		}

		return response;
	}

}
