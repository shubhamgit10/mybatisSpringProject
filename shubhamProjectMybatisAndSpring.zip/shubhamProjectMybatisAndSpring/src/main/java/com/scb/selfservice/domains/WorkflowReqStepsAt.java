package com.scb.selfservice.domains;

import java.sql.Timestamp;

/*
 * pojo for
 * 	workflow_req_steps_at
 */
public class WorkflowReqStepsAt {

	private Integer reqAtId;//
	private Integer reqId;//
	private String stepId;//
	private Integer workflowId;//
	private String status;
	private String remarks;
	private Timestamp startTime;
	//private String completedTime;
	private String stepPendingGrp;
	private Integer stepPendingUser;
	private Integer stepActionedBy;
	private String stepAction;
	
	private Integer snapshotId; //0209

	public Integer getReqAtId() {
		return reqAtId;
	}
	public void setReqAtId(Integer reqAtId) {
		this.reqAtId = reqAtId;
	}
	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public Integer getWorkflowId() {
		return workflowId;
	}
	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Timestamp getStartTime() {
		return startTime;
	}
	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}
	public String getStepPendingGrp() {
		return stepPendingGrp;
	}
	public void setStepPendingGrp(String stepPendingGrp) {
		this.stepPendingGrp = stepPendingGrp;
	}
	public Integer getStepPendingUser() {
		return stepPendingUser;
	}
	public void setStepPendingUser(Integer stepPendingUser) {
		this.stepPendingUser = stepPendingUser;
	}
	public Integer getStepActionedBy() {
		return stepActionedBy;
	}
	public void setStepActionedBy(Integer stepActionedBy) {
		this.stepActionedBy = stepActionedBy;
	}
	public String getStepAction() {
		return stepAction;
	}
	public void setStepAction(String stepAction) {
		this.stepAction = stepAction;
	}

	public Integer getSnapshotId() {
		return snapshotId;
	}
	public void setSnapshotId(Integer snapshotId) {
		this.snapshotId = snapshotId;
	}
	@Override
	public String toString() {
		return "WorkflowReqStepsAt [reqAtId=" + reqAtId + ", reqId=" + reqId + ", stepId=" + stepId + ", workflowId="
				+ workflowId + ", status=" + status + ", remarks=" + remarks + ", startTime=" + startTime
				+ ", stepPendingGrp=" + stepPendingGrp + ", stepPendingUser=" + stepPendingUser + ", stepActionedBy="
				+ stepActionedBy + ", stepAction=" + stepAction + ", snapshotId=" + snapshotId + "]";
	}
	
}
