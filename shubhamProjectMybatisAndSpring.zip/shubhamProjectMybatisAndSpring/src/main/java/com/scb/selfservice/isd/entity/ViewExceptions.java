package com.scb.selfservice.isd.entity;


/**
 * @author akuma400
 *
 */
public class ViewExceptions {

	private String issueCategory;
	private String tablesImpacted;
	private String columnsImpacted;
	
	public String getIssueCategory() {
		return issueCategory;
	}
	public void setIssueCategory(String issueCategory) {
		this.issueCategory = issueCategory;
	}
	public String getTablesImpacted() {
		return tablesImpacted;
	}
	public void setTablesImpacted(String tablesImpacted) {
		this.tablesImpacted = tablesImpacted;
	}
	public String getColumnsImpacted() {
		return columnsImpacted;
	}
	public void setColumnsImpacted(String columnsImpacted) {
		this.columnsImpacted = columnsImpacted;
	}
	@Override
	public String toString() {
		return "ViewExceptions [issueCategory=" + issueCategory + ", tablesImpacted=" + tablesImpacted
				+ ", columnsImpacted=" + columnsImpacted + "]";
	}
	
}
