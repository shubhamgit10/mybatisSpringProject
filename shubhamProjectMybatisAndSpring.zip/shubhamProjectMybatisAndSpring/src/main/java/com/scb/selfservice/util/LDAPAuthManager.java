package com.scb.selfservice.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.ldap.core.support.BaseLdapPathContextSource;
import org.springframework.stereotype.Component;

import javax.naming.NamingEnumeration;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import java.text.MessageFormat;

@Component
public class LDAPAuthManager {
    private static Logger logger = LogManager.getLogger(LDAPAuthManager.class);
    private BaseLdapPathContextSource contextSource;
    private String userDNPattern;
    /**
     //* @return the contextSource
     */
    public BaseLdapPathContextSource getContextSource() {
        return contextSource;
    }

    /**
     //* @param contextSource
     *            the contextSource to set
     */
    public void setContextSource(BaseLdapPathContextSource contextSource) {
        this.contextSource = contextSource;
    }

    /**
     * @return the userDNPattern
     */
    public String getUserDNPattern() {
        return userDNPattern;
    }

    /**
     * @param userDNPattern
     *            the userDNPattern to set
     */
    public void setUserDNPattern(String userDNPattern) {
        this.userDNPattern = userDNPattern;
    }

    public Boolean doAuthenticate(String userId, String passWord){
        String filter = "(objectclass=scbPerson)";
        DirContext ctx = null;
        String userDn = new MessageFormat(userDNPattern).format(new String[] { userId });

        try{
            ctx = contextSource.getContext(userDn, passWord);
            SearchControls ctls = new SearchControls();
            ctls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            ctls.setReturningAttributes(new String[] { "logindisabled", "uid" });

            NamingEnumeration<SearchResult> searchResults = ctx.search(userDn, filter, ctls);
            if (searchResults.hasMoreElements()) { // get the first result
                SearchResult r = searchResults.next();
                return Boolean.TRUE; // Authentication is successfull
            }
            return Boolean.FALSE; // Authentication is failed

        }catch (Exception e){
            logger.debug("LDAP Failed for user:"+ userId);
            logger.debug(e.getMessage());
            e.printStackTrace();
            return Boolean.FALSE; // Authentication is failed
        } finally {
            try {
                if (ctx != null)
                    ctx.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
