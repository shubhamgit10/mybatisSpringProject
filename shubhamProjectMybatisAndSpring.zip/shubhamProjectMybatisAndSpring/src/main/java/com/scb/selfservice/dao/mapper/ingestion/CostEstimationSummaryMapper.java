package com.scb.selfservice.dao.mapper.ingestion;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.model.CostEstimation;
import com.scb.selfservice.model.CostEstimationSummary;
import com.scb.selfservice.model.CostEstimationTemplate;
/**
 * 
 * @author shubhasi
 *
 */
public interface CostEstimationSummaryMapper {

	public List<CostEstimationTemplate> getEstimatedCost(@Param("sourceId") Integer sourceId);

	public CostEstimation searchTemplate(@Param("userId") int userId, @Param("sourceType") String sourceType,
			@Param("estId") int estId);

	public CostEstimation searchByRequestId(@Param("reqId") int reqId, @Param("sourceType") String sourceType);

	public int updateEstimatedCostCopy(@Param("CostEstimation") CostEstimation costEstimation);

	public List<CostEstimationTemplate> getTemplateBySourceType(@Param("sourceType") String sourceType);

	public int insertEstimatedCostCopy(@Param("CostEstimation") CostEstimation costEstimation);

	public CostEstimation readEstimatedCost(@Param("estimationId") Integer estimationId);
	
	public int	insertEstimatedCostToDb(@Param("costEstimationReq") CostEstimation costEstimationReq, @Param("workflowId")Integer workflowId, @Param("stepId")String stepId);
	
	public int  updateEstimatedCostToDb(@Param("costEstimationReq") CostEstimation costEstimationReq,@Param("workflowId")Integer workflowId, @Param("stepId")String stepId);
	
	public CostEstimationSummary getEstimatedCostFromDb(@Param("estimationId") int estimationId,@Param("workflowId")Integer workflowId, @Param("stepId")String stepId);

	public CostEstimationSummary getEstimatedCostFromDbById(@Param("estimationId") Integer estimationId);
	

}
