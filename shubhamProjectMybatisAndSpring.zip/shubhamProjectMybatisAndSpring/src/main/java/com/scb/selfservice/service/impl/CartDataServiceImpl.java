package com.scb.selfservice.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.CartDataMapper;
import com.scb.selfservice.domains.DeleteCart;
import com.scb.selfservice.domains.EDMPCartConsumptionRequest;
import com.scb.selfservice.domains.EDMPConsumpReqDetails;
import com.scb.selfservice.domains.EDMPSelfServiceReq;
import com.scb.selfservice.service.CartDataService;
import com.scb.selfservice.util.Response;

@Service
public class CartDataServiceImpl implements CartDataService{

	private static Logger logger = LogManager.getLogger(CartDataServiceImpl.class);
	
	@Autowired
	private CartDataMapper cartDataMapper;


	@Override
	@Transactional
	public Response addToCart(List<EDMPCartConsumptionRequest> eDMPCartConsumptionRequest,Integer userId) {
		// TODO Auto-generated method stub
		Response response = new Response();
		logger.info("STARTED CartDataServiceImpl::addToCart");
		Integer reqID = eDMPCartConsumptionRequest.get(0).getReqID();
		if (reqID != null) {
			logger.info("Details being added to EDMP_SELFSERVICE_REQ");
			int reqId = cartDataMapper.insertCartData(eDMPCartConsumptionRequest);
			response = validate(eDMPCartConsumptionRequest.get(0).getReqID());
			logger.info("Details being added to EDMP_SELFSERVICE_REQ - Done");
		} else {
			//its time to insert in EDMP_SERLFSERVICE_REQ and EDMP_CONSUMP_REQ_DETAILS
			EDMPSelfServiceReq edmpSsReq = new EDMPSelfServiceReq();
			edmpSsReq.setStatus("DRAFT");
			edmpSsReq.setWorkflowType("CONSUMPTION");
			edmpSsReq.setRequestCreatedBy(userId);

			int edmp_ss_req_value = cartDataMapper.insertEDMPSelfService(edmpSsReq);
			response = validate (edmpSsReq.getReqId());
			if (response.getStatusCode() == 200) {
				logger.info("RequestID geenrated for cart: " + edmp_ss_req_value);
				eDMPCartConsumptionRequest = addRequestId(eDMPCartConsumptionRequest, edmpSsReq.getReqId());

				int edmp_cnsmpvalue = cartDataMapper.insertCartData(eDMPCartConsumptionRequest);
				logger.info("Done with updating tables...EDMP_SERLFSERVICE_REQ and EDMP_CONSUMP_REQ_DETAILS");
			} else {
				logger.info("Failed to insert into: EDMP_SERLFSERVICE_REQ and EDMP_CONSUMP_REQ_DETAILS");
				logger.info(response);
			}
		}
		logger.info("EXIT CartDataServiceImpl::addToCart");
		return response;
	}


	@Override
	@Transactional
	public Response getCartData(Integer requestId) {
		// TODO Auto-generated method stub
		List<EDMPConsumpReqDetails> consumpReqDetails = cartDataMapper.getCartData(requestId);
		Response cartDataList = new Response();
		if (consumpReqDetails.isEmpty()) {
			cartDataList.setStatus(HttpStatus.NO_CONTENT.toString());
			cartDataList.setStatusCode(HttpStatus.NO_CONTENT.value());
		} else {
			List<EDMPConsumpReqDetails> consumpReqDetailsList = new ArrayList<EDMPConsumpReqDetails>();
			for (EDMPConsumpReqDetails edmpConsumpReqDetails : consumpReqDetails) {
				String segment = Stream.of(edmpConsumpReqDetails.getSegment().split(",")).distinct().collect(Collectors.joining(","));
				String instance = Stream.of(edmpConsumpReqDetails.getInstance().split(",")).distinct().collect(Collectors.joining(","));
				EDMPConsumpReqDetails edmpConsumpReqDetail =  new EDMPConsumpReqDetails();
				edmpConsumpReqDetail.setReqID(edmpConsumpReqDetails.getReqID());
				edmpConsumpReqDetail.setAppName(edmpConsumpReqDetails.getAppName());
				edmpConsumpReqDetail.setInstance(instance);
				edmpConsumpReqDetail.setTableName(edmpConsumpReqDetails.getTableName());
				edmpConsumpReqDetail.setColumnCount(edmpConsumpReqDetails.getColumnCount());
				edmpConsumpReqDetail.setHasPiiCols(edmpConsumpReqDetails.getHasPiiCols());
				edmpConsumpReqDetail.setCertified(edmpConsumpReqDetails.getCertified());
				edmpConsumpReqDetail.setSegment(segment);
				edmpConsumpReqDetail.setAppDescription(edmpConsumpReqDetails.getAppDescription());
				edmpConsumpReqDetail.setTableDescription(edmpConsumpReqDetails.getTableDescription());

				consumpReqDetailsList.add(edmpConsumpReqDetail);
			}
			cartDataList.setResponse(consumpReqDetailsList);
			cartDataList.setStatus(HttpStatus.OK.toString());
			cartDataList.setStatusCode(200);
		}

		return cartDataList;
	}

	
	private Response validate(int reqId) {
		Response response = new Response();
		if (reqId != 0) {
			EDMPCartConsumptionRequest obj = new EDMPCartConsumptionRequest();
			obj.setReqID(reqId);
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus("Success");
        	response.setResponse(obj);
		} else {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus("FAILURE");
        	response.setResponse("NA");
		}
		return response;
	}

	//method to set reqId generated
	private List<EDMPCartConsumptionRequest> addRequestId(List<EDMPCartConsumptionRequest> eDMPCartConsumptionRequest, int ssReqId) {
		
		for (EDMPCartConsumptionRequest edmpConsumpReqDetails : eDMPCartConsumptionRequest) {
			edmpConsumpReqDetails.setReqID(ssReqId);
		}
		return eDMPCartConsumptionRequest;
	}

	@Override
	@Transactional()
	public Response deleteCart(DeleteCart deleteCart) {
		logger.info("STARTED WorkflowRequestServiceImpl:: deleteCart");
		int deleteCartValue = cartDataMapper.deleteCart(deleteCart,deleteCart.getInstance(),deleteCart.getSegment());
		Response deleteResponse = new Response();
		if (deleteCartValue == 0) {
			deleteResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			deleteResponse.setStatus(HttpStatus.NO_CONTENT.toString());
			deleteResponse.setResponse(deleteCart.getReqId() + " not found!");
		} else {
			deleteResponse.setStatusCode(HttpStatus.OK.value());
			deleteResponse.setStatus(HttpStatus.OK.toString());
			deleteResponse.setResponse(deleteCart.getReqId() + " got deleted");
		}
		logger.info("EXITING WorkflowProcessController:: deleteCart");
		return deleteResponse;
	}

}
