package com.scb.selfservice.model.RangerPolicy;

/**
 * 
 * @author 1610601
 *
 */

public class RangerPolicyResourcesRespModel {
	
	
	private RangerPolicyResourceSupportingModel database;
    private RangerPolicyResourceSupportingModel column;
    private RangerPolicyResourceSupportingModel table;
    private RangerPolicyResourceSupportingModel path;
    private RangerPolicyResourceSupportingModel columnFamily;
    private RangerPolicyResourceSupportingModel url;
    private RangerPolicyResourceSupportingModel hiveservice;
    
	/**
	 * 
	 */
	public RangerPolicyResourcesRespModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param database
	 * @param column
	 * @param table
	 * @param path
	 * @param columnFamily
	 * @param url
	 */
	public RangerPolicyResourcesRespModel(RangerPolicyResourceSupportingModel database,
			RangerPolicyResourceSupportingModel column, RangerPolicyResourceSupportingModel table,
			RangerPolicyResourceSupportingModel path, RangerPolicyResourceSupportingModel columnFamily,
			RangerPolicyResourceSupportingModel url, RangerPolicyResourceSupportingModel hiveservice) {
		super();
		this.database = database;
		this.column = column;
		this.table = table;
		this.path = path;
		this.columnFamily = columnFamily;
		this.url = url;
		this.hiveservice = hiveservice;
	}

	/**
	 * @return the database
	 */
	public RangerPolicyResourceSupportingModel getDatabase() {
		return database;
	}

	/**
	 * @param database the database to set
	 */
	public void setDatabase(RangerPolicyResourceSupportingModel database) {
		this.database = database;
	}

	/**
	 * @return the column
	 */
	public RangerPolicyResourceSupportingModel getColumn() {
		return column;
	}

	/**
	 * @param column the column to set
	 */
	public void setColumn(RangerPolicyResourceSupportingModel column) {
		this.column = column;
	}

	/**
	 * @return the table
	 */
	public RangerPolicyResourceSupportingModel getTable() {
		return table;
	}

	/**
	 * @param table the table to set
	 */
	public void setTable(RangerPolicyResourceSupportingModel table) {
		this.table = table;
	}

	/**
	 * @return the path
	 */
	public RangerPolicyResourceSupportingModel getPath() {
		return path;
	}

	/**
	 * @param path the path to set
	 */
	public void setPath(RangerPolicyResourceSupportingModel path) {
		this.path = path;
	}

	/**
	 * @return the columnFamily
	 */
	public RangerPolicyResourceSupportingModel getColumnFamily() {
		return columnFamily;
	}

	/**
	 * @param columnFamily the columnFamily to set
	 */
	public void setColumnFamily(RangerPolicyResourceSupportingModel columnFamily) {
		this.columnFamily = columnFamily;
	}

	/**
	 * @return the url
	 */
	public RangerPolicyResourceSupportingModel getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(RangerPolicyResourceSupportingModel url) {
		this.url = url;
	}

	/**
	 * @return the hiveservice
	 */
	public RangerPolicyResourceSupportingModel getHiveservice() {
		return hiveservice;
	}

	/**
	 * @param hiveservice the hiveservice to set
	 */
	public void setHiveservice(RangerPolicyResourceSupportingModel hiveservice) {
		this.hiveservice = hiveservice;
	}

	@Override
	public String toString() {
		return "RangerPolicyResourcesRespModel [database=" + database + ", column=" + column + ", table=" + table
				+ ", path=" + path + ", columnFamily=" + columnFamily + ", url=" + url + ", hiveservice=" + hiveservice
				+ "]";
	}

}
