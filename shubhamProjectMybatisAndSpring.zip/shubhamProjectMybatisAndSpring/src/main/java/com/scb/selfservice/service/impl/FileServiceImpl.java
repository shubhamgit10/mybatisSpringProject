package com.scb.selfservice.service.impl;

import com.scb.selfservice.service.FileService;
import freemarker.template.Configuration;
import freemarker.template.Template;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

@Service
public class FileServiceImpl implements FileService {
    private static Logger logger = LogManager.getLogger(FileServiceImpl.class);

    @Autowired
    private Configuration freemarkerConfig;

    public boolean createDirectory(String filePath){

        try{
            Files.createDirectories(Paths.get(filePath));
        }catch (Exception e){
            logger.debug(e.getMessage());
            return false;
        }
        return true;
    }

    public boolean saveStringAsFile(String filePath, String fileName, String fileContent, boolean fileOverWrite){
        logger.debug("Method:saveAsFile");
        logger.debug("File Path:"+ filePath);
        logger.debug("File Name:"+ fileName);

        try{

            if (filePath.substring(filePath.length() - 1) != "/"){
                filePath += "/";
            }

            if (! createDirectory(filePath)){
                return false;
            }

            String fileFullName = filePath + fileName;
            File file = new File(fileFullName);

            if (!file.exists() || fileOverWrite ){
                BufferedWriter writer = new BufferedWriter(new FileWriter(fileFullName));
                writer.write(fileContent);
                writer.close();
            } else {
                logger.debug("File Already Exists:" + fileFullName);
                return false;
            }

        }catch (Exception e){
            e.printStackTrace();
            logger.debug(e.getMessage());
            return false;
        }
        return true;
    }

    public boolean saveTemplateAsFile(String filePath,
                                      String fileName,
                                      String template,
                                      Map<String, Object> params,
                                      boolean fileOverWrite){
        try {
            logger.debug("Method:saveTemplateAsFile");
            logger.debug("File Path:"+ filePath);
            logger.debug("File Name:"+ fileName);
            logger.debug("Content Template:"+ template);

            Template temp = freemarkerConfig.getTemplate(template);
            String fileContent = FreeMarkerTemplateUtils.processTemplateIntoString(temp, params);
            saveStringAsFile(filePath,fileName,fileContent, fileOverWrite);

        }catch (Exception e){
            e.printStackTrace();
            logger.debug(e.getMessage());
            return false;
        }

        return true;
    }

}
