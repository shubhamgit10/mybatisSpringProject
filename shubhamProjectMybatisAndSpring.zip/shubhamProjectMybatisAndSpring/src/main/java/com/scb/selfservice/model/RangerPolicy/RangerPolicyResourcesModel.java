package com.scb.selfservice.model.RangerPolicy;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;

/**
 * 
 * @author 1610601
 *
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY)
public class RangerPolicyResourcesModel implements Serializable {

	/**
	 * 
	 */
	public RangerPolicyResourcesModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "RangerPolicyResourcesModel []";
	}
	

}
