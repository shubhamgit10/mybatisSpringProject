
package com.scb.selfservice.isd.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.UnsupportedFileFormatException;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.selfservice.isd.entity.ISDRequestDetails;
import com.scb.selfservice.isd.entity.ISDResponse;
import com.scb.selfservice.isd.entity.ISDSummary;
import com.scb.selfservice.isd.entity.ISDVerificationStatus;
import com.scb.selfservice.isd.entity.ViewExceptions;
import com.scb.selfservice.isd.exception.InvalidFileException;
import com.scb.selfservice.isd.service.IsdServiceImpl;
import com.scb.selfservice.util.EDMpUtil;
import com.scb.selfservice.util.Response;

/**
 * @author akuma400
 *
 */
@RestController
@RequestMapping("/api/isd")
public class ISDController {

	// private final static Logger log = Logger.getLogger(ISDController.class);
	private static Logger log = LogManager.getLogger(ISDController.class);

	@Autowired
	private IsdServiceImpl isdService;

	@RequestMapping(value = "/uploadExcel", method = RequestMethod.POST, consumes = {
			MediaType.MULTIPART_FORM_DATA_VALUE,
			MediaType.APPLICATION_JSON_VALUE }, produces = MediaType.APPLICATION_JSON_VALUE)
	Response uploadISDExecl(@RequestParam("file") MultipartFile file, @RequestParam("isdInputs") String isdInputsJson) {
		log.info("Start:uploadISDExecl");
		Response resp = new Response();
		Integer latestVersion = 0;
		List<ISDVerificationStatus> isdList = new ArrayList<>();
		/*
		 * UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser(); if
		 * (null == loggedInUser) { resp.setStatus(HttpStatus.UNAUTHORIZED.toString());
		 * resp.setStatusCode(HttpStatus.UNAUTHORIZED.value()); return resp; }
		 */

		ObjectMapper objectMapper = new ObjectMapper();
		ISDRequestDetails isdInputs = null;
		try {
			isdInputs = objectMapper.readValue(isdInputsJson, ISDRequestDetails.class);
			log.info("uploadISDExecl:isdInputs:" + isdInputs);
		} catch (Exception e) {
			log.error("uploadISDExecl:error parsing input json");
			e.printStackTrace();
		}

		ISDVerificationStatus response = null;
		ISDResponse isdResponse = new ISDResponse();
		if (file.isEmpty()) {

			log.error("uploadISDExecl:file.isEmpty()" + file.isEmpty());
			return bindNonAcceptableResponse(resp);
		}
		try {

			// Get the file and save it somewhere
			byte[] bytes = file.getBytes();
			isdService.saveISDFile(bytes, isdInputs, file.getOriginalFilename());
			latestVersion = isdService.getLatestVersion(isdInputs.getReqId());
			log.info("uploadISDExecl:latesstVersion:" + latestVersion);
			InputStream excelFile = new ByteArrayInputStream(bytes);
			XSSFWorkbook workbook = new XSSFWorkbook(excelFile);
			response = isdService.performOperationOnISD(workbook, isdInputs, latestVersion);
			if (null == response) {
				log.error("uploadISDExecl:error in excel validation");
				return bindNonAcceptableResponse(resp);
			}
			isdService.updateFlagForApproval(isdInputs.getReqId());
			List<ISDSummary> isdSummary = isdService.getISDSummary(isdInputs);
			log.debug("uploadISDExecl:isdSummary:" + isdSummary);
			log.info("uploadISDExecl:response:" + response);
			isdList.add(response);
			isdResponse.setListIsdVarificationStatus(isdList);
			isdResponse.setIsdSummary(isdSummary);

		} catch (UnsupportedFileFormatException  | IOException e) {
			log.error("uploadISDExecl:e.getMessage():" + e.getMessage());
			e.printStackTrace();
			throw new InvalidFileException("Invalid File");
		}

		log.info("END:uploadISDExecl");
		resp.setStatus(HttpStatus.OK.toString());
		resp.setStatus("OK");
		resp.setResponse(isdResponse);
		resp.setStatusCode(HttpStatus.OK.value());
		return resp;
	}

	private Response bindNonAcceptableResponse(Response resp) {
		resp.setStatus(HttpStatus.PARTIAL_CONTENT.toString());
		resp.setResponse("Invalid File");
		resp.setStatusCode(HttpStatus.PARTIAL_CONTENT.value());
		return resp;

	}

	@RequestMapping(value = "/varification/status", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response retriveIsdVarificationStatus(@RequestBody ISDRequestDetails isdInputs) {
		log.info("retriveIsdVarificationStatus:start");
		Response response = new Response();
		try {
			List<ISDVerificationStatus> status = isdService.getVerificationStatus(isdInputs);
			List<ISDSummary> isdSummary = null;
			ISDResponse isdResponse = new ISDResponse();
			isdResponse.setListIsdVarificationStatus(status);

			if (status != null && status.size() > 0) {
				isdSummary = isdService.getISDSummary(isdInputs);
			}
			isdResponse.setIsdSummary(isdSummary);

			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus("OK");
			response.setResponse(isdResponse);
		} catch (Exception e) {
			e.printStackTrace();
			throw new InvalidFileException("No Content");
		}
		log.info("retriveIsdVarificationStatus:end");
		return response;
	}

	@RequestMapping(value = "/viewExceptions/{reqId}/{versionNo}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response getIsdExceptions(@PathVariable("reqId") int reqId,
			@PathVariable("versionNo") Integer versionNo) {
		log.info("getIsdExceptions:start:reqId:" + reqId + ":versionNo:" + versionNo);
		List<ViewExceptions> exceptions = isdService.retrieveException(reqId, versionNo);
		Response response = new Response();
		response.setStatusCode(HttpStatus.OK.value());
		response.setStatus(HttpStatus.OK.toString());
		response.setResponse(exceptions);
		log.info("getIsdExceptions:end");

		return response;
	}

	@GetMapping(path = "/download/exception/{reqId}/{versionNo}", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<InputStreamResource> getFile(@PathVariable("reqId") int reqId,
			@PathVariable("versionNo") Integer versionNo) throws IOException {
		log.info("getFile:start:reqId:" + reqId + ":versionNo:" + versionNo);
		ByteArrayInputStream stream = isdService.prepareFileForException(reqId, versionNo);

		if (null == stream) {
			return ResponseEntity.noContent().build();
		}

		HttpHeaders headers = new HttpHeaders();
		String fileNames = "ISD" + reqId + "_" + EDMpUtil.formattedDate() + ".xlsx";
		headers.add("Content-Disposition", "attachment; filename=" + fileNames);
		log.info("getFile:end");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(stream));
	}

}
