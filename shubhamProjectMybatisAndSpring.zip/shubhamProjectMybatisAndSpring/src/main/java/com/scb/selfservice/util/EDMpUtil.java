package com.scb.selfservice.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.scb.selfservice.domains.DownloadFile;
import com.scb.selfservice.domains.EDMPEstimationMetaData;
import com.scb.selfservice.domains.IngestionRequest;
import com.scb.selfservice.domains.IsdFileStore;
import com.scb.selfservice.domains.Pipelineview;

public class EDMpUtil {

	private static Logger logger = LogManager.getLogger(EDMpUtil.class);

	private static List<String> colHeaders() {
		String[] str = { "Data Injestion Request Id", "Source Name", "Instance Name", "Years Of History Is Req",
				"Approx History Data Size", "History Storage Type", "Frequency", "Approx Incremental Data Size",
				"Incremental Storage Type", "Expected Delivery Date", "Expected No Of Files",
				"Expected No Of Attributes", "Priority", "ItamNumber", "Project Name", "Business Stream",
				"Funding Avenue", "Benefit Catagory", "Benefit Details", "Request Summary", "SourceType" };
		List<String> headers = Arrays.asList(str);
		return headers;
	}

	public static ByteArrayInputStream prepareXlsx(List<DownloadFile> fileData) throws IOException {
		logger.info("starting EDMpUtil::prepareXlsx");
		XSSFWorkbook workbook = null;
		ByteArrayOutputStream out = null;
		try {
			workbook = new XSSFWorkbook();
			out = new ByteArrayOutputStream();
			XSSFSheet sheet = workbook.createSheet("Ingestion Request");

			int rownum = 0;
			int cellnum = 0;
			Row row = sheet.createRow(rownum++);
			CellStyle cellStyle = getHeaderCellStyle(workbook);

			for (String header : colHeaders()) {
				Cell cell = row.createCell(cellnum++);

				cell.setCellValue(header);
				cell.setCellStyle(cellStyle);
			}
			row = sheet.createRow(rownum);
			cellnum = 0; // row first cell
			cellStyle = getCellStyle(workbook);
			if (fileData.isEmpty() || (null == fileData)) {
				row = sheet.createRow(rownum++);
				Cell cell = row.createCell(cellnum);

				cell.setCellValue("DATA NOT AVAILABLE");
				sheet.addMergedRegion(new CellRangeAddress(rownum + 2, rownum + 2, 0, 2));
				logger.info("EDMpUtil::prepareXlsx DATA NOT AVAILABLE");
			} else {
				logger.info("EDMpUtil::prepareXlsx WRITING " + fileData.size() + " rows");
				for (DownloadFile item : fileData) {
					row = sheet.createRow(rownum++);
					cellnum = 0;
					logger.info("EDMpUtil::prepareXlsx starting row " + (rownum - 1));
					for (String str : item.getGetters(item)) {
						Cell cell = row.createCell(cellnum++);
						if (StringUtils.isBlank(str) || str.equals("null"))
							cell.setCellValue("-");
						else
							cell.setCellValue(str);
						cell.setCellStyle(cellStyle);
					}
					logger.info("EDMpUtil::prepareXlsx done with row " + (rownum - 1));
				}
				logger.info("EDMpUtil::prepareXlsx DATA WRITTEN");
			}
			row = sheet.createRow(rownum + 2); //
			Cell cell = row.createCell(0);
			cell.setCellValue("<End of Report >");
			sheet.addMergedRegion(new CellRangeAddress(rownum + 1, rownum + 1, 0, 2));
			workbook.write(out);
			logger.info("exiting EDMpUtil::prepareXlsx");
			return new ByteArrayInputStream(out.toByteArray());
		} catch (Exception ex) {
			logger.info("EXCEPTION occuered while preparing xlsx " + ex.getMessage());
			return null;
		} finally {
			if (null != out)
				out.close();
			if (null != workbook)
				workbook.close();
		}
	}

	public static CellStyle getHeaderCellStyle(XSSFWorkbook workbook) {
		CellStyle style = workbook.createCellStyle();
		// style.setFillBackgroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
		style.setBorderBottom(BorderStyle.THIN);
		style.setBorderLeft(BorderStyle.THIN);
		style.setBorderRight(BorderStyle.THIN);
		style.setBorderTop(BorderStyle.THIN);
		style.setWrapText(true);
		style.setAlignment(HorizontalAlignment.LEFT);
		style.setVerticalAlignment(VerticalAlignment.TOP);
		style.setFont(boldFont(workbook, true));

		return style;
	}

	public static Font boldFont(XSSFWorkbook workbook, boolean boldFont) {
		Font font = workbook.createFont();
		font.setFontHeightInPoints((short) 7);
		font.setFontName("Segoe UI");
		if (boldFont)
			font.setBold(true);
		else
			font.setBold(false);
		return font;
	}

	private static CellStyle getCellStyle(XSSFWorkbook workbook) {
		CellStyle style = workbook.createCellStyle();
		style.setBorderBottom(BorderStyle.THIN);
		style.setBorderLeft(BorderStyle.THIN);
		style.setBorderRight(BorderStyle.THIN);
		style.setBorderTop(BorderStyle.THIN);
		style.setWrapText(true);

		style.setFont(boldFont(workbook, false));

		return style;
	}

	public static String formattedDate() {
		DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

		LocalDateTime localDateTime = LocalDateTime.now();

		String dateTime = format.format(localDateTime);
		logger.info("The formatted date is: " + dateTime);

		return dateTime;
	}

	public static String fileName(String sourceType) {
		String fileName = "ISD" + sourceType + "_" + formattedDate() + ".xlsx";
		return fileName;
	}

	public static String fileNameForIsd(String sourceType) {
		String fileName = "ISD" + sourceType + "_" + formattedDate() + ".xlsm";
		return fileName;
	}

	public static String fileNameIsdFilestore(String reqId) {
		String fileName = "ISDFILESTORE" + "_" + formattedDate() + ".xlsm";
		return fileName;
	}

	public static String fileNameViewPipeline() {
		String fileName = "ViewPipeline" + "_" + formattedDate() + ".xlsx";
		return fileName;
	}

	public static ByteArrayInputStream prepareIsdXlsx(EDMPEstimationMetaData fileData) throws IOException {
		logger.info("starting EDMpUtil::prepareIsdXlsx");
		ByteArrayInputStream bis = null;
		if (fileData.getCostEstimationTemplate() != null) {
			try {
				bis = new ByteArrayInputStream(fileData.getCostEstimationTemplate());
				logger.info("exiting EDMpUtil::prepareIsdXlsx");
			} catch (Exception ex) {
				logger.info("EXCEPTION occuered while preparing Isd xlsx " + ex.getMessage());
			} finally {
				if (null != bis)
					bis.close();
			}
		}
		return bis;

	}

	public static ByteArrayInputStream prepareIsdFileStoreXlsx(List<IsdFileStore> fileData) throws IOException {
		logger.info("starting EDMpUtil::prepareIsdFileStoreXlsx");
		ByteArrayInputStream bis = null;
		IsdFileStore isdFileStore = null;
		if (fileData != null && fileData.size() > 0) {
			try {
				isdFileStore = fileData.get(0);
				bis = new ByteArrayInputStream(isdFileStore.getFiles());
				logger.info("exiting EDMpUtil::prepareIsdFileStoreXlsx" + isdFileStore.getVersionNo());
				System.out.println(isdFileStore.getVersionNo());
			} catch (Exception ex) {
				logger.info("EXCEPTION occuered while preparing Isd xlsx " + ex.getMessage());
			} finally {
				if (null != bis)
					bis.close();
			}
		}
		return bis;

	}
	
	private static List<String> colHeadersForPipeline() {
		String[] str = { "Data Injestion Request Id", "Source Name", "Instance Name", "Expected Delivery Date", "Expected No Of Files",
				"Expected No Of Attributes", "ItamNumber", "Project Name", "Business Stream",
				"Funding Avenue", "Benefit Catagory", "Benefit Details", "Request Summary", "SourceType"};
		List<String> headers = Arrays.asList(str);
		return headers;
	}
	
	public static ByteArrayInputStream preparePipelineXlsx(List<Pipelineview> fileData) throws IOException {
		logger.info("starting EDMpUtil::prepareXlsx");
		XSSFWorkbook workbook = null;
		ByteArrayOutputStream out = null;
		try {
			workbook = new XSSFWorkbook();
			out = new ByteArrayOutputStream();
			XSSFSheet sheet = workbook.createSheet("Ingestion Request");

			int rownum = 0;
			int cellnum = 0;
			Row row = sheet.createRow(rownum++);
			CellStyle cellStyle = getHeaderCellStyle(workbook);

			for (String header : colHeadersForPipeline()) {
				Cell cell = row.createCell(cellnum++);

				cell.setCellValue(header);
				cell.setCellStyle(cellStyle);
			}
			row = sheet.createRow(rownum);
			cellnum = 0; // row first cell
			cellStyle = getCellStyle(workbook);
			if (fileData.isEmpty() || (null == fileData)) {
				row = sheet.createRow(rownum++);
				Cell cell = row.createCell(cellnum);

				cell.setCellValue("DATA NOT AVAILABLE");
				sheet.addMergedRegion(new CellRangeAddress(rownum + 2, rownum + 2, 0, 2));
				logger.info("EDMpUtil::prepareXlsx DATA NOT AVAILABLE");
			} else {
				logger.info("EDMpUtil::prepareXlsx WRITING " + fileData.size() + " rows");
				for (Pipelineview item : fileData) {
					row = sheet.createRow(rownum++);
					cellnum = 0;
					logger.info("EDMpUtil::prepareXlsx starting row " + (rownum - 1));
					for (String str : item.getGetters(item)) {
						Cell cell = row.createCell(cellnum++);
						if (StringUtils.isBlank(str) || str.equals("null"))
							cell.setCellValue("-");
							 //cell = row.createCell(cellnum--);
						else
							cell.setCellValue(str);
						cell.setCellStyle(cellStyle);
					}
					logger.info("EDMpUtil::prepareXlsx done with row " + (rownum - 1));
				}
				logger.info("EDMpUtil::prepareXlsx DATA WRITTEN");
			}
			row = sheet.createRow(rownum + 2); //
			Cell cell = row.createCell(0);
			cell.setCellValue("<End of Report >");
			sheet.addMergedRegion(new CellRangeAddress(rownum + 1, rownum + 1, 0, 2));
			workbook.write(out);
			logger.info("exiting EDMpUtil::prepareXlsx");
			return new ByteArrayInputStream(out.toByteArray());
		} catch (Exception ex) {
			logger.info("EXCEPTION occuered while preparing xlsx " + ex.getMessage());
			return null;
		} finally {
			if (null != out)
				out.close();
			if (null != workbook)
				workbook.close();
		}
	}

}
