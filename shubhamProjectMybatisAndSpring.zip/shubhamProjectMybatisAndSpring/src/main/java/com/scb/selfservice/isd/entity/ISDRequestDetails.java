package com.scb.selfservice.isd.entity;

public class ISDRequestDetails {
	  private int reqId; 
	  private String system; 
	  private String country;
	  private Integer filesCount; //tables
	  private Integer attributesCount; //columns
	  private String stepId; 
	  
	public int getReqId() {
		return reqId;
	}
	public void setReqId(int reqId) {
		this.reqId = reqId;
	}
	public String getSystem() {
		return system;
	}
	public void setSystem(String system) {
		this.system = system;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Integer getFilesCount() {
		return filesCount;
	}
	public void setFilesCount(Integer filesCount) {
		this.filesCount = filesCount;
	}
	public Integer getAttributesCount() {
		return attributesCount;
	}
	public void setAttributesCount(Integer attributesCount) {
		this.attributesCount = attributesCount;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	@Override
	public String toString() {
		return "ISDRequestDetails [reqId=" + reqId + ", system=" + system + ", country=" + country + ", filesCount="
				+ filesCount + ", attributesCount=" + attributesCount + ", stepId=" + stepId + "]";
	}
	  
	
}
