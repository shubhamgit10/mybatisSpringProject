package com.scb.selfservice.service.impl;

import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.IngestionDynamicMapper;
import com.scb.selfservice.dao.mapper.WorkflowMapper;
import com.scb.selfservice.dao.mapper.ingestion.ISDSummaryMapper;
import com.scb.selfservice.dao.td.mapper.ImpactedConsumerTDMapper;
import com.scb.selfservice.domains.IngestionDeployForms;
import com.scb.selfservice.domains.IngestionDeployIterations;
import com.scb.selfservice.domains.IngestionExceptions;
import com.scb.selfservice.domains.IngestionInput;
import com.scb.selfservice.domains.IngestionTestIterations;
import com.scb.selfservice.domains.WorkflowIdType;
import com.scb.selfservice.domains.databaseentity.ImpactedConsumer;
import com.scb.selfservice.service.IngestionService;
import com.scb.selfservice.util.Response;


@Service
public class IngestionImpl implements IngestionService {
	
	Logger logger = LogManager.getLogger(IngestionImpl.class);
	
	
	@Autowired
	IngestionDynamicMapper idynMapper;
	
	@Autowired
	WorkflowMapper workflowMapper;
	
	@Autowired
	ImpactedConsumerTDMapper impactedConsumerTDMapper;
	
	/*
	 * @Autowired private ISDServiceMapper isdServiceMapper;
	 */

	@Autowired
	private ISDSummaryMapper isdSummaryMapper;

	@Override
	public Response getIngestionSitData(Integer reqId, String stepId) {
		// TODO Auto-generated method stub
		
		Response getSitResp = new Response();
		
		List<IngestionDeployIterations> irObj = idynMapper.iterationfindByReqId(reqId, stepId);
		
			if(null == irObj) {
			
				getSitResp.setStatusCode(HttpStatus.NO_CONTENT.value());
				getSitResp.setStatus(HttpStatus.NO_CONTENT.toString());
			
			}else {
								
				getSitResp.setResponse(irObj);
				getSitResp.setStatusCode(HttpStatus.OK.value());
				getSitResp.setStatus(HttpStatus.OK.toString());
			}
		
		return getSitResp;
	}

	@Override
	public Response updateDepIterations(IngestionInput ingestionInput) {
		// TODO Auto-generated method stub
		
		Response isaResponse = new Response();

		HashMap<String, Object> hm = (HashMap<String, Object>) ingestionInput.getParams();

		hm.put("reqId", ingestionInput.getReqId());
		
		hm.put("stepId", ingestionInput.getStepId());
		
		//TODO ::: need to call SCB API for Inserting Exception details
		
		hm.put("deploymentStatus", "SUCCESS");
		hm.put("exceptions", 1);
		
		Object environment = hm.get("environmentToDeploy");
		
		hm.put("environment", environment);
		
		//if (irObjNew != null) {
			logger.info("update for updateSitIterationRequest..." + ingestionInput.getReqId());

			int updateStatus = idynMapper.updateSitIterationRequest(hm); // insert
			
			
			isaResponse = getActionStatus("update", updateStatus, ingestionInput.getReqId());
			
		
			logger.info("EXIT save request at userAction equals null");
	//	} 
		
		//Depends on the result of SCB API 
	//	if(irObj==null) {
			
			logger.info("START it is a new entry for new request  saveExceptionDetails..." + ingestionInput.getReqId());
		
			idynMapper.saveExceptionDetails(hm); // update

			logger.info("exit saveExceptionDetails..." );			

	//	}	
		
		//isaResponse.setResponse(updateStatus);
			
			HashMap<String, Object> hmNew = (HashMap<String, Object>) ingestionInput.getParams();
			
			Integer releaseId = (Integer) hm.get("releaseId");
					
				
				IngestionDeployIterations idIterations = new IngestionDeployIterations();
				
				idIterations.setReqId(ingestionInput.getReqId());
				idIterations.setStepId(ingestionInput.getStepId());
				idIterations.setReleaseId(releaseId);
		
				idIterations.setExceptions(1);
				idIterations.setDeploymentStatus("SUCCESS");
				
				isaResponse.setResponse(idIterations);
		return isaResponse;
	}
	
	
	
	@Override
	public Response getSitExceptionDetails(Integer reqId, String stepId) {
		// TODO Auto-generated method stub
		
		logger.info("inside getSitExceptionDetails..." );
		
		Response getExceptionResp = new Response();
		
		List<IngestionExceptions> irObj = idynMapper.exceptionsfindByReqId(reqId, stepId);
		
		logger.info("inside getSitExceptionDetails..." +irObj); 
		
			if(null == irObj) {
			
				getExceptionResp.setStatusCode(HttpStatus.NO_CONTENT.value());
				getExceptionResp.setStatus(HttpStatus.NO_CONTENT.toString());
			
			}else {
								
				getExceptionResp.setResponse(irObj);
				getExceptionResp.setStatusCode(HttpStatus.OK.value());
				getExceptionResp.setStatus(HttpStatus.OK.toString());
			}
		
			logger.info("exit getSitExceptionDetails..." );
		return getExceptionResp;
	}
	
	
	
	// to retrieve the SIT verification Iteration table Data using get Mapping
	@Override
	public Response getSitVerfData(Integer reqId, String stepId) {
		// TODO Auto-generated method stub
		
		Response getSitResp = new Response();
		
		List<IngestionTestIterations> irObj = idynMapper.verficationfindByReqId(reqId, stepId);
		
			if(null == irObj) {
			
				getSitResp.setStatusCode(HttpStatus.NO_CONTENT.value());
				getSitResp.setStatus(HttpStatus.NO_CONTENT.toString());
			
			}else {
								
				getSitResp.setResponse(irObj);
				getSitResp.setStatusCode(HttpStatus.OK.value());
				getSitResp.setStatus(HttpStatus.OK.toString());
			}
		
		return getSitResp;
	}
	
	
	
	/**
	 * @param type
	 * @param saveStatus
	 * @param reqId
	 * @return
	 */
	private Response getActionStatus(String type, int saveStatus, int reqId) {
		Response response = new Response();
		if (saveStatus == 1) {
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus(HttpStatus.OK.toString());
			response.setResponse(reqId + "Request id " + (type.equals("save") ? "INSERTED" : "UPDATED"));
		} else {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
			response.setResponse("!!!Action not taken!!!");
		}
		return response;
	}

	@Override
	public Response updateVerifIterations(IngestionInput ingestionInput) {
		// TODO Auto-generated method stub
		
		
		Response isaResponse = new Response();

		HashMap<String, Object> hm = (HashMap<String, Object>) ingestionInput.getParams();

		hm.put("reqId", ingestionInput.getReqId());
		hm.put("stepId", ingestionInput.getStepId());
		
		//TODO ::: need to call SCB API for Inserting Exception details
		
		hm.put("executionStatus", "SUCCESS");
		hm.put("exceptions", 1);
		hm.put("totalIssues", 5);
		
		Object environment = hm.get("environmentToDeploy");
		
		hm.put("environment", environment);
		
		//if (irObjNew != null) {
			logger.info("update for updateSitIterationRequest..." + ingestionInput.getReqId());

			int updateStatus = idynMapper.updateSitVerifIterReq(hm); // insert
			
			
			isaResponse = getActionStatus("update", updateStatus, ingestionInput.getReqId());
			
		
			logger.info("EXIT save request at userAction equals null");
	//	} 
		
		//Depends on the result of SCB API 
	//	if(irObj==null) {
			
			logger.info("START it is a new entry for new request  saveExceptionDetails..." + ingestionInput.getReqId());
		
			idynMapper.saveExceptionDetails(hm); // update

			logger.info("exit saveExceptionDetails..." );			

	//	}	
		
		//isaResponse.setResponse(updateStatus);
			
			HashMap<String, Object> hmNew = (HashMap<String, Object>) ingestionInput.getParams();
			
			Integer iterationNum = (Integer) hm.get("iterationNum");
					
			System.out.println(iterationNum);
				
				IngestionTestIterations idIterations = new IngestionTestIterations();
				
				idIterations.setReqId(ingestionInput.getReqId());
				idIterations.setStepId(ingestionInput.getStepId());
				idIterations.setIterationNum(iterationNum);
		
				idIterations.setExceptions(1);
				idIterations.setExecutionStatus("SUCCESS");
				idIterations.setTotalIssues(5);
				
				isaResponse.setResponse(idIterations);
		return isaResponse;
		
	}
	
	@Override
	@Transactional(value = "transactionManagerTD"
	)
	public Response findByImpactedConsumer(String reqId) {
		List<String> tableNames = getTableNames(reqId);
		List<ImpactedConsumer> impactedConsumer = impactedConsumerTDMapper.findByImpactedConsumer(tableNames);
		Response response = new Response();
		if (impactedConsumer != null) {
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus(HttpStatus.OK.toString());
			response.setResponse(impactedConsumer);
		} else {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
		}

		return response;
	}
	
	@Transactional(value = "transactionManager")
	private List<String> getTableNames(String reqId) {
		 List<String> tableNames = isdSummaryMapper.getTableNamesByReqId(Integer.parseInt(reqId));
		 return tableNames;
	}
	
	

}
