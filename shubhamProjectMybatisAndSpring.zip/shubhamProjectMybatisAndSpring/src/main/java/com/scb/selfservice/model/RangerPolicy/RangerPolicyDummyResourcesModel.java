package com.scb.selfservice.model.RangerPolicy;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;

/**
 * 
 * @author 1610601
 *
 */

@JsonAutoDetect(fieldVisibility = Visibility.ANY)
public class RangerPolicyDummyResourcesModel extends RangerPolicyResourcesModel implements Serializable {

    private RangerPolicyResourceSupportingModel url;

    public RangerPolicyDummyResourcesModel() {
    }

    public RangerPolicyDummyResourcesModel(RangerPolicyResourceSupportingModel url) {
        this.url = url;
    }

    public RangerPolicyResourceSupportingModel getUrl() {
        return url;
    }

    public void setUrl(RangerPolicyResourceSupportingModel url) {
        this.url = url;
    }

    @Override
    public String toString() {
        return "RangerPolicyDummyResourcesModel{" +
                "url=" + url +
                '}';
    }
}
