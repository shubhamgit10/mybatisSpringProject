package com.scb.selfservice.domains;

public class SDMTechConfigDto {

	private Integer configId;
	private String configCategory;
	private String configName;
	private String configLabel;
	private Integer lookupKey;
	private String configType;
	private String defaultValue;
	
	public Integer getConfigId() {
		return configId;
	}
	public void setConfigId(Integer configId) {
		this.configId = configId;
	}
	public String getConfigCategory() {
		return configCategory;
	}
	public void setConfigCategory(String configCategory) {
		this.configCategory = configCategory;
	}
	public String getConfigName() {
		return configName;
	}
	public void setConfigName(String configName) {
		this.configName = configName;
	}
	public String getConfigLabel() {
		return configLabel;
	}
	public void setConfigLabel(String configLabel) {
		this.configLabel = configLabel;
	}
	public Integer getLookupKey() {
		return lookupKey;
	}
	public void setLookupKey(Integer lookupKey) {
		this.lookupKey = lookupKey;
	}
	public String getConfigType() {
		return configType;
	}
	public void setConfigType(String configType) {
		this.configType = configType;
	}
	public String getDefualtValue() {
		return defaultValue;
	}
	public void setDefualtValue(String defualtValue) {
		this.defaultValue = defualtValue;
	}
	@Override
	public String toString() {
		return "SDMTechConfigDto [configId=" + configId + ", configCategory=" + configCategory + ", configName="
				+ configName + ", configLabel=" + configLabel + ", lookupKey=" + lookupKey + ", configType="
				+ configType + ", defualtValue=" + defaultValue + "]";
	}
	
	
}
