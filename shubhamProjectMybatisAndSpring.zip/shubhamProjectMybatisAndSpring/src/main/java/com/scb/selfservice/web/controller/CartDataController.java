package com.scb.selfservice.web.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.domains.DeleteCart;
import com.scb.selfservice.domains.EDMPCartConsumptionRequest;
import com.scb.selfservice.service.CartDataService;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;
import com.scb.selfservice.web.authentication.UserPrincipal;

@RestController
@RequestMapping("/api/cartData")
public class CartDataController {
	private static Logger logger = LogManager.getLogger(CartDataController.class);
	@Autowired
	private CartDataService cartDataService;

	@RequestMapping(path = "/addToCartData", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> addToCart(@RequestBody List<EDMPCartConsumptionRequest> eDMPCartConsumptionRequest) {
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response cartDataResponse = new Response();
		if (loggedInUser != null) {
			Integer userId = Integer.valueOf(loggedInUser.getUserId());
			cartDataResponse = cartDataService.addToCart(eDMPCartConsumptionRequest,userId);	
		} else {
			cartDataResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			cartDataResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
		return new ResponseEntity<Response>(cartDataResponse,HttpStatus.OK);
	}

	@RequestMapping(path = "/getCartData", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getCartData(@RequestParam Integer requestId) {
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response cartDataResponse = new Response();
		if (loggedInUser != null) {
			cartDataResponse = cartDataService.getCartData(requestId);
		} else {
			cartDataResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			cartDataResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
		return new ResponseEntity<Response>(cartDataResponse,HttpStatus.OK);
	}

	@RequestMapping(path = "/deleteCart", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> deleteCart(@RequestBody DeleteCart deleteCart) {
		logger.info("STARTED CartDataController:: deleteCart");
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response deleteCartResponse = new Response();
		if (loggedInUser != null) {
			deleteCartResponse = cartDataService.deleteCart(deleteCart);
		logger.info("EXITING CartDataController:: deleteCart");
		} else {
			deleteCartResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			deleteCartResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
		return new ResponseEntity<Response>(deleteCartResponse, HttpStatus.OK);
	}

}
