/**
 * 
 */
package com.scb.selfservice.dao.td.mapper;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.databaseentity.DBAdRoleGroup;

/**
 * Mapper class for all persistance of Consumption Master related data 
 * 
 * @author Amarnath BB
 *
 */
public interface ConsumptionMasterMapper {
	
	/**
	 * Method to retrieve existing Consumption Master AD Role details
	 * 
	 * @return
	 */
	public List<DBAdRoleGroup> getConsumptionMasterADRole();
	
	/**
	 * Method to create a new consumption request
	 * @param result
	 */
	public void createNewConsumptionRequest(HashMap<String, String> result);
	
	/**
	 * Method to update the consumption master table
	 * @param result
	 */
	public void updateConsumptionMaster(HashMap<String, String> result);
	
	/**
	 * Method to insert request table details into temp details
	 * @param reqTables
	 */
	public void insertTabDetails(@Param("consumerId")String consumerId, @Param("reqTables") List<HashMap<String,String>> reqTables);
	
	/**
	 * Method to insert to SLA Meta Details table
	 * @param result
	 */
	public void insertSLAMetaDetails(HashMap<String, String> result);
	
	/**
	 * Method to insert into AD Group details
	 * @param result
	 */
	public void insertADGroupDetails(HashMap<String, String> result);
	
	/**
	 * delete request from temp table
	 * @param consumerId
	 */
	public void deleteTabDetails(@Param("consumerId")String consumerId);
	
	/**
	 * Get the Existing SLA Metadata table
	 * @param consumerId
	 */
	public String getSLAMetaByConsumerId(@Param("consumerId")String consumerId);
	
	/**
	 * Method to get the processed count records in T_OPS_SLA_METADATA_DETAIL
	 * @param consumerId
	 * @return
	 */
	public int getProcessedCountRecords(@Param("consumerId")String consumerId);
	
	

}
