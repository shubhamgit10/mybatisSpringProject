/**
 * 
 */
package com.scb.selfservice.service;

/**
 * Ranger Policy Wrapper Service to create the Access rights for the ADGroups
 * 
 * @author Amarnath
 *
 */
public interface RangerPolicyServiceWrapper {
	
	/**
	 * Method to handle policy creation
	 * @param reqId
	 * @param stepId
	 */
	public void handlePolicyCreation(String reqId, String stepId, String userId);

}
