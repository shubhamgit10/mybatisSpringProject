package com.scb.selfservice.web.controller;


import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.service.ConsumerRequestEmailService;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;
import com.scb.selfservice.web.authentication.UserPrincipal;
import com.scb.selfservice.workflow.service.ExecutionContext;
import com.scb.selfservice.workflow.service.task.MailNotificationTask;

@RestController
@RequestMapping("/api/email")
public class EmailController {

	private static Logger logger = LogManager.getLogger(EmailController.class);
	
    @Autowired
    private MailNotificationTask consumptionMailNotifTask;
    
    @Autowired
	private ConsumerRequestEmailService consumerRequestEmailService;
    /**
     * Method to send mail to the approval group for the given workflowid
     * @param reqid
     * @param stepid
     * @param stepaction
     * @return
     */

    @RequestMapping(path = "/reqstatusmail", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, String> sendmail(@RequestHeader Map<String, String> header,
                                        @RequestParam(name = "reqid") int reqid,
                                        @RequestParam(name = "stepid") String stepid,
                                        @RequestParam(name = "stepaction") String stepaction,
                                        HttpServletRequest request) {

        Map<String, String> result = new HashMap<String, String>();
        ExecutionContext ctx = new ExecutionContext();
        ctx.setReqId(reqid+"");
        ctx.setStepId(stepid);
        ctx.setAction(stepaction);
        consumptionMailNotifTask.execute(ctx);
        
        result.put("status","200");
        return result;
    }
    
    @PostMapping(path="/costEstimationMail", produces=MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Response> sendCostEstimationMail(@RequestParam("requestId") String requestId,
    		@RequestParam("estimationId") Integer estimationId) {
    	UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
    	Response sendCostEstimationMailResponse = new Response();
    	if (loggedInUser != null && requestId != null ) {
    		try {
    			sendCostEstimationMailResponse = consumerRequestEmailService.sendCostEstimationMail(Integer.parseInt(loggedInUser.getUserId()),Integer.getInteger(requestId), estimationId);
    		} catch (Exception ex) {
				logger.info("EXCEPTION EmailController::sendCostEstimationMail: " + ex.getMessage());
				sendCostEstimationMailResponse.setStatus(HttpStatus.NO_CONTENT.toString());
				sendCostEstimationMailResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			}	
    	} else {
    		if(requestId == null ) {
    			sendCostEstimationMailResponse.setStatus("Request ID is NULL");
				sendCostEstimationMailResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
    		} else {
    			sendCostEstimationMailResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
        		sendCostEstimationMailResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
    		}
    	}
    	
    	return new ResponseEntity<Response>(sendCostEstimationMailResponse,HttpStatus.OK);
    }

}
