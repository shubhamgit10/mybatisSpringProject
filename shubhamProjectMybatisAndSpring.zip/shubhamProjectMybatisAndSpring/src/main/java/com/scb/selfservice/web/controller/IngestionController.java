package com.scb.selfservice.web.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.dao.mapper.IngestionDynamicMapper;
import com.scb.selfservice.domains.IngestionInput;
import com.scb.selfservice.domains.IngestionRequest;
import com.scb.selfservice.service.IngestionService;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;
import com.scb.selfservice.web.authentication.UserPrincipal;

@RestController
@RequestMapping("/api/ingestionData")
public class IngestionController {

	Logger logger = LogManager.getLogger(IngestionController.class);

	@Autowired
	IngestionService iService;

	// GetMethod for getSitIterationData in Ingestion
	@RequestMapping(path = "/IterationData", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getIngestionSitData(@RequestParam("reqId") Integer reqId, @RequestParam("stepId") String stepId) {

		logger.info("getIngestionSitData ");
		Response dataSourceResponse = new Response();

		try {
			dataSourceResponse = iService.getIngestionSitData(reqId, stepId);
		} catch (Exception ex) {
			logger.info("EXCEPTION IngestionController::getIngestionSitData: " + ex.getMessage());
			dataSourceResponse.setStatus(HttpStatus.NO_CONTENT.toString());
			dataSourceResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
		}
		return new ResponseEntity<Response>(dataSourceResponse, HttpStatus.OK);
	}

	@PutMapping(path = "/updateDepIterations", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> updateDepIterations(@RequestBody IngestionInput ingestionInput) {
		
		logger.info("inside IngestionController::updateDepIterations ");

		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		Response ingestionResponse = new Response();
		if (loggedInUser != null) {
			Integer userId = Integer.valueOf(loggedInUser.getUserId());
			ingestionInput.setUserId(userId);
			try {
				ingestionResponse = iService.updateDepIterations(ingestionInput);
			} catch (Exception ex) {
				ingestionResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
				ingestionResponse.setStatus(HttpStatus.NO_CONTENT.toString());
				logger.info("EXCEPTION IngestionController>updateDepIterations: " + ex.getMessage());
			}
		} else {
			ingestionResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
			ingestionResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		}

		return new ResponseEntity<Response>(ingestionResponse, HttpStatus.OK);
	}

	// GetMethod for getSitExceptionDetails in Ingestion
	@RequestMapping(path = "/ExceptionDetails", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getSitExceptionDetails(@RequestParam("reqId") Integer reqId,@RequestParam("stepId") String stepId) {

		logger.info("getSitExceptionDetails ");
		Response dataSourceResponse = new Response();

		try {
			dataSourceResponse = iService.getSitExceptionDetails(reqId, stepId);
		} catch (Exception ex) {
			logger.info("EXCEPTION IngestionController::getSitExceptionDetails: " + ex.getMessage());
			dataSourceResponse.setStatus(HttpStatus.NO_CONTENT.toString());
			dataSourceResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
		}
		return new ResponseEntity<Response>(dataSourceResponse, HttpStatus.OK);
	}
	
	
	// GetMethod for getSitVerfData in Ingestion
		@RequestMapping(path = "/VerifItrerationData", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<Response> getSitVerfData(@RequestParam("reqId") Integer reqId,@RequestParam("stepId") String stepId) {

			logger.info("getSitVerfData ");
			Response dataSourceResponse = new Response();

			try {
				dataSourceResponse = iService.getSitVerfData(reqId,stepId);
			} catch (Exception ex) {
				logger.info("EXCEPTION IngestionController::getSitVerfData: " + ex.getMessage());
				dataSourceResponse.setStatus(HttpStatus.NO_CONTENT.toString());
				dataSourceResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			}
			return new ResponseEntity<Response>(dataSourceResponse, HttpStatus.OK);
		}

		//to update the EDMP_ING_TEST_ITERATIONS table
		@PutMapping(path = "/updateVerifIterations", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<Response> updateVerifIterations(@RequestBody IngestionInput ingestionInput) {
			
			logger.info("inside IngestionController::updateVerifIterations ");

			UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
			Response ingestionResponse = new Response();
			if (loggedInUser != null) {
				Integer userId = Integer.valueOf(loggedInUser.getUserId());
				ingestionInput.setUserId(userId);
				try {
					ingestionResponse = iService.updateVerifIterations(ingestionInput);
				} catch (Exception ex) {
					ingestionResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
					ingestionResponse.setStatus(HttpStatus.NO_CONTENT.toString());
					logger.info("EXCEPTION IngestionController>updateVerifIterations: " + ex.getMessage());
				}
			} else {
				ingestionResponse.setStatus(HttpStatus.UNAUTHORIZED.toString());
				ingestionResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());
			}

			return new ResponseEntity<Response>(ingestionResponse, HttpStatus.OK);
		}
		

		@GetMapping(path = "/impactedconsumer", produces=MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<Response> getImpactedConsumer(@RequestParam String reqId) {
			UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
			Response getImpactedConsumer = new Response();
			if (loggedInUser != null) {
				getImpactedConsumer = iService.findByImpactedConsumer(reqId);
			} else {
				getImpactedConsumer.setStatus(HttpStatus.UNAUTHORIZED.toString());
				getImpactedConsumer.setStatusCode(HttpStatus.UNAUTHORIZED.value());
			}
			return new ResponseEntity<Response>(getImpactedConsumer, HttpStatus.OK);
		}
		
}
