package com.scb.selfservice.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
/**
 * @author shubhasi 
 * Model class for the Response of the cost API
 */
public class CostEstimationSummary {
	private Integer estimationId;
	private String personDaysCost;
	private String infraNASCost;
	private String infraHAASCost;
	private String nifiAllocationCost;
	private String iMFTMaintenanceCost;
	private String developmentSITRegression;
	private String sourceSystemCosting;
	private String totalDownstreamCosting;
	private String otherCosts;
	private String estimatedCost;

	public Integer getEstimationId() {
		return estimationId;
	}

	public void setEstimationId(Integer estimationId) {
		this.estimationId = estimationId;
	}

	public String getPersonDaysCost() {
		return personDaysCost;
	}

	public void setPersonDaysCost(String personDaysCost) {
		this.personDaysCost = personDaysCost;
	}

	public String getInfraNASCost() {
		return infraNASCost;
	}

	public void setInfraNASCost(String infraNASCost) {
		this.infraNASCost = infraNASCost;
	}

	public String getInfraHAASCost() {
		return infraHAASCost;
	}

	public void setInfraHAASCost(String infraHAASCost) {
		this.infraHAASCost = infraHAASCost;
	}

	public String getNifiAllocationCost() {
		return nifiAllocationCost;
	}

	public void setNifiAllocationCost(String nifiAllocationCost) {
		this.nifiAllocationCost = nifiAllocationCost;
	}

	public String getiMFTMaintenanceCost() {
		return iMFTMaintenanceCost;
	}

	public void setiMFTMaintenanceCost(String iMFTMaintenanceCost) {
		this.iMFTMaintenanceCost = iMFTMaintenanceCost;
	}

	public String getDevelopmentSITRegression() {
		return developmentSITRegression;
	}

	public void setDevelopmentSITRegression(String developmentSITRegression) {
		this.developmentSITRegression = developmentSITRegression;
	}

	public String getSourceSystemCosting() {
		return sourceSystemCosting;
	}

	public void setSourceSystemCosting(String sourceSystemCosting) {
		this.sourceSystemCosting = sourceSystemCosting;
	}

	public String getTotalDownstreamCosting() {
		return totalDownstreamCosting;
	}

	public void setTotalDownstreamCosting(String totalDownstreamCosting) {
		this.totalDownstreamCosting = totalDownstreamCosting;
	}

	public String getOtherCosts() {
		return otherCosts;
	}

	public void setOtherCosts(String otherCosts) {
		this.otherCosts = otherCosts;
	}

	public String getEstimatedCost() {
		return estimatedCost;
	}

	public void setEstimatedCost(String estimatedCost) {
		this.estimatedCost = estimatedCost;
	}

}
