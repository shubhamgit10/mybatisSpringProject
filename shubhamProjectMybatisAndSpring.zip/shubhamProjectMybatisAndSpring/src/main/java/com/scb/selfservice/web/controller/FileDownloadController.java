package com.scb.selfservice.web.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.domains.FileData;
import com.scb.selfservice.domains.FileUpload;
import com.scb.selfservice.service.FileDownloadService;
import com.scb.selfservice.util.CommonUtils;

@RestController
@RequestMapping("/api/download")
public class FileDownloadController {

	private static Logger logger = LogManager.getLogger(FileDownloadController.class);

	@Autowired
	FileDownloadService fileDownloadService;

	@GetMapping (path="/cart", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public  ResponseEntity<InputStreamResource> getFile(@RequestParam Integer reqId) throws IOException {
		logger.info("STARTING FileDownloadController::getFile");

		List<FileData> fileData = fileDownloadService.pullData(reqId);

		ByteArrayInputStream in = CommonUtils.prepareXlsx(fileData);
		if (null == in) {
			return ResponseEntity.noContent().build();
		}

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=" + CommonUtils.fileName(reqId));
		logger.info("EXISTING FileDownloadController::getFile");
		return ResponseEntity
				.ok()
				.headers(headers)
				.body(new InputStreamResource(in));
	}

	@GetMapping (path="/file", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public  ResponseEntity<InputStreamResource> pullFile(@RequestParam Integer uploadId) throws IOException {
		logger.info("STARTING FileDownloadController::pullFile");

		FileUpload fileUpload = fileDownloadService.pullFile(uploadId);

		if (null == fileUpload) {
			return ResponseEntity.noContent().build();
		}
		String fileName = fileUpload.getFileName();

		try (ByteArrayInputStream in = CommonUtils.prepareFileData(fileUpload.getContent())){
			if (null == in) {
				return ResponseEntity.noContent().build();
			}

			HttpHeaders headers = new HttpHeaders();
			headers.add("Content-Disposition", "attachment; filename=" + fileName);

			return ResponseEntity
					.ok()
					.headers(headers)
					.body(new InputStreamResource(in));
		}
	}
}
