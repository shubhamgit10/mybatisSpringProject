package com.scb.selfservice.model.RangerPolicy;

import java.util.List;

/**
 * 
 * @author Chenna
 *
 */
public class HBasePolicyRequestModel {
	
	private String repositoryName;
	private static final String repositoryType = "hbase";
	private String policyName;
	private String description;
	private List<RangerPolicyPermissionsList> permMapList;
	private static final boolean isAuditEnabled = true;
	private static final boolean isEnabled = true;
	private static final String columnType = "Inclusion";
	private static final String tableType = "Inclusion";
	private String columnFamilies;
	private String tables;
	private String columns;
	
	/**
	 * 
	 */
	public HBasePolicyRequestModel() {
		super();
	}

	/**
	 * @param repositoryName
	 * @param policyName
	 * @param description
	 * @param permMapList
	 * @param columnFamilies
	 * @param tables
	 * @param columns
	 */
	public HBasePolicyRequestModel(String repositoryName, String policyName, String description, 
			List<RangerPolicyPermissionsList> permMapList, String columnFamilies, String tables, String columns) {
		super();
		this.repositoryName = repositoryName;
		this.policyName = policyName;
		this.description = description;
		this.permMapList = permMapList;
		this.columnFamilies = columnFamilies;
		this.tables = tables;
		this.columns = columns;
	}

	/**
	 * @return the repositoryName
	 */
	public String getRepositoryName() {
		return repositoryName;
	}

	/**
	 * @param repositoryName the repositoryName to set
	 */
	public void setRepositoryName(String repositoryName) {
		this.repositoryName = repositoryName;
	}

	/**
	 * @return the policyName
	 */
	public String getPolicyName() {
		return policyName;
	}

	/**
	 * @param policyName the policyName to set
	 */
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the permMapList
	 */
	public List<RangerPolicyPermissionsList> getPermMapList() {
		return permMapList;
	}

	/**
	 * @param permMapList the permMapList to set
	 */
	public void setPermMapList(List<RangerPolicyPermissionsList> permMapList) {
		this.permMapList = permMapList;
	}

	/**
	 * @return the columnFamilies
	 */
	public String getColumnFamilies() {
		return columnFamilies;
	}

	/**
	 * @param databases the databases to set
	 */
	public void setColumnFamilies(String columnFamilies) {
		this.columnFamilies = columnFamilies;
	}

	/**
	 * @return the tables
	 */
	public String getTables() {
		return tables;
	}

	/**
	 * @param tables the tables to set
	 */
	public void setTables(String tables) {
		this.tables = tables;
	}

	/**
	 * @return the columns
	 */
	public String getColumns() {
		return columns;
	}

	/**
	 * @param columns the columns to set
	 */
	public void setColumns(String columns) {
		this.columns = columns;
	}

	/**
	 * @return the repositorytype
	 */
	public static String getRepositoryType() {
		return repositoryType;
	}

	/**
	 * @return the isAuditEnabled
	 */
	public static boolean isIsAuditEnabled() {
		return isAuditEnabled;
	}

	/**
	 * @return the isEnabled
	 */
	public static boolean isIsEnabled() {
		return isEnabled;
	}

	/**
	 * @return the columntype
	 */
	public static String getColumnType() {
		return columnType;
	}

	/**
	 * @return the tabletype
	 */
	public static String getTableType() {
		return tableType;
	}

	@Override
	public String toString() {
		return "HBasePolicy [repositoryName=" + repositoryName + ", policyName=" + policyName + ", description="
				+ description + ", permMapList=" + permMapList + ", columnFamilies=" + columnFamilies + ", tables="
				+ tables + ", columns=" + columns + "]";
	}

}
