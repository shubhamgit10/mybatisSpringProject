package com.scb.selfservice.domains;

public class EDMPCartConsumptionRequest {
/*
 * APP_NAME
COLUMN_NAME
INSTANCE
REQ_ID
SEGMENT
TABLE_NAME
 */
	private Integer reqID;
	private String appName;
	private String instance;
	private String tableName;
	private String columnName;
	private String segment;
	public Integer getReqID() {
		return reqID;
	}
	public void setReqID(Integer reqID) {
		this.reqID = reqID;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getInstance() {
		return instance;
	}
	public void setInstance(String instance) {
		this.instance = instance;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getSegment() {
		return segment;
	}
	public void setSegment(String segment) {
		this.segment = segment;
	}
	@Override
	public String toString() {
		return "EDMPCartConsumptionRequest [reqID=" + reqID + ", appName=" + appName + ", instance=" + instance
				+ ", tableName=" + tableName + ", columnName=" + columnName + ", segment=" + segment + "]";
	}

}
