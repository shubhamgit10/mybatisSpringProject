package com.scb.selfservice.dao.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.BizAnylstResponse;
import com.scb.selfservice.domains.IngestionDeployForms;
import com.scb.selfservice.domains.IngestionDeployIterations;
import com.scb.selfservice.domains.IngestionDmApproval;
import com.scb.selfservice.domains.IngestionExceptions;
import com.scb.selfservice.domains.IngestionRequestorResp;
import com.scb.selfservice.domains.IngestionSolArchApproval;
import com.scb.selfservice.domains.IngestionTestForms;
import com.scb.selfservice.domains.IngestionTestIterations;

public interface IngestionDynamicMapper {

	int saveSolutionArchRequest(@Param("params")Map<String, Object> params);

	int updateSolArchRequest(@Param("params")Map<String, Object> params);

	public IngestionSolArchApproval findByRequestId(@Param("reqId") Integer reqId);

	int updateIngestionRequestorResp(@Param("params")Map<String, Object> params);

	int saveIngestionRequestorResp(@Param("params")Map<String, Object> params);

	int saveDmApprovalRequest(@Param("params")Map<String, Object> params);

	int updateDmApprovalRequest(@Param("params")Map<String, Object> params);

	public IngestionDmApproval dMfindByRequestId(@Param("reqId") Integer reqId);

	public IngestionRequestorResp cAfindByRequestId(@Param("reqId") Integer reqId);

	public IngestionDeployForms sitfindByRequestId(@Param("reqId") Integer reqId, @Param("stepId") String stepId);

	int saveSitApprovalRequest(@Param("params")Map<String, Object> params);

	int updateSitApprovalRequest(@Param("params")Map<String, Object> params);

	public List<IngestionDeployIterations> iterationfindByReqId(@Param("reqId")Integer reqId, @Param("stepId") String stepId);

	int saveSitIterationRequest(@Param("params")Map<String, Object> params);

	int updateSitIterationRequest(@Param("params")Map<String, Object> params);

	int saveExceptionDetails(@Param("params")Map<String, Object> params);

	List<IngestionExceptions> exceptionsfindByReqId(@Param("reqId")Integer reqId, @Param("stepId") String stepId);
	
	int updateExceptionDetails(@Param("params")Map<String, Object> params);

	public IngestionTestForms sitVerffindByReqId(@Param("reqId")Integer reqId, @Param("stepId") String stepId);

	int saveSitVerfReq(@Param("params")Map<String, Object> params);

	int updateSitVerfReq(@Param("params")Map<String, Object> params);

	int saveSitVerfIterationReq(@Param("params")Map<String, Object> params);

	List<IngestionTestIterations> verficationfindByReqId(@Param("reqId")Integer reqId, @Param("stepId") String stepId);

	int updateSitVerifIterReq(@Param("params")Map<String, Object> params);
	
	public IngestionDeployForms sitfindByReqId(@Param("reqId") Integer reqId);
	
	public IngestionTestForms sitVfindByReqId(@Param("reqId")Integer reqId);

	public BizAnylstResponse bAfindByReqId(@Param("reqId") Integer reqId);

	int saveBaRequest(@Param("params")Map<String, Object> params);

	int updateBaRequest(@Param("params")Map<String, Object> params);

}
