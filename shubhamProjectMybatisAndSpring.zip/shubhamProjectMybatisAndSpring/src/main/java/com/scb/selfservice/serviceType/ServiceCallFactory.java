package com.scb.selfservice.serviceType;

/*
 * Class to return the appropriate bean
 */
public class ServiceCallFactory {

	public ServiceCall getService(String type){
		if(type.equalsIgnoreCase("startConsumptionWF")){
			return new StartConsumptionWF();
		} else if(type.equalsIgnoreCase("endConsumptionWF")){
			return new EndConsumptionWF();
		} else {
			return null;
		}	
	}
}