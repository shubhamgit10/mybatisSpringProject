package com.scb.selfservice.model.RangerPolicy;

import java.util.Date;

/**
 * 
 * @author 1610601
 *
 */
public class RangerPolicyRespModel {
	
	private Long id;
	private String policyName;
	private Date createDate;
	private Date updateDate;
	private String owner;
	private String updatedBy;
	private String resourceName;
	private String description;
	private String repositoryName;
	private String repositoryType;
	private String tables;
	private String columns;
	private String databases;
	private String tableType;
	private String columnType;
	private boolean isEnabled;
	private boolean isRecursive;
	private boolean isAuditEnabled;
	private String version;
	private boolean replacePerm;
	
	/**
	 * 
	 */
	public RangerPolicyRespModel() {
	}

	/**
	 * @param id
	 * @param policyName
	 * @param createDate
	 * @param updateDate
	 * @param owner
	 * @param updatedBy
	 * @param resourceName
	 * @param description
	 * @param repositoryName
	 * @param repositoryType
	 * @param tables
	 * @param columns
	 * @param databases
	 * @param tableType
	 * @param columnType
	 * @param isEnabled
	 * @param isRecursive
	 * @param isAuditEnabled
	 * @param version
	 * @param replacePerm
	 */
	public RangerPolicyRespModel(Long id, String policyName, Date createDate, Date updateDate, String owner,
			String updatedBy, String resourceName, String description, String repositoryName, String repositoryType,
			String tables, String columns, String databases, String tableType, String columnType, boolean isEnabled,
			boolean isRecursive, boolean isAuditEnabled, String version, boolean replacePerm) {
		super();
		this.id = id;
		this.policyName = policyName;
		this.createDate = createDate;
		this.updateDate = updateDate;
		this.owner = owner;
		this.updatedBy = updatedBy;
		this.resourceName = resourceName;
		this.description = description;
		this.repositoryName = repositoryName;
		this.repositoryType = repositoryType;
		this.tables = tables;
		this.columns = columns;
		this.databases = databases;
		this.tableType = tableType;
		this.columnType = columnType;
		this.isEnabled = isEnabled;
		this.isRecursive = isRecursive;
		this.isAuditEnabled = isAuditEnabled;
		this.version = version;
		this.replacePerm = replacePerm;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the policyName
	 */
	public String getPolicyName() {
		return policyName;
	}

	/**
	 * @param policyName the policyName to set
	 */
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	/**
	 * @return the createDate
	 */
	public Date getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	/**
	 * @return the updateDate
	 */
	public Date getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate the updateDate to set
	 */
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	/**
	 * @return the owner
	 */
	public String getOwner() {
		return owner;
	}

	/**
	 * @param owner the owner to set
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the resourceName
	 */
	public String getResourceName() {
		return resourceName;
	}

	/**
	 * @param resourceName the resourceName to set
	 */
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the repositoryName
	 */
	public String getRepositoryName() {
		return repositoryName;
	}

	/**
	 * @param repositoryName the repositoryName to set
	 */
	public void setRepositoryName(String repositoryName) {
		this.repositoryName = repositoryName;
	}

	/**
	 * @return the repositoryType
	 */
	public String getRepositoryType() {
		return repositoryType;
	}

	/**
	 * @param repositoryType the repositoryType to set
	 */
	public void setRepositoryType(String repositoryType) {
		this.repositoryType = repositoryType;
	}

	/**
	 * @return the tables
	 */
	public String getTables() {
		return tables;
	}

	/**
	 * @param tables the tables to set
	 */
	public void setTables(String tables) {
		this.tables = tables;
	}

	/**
	 * @return the columns
	 */
	public String getColumns() {
		return columns;
	}

	/**
	 * @param columns the columns to set
	 */
	public void setColumns(String columns) {
		this.columns = columns;
	}

	/**
	 * @return the databases
	 */
	public String getDatabases() {
		return databases;
	}

	/**
	 * @param databases the databases to set
	 */
	public void setDatabases(String databases) {
		this.databases = databases;
	}

	/**
	 * @return the tableType
	 */
	public String getTableType() {
		return tableType;
	}

	/**
	 * @param tableType the tableType to set
	 */
	public void setTableType(String tableType) {
		this.tableType = tableType;
	}

	/**
	 * @return the columnType
	 */
	public String getColumnType() {
		return columnType;
	}

	/**
	 * @param columnType the columnType to set
	 */
	public void setColumnType(String columnType) {
		this.columnType = columnType;
	}

	/**
	 * @return the isEnabled
	 */
	public boolean isEnabled() {
		return isEnabled;
	}

	/**
	 * @param isEnabled the isEnabled to set
	 */
	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}

	/**
	 * @return the isRecursive
	 */
	public boolean isRecursive() {
		return isRecursive;
	}

	/**
	 * @param isRecursive the isRecursive to set
	 */
	public void setRecursive(boolean isRecursive) {
		this.isRecursive = isRecursive;
	}

	/**
	 * @return the isAuditEnabled
	 */
	public boolean isAuditEnabled() {
		return isAuditEnabled;
	}

	/**
	 * @param isAuditEnabled the isAuditEnabled to set
	 */
	public void setAuditEnabled(boolean isAuditEnabled) {
		this.isAuditEnabled = isAuditEnabled;
	}

	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * @return the replacePerm
	 */
	public boolean isReplacePerm() {
		return replacePerm;
	}

	/**
	 * @param replacePerm the replacePerm to set
	 */
	public void setReplacePerm(boolean replacePerm) {
		this.replacePerm = replacePerm;
	}

	@Override
	public String toString() {
		return "RangerPolicyRespModel [id=" + id + ", policyName=" + policyName + ", createDate=" + createDate
				+ ", updateDate=" + updateDate + ", owner=" + owner + ", updatedBy=" + updatedBy + ", resourceName="
				+ resourceName + ", description=" + description + ", repositoryName=" + repositoryName
				+ ", repositoryType=" + repositoryType + ", tables=" + tables + ", columns=" + columns + ", databases="
				+ databases + ", tableType=" + tableType + ", columnType=" + columnType + ", isEnabled=" + isEnabled
				+ ", isRecursive=" + isRecursive + ", isAuditEnabled=" + isAuditEnabled + ", version=" + version
				+ ", replacePerm=" + replacePerm + "]";
	}

}
