package com.scb.selfservice.domains;

import java.sql.Date;
import java.sql.Timestamp;

public class IngestionDeployIterations {
	
	
private Integer reqId;
	
	private Integer releaseId;
	
	private String stepId;
	
	private Date deploymentDate;
	
	private String dataSource;
	
	private String instanceToBeCovered;
	
	//private String instance;
	
	private String environmentToDeploy;
	
	//private String environment;
	
	private String deploymentStatus;
	
	private Integer exceptions;

	public Integer getReqId() {
		return reqId;
	}

	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}

	public Integer getReleaseId() {
		return releaseId;
	}

	public void setReleaseId(Integer releaseId) {
		this.releaseId = releaseId;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public Date getDeploymentDate() {
		return deploymentDate;
	}

	public void setDeploymentDate(Date deploymentDate) {
		this.deploymentDate = deploymentDate;
	}

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	public String getInstanceToBeCovered() {
		return instanceToBeCovered;
	}

	public void setInstanceToBeCovered(String instanceToBeCovered) {
		this.instanceToBeCovered = instanceToBeCovered;
	}

	public String getEnvironmentToDeploy() {
		return environmentToDeploy;
	}

	public void setEnvironmentToDeploy(String environmentToDeploy) {
		this.environmentToDeploy = environmentToDeploy;
	}

	public String getDeploymentStatus() {
		return deploymentStatus;
	}

	public void setDeploymentStatus(String deploymentStatus) {
		this.deploymentStatus = deploymentStatus;
	}

	public Integer getExceptions() {
		return exceptions;
	}

	public void setExceptions(Integer exceptions) {
		this.exceptions = exceptions;
	}

	@Override
	public String toString() {
		return "IngestionDeployIterations [reqId=" + reqId + ", releaseId=" + releaseId + ", stepId=" + stepId
				+ ", deploymentDate=" + deploymentDate + ", dataSource=" + dataSource + ", instanceToBeCovered="
				+ instanceToBeCovered + ", environmentToDeploy=" + environmentToDeploy + ", deploymentStatus="
				+ deploymentStatus + ", exceptions=" + exceptions + "]";
	}	

}
