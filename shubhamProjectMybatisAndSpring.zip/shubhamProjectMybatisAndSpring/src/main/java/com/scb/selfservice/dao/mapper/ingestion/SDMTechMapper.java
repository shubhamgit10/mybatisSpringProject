package com.scb.selfservice.dao.mapper.ingestion;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.SDMTechCkSumGrid;
import com.scb.selfservice.domains.SDMTechGrid;
import com.scb.selfservice.domains.SDMTechResponse;
import com.scb.selfservice.domains.ViewPipeline;

/**
 * 
 * @author shubhasi Mapper class to map SDm related data with Mybatis
 */
public interface SDMTechMapper {

	public List<String> getSDMTableNameFromDb(@Param("reqId") Integer reqId);

	public SDMTechResponse getHdfsById(@Param("reqId") Integer reqId);

	public int saveSDMHdfs(@Param("params") Map<String, Object> params);

	public int updateSDMHdfs(@Param("params") Map<String, Object> params);

	public List<SDMTechResponse> getSDMConfig(@Param("reqId") Integer reqId);

	public List<String> readConfigCategory();

	public int saveSdmConfig(@Param("sdmResList") List<SDMTechResponse> sdmResList);

	public int insertIntoAuditTable(@Param("reqId") Integer reqId);

	public int deleteExistingrRecord(@Param("reqId") Integer reqId);

	// method to pull existing ViewPipelineController
	public List<ViewPipeline> findByRequestParam();
	
	public int updateIntoSourceTable(@Param("reqId")Integer reqId, @Param("reconLogicList") List<SDMTechGrid> reconLogicList);

	public int updateIntoCkSum(@Param("reqId")Integer reqId, @Param("chkSumLogicList") List<SDMTechCkSumGrid> chkSumLogicList);

	public List<SDMTechGrid> readReconGridValues(@Param("reqId")Integer reqId);

	public List<SDMTechCkSumGrid> readCkSumGridValues(@Param("reqId")Integer reqId);

}
