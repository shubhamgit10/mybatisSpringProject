package com.scb.selfservice.isd.entity;

import java.util.List;

/**
 * @author akuma400
 *
 */
public class ExceptionCategoryProtocol {

	private List<String> issueCategory;
	private List<String> columnId;
	private List<String> sheetName;
	private List<String> columnsImpacted;
	private List<String> tablesImpacted;
	private List<String> description;
	
	public List<String> getIssueCategory() {
		return issueCategory;
	}
	public void setIssueCategory(List<String> issueCategory) {
		this.issueCategory = issueCategory;
	}
	public List<String> getColumnId() {
		return columnId;
	}
	public void setColumnId(List<String> columnId) {
		this.columnId = columnId;
	}
	public List<String> getSheetName() {
		return sheetName;
	}
	public void setSheetName(List<String> sheetName) {
		this.sheetName = sheetName;
	}
	public List<String> getColumnsImpacted() {
		return columnsImpacted;
	}
	public void setColumnsImpacted(List<String> columnsImpacted) {
		this.columnsImpacted = columnsImpacted;
	}
	public List<String> getTablesImpacted() {
		return tablesImpacted;
	}
	public void setTablesImpacted(List<String> tablesImpacted) {
		this.tablesImpacted = tablesImpacted;
	}
	public List<String> getDescription() {
		return description;
	}
	public void setDescription(List<String> description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "ExceptionCategoryProtocol [issueCategory=" + issueCategory + ", columnId=" + columnId + ", sheetName="
				+ sheetName + ", columnsImpacted=" + columnsImpacted + ", tablesImpacted=" + tablesImpacted
				+ ", description=" + description + "]";
	}
	
	
}
