/**
 * 
 */
package com.scb.selfservice.web.authentication;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 * Application Security Holder class to create Spring Security Context Holder
 * and create Authentication Object
 * 
 * @author Amarnath
 *
 */
public class AppSecurityContextHolder {

	/**
	 * Method to create SecurityContext and create UserDetails Authentication Object
	 * @param userId
	 */
	public static void createSecurityContextHolder(String userId, String role, String lineManager) {
		SecurityContext context = SecurityContextHolder.getContext();
		List<UserGroup> authorities = new ArrayList<UserGroup>();
		String[] roles = StringUtils.split(role, ";");		
		for (int i=0; i < roles.length; i++) 
			authorities.add(new UserGroup(roles[i]));			
		UserPrincipal authObject = new UserPrincipal(userId,authorities,lineManager);		
		context.setAuthentication(authObject);		
	}
	
	/**
	 * Method to get LoggedIn User from the Security Context
	 * @return
	 */
	public static UserPrincipal getLoggedInUser() {
		SecurityContext context = SecurityContextHolder.getContext();
		if (context != null && context.getAuthentication() != null) 
			return (UserPrincipal)context.getAuthentication();		
		return null;
		
	}
	
	/**
	 * Method to clear the SecurityContext once the thread processing is completed
	 * 
	 */
	public static void clearSecurityContext() {
		SecurityContextHolder.clearContext();
	}

}
