package com.scb.selfservice.web.controller;

import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.domains.PSHRActive;
import com.scb.selfservice.service.PSHRActiveService;
import com.scb.selfservice.util.Response;

@RestController
@RequestMapping("/api/pshractive")
public class PSHRActiveController {

	private static Logger logger = LogManager.getLogger(PSHRActiveController.class);
	
	@Autowired
	private PSHRActiveService psHRActiveService; 
	
	
	@RequestMapping(path = "/validate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> validate(@RequestBody HashMap<String, List<PSHRActive>> requestBody) {
		logger.info("------------Inside PSID Vallidation------------");
		Response validateresponse = psHRActiveService.validate(requestBody);
		logger.info("------------PSID Vallidation Completed------------");
		return new ResponseEntity<Response>(validateresponse,HttpStatus.OK);
	}
	
	
	/**
	 *Auto Suggestion PSHRACTIVE
	 */
	@RequestMapping(path = "/validated", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> validated(@RequestParam String staffName) {
		logger.info("------------Inside PSID Vallidation------------");
		Response validate = psHRActiveService.validated(staffName);
		logger.info("------------PSID Vallidation Completed------------");
		return new ResponseEntity<Response>(validate,HttpStatus.OK);
	}
	
}
