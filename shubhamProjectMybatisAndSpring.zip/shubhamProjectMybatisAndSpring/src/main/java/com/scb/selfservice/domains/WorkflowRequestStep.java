package com.scb.selfservice.domains;

import java.sql.Timestamp;

//import java.sql.Timestamp;

/*
 * pojo to map
 * WORKFLOW_REQUEST_STEPS
 */
public class WorkflowRequestStep {

	private Integer reqId;  //req_id
	private String stepId; //STEP_ID
	private String  status; //STATUS
	private String  remarks; //REMARKS
	private Timestamp startTime; //START_TIME
	private Timestamp completedTime; //COMPLETED_TIME
	private String    stepPendingGrp; //STEP_PENDING_GRP
	private Integer   stepPendingUser; //STEP_PENDING_USER
	private Integer   stepActionedBy;  //STEP_ACTIONED_BY
	private String    stepAction;      //STEP_ACTION
	public WorkflowRequestStep(Integer reqId, String stepId, String status, String remarks, String stepPendingGrp,
			Integer stepPendingUser, Integer stepActionedBy, String stepAction) {
		super();
		this.reqId = reqId;
		this.stepId = stepId;
		this.status = status;
		this.remarks = remarks;
		this.stepPendingGrp = stepPendingGrp;
		this.stepPendingUser = stepPendingUser;
		this.stepActionedBy = stepActionedBy;
		this.stepAction = stepAction;
	}
	public WorkflowRequestStep(Integer reqId, String stepId, String status, String remarks, Timestamp startTime, 
			Timestamp completedTime, String stepPendingGrp, Integer stepPendingUser, Integer stepActionedBy, String stepAction) {
		super();
		this.reqId = reqId;
		this.stepId = stepId;
		this.status = status;
		this.remarks = remarks;
		this.startTime = startTime;
		this.completedTime = completedTime;
		this.stepPendingGrp = stepPendingGrp;
		this.stepPendingUser = stepPendingUser;
		this.stepActionedBy = stepActionedBy;
		this.stepAction = stepAction;
	}
	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Timestamp getStartTime() {
		return startTime;
	}
	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}
	public Timestamp getCompletedTime() {
		return completedTime;
	}
	public void setCompletedTime(Timestamp completedTime) {
		this.completedTime = completedTime;
	}
	public String getStepPendingGrp() {
		return stepPendingGrp;
	}
	public void setStepPendingGrp(String stepPendingGrp) {
		this.stepPendingGrp = stepPendingGrp;
	}
	public Integer getStepPendingUser() {
		return stepPendingUser;
	}
	public void setStepPendingUser(Integer stepPendingUser) {
		this.stepPendingUser = stepPendingUser;
	}
	public Integer getStepActionedBy() {
		return stepActionedBy;
	}
	public void setStepActionedBy(Integer stepActionedBy) {
		this.stepActionedBy = stepActionedBy;
	}
	public String getStepAction() {
		return stepAction;
	}
	public void setStepAction(String stepAction) {
		this.stepAction = stepAction;
	}
	@Override
	public String toString() {
		return "WorkflowRequestStep [reqId=" + reqId + ", stepId=" + stepId + ", status=" + status + ", remarks="
				+ remarks + ", stepPendingGrp=" + stepPendingGrp + ", stepPendingUser=" + stepPendingUser
				+ ", stepActionedBy=" + stepActionedBy + ", stepAction=" + stepAction + "]";
	}

}
