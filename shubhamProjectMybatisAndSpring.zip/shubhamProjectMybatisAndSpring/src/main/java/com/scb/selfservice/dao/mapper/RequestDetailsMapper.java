/**
 * 
 */
package com.scb.selfservice.dao.mapper;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;

/**
 * Mapper Interface for querying consumption related data
 * 
 * @author Amarnath BB
 *
 */
public interface RequestDetailsMapper {
	
	/**
	 * Method to get the list of dataset subscribed as part of this request
	 * @param reqId
	 * @return
	 */
	public List<HashMap<String,String>> getDatasetSubscribed(String reqId);
	
	/**
	 * Method to get the request details
	 * @param reqId
	 * @return
	 */
	public HashMap<String,String> getRequestDetails(String reqId);
	
	/**
	 * Method to get the STEP ID based on workflow Id and Step Name
	 * @param workflowId
	 * @param stepName
	 * @return
	 */
	public String getStepId(@Param("workflowId")String workflowId, @Param("stepName")String stepName);
	
	public void updateJiraKey(@Param("jiraKey")String jiraKey, @Param("reqId")String reqId);
	
	public HashMap<String,String> getParentUserTypeStep(@Param("reqId")String reqId, @Param("stepId")String stepId);
	
	public List<HashMap<String,String>> getStepUserResponse(@Param("reqId")String reqId, @Param("stepId")String stepId);
	
	public List<String> getReqActedUsers(@Param("reqId")String reqId);

	//Added as per Amar's mail
	public List<HashMap<String, String>> getNextServiceTask(@Param("reqId") String reqId, @Param("stepId") String stepId);
 

	

}
