package com.scb.selfservice.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.scb.selfservice.config.PropertyFileCongifuration;

public class TestPropertyFile {

		  public static void main( String[] args ){
		    //EntityManager
		    AbstractApplicationContext context = new AnnotationConfigApplicationContext(PropertyFileCongifuration.class);
		    DriverManagerDataSource dataSource =  context.getBean("dataSource", DriverManagerDataSource.class);
		    System.out.println("user name - " + dataSource.getUsername());
		    System.out.println("DB password is - " + dataSource.getPassword());
		    context.close();
		  }
		}

