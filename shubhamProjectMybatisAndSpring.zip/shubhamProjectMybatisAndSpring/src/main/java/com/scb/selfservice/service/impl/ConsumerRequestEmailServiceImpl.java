package com.scb.selfservice.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.email.EmailMapper;
import com.scb.selfservice.dao.mapper.ingestion.CostEstimationSummaryMapper;
import com.scb.selfservice.model.AdminData;
import com.scb.selfservice.model.CostEstimation;
import com.scb.selfservice.model.CostEstimationSummary;
import com.scb.selfservice.model.EmailAddressDetails;
import com.scb.selfservice.model.EmailContent;
import com.scb.selfservice.service.ConsumerRequestEmailService;
import com.scb.selfservice.service.MailService;
import com.scb.selfservice.util.Response;

@Service(value="consumerRequestEmailService")
@EnableAsync
public class ConsumerRequestEmailServiceImpl implements ConsumerRequestEmailService {

    private static Logger logger = LogManager.getLogger(ConsumerRequestEmailServiceImpl.class);

    private String consumptionActionLink;

    @Autowired
    private EmailMapper emailMapper;

    @Autowired
    private MailService smtpMailService;
    
	@Autowired
	CostEstimationSummaryMapper estimateMapper;


    public String getConsumptionActionLink() {
        return consumptionActionLink;
    }

    public void setConsumptionActionLink(String consumptionActionLink) {
        this.consumptionActionLink = consumptionActionLink;
    }

    private Map<String,Object> emailContentToMap(EmailContent emailContent){
        Map<String,Object> mailContentMap = new HashMap<String,Object>();

        mailContentMap.put("reqId", emailContent.getReqId());
        mailContentMap.put("consumptionApplicationName", emailContent.getConsumptionApplicationName());
        mailContentMap.put("purposeOfConsumption", emailContent.getPurposeOfConsumption());
        mailContentMap.put("existingReqId", emailContent.getExistingReqId());
        mailContentMap.put("targetDate", emailContent.getTargetDate());
        mailContentMap.put("reqSources", emailContent.getReqSources());
        mailContentMap.put("reqCreatedBy", emailContent.getReqCreatedBy());
        mailContentMap.put("reqCreatedOn", emailContent.getReqCreatedOn());
        mailContentMap.put("lastActionBy", emailContent.getLastActionBy());
        mailContentMap.put("lastActionOn", emailContent.getLastActionOn());
        mailContentMap.put("reqPendingWith", emailContent.getReqPendingWith());
        mailContentMap.put("reqRemarks", emailContent.getReqRemarks());
        mailContentMap.put("reqStatus", emailContent.getReqStatus());
        mailContentMap.put("consumptionRequest", emailContent.getConsumptionRequest());
        mailContentMap.put("proposedSolution", emailContent.getProposedSolution());
        mailContentMap.put("requestClassification", emailContent.getRequestClassification());
        mailContentMap.put("consumptionActionLink",consumptionActionLink);
        return mailContentMap;
    }

    /**
	 * Method to send Mail based on the Workflow Request & StepId. Starts as the
	 * new Transaction to ensure that the workflow request is commited
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	@Async
    public void sendStatusMail(int reqId, String stepId, String stepAction){
		logger.debug("Preparing to sending Mail for Request " + reqId);
		
		try {
			Thread.sleep(30000); // sleep for 30 sec so that outer transaction
									// is committed and workflow data is
									// available to trigger mail notification
		} catch (Exception ex) {}


        String toMailList=null;
        String ccMailList=null;
        String mailSubject=null;
        String mailTemplate="consumption-request-status-template.ftl";
        Map<String,Object> mailContentMap = null;

        if (stepAction.equalsIgnoreCase("APPROVE")){
        	EmailAddressDetails toAddress = emailMapper.getApproveMailToList(reqId,stepId);
        	if (toAddress != null)
        		toMailList = String.join(",",toAddress.geteMailAddress());
        	EmailAddressDetails ccAddress = emailMapper.getApproveMailCcList(reqId,stepId);
        	if (ccAddress != null)
        		ccMailList = String.join(",",ccAddress.geteMailAddress());
        	//admin email id
        	if (toMailList == null) {
                toMailList = ccMailList;
                ccMailList = "";
            }

            EmailContent content = emailMapper.getApproveMailContent(reqId,stepId);
            mailContentMap = emailContentToMap(content);
            if (stepId.equals("S1")){
                mailSubject = "EDMp Data Consumption Request - " + reqId + " - Submitted by "+ content.getLastActionedGroup() ;
            }else {
                if (content.getLastActionedGroup().equalsIgnoreCase("OFFLINE_APPROVAL")) {
                    mailSubject = "EDMp Data Consumption Request - " + reqId + " - Offline Approval Submitted by Requestor";
                } else {
                    mailSubject = "EDMp Data Consumption Request - " + reqId + " - Approved by " + content.getLastActionedGroup() + " Team";
                }
            }
        }
        if (stepAction.equalsIgnoreCase("REJECT")){
            toMailList = String.join(",",emailMapper.getRejectMailToList(reqId,stepId).geteMailAddress());
            ccMailList = String.join(",",emailMapper.getRejectMailCcList(reqId,stepId).geteMailAddress());
            EmailContent emailContent = emailMapper.getApproveMailContent(reqId,stepId);
            mailContentMap = emailContentToMap(emailMapper.getRejectMailContent(reqId,stepId));
            mailSubject= "EDMp Data Consumption request (id=" + reqId + ") - Rejected";
        }
        if (stepAction.equalsIgnoreCase("PENDING") || stepAction.equalsIgnoreCase("CANCELLED")){
            toMailList = String.join(",",emailMapper.getRejectMailToList(reqId,stepId).geteMailAddress());
            ccMailList = String.join(",",emailMapper.getRejectMailCcList(reqId,stepId).geteMailAddress());
            ccMailList += "," + addAdminEmail();
            
            mailContentMap = emailContentToMap(emailMapper.getApproveMailContent(reqId,stepId));
            mailContentMap.forEach((k, v) -> logger.info(k + "----" + v));
            mailTemplate = "consumption-request-status-pending-template.ftl";
            if (stepAction.equalsIgnoreCase("CANCELLED"))
            	mailSubject = "EDMp Consumption Request " + reqId + " has been CANCELLED";
            else
            	mailSubject = "EDMp Consumption Request " + reqId + " Pending your action";
        }
        logger.debug(toMailList);
        logger.debug(ccMailList);
        
        smtpMailService.sendMail(null,toMailList,ccMailList,mailSubject,mailTemplate,mailContentMap);

    }
	
	private String addAdminEmail() {
		List<AdminData> admData = emailMapper.getAdminMailCcList();
        AdminData obj = new AdminData();
        List<String> emails = obj.getAdminEmailIds(admData);
        logger.info("Admin emails: " + emails);
        return String.join(",", emails); //""
	}

	/**
	 * Thread pool Executor for the Async Threads
	 * 
	 * @return
	 */
	@Bean
	public Executor taskExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(2);
		executor.setMaxPoolSize(2);
		executor.setQueueCapacity(500);
		executor.setThreadNamePrefix("ServiceTask - ");
		executor.initialize();
		return executor;
	}

	@Override
	public Response sendCostEstimationMail(Integer userId, Integer requestId, Integer estimationId) {
		String mailSubject = null;
		String toMailList = null;
		Response response = new Response();
		String mailTemplate="ingestion-costestimation-template.ftl";
        
		EmailAddressDetails toAddress = emailMapper.getCostEstimationMailToList(userId);
		if (toAddress != null)
    		toMailList = String.join(",",toAddress.geteMailAddress());
		mailSubject = "Cost Estimation Summary for " + requestId; 
		
		//CostEstimation costEstimation =  estimateMapper.readEstimatedCost(estimationId);
		CostEstimationSummary costEstimationSummary =  estimateMapper.getEstimatedCostFromDbById(estimationId);
		
		Map<String,Object> mailContentMap = CostEstMailContentToMap(costEstimationSummary, requestId);
		
		smtpMailService.sendMail("edmpuser@test.com",toMailList,null,mailSubject,mailTemplate,mailContentMap);
		
		//response.setResponse();
		response.setStatusCode(HttpStatus.OK.value());
		response.setStatus(HttpStatus.OK.toString());
		return response;
	}
	
	private Map<String,Object> CostEstMailContentToMap(CostEstimationSummary costEstimation, Integer requestId) {
        Map<String,Object> mailContentMap = new HashMap<String,Object>();

        mailContentMap.put("reqId", requestId);
        mailContentMap.put("estimationId", costEstimation.getEstimationId());
        mailContentMap.put("personDaysCost", costEstimation.getPersonDaysCost());
        mailContentMap.put("infraNASCost", costEstimation.getInfraNASCost());
        mailContentMap.put("infraHAASCost", costEstimation.getInfraHAASCost());
        mailContentMap.put("nifiAllocationCost", costEstimation.getNifiAllocationCost());
        mailContentMap.put("iMFTMaintenanceCost", costEstimation.getiMFTMaintenanceCost());
        mailContentMap.put("developmentSITRegression", costEstimation.getDevelopmentSITRegression());
        mailContentMap.put("sourceSystemCosting", costEstimation.getSourceSystemCosting());
        mailContentMap.put("totalDownstreamCosting", costEstimation.getTotalDownstreamCosting());
        mailContentMap.put("otherCosts", costEstimation.getOtherCosts());
        mailContentMap.put("estimatedCost", costEstimation.getEstimatedCost());
        return mailContentMap;
	}
	
	/* (non-Javadoc)
     * @see com.scb.selfservice.service.ConsumerRequestEmailService#sendRejectMail(int, java.lang.String, java.lang.String)
     * 
      * For Reject scenario, the call has to be made in a sync way.
     */
     @Override
     public void sendRejectMail(int reqId, String stepId, String stepAction) {
           this.sendStatusMail(reqId, stepId, stepAction);       
     }


}
