package com.scb.selfservice.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.model.ConsumptionRequestModel;

/**
 * 
 * @author Chenna
 *
 */
public interface RangerPolicyMapper {
	
	public List<ConsumptionRequestModel> getRangerPoliciesByRequestId(@Param("request_id") Long requestId);
	
	public void addRangerPolicyDetails(@Param("req_id") Long requestId, @Param("app_name") String appName, 
			@Param("country") String instance, @Param("group_name") String groupName, 
			@Param("policy_name") String policyName, @Param("policy_id") Long policyId, 
			@Param("policy_create_type") String policyCreateType, @Param("policy_type") String policyType, 
			@Param("status") String status, @Param("error_msg") String errorMsg, @Param("repo_type") String repoType, 
			@Param("create_time") String createdTime, @Param("update_time") String updatedTime);
	
	public String getParentStepId(@Param("req_id") Long requestId, @Param("step_id") String stepId);

}
