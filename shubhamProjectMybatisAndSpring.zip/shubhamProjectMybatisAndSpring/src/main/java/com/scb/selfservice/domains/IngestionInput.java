package com.scb.selfservice.domains;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class IngestionInput {
	
	private String StepId;
	
	private String workflowType;
	
	private Integer reqId;

	private Map<String, Object> params;
	
	@JsonIgnore
	private Integer userId;
	
	private String userAction;
	
	private String remarks;
	
	
	public String getStepId() {
		return StepId;
	}

	public void setStepId(String stepId) {
		StepId = stepId;
	}

	public String getWorkflowType() {
		return workflowType;
	}

	public void setWorkflowType(String workflowType) {
		this.workflowType = workflowType;
	}

		
	public Integer getReqId() {
		return reqId;
	}

	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	
	public Map<String, Object> getParams() {
		return params;
	}

	public void setParams(Map<String, Object> params) {
		this.params = params;
	}

	public String getUserAction() {
		return userAction;
	}

	public void setUserAction(String userAction) {
		this.userAction = userAction;
	}
	

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	
	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "IngestionInput [StepId=" + StepId + ", workflowType=" + workflowType + ", reqId=" + reqId + ", params="
				+ params + ", userId=" + userId + ", userAction=" + userAction + ", remarks=" + remarks + "]";
	}
	
	
}
