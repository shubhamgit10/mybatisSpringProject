package com.scb.selfservice.model;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Arrays;

/**
 * @author shubhasi
 * 
 *         Modal class to store the calculated cost estimation details in the
 *         database
 */

public class CostEstimation {
	private int estimationId;
	private int reqId;
	private String stepId;
	private int createdBy;
	private String status;
	private Timestamp creationDate;
	private Timestamp lastUpdatedDate;
	private byte[] costEstimationCopy;
	private String updatedBy;
	private String sourceType;
	private String personDaysCost;
	private String infraNASCost;
	private String infraHAASCost;
	private String nifiAllocationCost;
	private String iMFTMaintenanceCost;
	private String developmentSITRegression;
	private String sourceSystemCosting;
	private String totalDownstreamCosting;
	private String otherCosts;
	private String estimatedCost;


	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public int getEstimationId() {
		return estimationId;
	}

	public void setEstimationId(int estimationId) {
		this.estimationId = estimationId;
	}

	public int getReqId() {
		return reqId;
	}

	public void setReqId(int reqId) {
		this.reqId = reqId;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public byte[] getCostEstimationCopy() {
		return costEstimationCopy;
	}

	public void setCostEstimationCopy(byte[] costEstimationCopy) {
		this.costEstimationCopy = costEstimationCopy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public String getPersonDaysCost() {
		return personDaysCost;
	}

	public void setPersonDaysCost(String personDaysCost) {
		this.personDaysCost = personDaysCost;
	}

	public String getInfraNASCost() {
		return infraNASCost;
	}

	public void setInfraNASCost(String infraNASCost) {
		this.infraNASCost = infraNASCost;
	}

	public String getInfraHAASCost() {
		return infraHAASCost;
	}

	public void setInfraHAASCost(String infraHAASCost) {
		this.infraHAASCost = infraHAASCost;
	}

	public String getNifiAllocationCost() {
		return nifiAllocationCost;
	}

	public void setNifiAllocationCost(String nifiAllocationCost) {
		this.nifiAllocationCost = nifiAllocationCost;
	}

	public String getiMFTMaintenanceCost() {
		return iMFTMaintenanceCost;
	}

	public void setiMFTMaintenanceCost(String iMFTMaintenanceCost) {
		this.iMFTMaintenanceCost = iMFTMaintenanceCost;
	}

	public String getDevelopmentSITRegression() {
		return developmentSITRegression;
	}

	public void setDevelopmentSITRegression(String developmentSITRegression) {
		this.developmentSITRegression = developmentSITRegression;
	}

	public String getSourceSystemCosting() {
		return sourceSystemCosting;
	}

	public void setSourceSystemCosting(String sourceSystemCosting) {
		this.sourceSystemCosting = sourceSystemCosting;
	}

	public String getTotalDownstreamCosting() {
		return totalDownstreamCosting;
	}

	public void setTotalDownstreamCosting(String totalDownstreamCosting) {
		this.totalDownstreamCosting = totalDownstreamCosting;
	}

	public String getOtherCosts() {
		return otherCosts;
	}

	public void setOtherCosts(String otherCosts) {
		this.otherCosts = otherCosts;
	}

	public String getEstimatedCost() {
		return estimatedCost;
	}

	public void setEstimatedCost(String estimatedCost) {
		this.estimatedCost = estimatedCost;
	}

	@Override
	public String toString() {
		return "CostEstimation [estimationId=" + estimationId + ", reqId=" + reqId  + ", createdBy=" + createdBy + ", status=" + status
				+ ", creationDate=" + creationDate + ", lastUpdatedDate=" + lastUpdatedDate + ", costEstimationCopy="
				+ Arrays.toString(costEstimationCopy) + ", updatedBy=" + updatedBy + ", sourceType=" + sourceType
				+ ", personDaysCost=" + personDaysCost + ", infraNASCost=" + infraNASCost + ", infraHAASCost="
				+ infraHAASCost + ", nifiAllocationCost=" + nifiAllocationCost + ", iMFTMaintenanceCost="
				+ iMFTMaintenanceCost + ", developmentSITRegression=" + developmentSITRegression
				+ ", sourceSystemCosting=" + sourceSystemCosting + ", totalDownstreamCosting=" + totalDownstreamCosting
				+ ", otherCosts=" + otherCosts + ", estimatedCost=" + estimatedCost + "]";
	}

}
