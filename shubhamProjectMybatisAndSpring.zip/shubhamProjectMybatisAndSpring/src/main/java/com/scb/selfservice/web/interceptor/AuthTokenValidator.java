/**
 * 
 */
package com.scb.selfservice.web.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.lang.Nullable;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.scb.selfservice.util.JWTUtil;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;

/**
 * Auth Token Validator to intercept all the API request and if AUTH Token is available in header then
 * it validate the token and retrieves the User Id and add to Security Context
 * 
 * @author Amarnath BB
 *
 */
public class AuthTokenValidator extends HandlerInterceptorAdapter {
	
	@Autowired
	JWTUtil jutil;
	
	/**
	 * PreHandle Method to check for the Auth Header and validate the Token
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		
		String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
		if (authHeader == null)
			authHeader = request.getParameter(HttpHeaders.AUTHORIZATION);
		if (StringUtils.isNotEmpty(authHeader)) {
			String token = StringUtils.replace(authHeader, "Basic ", "").trim();
			if (token == null || "null".equalsIgnoreCase(token))
				return true;
			String[] data = jutil.verifyJWT(token);
			if (data != null)
				AppSecurityContextHolder.createSecurityContextHolder(data[0], data[1], data[2]);
			// null userId could indicate either token is invalid or has expired
		}

		return true;
	}
	
	/**
	 * Post Handle to clear the context
	 */
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			@Nullable ModelAndView modelAndView) throws Exception {
		AppSecurityContextHolder.clearSecurityContext();
	}

}
