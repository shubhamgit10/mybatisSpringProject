/**
 * 
 */
package com.scb.selfservice.config;

import java.io.IOException;
import java.util.Properties;

import org.springframework.beans.factory.config.PropertyOverrideConfigurer;

/**
 * Property Override Configurer
 * 
 * @author Amarnath
 *
 */
public class AppPropertyOverrideConfigurer extends PropertyOverrideConfigurer {

	/**
	 * 
	 */

	public AppPropertyOverrideConfigurer() {
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.core.io.support.PropertiesLoaderSupport#
	 * mergeProperties()
	 */
	@Override
	protected Properties mergeProperties() throws IOException {
		return PropertyConfigurer.getOverrideProperties();
	}

}
