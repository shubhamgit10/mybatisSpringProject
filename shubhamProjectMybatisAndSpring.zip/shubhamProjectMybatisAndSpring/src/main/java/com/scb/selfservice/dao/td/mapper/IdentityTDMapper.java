/**
 * 
 */
package com.scb.selfservice.dao.td.mapper;

import com.scb.selfservice.model.UserDetails;

/**
 * @author Amarnath BB
 *
 */
public interface IdentityTDMapper {
	
	/**
	 * Method to get PSHR details
	 * @param userId
	 * @return
	 */
	public UserDetails getPSHRUserDetails(String userId);

}
