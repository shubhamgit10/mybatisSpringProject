package com.scb.selfservice.web.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.domains.EDMPTabsCount;
import com.scb.selfservice.service.CatalogueDataLoadService;
import com.scb.selfservice.util.Response;

@RestController
@RequestMapping("/api/catalogueData")
public class CatalogueDataLoadController {
	
	private static Logger logger = LogManager.getLogger(CatalogueDataLoadController.class);

	@Autowired
	private CatalogueDataLoadService consumptionService; 

	@RequestMapping(path = "/getDataSources", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getDataSources() {
		Response dataSourceResponse = consumptionService.getDataSources();
		return new ResponseEntity<Response>(dataSourceResponse,HttpStatus.OK);
	}
	
	// GetMethod for Ingestion
	@RequestMapping(path = "/getIngestionCountry", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getIngestionCountry() {
		
		Response dataSourceResponse = new Response();
		
		try {
		 dataSourceResponse = consumptionService.getIngestionDataSources();
		} catch(Exception ex) {
			logger.info("EXCEPTION MyRequestController::getApprovalWorkflow: " + ex.getMessage());
			dataSourceResponse.setStatus(HttpStatus.NO_CONTENT.toString());
			dataSourceResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
		}
		return new ResponseEntity<Response>(dataSourceResponse,HttpStatus.OK);
	}
	
	@RequestMapping(path = "/getIngestionDataSources", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getIngestionDataSources() {
		
		Response dataSourceResponse = new Response();
		
		try {
		 dataSourceResponse = consumptionService.getIngestionDS();
		} catch(Exception ex) {
			logger.info("EXCEPTION MyRequestController::getApprovalWorkflow: " + ex.getMessage());
			dataSourceResponse.setStatus(HttpStatus.NO_CONTENT.toString());
			dataSourceResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
		}
		return new ResponseEntity<Response>(dataSourceResponse,HttpStatus.OK);
	}
	
	

	@RequestMapping(path = "/getDataSetCount", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getDataSetCount(@RequestBody List<EDMPTabsCount> edmpTabsCount) {
		Response dataSetCountresponse = consumptionService.getDataSetCount(edmpTabsCount);
		return new ResponseEntity<Response>(dataSetCountresponse,HttpStatus.OK);
	}


	@RequestMapping(path = "/getDataSetName", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getDataSetName(@RequestParam("itamId") String itamId,@RequestParam("country") List<String> country) {
		Response datasetResponse = consumptionService.getDataSetName(itamId,country);
		return new ResponseEntity<Response>(datasetResponse,HttpStatus.OK);
	}

	@RequestMapping(path = "/getAttributeName", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getAttributeName(@RequestParam("itamId") String itamId, @RequestParam("tableName") String tableName) {
		Response atrributeNameResponse = consumptionService.getAttributeName(itamId,tableName);
		return new ResponseEntity<Response>(atrributeNameResponse,HttpStatus.OK);
	}

}
