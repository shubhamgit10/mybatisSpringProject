package com.scb.selfservice.domains;

import java.sql.Date;

public class MyApprovalIngestion {
	
	
	private Integer reqId;
	private String  stepId;
	private String  reqSummary;
	private String  reqCreatedAt;
	private String  stepActionedBy;
	private String  createdBy;
	private String pendingWith;
	private String status;
	private String interimStatus;
	private String requestType;
	private String statusApproved;
	
	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getReqSummary() {
		return reqSummary;
	}
	public void setReqSummary(String reqSummary) {
		this.reqSummary = reqSummary;
	}
	public String getReqCreatedAt() {
		return reqCreatedAt;
	}
	public void setReqCreatedAt(String reqCreatedAt) {
		this.reqCreatedAt = reqCreatedAt;
	}
	public String getStepActionedBy() {
		return stepActionedBy;
	}
	public void setStepActionedBy(String stepActionedBy) {
		this.stepActionedBy = stepActionedBy;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getPendingWith() {
		return pendingWith;
	}
	public void setPendingWith(String pendingWith) {
		this.pendingWith = pendingWith;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getInterimStatus() {
		return interimStatus;
	}
	public void setInterimStatus(String interimStatus) {
		this.interimStatus = interimStatus;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getStatusApproved() {
		return statusApproved;
	}
	public void setStatusApproved(String statusApproved) {
		this.statusApproved = statusApproved;
	}
	@Override
	public String toString() {
		return "MyApprovalIngestion [reqId=" + reqId + ", stepId=" + stepId + ", reqSummary=" + reqSummary
				+ ", reqCreatedAt=" + reqCreatedAt + ", stepActionedBy=" + stepActionedBy + ", createdBy=" + createdBy
				+ ", pendingWith=" + pendingWith + ", status=" + status + ", interimStatus=" + interimStatus
				+ ", requestType=" + requestType + ", statusApproved=" + statusApproved + "]";
	}

}
