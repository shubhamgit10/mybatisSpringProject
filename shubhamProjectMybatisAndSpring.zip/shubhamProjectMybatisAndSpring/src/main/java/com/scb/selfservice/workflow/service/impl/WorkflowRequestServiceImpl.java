package com.scb.selfservice.workflow.service.impl;

import static com.scb.selfservice.util.WorkflowConstants.APPROVE;
import static com.scb.selfservice.util.WorkflowConstants.AUTOAPPROVED;
import static com.scb.selfservice.util.WorkflowConstants.CAUSER;
import static com.scb.selfservice.util.WorkflowConstants.COMPLETED;
import static com.scb.selfservice.util.WorkflowConstants.DMUSER;
import static com.scb.selfservice.util.WorkflowConstants.FAILURE;
import static com.scb.selfservice.util.WorkflowConstants.LMUSER;
import static com.scb.selfservice.util.WorkflowConstants.NOT_STARTED;
import static com.scb.selfservice.util.WorkflowConstants.PENDING;
import static com.scb.selfservice.util.WorkflowConstants.REJECTED;
import static com.scb.selfservice.util.WorkflowConstants.SDUSER;
import static com.scb.selfservice.util.WorkflowConstants.SKIPPED;
import static com.scb.selfservice.util.WorkflowConstants.SUBMITTED;
import static com.scb.selfservice.util.WorkflowConstants.SUCCESS;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.DataConsumptionRequestMapper;
import com.scb.selfservice.dao.mapper.RequestDetailsMapper;
import com.scb.selfservice.dao.mapper.WorkflowMapper;
import com.scb.selfservice.domains.AuditWorkflowRequestSteps;
import com.scb.selfservice.domains.ConsumptionRequest;
import com.scb.selfservice.domains.DMPsid;
import com.scb.selfservice.domains.EdmpConsumpReqUserResp;
import com.scb.selfservice.domains.MyApprovalList;
import com.scb.selfservice.domains.RequestProcessStep;
import com.scb.selfservice.domains.Upject;
import com.scb.selfservice.domains.WorkflowIdType;
import com.scb.selfservice.domains.WorkflowProcessSteps;
import com.scb.selfservice.domains.WorkflowReqStepsAt;
import com.scb.selfservice.domains.WorkflowRequest;
import com.scb.selfservice.domains.WorkflowRequestStep;
import com.scb.selfservice.domains.WorkflowRequestStepsNames;
import com.scb.selfservice.util.Response;
import com.scb.selfservice.util.WorkflowConstants;
import com.scb.selfservice.web.authentication.AppSecurityContextHolder;
import com.scb.selfservice.web.authentication.UserPrincipal;
import com.scb.selfservice.workflow.service.ExecutionContext;
import com.scb.selfservice.workflow.service.WorkflowRequestService;
import com.scb.selfservice.workflow.service.WorkflowServiceTask;

/*
 * Class for workflowRequest related services like 
 * 	initial steps
 *  reject
 *  approve
 */
@Service
public class WorkflowRequestServiceImpl implements WorkflowRequestService {

	private static Logger logger = LogManager.getLogger(WorkflowRequestServiceImpl.class);

	@Autowired
	WorkflowMapper workflowMapper;

	@Autowired
	DataConsumptionRequestMapper dcrMapper;

	@Autowired
	ApplicationContext applicationContext;
	
	// Added as per AMAR's mail
	@Autowired
	private RequestDetailsMapper requestDetailsMapper;
	
	@Override
	@Transactional(rollbackFor = Exception.class)
	public String insertWorkFlowRequest(WorkflowRequest workflowRequest, Integer snapshotId) throws Exception {
		logger.info("STARTED WorkflowRequestServiceImpl::insertWorkFlowRequest");

		logger.info("WorkflowRequest received-----> " + workflowRequest);
		WorkflowConstants workflowConstants = new WorkflowConstants();
		String status = null;
		try {
			//check 'rejected' already!!! //if so do the ground work
			completeRejectedProcess(workflowRequest);

			int wfRequestValue = workflowMapper.insertWorkFlowRequest(workflowRequest, workflowConstants); //single and 'parent' entry

			logger.info("WorkflowRequestServiceImpl.insertWorkFlowRequest--->" + wfRequestValue);
			List<WorkflowProcessSteps> wfProcessSteps = workflowMapper.getWorkflowProcessSteps(workflowRequest.getWorkflowId()); //static process steps

			//prepare the next workflow_request_steps//
			List<WorkflowRequestStep> wfReqSteps = initialWorkflowRequestSteps(workflowRequest, wfProcessSteps);//workflowRequestSteps(workflowRequest, wfProcessSteps);
			if (wfProcessSteps.isEmpty() || (null == wfProcessSteps))
				throw new Exception("EXCEPTION with preparing workflow_request_steps");
			logger.info("-----------------------------------------------");
			//now time to insert into Workflow_Request_Steps (child entry!!!)//
			int wfRequestStepsValue = workflowMapper.insertWorkFlowRequestStep(workflowRequest, workflowConstants, wfReqSteps);
			if (wfRequestStepsValue == 0) {
				throw new Exception("EXCEPTION with step insertWorkFlowRequestStep");
			}
			//audit here
			logger.info("WorkflowRequestServiceImpl - time for audit - initiation of workflow");
			int auditVal = workflowMapper.insertIntoWorkflowReqStepsAt(prepareAuditWfReqStepAt(wfReqSteps.get(0), 
					workflowRequest.getWorkflowId(), snapshotId));
			if (auditVal == 0) {
				throw new Exception("EXCEPTION with inserting into audit - initiation - workflow_req_steps_at");
			}
			logger.info("WorkflowRequestServiceImpl.insertWorkFlowRequestSteps--->" + wfRequestStepsValue);
			logger.info("STARTED WorkflowRequestServiceImpl::insertWorkFlowRequest");
			status = "SUCCESS";
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.info("EXCEPTION while iniating workflow: " + ex.getMessage());
			throw ex;
		}
		return status;
	}

	@Override
	public List<WorkflowRequestStepsNames> getWorkflowRequestStepsById(Integer reqId, String workflowType) throws Exception {
		logger.info("STARTED WorkflowRequestServiceImpl::getWorkflowRequestStepsById");
		Integer workflowId = getWorkflowId(workflowType);
		logger.info("WorkflowRequestServiceImpl::getWorkflowRequestStepsById for workflowId " + workflowId + " with " + workflowType);
		List<WorkflowRequestStepsNames> stepNames = workflowMapper.getWorkflowRequestStepsById(reqId, workflowId);
		logger.info("EXITING WorkflowRequestServiceImpl::getWorkflowRequestStepsById");
		return stepNames;
	}

	//method to handle either Update/Reject of given requestId
	@Override
	@Transactional(rollbackFor=Exception.class)
	public Response initiateUpdateOrReject(HashMap<String, String> requestMap) throws Exception{
		Response response = new Response();
		try {
			Upject upject = prepareActionObject(requestMap);
			List<EdmpConsumpReqUserResp> lst = prepareInsertRows(requestMap);

			if (upject.getStatus().equalsIgnoreCase("REJECT")) {
				logger.info("STARTED WorkflowRequestServiceImpl:: initiateUpdateOrReject - REJECT");
				upject.setStatus("REJECTED");
				response = workflowReject(upject, lst);

				logger.info("DONE  with workflow_request (steps) REJECT");

			} else if (upject.getStatus().equalsIgnoreCase("ACCEPT") ||
					upject.getStatus().equalsIgnoreCase("UPDATE")) {
				logger.info("STARTED WorkflowRequestServiceImpl:: initiateUpdateOrReject - UPDATE");

				response = workflowApprove(upject, lst);

				logger.info("DONE with workflow_request (steps) UPDATE");
			} else if (upject.getStatus().equalsIgnoreCase("ADMIN")) {
				logger.info("Starting Admin Save user response for " + upject.getReqId() + " for stepid: " +  upject.getStepId());
				actOnEdmpConsumpReqUserResp(upject.getReqId(), upject.getStepId(), lst);
				logger.info("Exiting Admin Save user response");

				response.setStatusCode(HttpStatus.OK.value());
				response.setStatus(HttpStatus.OK.toString());
				response.setResponse("Admin done with updating the user response");
			} else {
				response.setStatusCode(HttpStatus.NOT_IMPLEMENTED.value());
				response.setStatus("Operation NOT implemented");
				response.setResponse("Operation not allowed");
			}
		} catch(Exception ex) {
			logger.info("EXCEPTION in initiateUpdateOrReject: " + ex.getMessage());
			throw ex;
		}

		return response;
	}

	@Override
	@Transactional
	public Response getMyApprovalList(Integer userId, String workflowType) {
		Response response = new Response();
		logger.info("STARTED getMyApprovalList");
		try {
			Integer workflowId = getWorkflowId(workflowType);
			List<MyApprovalList> myApprovalList = workflowMapper.getMyApprovalList(userId, workflowId);
			logger.info("EXITING getMyApprovalList");
			if (myApprovalList.isEmpty() || null== myApprovalList) {
				response.setStatusCode(HttpStatus.NO_CONTENT.value());
				response.setStatus("NO CONTENT");
				response.setResponse("No data found for the user");
			} else {
				response.setStatusCode(HttpStatus.OK.value());
				response.setStatus("SUCCESS");
				response.setResponse(myApprovalList);
			}
		} catch (Exception ex) {
			logger.info("WorkflowRequestServiceImpl getMyApprovalList exception for " +
						workflowType + " with " + ex.getMessage());
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus("NO CONTENT");
			response.setResponse("No data found for the user");
		}
		
		return response;
	}

	//method to proceed with workflowReject
	@Override
	@Transactional
	public Response workflowReject(Upject upject, List<EdmpConsumpReqUserResp> lst ) throws Exception {
		Response response = new Response();
		logger.info("STARTED workflowRejection");
		//
		if(null!=lst) {
		actOnEdmpConsumpReqUserResp(upject.getReqId(), upject.getStepId(), lst);
		}
		int updateValue = 0;
		updateValue = workflowMapper.workflowRequestStepsRejectStep(upject, 0);
		logger.info("DONE workflowRejection for initiator step: " + updateValue);
		if (updateValue == 0) {
			throw new Exception("Error (REJECT) Failed to reject on workflow_request_steps");
		}
		executeServiceTask(String.valueOf(upject.getReqId()), upject.getStepId(), "REJECT");
		
		//get current step's reject_step_id
		WorkflowProcessSteps wfps = workflowMapper.getRejectStepId(upject);
		if (wfps.getRejectStepId().equals("S0")) {
			///if (wfps.getStepName().equalsIgnoreCase(REQUESTOR)) {
			updateValue = workflowMapper.workflowRequestStepsReject(upject); //ALL WITH NOTSTARTED
			logger.info("DONE workflowRejection for all steps: " + updateValue);
			if (updateValue == 0) {
				throw new Exception("Error (REJECT) Failed to reject on workflow_request_steps for NOT STARTED");
			}
			upject.setStatus("REJECTED");
			updateValue = workflowMapper.updateEdmpSelfServiceReqComplete(upject);
			if (updateValue == 0) {
				throw new Exception("Error (REJECT) Failed to reject on EdmpSelfServiceReq");
			}
		} else {
			updateValue = workflowMapper.workflowRequestStepsRejectRequired(wfps.getRejectStepId(), upject.getReqId());
			logger.info("DONE workflowRejection for required step: " + updateValue);
			if (updateValue == 0) {
				throw new Exception("Error (REJECT) Failed to reject on workflow_request_steps for PENDING");
			}
		}

		updateValue = workflowMapper.workflowRequestReject(upject);
		if (updateValue == 0) {
			throw new Exception("Error (REJECT) Failed to reject on workflow_request");
		}
		//audit here
		logger.info("WorkflowRequestServiceImpl - time for audit - reject workflow");
		WorkflowRequestStep auditStep = workflowMapper.getWorkflowRequestStepsByStepId(upject.getReqId(), upject.getStepId());
		auditStep.setStatus(REJECTED);
		//snapshotId is null at the time of rejection 0209
		int auditVal = workflowMapper.insertIntoWorkflowReqStepsAt(prepareAuditWfReqStepAt(auditStep, upject.getWorkflowId(), null));
		if (auditVal == 0) {
			throw new Exception("EXCEPTION with inserting into audit - reject - workflow_req_steps_at");
		}
		logger.info("DONE workflowRejection for request: " + updateValue);

		response.setStatusCode(HttpStatus.OK.value());
		response.setStatus("Success");
		response.setResponse("Workflow Rejection SUCCESS");
		logger.info("DONE with workflow_request REJECT");
		return response;
	}

	//method to process on existing EdmpConsumpReqUserResp
	private void actOnEdmpConsumpReqUserResp(Integer reqId, String stepId, List<EdmpConsumpReqUserResp> lst) throws Exception {
		List <EdmpConsumpReqUserResp> ecrUserResp = workflowMapper.getEdmpConsumpReqUserResp(reqId, stepId);
		if (ecrUserResp.isEmpty()) {
			int insertValue = workflowMapper.insertIntoEdmpConsumpReqUserResp(lst);
			if (insertValue == 0) {
				throw new Exception("Error (REJECT) inserting rows into EdmpConsumpReqUserResp");
			}
		} else {
			for (EdmpConsumpReqUserResp item: lst) {
				int updateValue = workflowMapper.updateEdmpConsumpReqUserResp(item);
				if (updateValue == 0) {
					throw new Exception("Error (REJECT) updating EdmpConsumpReqUserResp");
				}
			}
		}
	}

	//method to prepare initial workflow_request_steps based on workflow_process_steps
	private List<WorkflowRequestStep> initialWorkflowRequestSteps(WorkflowRequest wfr, 
			List<WorkflowProcessSteps> wfps) throws Exception{

		boolean userType = false;
		boolean pending  = false;
		List<WorkflowRequestStep> wfrs = new ArrayList<>();
		UserPrincipal loggedInUser = AppSecurityContextHolder.getLoggedInUser();
		for(WorkflowProcessSteps step : wfps) {
			logger.info("STEP: " + step);
			logger.info("StepId: " + wfr.getLastActedStepId() + "---" + step.getStepId());
			if (step.getStepType().equals("U")) {
				logger.info("StepType: " + step.getStepType());
				if (userType == false) {
					//1
					wfrs.add(new WorkflowRequestStep(wfr.getReqId(), step.getStepId(), COMPLETED, wfr.getRemarks(), 
							new Timestamp(System.currentTimeMillis()), new Timestamp(System.currentTimeMillis()), 
							step.getStepUserGroup() == null? "": step.getStepUserGroup(),
									null, Integer.parseInt(loggedInUser.getUserId()), SUBMITTED));
					userType = true;
				} else {
					if (pending == false) {
						Integer stepPendingUser = null;
						if (StringUtils.isNotBlank(step.getStepUserGroup()) &&
								step.getStepUserGroup().equals(LMUSER)) {
							stepPendingUser = Integer.parseInt(loggedInUser.getUserLM());
							//1
							wfrs.add(new WorkflowRequestStep(wfr.getReqId(), step.getStepId(), PENDING, "", 
									new Timestamp(System.currentTimeMillis()), null,
									step.getStepUserGroup() == null? "": step.getStepUserGroup(),
											stepPendingUser, null, ""));
						} else if (StringUtils.isNotBlank(step.getStepUserGroup()) &&
								step.getStepUserGroup().equals(DMUSER)) {
							//3
							wfrs.add(getDmPsid(step, wfr.getReqId(), PENDING));
						}
						else {
							wfrs.add(new WorkflowRequestStep(wfr.getReqId(), step.getStepId(), PENDING, "", 
									new Timestamp(System.currentTimeMillis()), null,
									step.getStepUserGroup() == null? "": step.getStepUserGroup(),
											stepPendingUser, null, ""));
						}
						pending = true;
					} else {
						if (StringUtils.isNotBlank(step.getStepUserGroup()) &&
								step.getStepUserGroup().equals(DMUSER)) {
							//3
							wfrs.add(getDmPsid(step, wfr.getReqId(), NOT_STARTED));
						} else {
							//2
							wfrs.add(new WorkflowRequestStep(wfr.getReqId(), step.getStepId(), NOT_STARTED,
									"", step.getStepUserGroup() == null? "": step.getStepUserGroup(),
											null, null, ""));
						}
					}
				}
			} else { //StepType is 'S'
				if (pending == false) {
					logger.info("SERVICE TYPE step.....");
					String beanClass = step.getServiceStepClass();
					ExecutionContext ctx = new ExecutionContext();
					ctx.setReqId(wfr.getReqId()+"");
					ctx.setAction("APPROVE"); // Added as per AMAR's mail
					ctx.setStepId(step.getStepId());
					WorkflowServiceTask serviceTask = (WorkflowServiceTask) applicationContext.getBean(beanClass);;
					String status = serviceTask.execute(ctx);
					if (status.equalsIgnoreCase(FAILURE))
						throw new Exception("EXCEPTION - failed for the service: " + beanClass);
					String stepAction = getStatus(status);

					logger.info("Service ServiceStepClass stepAction= " + stepAction + " status= " + status);
					//2
					wfrs.add(new WorkflowRequestStep(wfr.getReqId(), step.getStepId(), status,
							"", step.getStepUserGroup() == null? "": step.getStepUserGroup(),
									null, Integer.parseInt(loggedInUser.getUserId()), stepAction));
				} else {
					//2
					wfrs.add(new WorkflowRequestStep(wfr.getReqId(), step.getStepId(), NOT_STARTED,
							"", step.getStepUserGroup() == null? "": step.getStepUserGroup(),
									null, null, ""));
					pending = true;
				}
			}
		}
		return wfrs;
	}

	//method to get psid for userType as DeliveryManager - added for ingestion- Temporary fix
	private WorkflowRequestStep getDmPsid(WorkflowProcessSteps step, Integer reqId, String status) {
		//execute SQL for pulling DeliveryManager's PSID from edmp_consumption_request
		if(step.getWorkflowId() == 101) {
			DMPsid dmpsid = workflowMapper.getDmPsid(reqId);
			//1
			return new WorkflowRequestStep(reqId, step.getStepId(), status, "", 
					new Timestamp(System.currentTimeMillis()), null,
					step.getStepUserGroup() == null? "": step.getStepUserGroup(),
							Integer.parseInt(dmpsid.getPsid()), null, "");
		}
		else {
			//DMPsid dmpsid = workflowMapper.getDmPsid(reqId);
			//1
			
			//need to remove
			return new WorkflowRequestStep(reqId, step.getStepId(), status, "", 
					new Timestamp(System.currentTimeMillis()), null,
					step.getStepUserGroup() == null? "": step.getStepUserGroup(),
							null, null, "");
		}
	}

	//method to convert Service call return value
	private String getStatus(String stepAction) {
		switch(stepAction) {
		case (SUCCESS): return COMPLETED;
		case (APPROVE): return COMPLETED;
		case (REJECTED): 
		case (FAILURE) : return PENDING;
		default: return "";
		}
	}

	//method to proceed with workflowApprove
	@Override
	@Transactional
	public Response workflowApprove(Upject upject, List<EdmpConsumpReqUserResp> lst) throws Exception {
		String actingStepId = upject.getStepId();
		Response response = new Response();
		
		if(null != lst) {

		actOnEdmpConsumpReqUserResp(upject.getReqId(), upject.getStepId(), lst);
		}
		int insertValue = 0;

		List<RequestProcessStep> rps = workflowMapper.getRequestProcessSteps(upject.getReqId(), upject.getWorkflowId());
		if (rps.isEmpty() || null == rps)
			throw new Exception("Error (APPROVE) pulling request_process_steps table");

		boolean stopStep = false;
		boolean userType = false;
		logger.info("Update received is: " + upject);
		RequestProcessStep last = null;
		boolean completed = false;
		boolean skipService = false;

		for(RequestProcessStep step : rps) {
			last = step;
			logger.info("STEP: " + step);
			if (stopStep == true)
				break;
			if (upject.getStepId().equals(step.getStepId())) {
				logger.info("StepId: " + upject.getStepId() + "---" + step.getStepId());
				if (step.getStepType().equals("U")) {
					logger.info("StepType: " + step.getStepType());
					if (userType == false) {
						insertValue = workflowMapper.updateWorkflowRequestStep(upject.getReqId(), upject.getStepId(), 
								COMPLETED, APPROVE,upject.getUserId(), upject.getRemarks(), 0);
						logger.info("1 Done with updating: " + upject.getReqId() + upject.getStepId());
						if (insertValue == 0) {
							throw new Exception("Error (APPROVE - COMPLETED) inserting rows into workflowRequestStep table");
						}
						logger.info("WorkflowRequestServiceImpl - time for audit - approve workflow");
						WorkflowRequestStep auditStep = workflowMapper.getWorkflowRequestStepsByStepId(upject.getReqId(), upject.getStepId());
						//snapshotid is null for approve too 0209: snapshot is only at the time of submission of req 
						int auditVal = workflowMapper.insertIntoWorkflowReqStepsAt(prepareAuditWfReqStepAt(auditStep, upject.getWorkflowId(), null));
						if (auditVal == 0) {
							throw new Exception("EXCEPTION with inserting into audit - APPROVE - workflow_req_steps_at");
						}
						userType = true;
					} else {
						ConsumptionRequest consumptionRequest = dcrMapper.findByRequestId(upject.getReqId());
						//HERE IS THE TIME TO BYPASS APPROVAL STEPS IF REQUIRED
						if(consumptionRequest !=null) {
						if ((null != consumptionRequest.getIsRelatedExistReq() && consumptionRequest.getIsRelatedExistReq().equals("1")) 
								&& (step.getStepUserGroup().equalsIgnoreCase(DMUSER) || 
										step.getStepUserGroup().equalsIgnoreCase(SDUSER) ||
										step.getStepUserGroup().equalsIgnoreCase(CAUSER))) {
							insertValue = workflowMapper.updateWorkflowRequestStep(upject.getReqId(), upject.getStepId(), 
									AUTOAPPROVED, SKIPPED, upject.getUserId(), upject.getRemarks(), 0);
							if (insertValue == 0) {
								throw new Exception("Error (AUTO APPROVE - COMPLETED) inserting rows into workflowRequestStep table");
							}
							logger.info("Done with AUTO updating: " + upject.getReqId() + upject.getStepId());

							WorkflowRequestStep auditStep = workflowMapper.getWorkflowRequestStepsByStepId(upject.getReqId(), upject.getStepId());
							//snapshotid is null for approve too 0209: snapshot is only at the time of submission of req 
							int auditVal = workflowMapper.insertIntoWorkflowReqStepsAt(prepareAuditWfReqStepAt(auditStep, upject.getWorkflowId(), null));
							if (auditVal == 0) {
								throw new Exception("EXCEPTION with inserting into audit - AUTO APPROVE - workflow_req_steps_at");
							}
							skipService = true;
							upject.setStepId(step.getNextStepId());
						} else {
							insertValue = workflowMapper.updateWorkflowRequestStepPending(upject.getReqId(), upject.getStepId(), 
									PENDING, "", null);
							logger.info("2 Done with updating: " + upject.getReqId() + upject.getStepId());
							if (insertValue == 0) {
								throw new Exception("Error (APPROVE - PENDING) inserting rows into workflowRequestStep table");
							}
							break;
						}
						}else {
							insertValue = workflowMapper.updateWorkflowRequestStepPending(upject.getReqId(), upject.getStepId(), 
									PENDING, "", null);
							logger.info("2 Done with updating: " + upject.getReqId() + upject.getStepId());
							if (insertValue == 0) {
								throw new Exception("Error (APPROVE - PENDING) inserting rows into workflowRequestStep table");
							}
							break;
							
						}
					}
					upject.setStepId(step.getNextStepId());
					if (null == step.getNextStepId()) {
						stopStep = true;
						upject.setStepId(actingStepId);
						upject.setStatus(COMPLETED);
						insertValue = workflowMapper.updateEdmpSelfServiceReqComplete(upject);
						if (insertValue == 0) {
							throw new Exception("Error (APPROVE - COMPLETED) inserting rows into EdmpSelfServiceReq table");
						}
						completed = true;
						continue;
					}
				} else { //StepType is 'S'
					if (!skipService) {
						logger.info("SERVICE TYPE step.....");
						String beanClass = step.getServiceStepClass();

						ExecutionContext ctx = new ExecutionContext();
						ctx.setReqId(upject.getReqId()+"");
						ctx.setStepId(step.getStepId());
						ctx.setAction("APPROVE");
						WorkflowServiceTask serviceTask = (WorkflowServiceTask) applicationContext.getBean(beanClass);;
						String status = serviceTask.execute(ctx);
						if (status.equalsIgnoreCase(FAILURE))
							throw new Exception ("Error (APPROVE) failed for the service: " + beanClass);
						String stepAction = getStatus(status);

						logger.info("Service ServiceStepClass stepAction= " + stepAction + " status= " + status);
						insertValue = workflowMapper.updateWorkflowRequestStep(upject.getReqId(), upject.getStepId(), 
								status, stepAction,upject.getUserId(), null, 0);
						logger.info("Done with ServiceType updation: " + upject.getReqId() + upject.getStepId() + 
								status + stepAction);
						if (insertValue == 0) {
							throw new Exception("Error (APPROVE) SERVICEType inserting rows into WorkflowRequestStep table");
						}
						upject.setStepId(step.getNextStepId());
						if (status.equals(PENDING) || (null == step.getNextStepId())) {
							stopStep = true;
							if (null == step.getNextStepId()) {
								upject.setStatus(COMPLETED);
								insertValue = workflowMapper.updateEdmpSelfServiceReqComplete(upject);
								if (insertValue == 0) {
									throw new Exception("Error (APPROVE) LASTStep inserting rows into EdmpConsumpReqUserResp table");
								}
								completed = true;
							}
							continue;
						}
					} else {
						upject.setStepId(step.getNextStepId());
						//continue;
					}
				} 
			}
		}//for loop ends

		logger.info("--------->" + upject + "------->" + last);
		upject.setStepId(last.getParentStepId());

		logger.info("It is time for updating workflow_request step");
		upject.setStepId(actingStepId);
		if (completed)
			upject.setStatus(COMPLETED);
		else
			upject.setStatus(PENDING);

		int updateValue = workflowMapper.workflowRequestUpdate(upject);
		if (updateValue == 0) {
			throw new Exception("Error (APPROVE) updating workflow_request table");
		} else {
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus("Success");
			response.setResponse("Worflow UPDATE/APPROVE is SUCCESS");
		}
		logger.info("DONE workflowApproval for request: " + upject.getReqId()); //changed the log message

		return response;
	}

	//method for preparing audit object 
	private WorkflowReqStepsAt prepareAuditWfReqStepAt(WorkflowRequestStep step, Integer workflowId, Integer snapshotId) {
		WorkflowReqStepsAt audit = new WorkflowReqStepsAt();
		audit.setRemarks(step.getRemarks());
		//audit.setReqAtId(reqAtId); DB level sequence
		audit.setReqId(step.getReqId());
		audit.setStartTime(step.getStartTime());
		audit.setStatus(step.getStatus());
		audit.setStepAction(step.getStepAction());
		audit.setStepActionedBy(step.getStepActionedBy());
		audit.setStepId(step.getStepId());
		audit.setStepPendingGrp(step.getStepPendingGrp());
		audit.setStepPendingUser(step.getStepPendingUser());
		audit.setWorkflowId(workflowId);
		audit.setSnapshotId(snapshotId);

		return audit;
	}

	//method to return update/reject pojo
	private Upject prepareActionObject(HashMap<String, String> requestMap) throws Exception {
		Upject obj = new Upject();
		obj.setRemarks(requestMap.get("remarks"));
		obj.setReqId(Integer.parseInt(requestMap.get("reqId")));
		obj.setStatus(requestMap.get("action"));
		obj.setStepId(requestMap.get("stepId"));
		obj.setUserId(Integer.valueOf(requestMap.get("userId")));
		//int workflowId = getWorkflowId(requestMap.get("workflowType"));
		obj.setWorkflowId(getWorkflowId(requestMap.get("workflowType")));
		return obj;
	}

	//method to pull workflowId corresponding to the given workflow Process_name
	@Override
	public int getWorkflowId(String workflowType) throws Exception {
		logger.info("STARTED pulling workflowId for the given workflowType: " + workflowType);
		WorkflowIdType workflowIdType = workflowMapper.getWorkflowId(workflowType);
		if (null != workflowIdType) {
			logger.info("EXITING with workflowId: " + workflowIdType.getWorkflowId());
			return workflowIdType.getWorkflowId();
		} else
			throw new Exception("Failed to pull workflow_id for the given workflow_type: " + workflowType);
	}

	//method preparing list of objects from requestBody of properties and values
	private List<EdmpConsumpReqUserResp> prepareInsertRows (HashMap<String, String> requestMap) {
		List<EdmpConsumpReqUserResp> lst = new ArrayList<>();
		Set<String> keys = requestMap.keySet(); //list of keys passed
		String reqId = requestMap.get("reqId");
		String stepId = requestMap.get("stepId");
		keys.remove("action");
		keys.remove("reqId");
		keys.remove("stepId");
		keys.remove("userId");
		keys.remove("workflowType");
		keys.remove("remarks");
		for(String key: keys) {
			EdmpConsumpReqUserResp obj = new EdmpConsumpReqUserResp();
			obj.setPropertyName(key);
			obj.setProjertyValue(requestMap.get(key));
			obj.setReqId(Integer.parseInt(reqId));
			obj.setStepId(stepId);
			lst.add(obj);
		}
		return lst;
	}

	//method to delete entries of existing rows, based on req_id, from
	//     workflow_request, workflow_reqeust_steps, edmp_consump_req_user_resp
	private void completeRejectedProcess(WorkflowRequest workflowRequest) throws Exception {
		logger.info("Inside completeRejectedProcess...");
		//will return reqId with REJECTED
		WorkflowRequestStep workflowRequestStep = workflowMapper.getRejectedWorkflowRequestSteps(workflowRequest.getReqId());
		if (null != workflowRequestStep) {
			//DO NOT THE CHANGE THE ORDER OF THE BELOW DELETE mappers
			int delWfrs = workflowMapper.deleteWorkFlowRequestSteps(workflowRequest.getReqId());
			if (delWfrs == 0)
				throw new Exception("Issue with deleting workflow_request");
			int delWfr = workflowMapper.deleteWorkFlowRequest(workflowRequest.getReqId());
			if (delWfr == 0)
				throw new Exception("Issue with deleting workflow_reqeust_steps");
			//int delss = workflowMapper.deleteEdmpConsumpReqUserResp(workflowRequest.getReqId());
			//if (delss == 0)
			//	throw new Exception("Issue with deleting edmp_consump_req_user_resp");
		} else { //the given req_id is NOT rejected and hence it is a new flow
			logger.info("Inside completeRejectedProcess... This is new initiation");
		}
	}


	//method to bring the audit details of workflow_request_steps along with userName (from userId)
	@Override
	public Response getAuditWorkflowRequestSteps(HashMap<String, String> requestMap) throws Exception {
		logger.info("Inside getAuditWorkflowRequestSteps...");
		List<AuditWorkflowRequestSteps> lst = workflowMapper.getAuditWorkflowRequestSteps(
				Integer.parseInt(requestMap.get("reqId")), getWorkflowId(requestMap.get("workflowType")));
		Response auditResponse = new Response();
		if (lst.isEmpty()) {
			auditResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			auditResponse.setStatus(HttpStatus.NO_CONTENT.toString());
		} else {
			auditResponse.setStatusCode(HttpStatus.OK.value());
			auditResponse.setStatus(HttpStatus.OK.toString());
			auditResponse.setResponse(lst);
		}
		logger.info("Exiting getAuditWorkflowRequestSteps...");
		return auditResponse;
	}

	// method to bring workflow_request workflowid from requestid
	@Override
	public Integer getWorkflowRequestWorkflowId(int reqId) {
		return workflowMapper.getWorkflowRequestWorkflowId(reqId);
	}

	@Override
	//method to pull workflowReqStepsAt
	public void insertIntoWorkflowReqStepsAt(WorkflowReqStepsAt workflowReqStepsAt) {
		workflowMapper.insertIntoWorkflowReqStepsAt(workflowReqStepsAt);
	}

	//method to pull workflowReqStep
	public void updateWorkflowReqSteps(WorkflowRequestStep workflowReqStep) {
		workflowMapper.updateExistingPendingSteps(workflowReqStep);
		workflowMapper.updateWorkflowReqSteps(workflowReqStep);
	} 
	
	/**
	 * Ingestion - Fetch the list of Approvals for the logged in user.
	 */
	@Override
	@Transactional
	public Response getMyIngestionApproval(Integer userId, String workflowType) throws Exception {
		Response response = new Response();
		logger.info("STARTED getMyIngestionApproval");
		logger.info("User : " + userId);
		Integer workflowId = getWorkflowId(workflowType);
		List<MyApprovalList> myApprovalList = workflowMapper.getMyIngestionApproval(userId,workflowId);
		logger.info("Approval count :" + myApprovalList);
		logger.info("EXITING getMyIngestionApproval");
		if (myApprovalList.isEmpty() || null== myApprovalList) {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus("NO CONTENT");
			response.setResponse("No data found for the user");
		} else {
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus("SUCCESS");
			response.setResponse(myApprovalList);
		}
		return response;
	}
	
	
    /**
     * 
     * Added as per AMAR's mail
     * 
     * @param reqId
     * @param stepId
     * @param action
     */
	protected void executeServiceTask(String reqId, String stepId, String action) {
		try {
			List<HashMap<String, String>> serviceTsk = requestDetailsMapper.getNextServiceTask(reqId, stepId);
			for(HashMap<String, String> data : serviceTsk) {
				String sTaskBean = data.get("SERVICE_STEP_CLASS");
                ExecutionContext ctx = new ExecutionContext();
                ctx.setReqId(reqId);
                ctx.setStepId(data.get("STEP_ID"));
                ctx.setAction(action);
                WorkflowServiceTask serviceTask = (WorkflowServiceTask) applicationContext.getBean(sTaskBean);
                String status = serviceTask.execute(ctx);
            }
			
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
}