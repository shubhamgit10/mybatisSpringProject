package com.scb.selfservice.service;

import org.springframework.stereotype.Service;

import com.scb.selfservice.model.CostEstimation;
import com.scb.selfservice.model.CostEstimationRequest;
import com.scb.selfservice.util.Response;

@Service
public interface CostEstimationSummaryService {

	
	public Response getEstimatedCost(CostEstimationRequest costEstimationRequest, int userId);

	public Response readEstimatedCost(Integer estimationId);

	public Response getEstimatedCostFromDb(Integer estimationId,String workflowType,String stepId);


}
