package com.scb.selfservice.service.impl;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.ingestion.SDMTechMapper;
import com.scb.selfservice.domains.ViewPipeline;
import com.scb.selfservice.service.SDMTechService;
import com.scb.selfservice.util.Response;

/**
 * @author shubhasi
 * 
 *         Implementation class for SDM tech related business logic
 *
 */
@Service
public class SDMTechServiceImpl implements SDMTechService {

	private static Logger logger = LogManager.getLogger(SDMTechServiceImpl.class);
	@Autowired
	private SDMTechMapper sdmMapper;

	@Override
	@Transactional
	public Response getSDMTableName(Integer reqId) {
		logger.info("<--Inside method :: getSDMTableName");
		Response tableNameRes = new Response();
		Set<String> set = new HashSet<>();
		List<String> listOftable = sdmMapper.getSDMTableNameFromDb(reqId);
		listOftable.removeAll(Collections.singletonList(null));
		set = listOftable.stream().collect(Collectors.toSet());
		Set<String> treeSet = new TreeSet<String>(set);

		if (listOftable.size() > 0) {
			tableNameRes.setStatusCode(HttpStatus.OK.value());
			tableNameRes.setStatus("Success");
			tableNameRes.setResponse(treeSet);
		} else {
			tableNameRes.setResponse("No Content!! please pass valid request Id");
		}
		return tableNameRes;
	}
	
	@Override
	@Transactional
	public Response findByReqGlobalParam() {
		List<ViewPipeline> viewPipeline = sdmMapper.findByRequestParam();
		Response response = new Response();
		if (viewPipeline != null) {
			response.setStatusCode(HttpStatus.OK.value());
			response.setStatus(HttpStatus.OK.toString());
			response.setResponse(viewPipeline);
		} else {
			response.setStatusCode(HttpStatus.NO_CONTENT.value());
			response.setStatus(HttpStatus.NO_CONTENT.toString());
		}
		return response;
	}

}
