package com.scb.selfservice.util;

import java.time.LocalDateTime;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LocalDateTime date = LocalDateTime.now();
		System.out.println(date.getDayOfWeek().getValue());
		
		
	}

}
