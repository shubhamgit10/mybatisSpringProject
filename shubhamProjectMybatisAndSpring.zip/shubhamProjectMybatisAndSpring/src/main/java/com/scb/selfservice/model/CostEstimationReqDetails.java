package com.scb.selfservice.model;



public class CostEstimationReqDetails {
	private int estimationId;
	private int reqId;
	private String stepId;
	private String workflowType;
	private Integer personDaysCost;
	private Integer infraNASCost;
	private Integer infraHAASCost;
	private Integer nifiAllocationCost;
	private Integer iMFTMaintenanceCost;
	private Integer developmentSITRegression;
	private Integer sourceSystemCosting;
	private Integer totalDownstreamCosting;
	private Integer otherCosts;
	private Integer estimatedCost;
	public int getEstimationId() {
		return estimationId;
	}
	public void setEstimationId(int estimationId) {
		this.estimationId = estimationId;
	}
	public int getReqId() {
		return reqId;
	}
	public void setReqId(int reqId) {
		this.reqId = reqId;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	
	public String getWorkflowType() {
		return workflowType;
	}
	public void setWorkflowType(String workflowType) {
		this.workflowType = workflowType;
	}
	public Integer getPersonDaysCost() {
		return personDaysCost;
	}
	public void setPersonDaysCost(Integer personDaysCost) {
		this.personDaysCost = personDaysCost;
	}
	public Integer getInfraNASCost() {
		return infraNASCost;
	}
	public void setInfraNASCost(Integer infraNASCost) {
		this.infraNASCost = infraNASCost;
	}
	public Integer getInfraHAASCost() {
		return infraHAASCost;
	}
	public void setInfraHAASCost(Integer infraHAASCost) {
		this.infraHAASCost = infraHAASCost;
	}
	public Integer getNifiAllocationCost() {
		return nifiAllocationCost;
	}
	public void setNifiAllocationCost(Integer nifiAllocationCost) {
		this.nifiAllocationCost = nifiAllocationCost;
	}
	public Integer getiMFTMaintenanceCost() {
		return iMFTMaintenanceCost;
	}
	public void setiMFTMaintenanceCost(Integer iMFTMaintenanceCost) {
		this.iMFTMaintenanceCost = iMFTMaintenanceCost;
	}
	public Integer getDevelopmentSITRegression() {
		return developmentSITRegression;
	}
	public void setDevelopmentSITRegression(Integer developmentSITRegression) {
		this.developmentSITRegression = developmentSITRegression;
	}
	public Integer getSourceSystemCosting() {
		return sourceSystemCosting;
	}
	public void setSourceSystemCosting(Integer sourceSystemCosting) {
		this.sourceSystemCosting = sourceSystemCosting;
	}
	public Integer getTotalDownstreamCosting() {
		return totalDownstreamCosting;
	}
	public void setTotalDownstreamCosting(Integer totalDownstreamCosting) {
		this.totalDownstreamCosting = totalDownstreamCosting;
	}
	public Integer getOtherCosts() {
		return otherCosts;
	}
	public void setOtherCosts(Integer otherCosts) {
		this.otherCosts = otherCosts;
	}
	public Integer getEstimatedCost() {
		return estimatedCost;
	}
	public void setEstimatedCost(Integer estimatedCost) {
		this.estimatedCost = estimatedCost;
	}
	@Override
	public String toString() {
		return "CostEstimationReqDetails [estimationId=" + estimationId + ", reqId=" + reqId + ", stepId=" + stepId
				+ ", workflowType=" + workflowType + ", personDaysCost=" + personDaysCost + ", infraNASCost="
				+ infraNASCost + ", infraHAASCost=" + infraHAASCost + ", nifiAllocationCost=" + nifiAllocationCost
				+ ", iMFTMaintenanceCost=" + iMFTMaintenanceCost + ", developmentSITRegression="
				+ developmentSITRegression + ", sourceSystemCosting=" + sourceSystemCosting
				+ ", totalDownstreamCosting=" + totalDownstreamCosting + ", otherCosts=" + otherCosts
				+ ", estimatedCost=" + estimatedCost + "]";
	}
		
}
