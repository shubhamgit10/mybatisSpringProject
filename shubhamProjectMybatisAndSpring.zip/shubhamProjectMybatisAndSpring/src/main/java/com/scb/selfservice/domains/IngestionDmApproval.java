package com.scb.selfservice.domains;

import java.sql.Date;

public class IngestionDmApproval {
	
	private Integer reqId;
	
	private String dmComments;
	
	private Date plannedReleaseDate;
	
	private Integer requestCreatedBy;
	
	private String userAction;
	
	private String stepId;
	
	private String workflowType;
	
	private String stepName;
		
	public String getStepName() {
		return stepName;
	}

	public void setStepName(String stepName) {
		this.stepName = stepName;
	}
	
	public String getWorkflowType() {
		return workflowType;
	}

	public void setWorkflowType(String workflowType) {
		this.workflowType = workflowType;
	}

	public Integer getReqId() {
		return reqId;
	}

	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}

	public String getDmComments() {
		return dmComments;
	}

	public void setDmComments(String dmComments) {
		this.dmComments = dmComments;
	}

	public Date getPlannedReleaseDate() {
		return plannedReleaseDate;
	}

	public void setPlannedReleaseDate(Date plannedReleaseDate) {
		this.plannedReleaseDate = plannedReleaseDate;
	}

	public Integer getRequestCreatedBy() {
		return requestCreatedBy;
	}

	public void setRequestCreatedBy(Integer requestCreatedBy) {
		this.requestCreatedBy = requestCreatedBy;
	}

	public String getUserAction() {
		return userAction;
	}

	public void setUserAction(String userAction) {
		this.userAction = userAction;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	@Override
	public String toString() {
		return "IngestionDmApproval [reqId=" + reqId + ", dmComments=" + dmComments + ", plannedReleaseDate="
				+ plannedReleaseDate + ", requestCreatedBy=" + requestCreatedBy + ", userAction=" + userAction
				+ ", stepId=" + stepId + "]";
	}

	
}
