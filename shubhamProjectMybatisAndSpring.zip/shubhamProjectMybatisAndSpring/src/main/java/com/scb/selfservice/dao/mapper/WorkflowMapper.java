package com.scb.selfservice.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.AuditWorkflowRequestSteps;
import com.scb.selfservice.domains.DMPsid;
import com.scb.selfservice.domains.EdmpConsumpReqUserResp;
import com.scb.selfservice.domains.MyApprovalList;
import com.scb.selfservice.domains.RequestProcessStep;
import com.scb.selfservice.domains.Upject;
import com.scb.selfservice.domains.WorkflowIdType;
import com.scb.selfservice.domains.WorkflowProcess;
import com.scb.selfservice.domains.WorkflowProcessSteps;
import com.scb.selfservice.domains.WorkflowReqStepsAt;
import com.scb.selfservice.domains.WorkflowRequest;
import com.scb.selfservice.domains.WorkflowRequestStep;
import com.scb.selfservice.domains.WorkflowRequestStepsNames;
import com.scb.selfservice.util.WorkflowConstants;

/*
 * Interface for Workflow request/process mapper
 * 		to return all the processes possible 
 */
public interface WorkflowMapper {
	
	/*
	 * Method to pull all available workflow_process details
	 */
	public List<WorkflowProcess> getWorkflowProcessDetails();

	/*
	 * Method to pull the required workflow_process detail
	 * @PARAM - workflow_id
	 * 			of required workflow_process
	 */
	public WorkflowProcess getWorkflowProcessDetailById(@Param("workflowId") Integer workflowId);

	/*
	 * Method to insert the initial workflow request
	 * in the table WORKFLOW_REQUEST
	 */
	public int insertWorkFlowRequest(@Param("workflowRequest")WorkflowRequest workflowRequest,
			@Param ("workflowConstants") WorkflowConstants workflowConstants);

	public int insertWorkFlowRequestStep(@Param("workflowRequest")WorkflowRequest workflowRequest,
			@Param ("workflowConstants") WorkflowConstants workflowConstants,
			@Param ("wfReqSteps") List<WorkflowRequestStep> wfReqSteps);

	/*
	 * mapper to pull all the rows from workflow_process_steps
	 */
	public List<WorkflowProcessSteps> getWorkflowProcessSteps(@Param("workflowId") Integer workflowId);

	/*
	 * mapper to pull all steps per request based on requestId
	 */
	public List<WorkflowRequestStepsNames> getWorkflowRequestStepsById(@Param("reqId") Integer reqId,
			@Param("workflowId") Integer workflowId);
	
	/*
	 * reject for given step_id
	 */
	public int workflowRequestStepsRejectStep(@Param("upject") Upject upject, @Param("attempt") Integer attempt);

	//mapper workflow_request_steps to reject status
	public int workflowRequestStepsReject(@Param("upject") Upject upject);

	//mapper workflow_request to reject status
	public int workflowRequestReject(@Param("upject") Upject upject);

	//mapper workflow_request to update status
	public int workflowRequestUpdate(@Param("upject") Upject upject);

	//mapper to pull current stepId's static workflow_process_step
	public WorkflowProcessSteps getWorkflowProcessStep(@Param("stepid") String stepId);

	//mapper to update the workflow_request_step - completed
	public int updateWorkflowRequestStep(@Param("reqId") Integer reqId, @Param("stepId") String stepId, 
										 @Param("status") String status, @Param("stepAction") String stepAction,
										 @Param("stepActionBy") Integer stepActionBy, @Param("remarks") String remarks,
										 @Param("attempt") Integer attempt);

	//mapper to update the workflow_request_step start time pending
	public int updateWorkflowRequestStepPending(@Param("reqId") Integer reqId, @Param("stepId") String stepId, 
											 @Param("status") String status, @Param("stepAction") String stepAction,
											 @Param("stepActionBy") Integer stepActionBy);

	//mapper to pull all the workflow_Request_steps
	public List<WorkflowRequestStep> getWorkflowRequestSteps(@Param("reqId") Integer reqId);

	//mapper to pull process+request steps corresponds to step_id based on req_id
	public List<RequestProcessStep> getRequestProcessSteps(@Param("reqId") Integer reqId, @Param("workflowId")Integer workflowId);

	public int insertIntoEdmpConsumpReqUserResp(@Param("lst") List<EdmpConsumpReqUserResp> lst);

	//mapper to mark edmp_selfservice_req as complete
	public int updateEdmpSelfServiceReqComplete(@Param("upject") Upject upject);

	//mapper to mark workflow_request as complete
	public int updateWorkflowRequestComplete(@Param("upject") Upject upject);

	public List<MyApprovalList> getMyApprovalList(@Param("userId") Integer userId, @Param("workflowId") Integer workflowId);

	//mapper for audit table inserts
	public int insertIntoWorkflowReqStepsAt(@Param("audit") WorkflowReqStepsAt audit);

	//mapper to pull all the workflow_Request_steps for a given 'step_id' and req_id
	public WorkflowRequestStep getWorkflowRequestStepsByStepId(@Param("reqId") Integer reqId, @Param("stepId") String stepId);

	//mapper to delete entries from workflow_request table based on req_id
	public int deleteWorkFlowRequest(@Param("reqId") Integer reqId);

	//mapper to delete entries from workflow_request_steps table based on req_id
	public int deleteWorkFlowRequestSteps(@Param("reqId") Integer reqId);

	//mapper to delete entries from edmp_consump_req_user_resp table based on req_id
	public int deleteEdmpConsumpReqUserResp(@Param("reqId") Integer reqId);

	//mapper to check 'rejected' status for the given reqId from edmp_consump_req_user_resp
	public WorkflowRequestStep getRejectedWorkflowRequestSteps(@Param("reqId") Integer reqId);

	//mapper to get Delivery Manager's PSID from edmp_consumption_request:delivery_manager_psid
	public DMPsid getDmPsid(@Param("reqId") Integer reqId);

	//mapper to get current step's reject_step_id
	public WorkflowProcessSteps getRejectStepId(@Param("upject") Upject upject);

	//mapper to mark the required step_id as pending while reject
	public int workflowRequestStepsRejectRequired(@Param("stepId") String stepId, @Param("reqId") Integer reqId);

	//mapper to get workflowId based on workflowType 
	public WorkflowIdType getWorkflowId(@Param("workflowType") String workflowType);

	//mapper to get edmp_consump_req_user_resp for (reqId + stepId)
	public List<EdmpConsumpReqUserResp> getEdmpConsumpReqUserResp(@Param("reqId") Integer reqId, @Param("stepId") String stepId);

	//mapper to update edmp_consump_req_user_resp for (reqId + stepId + propertyName)
	public int updateEdmpConsumpReqUserResp(@Param("item") EdmpConsumpReqUserResp item);

	//mapper to bring the audit details of workflow_request_steps along with userName (from userId)
	public List<AuditWorkflowRequestSteps> getAuditWorkflowRequestSteps(@Param("reqId") Integer reqId, 
														@Param("workflowId") Integer workflowId);
	
	public Integer getWorkflowRequestWorkflowId(@Param("reqId") Integer reqId);
	
	public void updateWorkflowReqSteps(@Param("step") WorkflowRequestStep step);
	
	public void updateExistingPendingSteps(@Param("step") WorkflowRequestStep step);
	
	public List<MyApprovalList> getMyIngestionApproval(@Param("userId") Integer userId, @Param("workflowId") Integer workflowId);
	
	/**
	 * @param stepId
	 * @param workflowId
	 * @return
	 */

	public WorkflowProcessSteps getWorkflowProcessStepByStepId(@Param("stepId") String stepId, @Param("workflowId") Integer workflowId);
}