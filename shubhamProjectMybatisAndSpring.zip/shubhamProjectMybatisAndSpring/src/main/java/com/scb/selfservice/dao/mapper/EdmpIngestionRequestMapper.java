package com.scb.selfservice.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.domains.IngestionRequest;

public interface EdmpIngestionRequestMapper {

	// method for save/insert the EdmpIngestionRequest
	public int saveIngestionRequest(@Param("IngestionRequest") IngestionRequest ingestionRequest);

	// method to pull existing EdmpIngestionRequest based on reqId
	public IngestionRequest findByRequestId(@Param("reqId") Integer reqId);

	// method for updating EdmpIngestionRequest
	public int updateIngestionRequest(@Param("IngestionRequest") IngestionRequest ingestionRequest);
	
	//method for update the EdmpIngestionRequest
		public int updateEDMPSelfService(@Param("IngestionRequest") IngestionRequest ingestionRequest);

	// method for update the EdmpIngestionRequest public int
	public int updateProposedCost(@Param("reqId") Integer reqId, @Param("userId") Integer userId,
			@Param("proposedCost") Double proposedCost);

	public int updateIngestionflag(@Param("reqId")Integer reqId, @Param("rejectedFlag")Integer rejectedFlag);

}
