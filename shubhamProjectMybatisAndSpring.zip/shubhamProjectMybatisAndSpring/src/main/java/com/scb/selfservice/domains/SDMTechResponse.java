package com.scb.selfservice.domains;

public class SDMTechResponse {

	private Integer reqId;
	private String stepId;
	private Integer itamId;
	private String configCategory;
	private String configName;
	private String configValue;
	private String userAction;
	private Integer createdBy;
	
	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public Integer getItamId() {
		return itamId;
	}
	public void setItamId(Integer itamId) {
		this.itamId = itamId;
	}
	public String getConfigCategory() {
		return configCategory;
	}
	public void setConfigCategory(String configCategory) {
		this.configCategory = configCategory;
	}
	public String getConfigName() {
		return configName;
	}
	public void setConfigName(String configName) {
		this.configName = configName;
	}
	public String getConfigValue() {
		return configValue;
	}
	public void setConfigValue(String configValue) {
		this.configValue = configValue;
	}
	public String getUserAction() {
		return userAction;
	}
	public void setUserAction(String userAction) {
		this.userAction = userAction;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer integer) {
		this.createdBy = integer;
	}
	@Override
	public String toString() {
		return "SDMTechResponse [reqId=" + reqId + ", stepId=" + stepId + ", itamId=" + itamId + ", configCategory="
				+ configCategory + ", configName=" + configName + ", configValue=" + configValue + ", userAction="
				+ userAction + ", createdBy=" + createdBy + "]";
	}
	


	
}