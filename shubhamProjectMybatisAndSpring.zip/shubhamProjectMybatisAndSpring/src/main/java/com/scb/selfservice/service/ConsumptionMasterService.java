/**
 * 
 */
package com.scb.selfservice.service;

import com.scb.selfservice.model.ConsumptionRequestInfo;

/**
 * Consumption Master Service to make entry into consumption Master table
 * 
 * @author Amarnath
 *
 */
public interface ConsumptionMasterService {
	
	/**
	 * Method to retrieve the request details for creating Consumption Master
	 * @param reqId
	 * @return
	 */
	public ConsumptionRequestInfo retrieveRequestDetails(String reqId);
	
	/**
	 * Method to create a new consumer Master record
	 */
	public String createOrUpdateConsumerMaster(String reqId, ConsumptionRequestInfo data);
	
	/**
	 * Method to create Audit Trail of Consumer Master creation
	 * @param reqId
	 * @param stepId
	 * @param userId
	 * @param status
	 * @param remarks
	 */
	public void createAuditTrailsData(Integer reqId, String stepId, String userId, String status, String remarks );

}
