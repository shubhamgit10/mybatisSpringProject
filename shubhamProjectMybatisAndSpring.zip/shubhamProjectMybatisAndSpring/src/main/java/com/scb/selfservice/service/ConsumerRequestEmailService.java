package com.scb.selfservice.service;

import com.scb.selfservice.util.Response;

public interface ConsumerRequestEmailService {
    /**
     * Method to send Edmp data consumption request status mail
     * @param reqId
     * @param stepId
     * @param stepAction
     */
    public void sendStatusMail(int reqId, String stepId, String stepAction);
    
    /**
     * 
     */
    public Response sendCostEstimationMail(Integer userId, Integer requestId, Integer estimationId);

    /* (non-Javadoc)
     * @see com.scb.selfservice.service.ConsumerRequestEmailService#sendRejectMail(int, java.lang.String, java.lang.String)
     * 
      * For Reject scenario, the call has to be made in a sync way.
     */
    public void sendRejectMail(int reqId, String stepId, String stepAction);
}
