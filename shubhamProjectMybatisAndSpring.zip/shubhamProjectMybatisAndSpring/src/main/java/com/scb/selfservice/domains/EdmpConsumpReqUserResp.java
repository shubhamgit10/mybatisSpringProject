package com.scb.selfservice.domains;

/*
 * pojo for 
 *  Update (Approve) or Reject
 *  EdmpConsumpReqUserResp
 */
public class EdmpConsumpReqUserResp {

	private Integer reqId;
	private String  stepId;
	private String  propertyName;
	private String  propertyValue;

	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getPropertyName() {
		return propertyName;
	}
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}
	public String getPropertyValue() {
		return propertyValue;
	}
	public void setProjertyValue(String propertyValue) {
		this.propertyValue = propertyValue;
	}
	@Override
	public String toString() {
		return "UpdateOrReject [reqId=" + reqId + ", stepId=" + stepId + ", propertyName=" + propertyName
				+ ", propertyValue=" + propertyValue + "]";
	}
}
