package com.scb.selfservice.isd.entity;

import java.util.Map;

/**
 * @author akuma400
 *
 */
public class ISDConfiguration {
 
	private String sheetName;
	private String configKey;
	private String configValue;
	
	public String getSheetName() {
		return sheetName;
	}
	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}
	public String getConfigKey() {
		return configKey;
	}
	public void setConfigKey(String configKey) {
		this.configKey = configKey;
	}
	public String getConfigValue() {
		return configValue;
	}
	public void setConfigValue(String configValue) {
		this.configValue = configValue;
	}
	@Override
	public String toString() {
		return "ISDConfiguration [sheetName=" + sheetName + ", configKey=" + configKey + ", configValue=" + configValue
				+ "]";
	}
	
	
	
}
