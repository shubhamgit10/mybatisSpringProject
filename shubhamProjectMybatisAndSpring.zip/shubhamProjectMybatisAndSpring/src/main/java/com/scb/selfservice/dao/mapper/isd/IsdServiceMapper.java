package com.scb.selfservice.dao.mapper.isd;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.scb.selfservice.isd.entity.ExceptionCategory;
import com.scb.selfservice.isd.entity.ISDConfiguration;
import com.scb.selfservice.isd.entity.ISDRequestDetails;
import com.scb.selfservice.isd.entity.ViewExceptions;

public interface IsdServiceMapper {
	
	public int saveISDSheet(@Param("isdInputs") ISDRequestDetails isdInputs , @Param("file") byte[] bytes );

	public List<ViewExceptions> fetchIsdExceptions(@Param("reqId") int reqId,@Param("versionNo") Integer versionNo);

	public void deleteLastExceptions(@Param("reqId") int reqId);

	public void deleteLastISDTemplate(@Param("reqId") int reqId, @Param("sheetDBTableName") String sheetDBTableName);

	public Integer fetchIsdLatestVersion(@Param("reqId") int reqId);

	public List<ExceptionCategory> fetchdetailedException(@Param("reqId") int reqId,@Param("versionNo") Integer versionNo);

	public List<ISDConfiguration> getIsdConfigDetails();

	public int updateFileName(@Param("reqId") int reqId, @Param("fileName") String fileName, @Param("tableName") String tableName);

	public void insertFileName(@Param("reqId") int reqId, @Param("fileName") String fileName, @Param("tableName") String tableName, @Param("stepId") String stepId);

	public String getTabeNameForStepId(@Param("stepId") String stepId);

}
