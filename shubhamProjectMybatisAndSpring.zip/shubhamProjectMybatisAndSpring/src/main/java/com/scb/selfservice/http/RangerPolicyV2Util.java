package com.scb.selfservice.http;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.domains.WorkflowReqStepsAt;
import com.scb.selfservice.domains.WorkflowRequestStep;
import com.scb.selfservice.model.ServerResponse;
import com.scb.selfservice.model.RangerPolicy.ConsumptionRangerPolicyModel;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyHdfsResourcesModel;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyHiveResourcesModel;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyModel;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyPolicyItems;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyRequestTypeEnum;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyResourcesModel;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyV2ReqModel;
import com.scb.selfservice.model.RangerPolicy.RangerPolicyV2RespModel;
import com.scb.selfservice.model.RangerPolicy.RepositoryTypeEnum;
import com.scb.selfservice.service.RangerPolicyService;
import com.scb.selfservice.workflow.service.WorkflowRequestService;

/**
 * 
 * Ranger Policy Utility class using V2 APIs
 * 
 * @author 1610601
 *
 */
@Service
public class RangerPolicyV2Util {
	
	@Autowired
	RangerPolicyV2 rangerPolicyV2;
	
	@Autowired
	RangerPolicyService rangerPolicyService;
	
	@Autowired
	WorkflowRequestService workflowRequestService;
	
	private static Logger logger = LogManager.getLogger(RangerPolicyV2Util.class);
	
	private static RepositoryTypeEnum[] repoTypesAllowed = {RepositoryTypeEnum.HIVE, RepositoryTypeEnum.HDFS};
	
	private boolean isPolicyExists = false; 
	
	
	public String processRangerPolicyRequest(String reqId, String stepId, String userId) {
		
		Long startTime = System.currentTimeMillis();
		logger.info("Initiated ranger policy request at : " +startTime);
		//This case won't come
		if(null == reqId || reqId.trim().isEmpty()) {
			logger.error("Request Id is mandatory : " + reqId);
			doLogRangerPolicyDetails(null, -1L, "", "", "", null, "Request Id is mandatory", false, "STEP_ID", startTime,userId);
			return "FAILURE";
		}
		
		Long requestId = Long.valueOf(reqId.trim());
		
		//This case won't come
		if(null == stepId || stepId.trim().isEmpty()) {
			logger.error("Step Id is mandatory : " + stepId);
			doLogRangerPolicyDetails(null, requestId, "", "", "", null, "Step Id is mandatory", false, "STEP_ID", startTime, userId);
			return "FAILURE";
		}
		logger.info("Fetching ranger policy details for the requestId : " +requestId);
		ConsumptionRangerPolicyModel consumptionRangerPolicyModel = rangerPolicyService.getRangerPoliciesByRequestId(requestId);
		logger.info("Fetched ranger policy details for the requestId : " +requestId + ", time taken : " +(System.currentTimeMillis() - startTime));
		if(null == consumptionRangerPolicyModel) {
			logger.error("Either request details are null or empty for the request id : " +requestId);
			doLogRangerPolicyDetails(null, requestId, "", "", "", null, "Either request details are null or empty", false, stepId, startTime, userId);
			logger.info("Ranger policy request processed for the requestId : " +requestId + ", time taken : " +(System.currentTimeMillis() - startTime));
			return "FAILURE";
		}
		if(consumptionRangerPolicyModel.getGroupName() == null || consumptionRangerPolicyModel.getGroupName().trim().isEmpty()) {
			logger.error("Group name is either null or empty for the request id : " +requestId);
			doLogRangerPolicyDetails(null, requestId, "", "", "", null, "Group name is either null or empty", false, stepId, startTime, userId);
			logger.info("Ranger policy request processed for the requestId : " +requestId + ", time taken : " +(System.currentTimeMillis() - startTime));
			return "FAILURE";
		}
		logger.debug("consumptionRangerPolicyModel : " +consumptionRangerPolicyModel);
		return doCreateOrUpdateRangerPolciy(requestId, consumptionRangerPolicyModel, stepId, startTime, userId);
	}
	
	private String doCreateOrUpdateRangerPolciy(Long requestId, 
			ConsumptionRangerPolicyModel consumptionRangerPolicyModel, 
			String stepId, Long startTime, String userId) {
		String groupName = consumptionRangerPolicyModel.getGroupName();
		ServerResponse resp = null;
		Long policiesCreationTime = System.currentTimeMillis();
		logger.info("Ranger policies creation started at : " +policiesCreationTime);
		for(String appName : consumptionRangerPolicyModel.getMetadataDetails().keySet()) {
			for(String country : consumptionRangerPolicyModel.getMetadataDetails().get(appName).keySet()) {
				logger.info("Initiated Ranger Policy Creation for reqId : " 
						+requestId + ", groupName : " +groupName + ", appName : " 
						+appName + ", instance : " +country);
				for(RepositoryTypeEnum repoType : repoTypesAllowed) {
					resp = doProcessCreateOrUpdateRangerPolicy(requestId, repoType, groupName, 
							country, appName, consumptionRangerPolicyModel.getMetadataDetails().get(appName).get(country));
					if(resp != null && resp.getStatusCode() == 200) {
						logger.info("Ranger Policy Created for reqId : " 
								+requestId + ", groupName : " +groupName + ", appName : " 
								+appName + ", instance : " +country + ", repoType : " +repoType);
						doLogRangerPolicyDetails(resp, requestId, appName, groupName, country, repoType, 
								"", true, stepId, startTime, userId);
					} else {
						logger.error("Error while creating Ranger Policy for reqId : " 
								+requestId + ", groupName : " +groupName +", appName : " 
								+appName +", instance : " +country + ", repoType : " +repoType);
						doLogRangerPolicyDetails(resp, requestId, appName, groupName, country, repoType, 
								"Error while processing request", true, stepId, startTime, userId);
						return "FAILURE";
					}
				}
			}
		}
		logger.info("Time taken to complete ranger policies creation : " + (System.currentTimeMillis() - policiesCreationTime));
		return "SUCCESS";
	}
	
	private ServerResponse doProcessCreateOrUpdateRangerPolicy(Long requestId, RepositoryTypeEnum repoType, 
			String groupName, String country, String appName, 
			Map<String, Map<String, Set<String>>> dbMetadata) {
		ServerResponse resp = null;
		RangerPolicyModel rangerPolicyModel = new RangerPolicyModel();
		rangerPolicyModel.setRequestId(requestId);
		rangerPolicyModel.setRepositoryType(repoType.toString().toLowerCase());
		rangerPolicyModel.setGroups(groupName);
		rangerPolicyModel.setPolicyName(groupName + "_" + appName.toLowerCase().trim() + "_" + country.toLowerCase().trim());
		rangerPolicyModel.setDescription(groupName + "_" + appName + "_" + country);
		rangerPolicyModel.setAppName(appName);
		rangerPolicyModel.setRequestType(RangerPolicyRequestTypeEnum.GET_POLICIES_BY_TYPE_AND_GROUP_AND_POLICYNAME);
		resp = rangerPolicyV2.processRequest(rangerPolicyModel);
		
		RangerPolicyV2ReqModel policy = null;
		
		if(resp != null) {
			if(resp.getStatusCode() == 200) {
				List<RangerPolicyV2RespModel> policies = (List<RangerPolicyV2RespModel>) resp.getOutput();
				if(null != policies) {
					policy = new RangerPolicyV2ReqModel();
					if(policies.isEmpty()) {
						logger.info("No policies exist for group : "+groupName +", repository type : " 
								+repoType + ", Policy name : " +rangerPolicyModel.getPolicyName());
						return doPopulateRangerPolicyDetails(requestId, null, repoType, false, dbMetadata, 
								policy, rangerPolicyModel.getPolicyName(), groupName, appName);
					} else {
						isPolicyExists = true;
						if(policies.size() == 1) {
							return doPopulateRangerPolicyDetails(requestId, policies.get(0), repoType, true, dbMetadata, 
									policy, rangerPolicyModel.getPolicyName(), groupName, appName);
						} else {
							//to-do: log an error or take last updated one
							logger.error("Fetching policies for type : " + 
									repoType + ", groupName : " +groupName + ", policyName : " + 
									rangerPolicyModel.getPolicyName() +", got more than one policy, policies count : " + policies.size());
							return new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, 
									"Fetching policies for type : " + 
									repoType + ", groupName : " +groupName + ", policyName : " + 
									rangerPolicyModel.getPolicyName() +", got more than one policy, policies count : " + policies.size());
						}
					}
				}
			} else {
				logger.error("Fetching policies for type : " + 
						repoType + ", groupName : " +groupName + ", policyName : " + 
						rangerPolicyModel.getPolicyName() +", response status code : " 
						+ resp.getStatusCode() + ", Status Message : " +resp.getStatusMessage());
//				return new ResponseEntity<> (HttpStatus.valueOf(resp.getStatusCode()));
				return resp;
			}
		} else {
			logger.error("Error while fetching policies for type : " 
					+ repoType + ", groupName : " +groupName + ", policyName : " 
					+rangerPolicyModel.getPolicyName());
			return new ServerResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Error while fetching policies for type : " 
					+ repoType + ", groupName : " +groupName + ", policyName : " +rangerPolicyModel.getPolicyName());
//			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return resp;
	}
	
	private ServerResponse doPopulateRangerPolicyDetails(Long requestId, RangerPolicyV2RespModel respPolicy, RepositoryTypeEnum repoType, 
			boolean isToUpdatePolicy, Map<String, Map<String, Set<String>>> metadata, RangerPolicyV2ReqModel policy, 
			String policyName, String groupName, String appName) {
		
		RangerPolicyResourcesModel resources = null;
		if(RepositoryTypeEnum.HIVE == repoType) {
			resources = new RangerPolicyHiveResourcesModel();
		} else if(RepositoryTypeEnum.HDFS == repoType) {
			resources = new RangerPolicyHdfsResourcesModel();
		}
		if(isToUpdatePolicy) {
			policy.setId(respPolicy.getId());
			policy.setPolicyType(respPolicy.getPolicyType());
			policy.setName(respPolicy.getName());
			policy.setDescription(respPolicy.getDescription());
			if(resources instanceof RangerPolicyHiveResourcesModel) {
				((RangerPolicyHiveResourcesModel) resources).setDatabase(respPolicy.getResources().getDatabase());
				((RangerPolicyHiveResourcesModel) resources).setColumn(respPolicy.getResources().getColumn());
				((RangerPolicyHiveResourcesModel) resources).setTable(respPolicy.getResources().getTable());
			} else if (resources instanceof RangerPolicyHdfsResourcesModel) {
				((RangerPolicyHdfsResourcesModel) resources).setPath(respPolicy.getResources().getPath());
			}
		} else {
			policy.setServiceType(repoType.toString().toLowerCase());
			policy.setPolicyType(0);
			policy.setName(policyName);
			policy.setDescription(policyName);
		}
		
		Set<String> pathValues = null;
		
		switch(repoType) {
		case HIVE:
			Set<String> databaseValues = new HashSet<String>(((RangerPolicyHiveResourcesModel) resources).getDatabase().getValues());
			Set<String> columnValues = new HashSet<String>(((RangerPolicyHiveResourcesModel) resources).getColumn().getValues());
			Set<String> tableValues = new HashSet<String>(((RangerPolicyHiveResourcesModel) resources).getTable().getValues());
			
			for(String database : metadata.keySet()) {
				databaseValues.add(database.trim());
				for(String column : metadata.get(database).keySet()) {
					columnValues.add((column.trim().equalsIgnoreCase("all")) ? "*" : column.trim());
					for(String table : metadata.get(database).get(column)) {
						tableValues.add(table.trim());
					}
				}
			}
			
			List<String> databases = new ArrayList<String> ();
			databases.addAll(databaseValues);
			((RangerPolicyHiveResourcesModel) resources).getDatabase().setValues(databases);
			
			List<String> tables = new ArrayList<String>();
			tables.addAll(tableValues);
//			this is to add dummy table as Ranger policy is not letting 
//			to create multiple policies against different AD Group names
//			if the request contains same data e.g., tables in the existing
//			policy/policies which has same set of data but different AD Group
			tables.add("TBL_" + requestId);
			((RangerPolicyHiveResourcesModel) resources).getTable().setValues(tables);
			
			List<String> columns = new ArrayList<String>();
			columns.addAll(columnValues);
			((RangerPolicyHiveResourcesModel) resources).getColumn().setValues(columns);
			break;
		case HDFS:
//			Set<String> pathValues = new HashSet<String>(((RangerPolicyHdfsResourcesModel) resources).getPath().getValues());
			pathValues = new HashSet<String> ();
//			this is to add dummy table as Ranger policy is not letting 
//			to create multiple policies against different AD Group names
//			if the request contains same data e.g., tables in the existing
//			policy/policies which has same set of data but different AD Group
			pathValues.add("TBL_" + requestId);
			for(String database : metadata.keySet()) {
				for(String column : metadata.get(database).keySet()) {
					for(String table : metadata.get(database).get(column)) {
						pathValues.add(database.toLowerCase().trim() + "/" + table.trim());
					}
				}
			}
		default:
			break;
		}
		
		policy.setResources(resources);
		
		List<RangerPolicyPolicyItems> policyItems = policy.getPolicyItems();
		RangerPolicyPolicyItems policyItem = null;
		if(policyItems != null && policyItems.isEmpty()) {
			policyItem = new RangerPolicyPolicyItems();
//			RangerPolicyAccesses access = new RangerPolicyAccesses();
//			policyItem.getAccesses().add(access);
			policyItems.add(policyItem);
		}
		if(policyItems != null && policyItems.size() == 1) {
			policyItem = policyItems.get(0);
			List<String> groups = policyItem.getGroups();
			if(!groups.contains(groupName)) {
				groups.add(groupName);
			}
		}
		
		return rangerPolicyV2.processRequest(policy, pathValues, repoType, 
				isToUpdatePolicy ? RangerPolicyRequestTypeEnum.UPDATE_POLICY : RangerPolicyRequestTypeEnum.CREATE_POLICY, 
						appName, requestId);
	}
	
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	private void doLogRangerPolicyDetails(ServerResponse resp, Long requestId, String appName, 
			String groupName, String instance, RepositoryTypeEnum repoType, String errorMsg, 
			boolean isReqProcessed, String stepId, Long startTime, String userId) {
		String policyName = "";
		Long policyId = -1L;
		String policyCreateType = isReqProcessed ? isPolicyExists ? "UPDATE" : "CREATE" : "UNPROCESSED";
		String policyType = "GENERAL"; //GENERAL, MASTER, MASK
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-YYYY hh:mm:ss a");
		String status = "FAILED"; //SUCCESS, FAILED
		String repType = (repoType == null) ? "" : repoType.toString();
		try {
			logger.info("Log Ranger Policy details in database");
			if(null != resp) {
				if(resp.getStatusCode() == 200) {
					RangerPolicyV2RespModel policy = (RangerPolicyV2RespModel) resp.getOutput();
					policyName = policy.getName();
					policyId = policy.getId();
					status = "SUCCESS";
					errorMsg = repoType + " Policy Creation Successfull for " + groupName + " - " + policyId + "/" + policyName;
				} else {
					errorMsg = (resp.getOutput() == null) ? resp.getStatusMessage() : resp.getOutput().toString();
				}
			} 
			logger.info("Logging Ranger Policy Details :::: requestId : " + requestId +", appName : " 
					+ appName + ", instance : " +instance + ", groupName : " +groupName + ", policyName : " 
					+ policyName + ", policyId : " +policyId +", policyCreateType : " + policyCreateType 
					+ ", policyType : " +policyType + ", status : " +status + ", errorMsg : " +errorMsg 
					+ ", repoType : " +repType +", createOrUpdateTime : " + formatter.format(date));
			rangerPolicyService.addRangerPolicyDetails(requestId, appName, instance, groupName, 
					policyName, policyId, policyCreateType, policyType, status, errorMsg, 
					repType, formatter.format(date), formatter.format(date));
			logger.info("Ranger Policy details successfully logged for the requestId : " +requestId );
			
			// create an Audit trail of the request
			WorkflowReqStepsAt workflowReqStepsAt = new WorkflowReqStepsAt();
			workflowReqStepsAt.setReqId(requestId.intValue());
			workflowReqStepsAt.setStepId(String.valueOf(stepId));
			workflowReqStepsAt.setStepActionedBy(Integer.valueOf(userId));
			workflowReqStepsAt.setWorkflowId(workflowRequestService.getWorkflowRequestWorkflowId(requestId.intValue()));
			workflowReqStepsAt.setStartTime(new Timestamp(startTime));
			workflowReqStepsAt.setStepPendingGrp("INITIATE_FULLFILLMENT");
			workflowReqStepsAt.setStatus("SUCCESS".equalsIgnoreCase(status)?"COMPLETED":status);
			workflowReqStepsAt.setRemarks(errorMsg);
			logger.info("Logging workflowReqStepsAt while processing ranger policy request : " 
					+requestId +", with details workflowReqStepsAt : " +workflowReqStepsAt);
			workflowRequestService.insertIntoWorkflowReqStepsAt(workflowReqStepsAt);
			logger.info("WorkflowReqStepsAt details logged successfully.");			
			
			if(!"success".equalsIgnoreCase(status)) {
				logger.info("Pushing back the request to INITIATE FULLFILMENT Step for the ReqId : " +requestId);
				String parentStepId = rangerPolicyService.getParentStepId(requestId, String.valueOf(stepId));
				WorkflowRequestStep workflowRequestStep = new WorkflowRequestStep(requestId.intValue(), 
						parentStepId, "PENDING", errorMsg, new Timestamp(startTime), 
						null, "FULLFILMENT", null, Integer.valueOf(userId), "");
				logger.info("With WorkflowRequestStep details : " +workflowRequestStep);
				workflowRequestService.updateWorkflowReqSteps(workflowRequestStep);
				logger.info("WorkflowRequestStep details are logged successfully");
			}
			
		} catch(Exception e) {
			logger.error("Error while logging ranger policy details in database for the requestId : " +requestId 
					+" :::: " +e.getMessage());
			e.printStackTrace();
		}
		
	}

}
