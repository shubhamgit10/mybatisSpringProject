package com.scb.selfservice.serviceType;

import java.util.Map;

public interface ServiceCall {
	public String execute(Map<String, String> params);
}
