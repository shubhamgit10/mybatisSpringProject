package com.scb.selfservice.service;

import com.scb.selfservice.domains.IngestionInput;
import com.scb.selfservice.util.Response;

public interface UserResponseService {
	
	public Response executeSave(IngestionInput ingestionInput);
	
	public Response fetchApprovalResponse(IngestionInput ingestionInput);
	
}
