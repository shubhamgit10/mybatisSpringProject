package com.scb.selfservice.service;

import java.util.HashMap;

import com.scb.selfservice.domains.IngestionWorkflowResponse;
import com.scb.selfservice.util.Response;

public interface MyRequestService {
	
	public Response getMyRequest(Integer userId, String workflowType);
	
	public Response getApprovalWorkflow(Integer requestId, String workflowType) throws Exception;

	//method to 'cancel' requestor's submitted workflow_request
	public Response cancelRequest(HashMap<String, String> cancelMap) throws Exception;
	//Ingestion - Fetch list of user request
	public Response getMyIngestionRequest(Integer userId, String worflowType);
	//Ingestion - 
	public Response getIngestionApprovalWorkflow(Integer requestId, String workflowType) throws Exception;
}
