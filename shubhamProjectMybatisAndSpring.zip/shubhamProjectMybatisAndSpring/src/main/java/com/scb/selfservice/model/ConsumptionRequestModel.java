package com.scb.selfservice.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 
 * @author 1610601
 *
 */
public class ConsumptionRequestModel {
	
	private Long requestId;
	private String appName;
	private String databaseName;
	private String country;
	private String tableName;
	private String columnName;
	private String groupName;
	
	/**
	 * 
	 */
	public ConsumptionRequestModel() {
	}

	/**
	 * @param requestId
	 * @param appName
	 * @param country
	 * @param tables
	 * @param columns
	 * @param groupName
	 */
	public ConsumptionRequestModel(Long requestId, String appName, String databaseName, 
			String country, String tables, String columnName, String groupName) {
		super();
		this.requestId = requestId;
		this.appName = appName;
		this.databaseName = databaseName;
		this.country = country;
		this.tableName = tables;
		this.columnName = columnName;
		this.groupName = groupName;
	}

	/**
	 * @return the requestId
	 */
	public Long getRequestId() {
		return requestId;
	}

	/**
	 * @param requestId the requestId to set
	 */
	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	/**
	 * @return the appName
	 */
	public String getAppName() {
		return appName;
	}

	/**
	 * @param appName the appName to set
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}
	
	

	/**
	 * @return the databaseName
	 */
	public String getDatabaseName() {
		return databaseName;
	}

	/**
	 * @param databaseName the databaseName to set
	 */
	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}

	/**
	 * @return the tableName
	 */
	public String getTableName() {
		return tableName;
	}

	/**
	 * @param tableName the tableName to set
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the columnName
	 */
	public String getColumnName() {
		return columnName;
	}
	
	/**
	 * @param columnName the columnName to set
	 */
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	/**
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}

	/**
	 * @param groupName the groupName to set
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	@Override
	public String toString() {
		return "ConsumptionRequestModel [requestId=" + requestId + ", appName=" + appName + ", databaseName="
				+ databaseName + ", country=" + country + ", tableName=" + tableName + ", columnName=" + columnName
				+ ", groupName=" + groupName + "]";
	}
	
}
