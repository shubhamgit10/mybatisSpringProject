package com.scb.selfservice.model;

import java.util.List;

public class EmailAddressDetails {

    protected String distributionType;
    protected List<String> eMailAddress;

    public String getDistributionType() {
        return distributionType;
    }

    public void setDistributionType(String distributionType) {
        this.distributionType = distributionType;
    }

    public List<String> geteMailAddress() {
        return eMailAddress;
    }

    public void seteMailAddress(List<String> eMailAddress) {
        this.eMailAddress = eMailAddress;
    }
}
