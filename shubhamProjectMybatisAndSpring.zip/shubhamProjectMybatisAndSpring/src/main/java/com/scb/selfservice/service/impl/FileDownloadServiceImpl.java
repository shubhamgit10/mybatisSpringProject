package com.scb.selfservice.service.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.FileDownloadMapper;
import com.scb.selfservice.domains.FileData;
import com.scb.selfservice.domains.FileUpload;
import com.scb.selfservice.service.FileDownloadService;

@Service
public class FileDownloadServiceImpl implements FileDownloadService {

	private static Logger logger = LogManager.getLogger(FileDownloadServiceImpl.class);
	
	@Autowired
	FileDownloadMapper fileDownloadMapper;

	@Override
	@Transactional
	public List<FileData> pullData(Integer reqId) {
		logger.info("STARTED FileDownloadServiceImpl::pullData");
		List<FileData> fileData = fileDownloadMapper.pullData(reqId);
		logger.info("EXITING FileDownloadServiceImpl::pullData");
		return fileData;
	}

	@Override
	@Transactional
	public FileUpload pullFile(Integer uploadId) {
		logger.info("STARTED FileDownloadServiceImpl::pullFile");
		FileUpload data = fileDownloadMapper.pullFile(uploadId);
		logger.info("EXITING FileDownloadServiceImpl::pullFile");
		return data;
	}

}
