package com.scb.selfservice.domains;

public class EDMPLookupTable {

	private Integer LookupId;
	private String  TableName;
	private String  Code;
	private String  Description;
	private Integer ParentId;
	public Integer getLookupId() {
		return LookupId;
	}
	public void setLookupId(Integer lookupId) {
		LookupId = lookupId;
	}
	public String getTableName() {
		return TableName;
	}
	public void setTableName(String tableName) {
		TableName = tableName;
	}
	public String getCode() {
		return Code;
	}
	public void setCode(String code) {
		Code = code;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public Integer getParentId() {
		return ParentId;
	}
	public void setParentId(Integer parentId) {
		ParentId = parentId;
	}
	
	
	
	
}
