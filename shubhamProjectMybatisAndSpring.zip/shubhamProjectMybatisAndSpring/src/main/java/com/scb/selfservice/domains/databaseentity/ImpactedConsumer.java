package com.scb.selfservice.domains.databaseentity;

public class ImpactedConsumer {
	private String reqId;
	private Integer sourceSystem;
	private String datasetName;
	private String consumerContact;
	private String impactedConsumer;
	private Integer impactAnalysisStatus;

	public String getReqId() {
		return reqId;
	}

	public void setReqId(String reqId) {
		this.reqId = reqId;
	}

	public Integer getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(Integer sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getDatasetName() {
		return datasetName;
	}

	public void setDatasetName(String datasetName) {
		this.datasetName = datasetName;
	}

	public String getConsumerContact() {
		return consumerContact;
	}

	public void setConsumerContact(String consumerContact) {
		this.consumerContact = consumerContact;
	}

	public String getImpactedConsumer() {
		return impactedConsumer;
	}

	public void setImpactedConsumer(String impactedConsumer) {
		this.impactedConsumer = impactedConsumer;
	}

	public Integer getImpactAnalysisStatus() {
		return impactAnalysisStatus;
	}

	public void setImpactAnalysisStatus(Integer impactAnalysisStatus) {
		this.impactAnalysisStatus = impactAnalysisStatus;
	}

	@Override
	public String toString() {
		return "ImpactedConsumer [reqId=" + reqId + ", sourceSystem=" + sourceSystem + ", datasetName=" + datasetName
				+ ", consumerContact=" + consumerContact + ", impactedConsumer=" + impactedConsumer
				+ ", impactAnalysisStatus=" + impactAnalysisStatus + "]";
	}

}
