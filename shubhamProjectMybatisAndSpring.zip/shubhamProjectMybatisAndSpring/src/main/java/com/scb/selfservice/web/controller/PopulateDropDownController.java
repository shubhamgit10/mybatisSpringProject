package com.scb.selfservice.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.service.PopulateDropDownService;
import com.scb.selfservice.util.Response;

@RestController
@RequestMapping("/api/populateDropDownValues")
public class PopulateDropDownController {

	
	@Autowired
	private PopulateDropDownService populateDropDownService; 
	
	@RequestMapping(path = "/getDropDownValues", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Response> getDropDownValues() {
		Response dataSourceResponse = populateDropDownService.getDropDownValues();
		return new ResponseEntity<Response>(dataSourceResponse,HttpStatus.OK);
    }
	
	@RequestMapping(path = "/getConsumerAdRole", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Response> getConsumerAdRole() {
		Response consumerAdRole = populateDropDownService.getConsumerAdRole();
		return new ResponseEntity<Response>(consumerAdRole,HttpStatus.OK);
    }
	
}
