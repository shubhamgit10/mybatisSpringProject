package com.scb.selfservice.web.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.scb.selfservice.domains.FilterRequest;
import com.scb.selfservice.domains.SearchRequest;
import com.scb.selfservice.service.SearchService;
import com.scb.selfservice.util.Response;

@RestController
@RequestMapping("/api/searchData")
public class SearchController {

	@Autowired
	SearchService searchService;

	private static Logger logger = LogManager.getLogger(SearchController.class);
	
	//Search based on datasource
	@PostMapping(path = "/searchDataSource", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> searchDataSource(@RequestBody SearchRequest searchRequest) {
		Response seaarchDataSourceResponse = searchService.searchDataSource(searchRequest);
		return new ResponseEntity<Response>(seaarchDataSourceResponse, HttpStatus.OK);
	}

	//Search based on dataset
	@PostMapping(path = "/searchDataSet", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> searchDataSet(@RequestBody SearchRequest searchRequest) {
		Response seaarchDataSetResponse = searchService.searchDataSet(searchRequest);
		return new ResponseEntity<Response>(seaarchDataSetResponse, HttpStatus.OK);
	}

	//Search based on attribute
	@PostMapping(path = "/searchAttribute", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> searchAttribute(@RequestBody SearchRequest searchRequest) {
		Response seaarchAttributeResponse = searchService.searchAttribute(searchRequest);
		return new ResponseEntity<Response>(seaarchAttributeResponse, HttpStatus.OK);
	}


	//Search based on attribute
	@PostMapping(path = "/searchApplyFilter", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> searchApplyFilter(@RequestBody FilterRequest filterRequest) {
		logger.info("Proceeding for search based on Applyfilter");
		Response seaarchApplyFilterResponse = searchService.searchApplyFilter(filterRequest);
		return new ResponseEntity<Response>(seaarchApplyFilterResponse, HttpStatus.OK);
	}

}
