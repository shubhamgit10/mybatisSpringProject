package com.scb.selfservice.domains;

import java.util.Arrays;

/*
 * pojo for
 *     File to be uploaded
 */
public class FileUpload {

	private Integer uploadId;
    private String fileName;
    private String fileType;
    private byte[] content;
    private Integer userId;
    
	public Integer getUploadId() {
		return uploadId;
	}
	public void setUploadId(Integer uploadId) {
		this.uploadId = uploadId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public byte[] getContent() {
		return content;
	}
	public void setContent(byte[] content) {
		this.content = content;
	}
	
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	@Override
	public String toString() {
		return "FileUpload [uploadId=" + uploadId + ", fileName=" + fileName + ", fileType=" + fileType + ", content="
				+ Arrays.toString(content) + ", userId=" + userId + "]";
	}
	
}