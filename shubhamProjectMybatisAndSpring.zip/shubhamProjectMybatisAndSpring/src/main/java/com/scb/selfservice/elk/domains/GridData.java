package com.scb.selfservice.elk.domains;

import java.util.List;
/*
pojo for grid data
*/
public class GridData {
	private String       itamId;
	private String       dataSetName; //table name
	private String       dataSetDesc;
	private String       cde;
	private List<String> segment;
	private String       appName;    //datasource
	private String       appDesc;
	private String       pii;
	private List<String> colnames;   //attribute
	private Integer      attribCnt;
	private Integer      matchAttribCnt;
	private String       certified;
	private List<String> country;
	public String getItamId() {
		return itamId;
	}
	public void setItamId(String itamId) {
		this.itamId = itamId;
	}
	public String getDataSetName() {
		return dataSetName;
	}
	public void setDataSetName(String dataSetName) {
		this.dataSetName = dataSetName;
	}
	public String getDataSetDesc() {
		return dataSetDesc;
	}
	public void setDataSetDesc(String dataSetDesc) {
		this.dataSetDesc = dataSetDesc;
	}
	public String getCde() {
		return cde;
	}
	public void setCde(String cde) {
		this.cde = cde;
	}
	public List<String> getSegment() {
		return segment;
	}
	public void setSegment(List<String> segment) {
		this.segment = segment;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getAppDesc() {
		return appDesc;
	}
	public void setAppDesc(String appDesc) {
		this.appDesc = appDesc;
	}
	public String getPii() {
		return pii;
	}
	public void setPii(String pii) {
		this.pii = pii;
	}
	public List<String> getColnames() {
		return colnames;
	}
	public void setColnames(List<String> colnames) {
		this.colnames = colnames;
	}
	public Integer getAttribCnt() {
		return attribCnt;
	}
	public void setAttribCnt(Integer attribCnt) {
		this.attribCnt = attribCnt;
	}
	public Integer getMatchAttribCnt() {
		return matchAttribCnt;
	}
	public void setMatchAttribCnt(Integer matchAttribCnt) {
		this.matchAttribCnt = matchAttribCnt;
	}
	public String getCertified() {
		return certified;
	}
	public void setCertified(String certified) {
		this.certified = certified;
	}
	public List<String> getCountry() {
		return country;
	}
	public void setCountry(List<String> country) {
		this.country = country;
	}
	@Override
	public String toString() {
		return "GridData [itamId=" + itamId + ", dataSetName=" + dataSetName + ", dataSetDesc=" + dataSetDesc + ", cde="
				+ cde + ", segment=" + segment + ", appName=" + appName + ", appDesc=" + appDesc + ", pii=" + pii
				+ ", colnames=" + colnames + ", attribCnt=" + attribCnt + ", matchAttribCnt=" + matchAttribCnt
				+ ", certified=" + certified + ", country=" + country + "]";
	}

}
