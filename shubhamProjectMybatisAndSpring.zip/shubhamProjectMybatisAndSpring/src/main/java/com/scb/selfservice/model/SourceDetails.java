package com.scb.selfservice.model;

public class SourceDetails {
    protected int sourceId;
    protected String sourceSystem;
    protected String countryCode;
    protected String appUserId;
    protected String appDRUserId;

    public int getSourceId() {
        return sourceId;
    }

    public void setSourceId(int sourceId) {
        this.sourceId = sourceId;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getAppUserId() {
        return appUserId;
    }

    public void setAppUserId(String appUserId) {
        this.appUserId = appUserId;
    }

    public String getAppDRUserId() {
        return appDRUserId;
    }

    public void setAppDRUserId(String appDRUserId) {
        this.appDRUserId = appDRUserId;
    }
}
