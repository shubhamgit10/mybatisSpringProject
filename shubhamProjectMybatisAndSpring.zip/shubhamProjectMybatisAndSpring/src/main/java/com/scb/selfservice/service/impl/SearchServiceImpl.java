package com.scb.selfservice.service.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.selfservice.dao.mapper.SearchMapper;
import com.scb.selfservice.domains.FilterRequest;
import com.scb.selfservice.domains.SearchDataSource;
import com.scb.selfservice.domains.SearchRequest;
import com.scb.selfservice.service.SearchService;
import com.scb.selfservice.util.CommonUtils;
import com.scb.selfservice.util.Response;

@Service
public class SearchServiceImpl implements SearchService {

	private static Logger logger = LogManager.getLogger(SearchServiceImpl.class);

	@Autowired
	SearchMapper searchMapper;

	@Override
	@Transactional
	public Response searchDataSource(SearchRequest searchRequest) {
		logger.info("searchDataSource for: "+ searchRequest.getSearchValue());
		List<SearchDataSource> searchDataSource = searchMapper.searchDataSource(searchRequest.getSearchValue(),searchRequest.getStartNum(),searchRequest.getEndNum());
		Response searchDataSourceResponse = CommonUtils.processSearchResults(searchDataSource);
		return searchDataSourceResponse;
	}

	@Override
	@Transactional
	public Response searchDataSet(SearchRequest searchRequest) {
		logger.info("searchDataSet for: "+ searchRequest.getSearchValue());
		List<SearchDataSource> searchDataSets = searchMapper.searchDataSet(searchRequest.getSearchValue(),searchRequest.getStartNum(),searchRequest.getEndNum());
		Response searchDataSetResponse = CommonUtils.processSearchResults(searchDataSets);
		return searchDataSetResponse;
	}

	@Override
	@Transactional
	public Response searchAttribute(SearchRequest searchRequest) {
		logger.info("searchAttribute for: "+ searchRequest.getSearchValue());
		List<SearchDataSource> attributeSearch = searchMapper.searchAttribute(searchRequest.getSearchValue(),searchRequest.getStartNum(),searchRequest.getEndNum());
		Response searchAttributeResponse = CommonUtils.processSearchResults(attributeSearch);
		return searchAttributeResponse;
	}

	/*
	 * service method for search based on ApplyFilter
	 */
	@Override
	@Transactional
	public Response searchApplyFilter(FilterRequest filterRequest) {
		String sqlPrepared = CommonUtils.prepareSql(filterRequest);
		List<SearchDataSource> applyfilter = searchMapper.searchApplyFilter(sqlPrepared,filterRequest.getStartNum(),filterRequest.getEndNum());
		
		Response searchApplyFilterResponse = new Response();
		searchApplyFilterResponse = CommonUtils.processSearchResults(applyfilter);
		
		return searchApplyFilterResponse;
	}
}
