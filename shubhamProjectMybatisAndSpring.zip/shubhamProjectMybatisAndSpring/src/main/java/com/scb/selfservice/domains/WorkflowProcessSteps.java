package com.scb.selfservice.domains;


/*
 * pojo for
 * 	WORKFLOW_REQUEST_STEPS
 */
public class WorkflowProcessSteps {

	private Integer workflowId;
	private String  stepId;
	private String  stepName;
	private Integer stepSeq;
	private String  stepType;
	private String  stepUserGroup;
	private String  rejectStepId;
	private String  serviceStepClass;
	private String  parentStepId;
	private String  nextStepId;
	private String  status;
	private Integer createdBy;
	private Integer modifiedBy;

	public Integer getWorkflowId() {
		return workflowId;
	}
	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getStepName() {
		return stepName;
	}
	public void setStepName(String stepName) {
		this.stepName = stepName;
	}
	public Integer getStepSeq() {
		return stepSeq;
	}
	public void setStepSeq(Integer stepSeq) {
		this.stepSeq = stepSeq;
	}
	public String getStepType() {
		return stepType;
	}
	public void setStepType(String stepType) {
		this.stepType = stepType;
	}
	public String getStepUserGroup() {
		return stepUserGroup;
	}
	public void setStepUserGroup(String stepUserGroup) {
		this.stepUserGroup = stepUserGroup;
	}
	public String getRejectStepId() {
		return rejectStepId;
	}
	public void setRejectStepId(String rejectStepId) {
		this.rejectStepId = rejectStepId;
	}
	public String getServiceStepClass() {
		return serviceStepClass;
	}
	public void setServiceStepClass(String serviceStepClass) {
		this.serviceStepClass = serviceStepClass;
	}
	public String getParentStepId() {
		return parentStepId;
	}
	public void setParentStepId(String parentStepId) {
		this.parentStepId = parentStepId;
	}
	public String getNextStepId() {
		return nextStepId;
	}
	public void setNextStepId(String nextStepId) {
		this.nextStepId = nextStepId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	@Override
	public String toString() {
		return "WorkflowProcessSteps [workflowId=" + workflowId + ", stepId=" + stepId + ", stepName=" + stepName
				+ ", stepSeq=" + stepSeq + ", stepType=" + stepType + ", stepUserGroup=" + stepUserGroup
				+ ", rejectStepId=" + rejectStepId + ", serviceStepClass=" + serviceStepClass + ", parentStepId="
				+ parentStepId + ", nextStepId=" + nextStepId + ", status=" + status + ", createdBy=" + createdBy
				+ ", modifiedBy=" + modifiedBy + "]";
	}

}
