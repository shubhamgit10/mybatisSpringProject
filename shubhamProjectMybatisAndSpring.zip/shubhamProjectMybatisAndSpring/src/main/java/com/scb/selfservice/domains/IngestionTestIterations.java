package com.scb.selfservice.domains;

import java.sql.Date;

public class IngestionTestIterations {

	private Integer reqId;

	private Integer iterationNum;

	private String stepId;

	private Date validationStartDate;

	private Date validationEndDate;

	private String dataSource;

	private String instanceToBeCovered;

	private Integer totalIssues;

	private String executionStatus;

	private Integer exceptions;

	public Integer getReqId() {
		return reqId;
	}

	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}

	public Integer getIterationNum() {
		return iterationNum;
	}

	public void setIterationNum(Integer iterationNum) {
		this.iterationNum = iterationNum;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	public Date getValidationStartDate() {
		return validationStartDate;
	}

	public void setValidationStartDate(Date validationStartDate) {
		this.validationStartDate = validationStartDate;
	}

	public Date getValidationEndDate() {
		return validationEndDate;
	}

	public void setValidationEndDate(Date validationEndDate) {
		this.validationEndDate = validationEndDate;
	}

	public String getInstanceToBeCovered() {
		return instanceToBeCovered;
	}

	public void setInstanceToBeCovered(String instanceToBeCovered) {
		this.instanceToBeCovered = instanceToBeCovered;
	}

	public Integer getTotalIssues() {
		return totalIssues;
	}

	public void setTotalIssues(Integer totalIssues) {
		this.totalIssues = totalIssues;
	}

	public String getExecutionStatus() {
		return executionStatus;
	}

	public void setExecutionStatus(String executionStatus) {
		this.executionStatus = executionStatus;
	}

	public Integer getExceptions() {
		return exceptions;
	}

	public void setExceptions(Integer exceptions) {
		this.exceptions = exceptions;
	}

	@Override
	public String toString() {
		return "IngestionTestIterations [reqId=" + reqId + ", iterationNum=" + iterationNum + ", stepId=" + stepId
				+ ", validationStartDate=" + validationStartDate + ", validationEndDate=" + validationEndDate
				+ ", dataSource=" + dataSource + ", instanceToBeCovered=" + instanceToBeCovered + ", totalIssues="
				+ totalIssues + ", executionStatus=" + executionStatus + ", exceptions=" + exceptions + "]";
	}

}
