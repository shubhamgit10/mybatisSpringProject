package com.scb.selfservice.workflow.service;

import com.scb.selfservice.domains.WorkflowProcess;
import com.scb.selfservice.util.Response;

/*
 * Interface for workflow process service
 * 		to get all the process available
 * 		in WORKFLOW_PROCESS
 */
public interface WorkflowProcessService {

	//public List<WorkflowProcess> getWorkflowProcessDetails();
	public Response getWorkflowProcessDetails();

	public WorkflowProcess getWorkflowProcessDetailById(Integer workflowId);
}
