package com.scb.selfservice.domains;

import java.sql.Timestamp;

public class BizAnylstResponse {
	
	private Integer reqId;
	
	private Integer requestCreatedBy;
	
	private String fileName;
	
	private String stepId;
	
	private String userAction;
	
	private Integer workflowId;
	
	private String workflowType;
	
	private Timestamp requestCreatedAt; 
	
	private String remarks;
	
	public Integer getReqId() {
		return reqId;
	}

	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}

	
	public Integer getRequestCreatedBy() {
		return requestCreatedBy;
	}

	public void setRequestCreatedBy(Integer requestCreatedBy) {
		this.requestCreatedBy = requestCreatedBy;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}

	public String getUserAction() {
		return userAction;
	}

	public void setUserAction(String userAction) {
		this.userAction = userAction;
	}

	public String getWorkflowType() {
		return workflowType;
	}

	public void setWorkflowType(String workflowType) {
		this.workflowType = workflowType;
	}

	public Timestamp getRequestCreatedAt() {
		return requestCreatedAt;
	}

	public void setRequestCreatedAt(Timestamp requestCreatedAt) {
		this.requestCreatedAt = requestCreatedAt;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "BizAnylstResponse [reqId=" + reqId + ", requestCreatedBy=" + requestCreatedBy + ", fileName=" + fileName
				+ ", stepId=" + stepId + ", userAction=" + userAction + ", workflowId=" + workflowId + ", workflowType="
				+ workflowType + ", requestCreatedAt=" + requestCreatedAt + ", remarks=" + remarks + "]";
	}

}
