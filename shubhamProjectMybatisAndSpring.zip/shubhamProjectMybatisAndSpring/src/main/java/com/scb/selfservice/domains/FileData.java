package com.scb.selfservice.domains;

import java.util.ArrayList;
import java.util.List;

import com.scb.selfservice.util.WorkflowConstants;

/*
 * pojo for
 *     file download of type XLSX
 */
public class FileData {

	private Integer reqId;
	private Integer instanceReqNo;
	private String status;
	private String itamId; 
	private String itamDescription; //
	private String appName;
	private String appDescription; 
	private String country;
	private String productCategory; 
//	private String segment; // removed on 4th Aug and as part of defect raised
	private String tableName;
	private String tableDescription;
	private String columnName;
	private String columnDescription;
	private String businessTerm;
	private String businessDescription;
	private String certified;
	private String piiCols;
	private String cdeCol;
	private String dataType;
	private String dataLength;
	private String dataLineage;
	private String dataXray;
	private String databaseName; //added past of Admin (Ref:EDMPINTPRJ-1201)

	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}
	public Integer getInstanceReqNo() {
		return instanceReqNo;
	}
	public void setInstanceReqNo(Integer instanceReqNo) {
		this.instanceReqNo = instanceReqNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		if (status.equalsIgnoreCase(WorkflowConstants.REJECTED)) {
			this.status = "Referred back";
		} else {
			this.status = status;
		}
	}
	public String getItamId() {
		return itamId;
	}
	public void setItamId(String itamId) {
		this.itamId = itamId;
	}
	public String getItamDescription() {
		return itamDescription;
	}
	public void setItamDescription(String itamDescription) {
		this.itamDescription = itamDescription;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getAppDescription() {
		return appDescription;
	}
	public void setAppDescription(String appDescription) {
		this.appDescription = appDescription;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getTableDescription() {
		return tableDescription;
	}
	public void setTableDescription(String tableDescription) {
		this.tableDescription = tableDescription;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getColumnDescription() {
		return columnDescription;
	}
	public void setColumnDescription(String columnDescription) {
		this.columnDescription = columnDescription;
	}
	public String getBusinessTerm() {
		return businessTerm;
	}
	public void setBusinessTerm(String businessTerm) {
		this.businessTerm = businessTerm;
	}
	public String getBusinessDescription() {
		return businessDescription;
	}
	public void setBusinessDescription(String businessDescription) {
		this.businessDescription = businessDescription;
	}
	public String getCertified() {
		return certified;
	}
	public void setCertified(String certified) {
		this.certified = certified;
	}
	public String getPiiCols() {
		return piiCols;
	}
	public void setPiiCols(String piiCols) {
		this.piiCols = piiCols;
	}
	public String getCdeCol() {
		return cdeCol;
	}
	public void setCdeCol(String cdeCol) {
		this.cdeCol = cdeCol;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getDataLength() {
		return dataLength;
	}
	public void setDataLength(String dataLength) {
		this.dataLength = dataLength;
	}
	public String getDataLineage() {
		return dataLineage;
	}
	public void setDataLineage(String dataLineage) {
		this.dataLineage = dataLineage;
	}
	public String getDataXray() {
		return dataXray;
	}
	public void setDataXray(String dataXray) {
		this.dataXray = dataXray;
	}
	public String getDatabaseName() {
		return databaseName;
	}
	public void setDatabasName(String databaseName) {
		this.databaseName = databaseName;
	}
	public List<String> getGetters(FileData item) {
		List<String> filedata = new ArrayList<>();
		filedata.add(Integer.toString(item.getReqId()));
		if (null == item.getInstanceReqNo()) {
			filedata.add("null");
		} else {
			filedata.add(Integer.toString(item.getInstanceReqNo()));
		}
		filedata.add(item.getStatus());
		filedata.add(item.getItamId());
		filedata.add(item.getItamDescription());
		filedata.add(item.getAppName());
		filedata.add(item.getAppDescription());
		filedata.add(item.getCountry());
		filedata.add(item.getProductCategory());
		filedata.add(item.getDatabaseName());
		filedata.add(item.getTableName());
		filedata.add(item.getTableDescription());
		filedata.add(item.getColumnName());
		filedata.add(item.getColumnDescription());
		filedata.add(item.getBusinessTerm());
		filedata.add(item.getBusinessDescription());
		filedata.add(item.getCertified());
		filedata.add(item.getPiiCols());
		filedata.add(item.getCdeCol());
		filedata.add(item.getDataType());
		filedata.add(item.getDataLength());
		filedata.add(item.getDataLineage());
		filedata.add(item.getDataXray());
		
		return filedata;
	}
}